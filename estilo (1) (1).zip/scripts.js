function mudarPlanoFormulario(id, tooltiptext, comp){
	
	var alvo = document.getElementById(id);

	var tooltip = document.getElementById("tooltip");
	
	var comp =  document.getElementById(comp);

	tooltip.innerHTML = tooltiptext;

	if(alvo.style.backgroundImage == "")
	{
		tooltip.style.display = "";
		alvo.style.backgroundImage = "url('bkgbox2.gif')" ;
		
		comp.appendChild(tooltip);
		//alert(tooltip.offsetTop);
		tooltip.style.top = tooltip.offsetTop - 25; 
		//tooltip.style.position = 'relative';
	}
		else
	{
		//tooltip.style.display = "none";
		tooltip.style.top = 0;
		alvo.style.backgroundImage = "" ;
	}
}

function calcHeight()
{
  //find the height of the internal page
  var the_height=
    document.getElementById('iContent').contentWindow.
      document.body.scrollHeight;

  //change the height of the iframe
  document.getElementById('iContent').height=
      the_height;
}
function resizeFrame(obj){
	var paiFrame = document.body;
	var iframe =  parent.window.document.getElementById('iContent').childNodes[0];
	iframe.height = 400;
	iframe.height = paiFrame.scrollHeight;
}