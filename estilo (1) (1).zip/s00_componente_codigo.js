/*** Zen Module: s00_componente_codigo ***/

self._zenClassIdx['scsCompositeMVRepetidor'] = 's00_componente_codigo_scsCompositeMVRepetidor';
self.s00_componente_codigo_scsCompositeMVRepetidor = function(index,id) {
	if (index>=0) {s00_componente_codigo_scsCompositeMVRepetidor__init(this,index,id);}
}

self.s00_componente_codigo_scsCompositeMVRepetidor__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_control__init) ?zenMaster._ZEN_Component_control__init(o,index,id):_ZEN_Component_control__init(o,index,id);
	o.delimitador = '|';
	o.delimitadorAtr = '';
	o.delimitadorMV = '';
	o.delimitadorSV = '';
	o.scsAlign = '';
	o.scsAlignValorGrid = '';
	o.scsApresentaNumeracao = false;
	o.scsAtributoSubValue = '';
	o.scsCamposPersistencia = '';
	o.scsCaption = '';
	o.scsClassCabecalhoLinha = '';
	o.scsClassCabecalhoTabela = 'tabela';
	o.scsClassColuna = '';
	o.scsClassConteudoTabela = 'tabela';
	o.scsClassLinha = '';
	o.scsColunasPadrao = '';
	o.scsDisabled = '';
	o.scsDisplayList = '';
	o.scsEditable = '';
	o.scsEnclosingClass = '';
	o.scsEnclosingStyle = '';
	o.scsHidden = '';
	o.scsId = '';
	o.scsLabel = '';
	o.scsLabelGrid = '';
	o.scsLarguraColunaNumeracao = '0px';
	o.scsLarguraColunaPadrao = '16px';
	o.scsLarguraInternaComponente = '';
	o.scsLinhaSelecaoAnterior = '';
	o.scsLinhasIniciais = '';
	o.scsMaxlength = '';
	o.scsOnBlur = '';
	o.scsOnChange = '';
	o.scsOnClick = '';
	o.scsOnClickLinha = '';
	o.scsOnFocus = '';
	o.scsOnKeyDown = '';
	o.scsOnKeyPress = '';
	o.scsOnKeyUp = '';
	o.scsPosicaoIniciaBackground = '0';
	o.scsQtdCaracteresColunaGrid = '';
	o.scsReadOnly = '';
	o.scsSize = '';
	o.scsSql = '';
	o.scsSqlColuna = '';
	o.scsSqlConvCodigoPropriedade = '';
	o.scsSqlTabela = '';
	o.scsStringMV = '';
	o.scsStyleCabecalhoLinha = '';
	o.scsStyleCabecalhoTabela = '';
	o.scsStyleColuna = '';
	o.scsStyleConteudoTabela = '';
	o.scsStyleLinha = '';
	o.scsTipo = '';
	o.scsTiposObjetosPermitidos = 'scsCalendarData;scsTextInteiro';
	o.scsValue = '';
	o.scsValueList = '';
	o.scsWidth = '';
	o.scsWidthColunas = '';
}
function s00_componente_codigo_scsCompositeMVRepetidor_serialize(set,s)
{
	var o = this;s[0]='3669419288';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.clientType;s[9]=o.containerStyle;s[10]=o.controlClass;s[11]=o.controlStyle;s[12]=o.dataBinding;s[13]=o.delimitador;s[14]=o.delimitadorAtr;s[15]=o.delimitadorMV;s[16]=o.delimitadorSV;s[17]=(o.disabled?1:0);s[18]=(o.dragEnabled?1:0);s[19]=(o.dropEnabled?1:0);s[20]=(o.dynamic?1:0);s[21]=o.enclosingClass;s[22]=o.enclosingStyle;s[23]=o.error;s[24]=o.height;s[25]=(o.hidden?1:0);s[26]=o.hint;s[27]=o.hintClass;s[28]=o.hintStyle;s[29]=(o.invalid?1:0);s[30]=o.invalidMessage;s[31]=o.label;s[32]=o.labelClass;s[33]=o.labelDisabledClass;s[34]=o.labelStyle;s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onblur;s[38]=o.onchange;s[39]=o.onclick;s[40]=o.ondblclick;s[41]=o.ondrag;s[42]=o.ondrop;s[43]=o.onfocus;s[44]=o.onhide;s[45]=o.onkeydown;s[46]=o.onkeypress;s[47]=o.onkeyup;s[48]=o.onmousedown;s[49]=o.onmouseout;s[50]=o.onmouseover;s[51]=o.onmouseup;s[52]=o.onrefresh;s[53]=o.onshow;s[54]=o.onsubmit;s[55]=o.ontouchend;s[56]=o.ontouchmove;s[57]=o.ontouchstart;s[58]=o.onupdate;s[59]=o.onvalidate;s[60]=o.originalValue;s[61]=o.overlayMode;s[62]=(o.readOnly?1:0);s[63]=o.renderFlag;s[64]=(o.required?1:0);s[65]=o.requiredMessage;s[66]=o.scsAlign;s[67]=o.scsAlignValorGrid;s[68]=(o.scsApresentaNumeracao?1:0);s[69]=o.scsAtributoSubValue;s[70]=o.scsCamposPersistencia;s[71]=o.scsCaption;s[72]=o.scsClassCabecalhoLinha;s[73]=o.scsClassCabecalhoTabela;s[74]=o.scsClassColuna;s[75]=o.scsClassConteudoTabela;s[76]=o.scsClassLinha;s[77]=o.scsColunasPadrao;s[78]=o.scsDisabled;s[79]=o.scsDisplayList;s[80]=o.scsEditable;s[81]=o.scsEnclosingClass;s[82]=o.scsEnclosingStyle;s[83]=o.scsHidden;s[84]=o.scsId;s[85]=o.scsLabel;s[86]=o.scsLabelGrid;s[87]=o.scsLarguraColunaNumeracao;s[88]=o.scsLarguraColunaPadrao;s[89]=o.scsLarguraInternaComponente;s[90]=o.scsLinhaSelecaoAnterior;s[91]=o.scsLinhasIniciais;s[92]=o.scsMaxlength;s[93]=o.scsOnBlur;s[94]=o.scsOnChange;s[95]=o.scsOnClick;s[96]=o.scsOnClickLinha;s[97]=o.scsOnFocus;s[98]=o.scsOnKeyDown;s[99]=o.scsOnKeyPress;s[100]=o.scsOnKeyUp;s[101]=o.scsPosicaoIniciaBackground;s[102]=o.scsQtdCaracteresColunaGrid;s[103]=o.scsReadOnly;s[104]=o.scsSize;s[105]=o.scsSql;s[106]=o.scsSqlColuna;s[107]=o.scsSqlConvCodigoPropriedade;s[108]=o.scsSqlTabela;s[109]=o.scsStringMV;s[110]=o.scsStyleCabecalhoLinha;s[111]=o.scsStyleCabecalhoTabela;s[112]=o.scsStyleColuna;s[113]=o.scsStyleConteudoTabela;s[114]=o.scsStyleLinha;s[115]=o.scsTipo;s[116]=o.scsTiposObjetosPermitidos;s[117]=o.scsValue;s[118]=o.scsValueList;s[119]=o.scsWidth;s[120]=o.scsWidthColunas;s[121]=(o.showLabel?1:0);s[122]=o.slice;s[123]=o.tabIndex;s[124]=o.title;s[125]=o.tuple;s[126]=o.valign;s[127]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[128]=(o.visible?1:0);s[129]=o.width;
}
function s00_componente_codigo_scsCompositeMVRepetidor_getSettings(s)
{
	s['name'] = 'string';
	s['delimitador'] = 'string';
	s['delimitadorAtr'] = 'string';
	s['delimitadorMV'] = 'string';
	s['delimitadorSV'] = 'string';
	s['scsAlign'] = 'string';
	s['scsAlignValorGrid'] = 'string';
	s['scsApresentaNumeracao'] = 'boolean';
	s['scsAtributoSubValue'] = 'string';
	s['scsCamposPersistencia'] = 'string';
	s['scsCaption'] = 'string';
	s['scsClassCabecalhoLinha'] = 'string';
	s['scsClassCabecalhoTabela'] = 'string';
	s['scsClassColuna'] = 'string';
	s['scsClassConteudoTabela'] = 'string';
	s['scsClassLinha'] = 'string';
	s['scsColunasPadrao'] = 'string';
	s['scsDisabled'] = 'string';
	s['scsDisplayList'] = 'string';
	s['scsEditable'] = 'string';
	s['scsEnclosingClass'] = 'string';
	s['scsEnclosingStyle'] = 'string';
	s['scsHidden'] = 'string';
	s['scsId'] = 'string';
	s['scsLabel'] = 'string';
	s['scsLabelGrid'] = 'string';
	s['scsLarguraColunaNumeracao'] = 'string';
	s['scsLarguraColunaPadrao'] = 'string';
	s['scsLarguraInternaComponente'] = 'string';
	s['scsLinhaSelecaoAnterior'] = 'string';
	s['scsLinhasIniciais'] = 'string';
	s['scsMaxlength'] = 'string';
	s['scsOnBlur'] = 'string';
	s['scsOnChange'] = 'string';
	s['scsOnClick'] = 'string';
	s['scsOnClickLinha'] = 'string';
	s['scsOnFocus'] = 'string';
	s['scsOnKeyDown'] = 'string';
	s['scsOnKeyPress'] = 'string';
	s['scsOnKeyUp'] = 'string';
	s['scsPosicaoIniciaBackground'] = 'integer';
	s['scsQtdCaracteresColunaGrid'] = 'string';
	s['scsReadOnly'] = 'string';
	s['scsSize'] = 'string';
	s['scsSql'] = 'string';
	s['scsSqlColuna'] = 'string';
	s['scsSqlConvCodigoPropriedade'] = 'string';
	s['scsSqlTabela'] = 'string';
	s['scsStringMV'] = 'string';
	s['scsStyleCabecalhoLinha'] = 'string';
	s['scsStyleCabecalhoTabela'] = 'string';
	s['scsStyleColuna'] = 'string';
	s['scsStyleConteudoTabela'] = 'string';
	s['scsStyleLinha'] = 'string';
	s['scsTipo'] = 'string';
	s['scsTiposObjetosPermitidos'] = 'string';
	s['scsValue'] = 'string';
	s['scsValueList'] = 'string';
	s['scsWidth'] = 'string';
	s['scsWidthColunas'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_alterarCorLinha = function(pLinha) {
var componente = zenPage.getComponent(this.index);
if(this.scsLinhaSelecaoAnterior != "") {
var tempLinhaAnterior = this.scsLinhaSelecaoAnterior.split(";")
var numeroLinha = tempLinhaAnterior[0];
var corBackground = tempLinhaAnterior[1];
var aux = componente.id + "linhagrid" + numeroLinha
var obj = document.getElementById(aux);
if(obj) { obj.style.background = corBackground; }
}
var aux = componente.id + "linhagrid" + pLinha
var obj = document.getElementById(aux);
this.scsLinhaSelecaoAnterior = pLinha+";"+obj.style.background
obj.style.background = '#fbe091'
}

self.s00_componente_codigo_scsCompositeMVRepetidor_consultarRepetidor = function() {
var camposPersistentes = (this.scsCamposPersistencia).split(this.delimitador);
var qtdColunas = camposPersistentes.length;
var campoInterface = zenPage.getComponentById(camposPersistentes[0]).getValue();
var qtdLinhas = (campoInterface.split(this.delimitadorMV)).length;
var novaStr = "";
var coluna = 0;
var linha = 0;
for(coluna=0; coluna<qtdColunas; coluna++){ //colunas (atributosMV)
var valorCampo = zenPage.getComponentById(camposPersistentes[coluna]).getValue();
if (novaStr == "") {
novaStr = valorCampo
}else{
novaStr = novaStr + this.delimitadorAtr + valorCampo
}
}
this.scsStringMV = novaStr;
var retorno = this.DesenhaTabela();
}

self.s00_componente_codigo_scsCompositeMVRepetidor_recuperarRepetidor = function() {
var camposPersistentes = (this.scsCamposPersistencia).split(this.delimitador);
var qtdColunas = camposPersistentes.length;
var strComponente = (this.scsStringMV).split(this.delimitadorAtr);
var coluna = 0
for(coluna=0; coluna < qtdColunas; coluna++){ //colunas (atributosMV)
var valorColuna = strComponente[coluna];
var campoPersistente = camposPersistentes[coluna];
zenPage.getComponentById(campoPersistente).setProperty('value', valorColuna+"novo")
zenPage.getComponentById(campoPersistente).onchangeHandler();
}
}

self.s00_componente_codigo_scsCompositeMVRepetidor_renderContents = function() {
var componente = zenPage.getComponent(this.index);
var retorno = componente.RenderRepetidor();
}

self.s00_componente_codigo_scsCompositeMVRepetidor_AdicionaObjetosZen = function() {
	return zenInstanceMethod(this,'AdicionaObjetosZen','','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_AdicionarItemRepetidorAjax = function(pAntesLinha,pLinhaEspecifica,pAtualizaLinha) {
	return zenInstanceMethod(this,'AdicionarItemRepetidorAjax','L,L,B','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_AdicionarSvRepetidorAjax = function(pAtributoSv,pAtributo,pMultivalue) {
	return zenInstanceMethod(this,'AdicionarSvRepetidorAjax','L,L,L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_AjustaLarguraComponente = function(pQtdLinhas) {
	return zenInstanceMethod(this,'AjustaLarguraComponente','L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_AtualizaControlesLinhas = function(pLinha) {
	return zenInstanceMethod(this,'AtualizaControlesLinhas','L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_AtualizaValorRepetidor = function(pValor,pLinha,pColuna,pSubValue) {
	return zenInstanceMethod(this,'AtualizaValorRepetidor','L,L,L,L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_AtualizaValorRepetidorAjax = function(pValor,pLinha,pColuna,pSubValor,pAtualiza) {
	return zenInstanceMethod(this,'AtualizaValorRepetidorAjax','L,L,L,L,B','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_CriaObjeto = function(pTipo) {
	return zenInstanceMethod(this,'CriaObjeto','L','HANDLE',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_DesenhaBackground = function() {
	return zenInstanceMethod(this,'DesenhaBackground','','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_DesenhaColunaPadrao = function(pTipoColuna,pMetodo,pLinha,pColuna) {
	return zenInstanceMethod(this,'DesenhaColunaPadrao','L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_DesenhaLinha = function(pLinha,matrizObjetosZen) {
	return zenInstanceMethod(this,'DesenhaLinha','L,L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_DesenhaLinhaAjax = function(pLinha) {
	return zenInstanceMethod(this,'DesenhaLinhaAjax','L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_DesenhaRepetidorColunaHtml = function(pTipoCampo,pColuna,pValorCampo,pLinha,matrizObjetosZen) {
	return zenInstanceMethod(this,'DesenhaRepetidorColunaHtml','L,L,L,L,L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_DesenhaTabela = function() {
	return zenInstanceMethod(this,'DesenhaTabela','','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_ExcluirItemRepetidor = function(pLinha) {
	return zenInstanceMethod(this,'ExcluirItemRepetidor','L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_ExcluirItemRepetidorAjax = function(pLinha) {
	return zenInstanceMethod(this,'ExcluirItemRepetidorAjax','L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_ExcluirSvRepetidor = function(pAtributo,pMultivalue,pSubValue) {
	return zenInstanceMethod(this,'ExcluirSvRepetidor','L,L,L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_ExcluirSvRepetidorAjax = function(pAtributoSv,pAtributo,pMultivalue,pSubValue) {
	return zenInstanceMethod(this,'ExcluirSvRepetidorAjax','L,L,L,L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_InsereValorRepetidor = function(pValor,pLinha,pColuna) {
	return zenInstanceMethod(this,'InsereValorRepetidor','L,L,L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_InsereValorRepetidorAjax = function(pCol1,pCol2,pCol3,pCol4,pCol5,pCol6,pCol7,pCol8,pCol9,pCol10,pCol11,pCol12,pCol13,pCol14,pCol15,pCol16,pCol17,pCol18,pCol19,pCol20) {
	return zenInstanceMethod(this,'InsereValorRepetidorAjax','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_PreparaObjetosZen = function() {
	return zenInstanceMethod(this,'PreparaObjetosZen','','HANDLE',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_PreparaObjetosZenLinha = function(pLinha) {
	return zenInstanceMethod(this,'PreparaObjetosZenLinha','L','HANDLE',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_QtdColunas = function() {
	return zenInstanceMethod(this,'QtdColunas','','INTEGER',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_QtdLinhas = function() {
	return zenInstanceMethod(this,'QtdLinhas','','INTEGER',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_RenderRepetidor = function() {
	return zenInstanceMethod(this,'RenderRepetidor','','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_RetornaValorRepetidor = function(pLinha,pColuna,pSubValor) {
	return zenInstanceMethod(this,'RetornaValorRepetidor','L,L,L','VARCHAR',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_UtilizaObjetosZen = function() {
	return zenInstanceMethod(this,'UtilizaObjetosZen','','BOOLEAN',arguments);
}

self.s00_componente_codigo_scsCompositeMVRepetidor_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente_codigo_scsCompositeMVRepetidor__Loader = function() {
	zenLoadClass('_ZEN_Component_control');
	s00_componente_codigo_scsCompositeMVRepetidor.prototype = zenCreate('_ZEN_Component_control',-1);
	var p = s00_componente_codigo_scsCompositeMVRepetidor.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_codigo_scsCompositeMVRepetidor;
	p.superClass = ('undefined' == typeof _ZEN_Component_control) ? zenMaster._ZEN_Component_control.prototype:_ZEN_Component_control.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.codigo.scsCompositeMVRepetidor';
	p._type = 'scsCompositeMVRepetidor';
	p.serialize = s00_componente_codigo_scsCompositeMVRepetidor_serialize;
	p.getSettings = s00_componente_codigo_scsCompositeMVRepetidor_getSettings;
	p.AdicionaObjetosZen = s00_componente_codigo_scsCompositeMVRepetidor_AdicionaObjetosZen;
	p.AdicionarItemRepetidorAjax = s00_componente_codigo_scsCompositeMVRepetidor_AdicionarItemRepetidorAjax;
	p.AdicionarSvRepetidorAjax = s00_componente_codigo_scsCompositeMVRepetidor_AdicionarSvRepetidorAjax;
	p.AjustaLarguraComponente = s00_componente_codigo_scsCompositeMVRepetidor_AjustaLarguraComponente;
	p.AjustaTamanhoValor = s00_componente_codigo_scsCompositeMVRepetidor_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente_codigo_scsCompositeMVRepetidor_ApresentaExcecao;
	p.AtualizaControlesLinhas = s00_componente_codigo_scsCompositeMVRepetidor_AtualizaControlesLinhas;
	p.AtualizaValorRepetidor = s00_componente_codigo_scsCompositeMVRepetidor_AtualizaValorRepetidor;
	p.AtualizaValorRepetidorAjax = s00_componente_codigo_scsCompositeMVRepetidor_AtualizaValorRepetidorAjax;
	p.CriaObjeto = s00_componente_codigo_scsCompositeMVRepetidor_CriaObjeto;
	p.DesenhaBackground = s00_componente_codigo_scsCompositeMVRepetidor_DesenhaBackground;
	p.DesenhaColunaPadrao = s00_componente_codigo_scsCompositeMVRepetidor_DesenhaColunaPadrao;
	p.DesenhaLinha = s00_componente_codigo_scsCompositeMVRepetidor_DesenhaLinha;
	p.DesenhaLinhaAjax = s00_componente_codigo_scsCompositeMVRepetidor_DesenhaLinhaAjax;
	p.DesenhaRepetidorColunaHtml = s00_componente_codigo_scsCompositeMVRepetidor_DesenhaRepetidorColunaHtml;
	p.DesenhaTabela = s00_componente_codigo_scsCompositeMVRepetidor_DesenhaTabela;
	p.ExcluirItemRepetidor = s00_componente_codigo_scsCompositeMVRepetidor_ExcluirItemRepetidor;
	p.ExcluirItemRepetidorAjax = s00_componente_codigo_scsCompositeMVRepetidor_ExcluirItemRepetidorAjax;
	p.ExcluirSvRepetidor = s00_componente_codigo_scsCompositeMVRepetidor_ExcluirSvRepetidor;
	p.ExcluirSvRepetidorAjax = s00_componente_codigo_scsCompositeMVRepetidor_ExcluirSvRepetidorAjax;
	p.GeraCheckBoxHtml = s00_componente_codigo_scsCompositeMVRepetidor_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente_codigo_scsCompositeMVRepetidor_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente_codigo_scsCompositeMVRepetidor_GeraRadioHtml;
	p.GeraSV1Label = s00_componente_codigo_scsCompositeMVRepetidor_GeraSV1Label;
	p.GeraSV1Text = s00_componente_codigo_scsCompositeMVRepetidor_GeraSV1Text;
	p.GeraSelectHtml = s00_componente_codigo_scsCompositeMVRepetidor_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente_codigo_scsCompositeMVRepetidor_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente_codigo_scsCompositeMVRepetidor_GeraTextHtml;
	p.GetValorPropriedade = s00_componente_codigo_scsCompositeMVRepetidor_GetValorPropriedade;
	p.InsereValorRepetidor = s00_componente_codigo_scsCompositeMVRepetidor_InsereValorRepetidor;
	p.InsereValorRepetidorAjax = s00_componente_codigo_scsCompositeMVRepetidor_InsereValorRepetidorAjax;
	p.LimpaComponente = s00_componente_codigo_scsCompositeMVRepetidor_LimpaComponente;
	p.PreparaObjetosZen = s00_componente_codigo_scsCompositeMVRepetidor_PreparaObjetosZen;
	p.PreparaObjetosZenLinha = s00_componente_codigo_scsCompositeMVRepetidor_PreparaObjetosZenLinha;
	p.QtdColunas = s00_componente_codigo_scsCompositeMVRepetidor_QtdColunas;
	p.QtdLinhas = s00_componente_codigo_scsCompositeMVRepetidor_QtdLinhas;
	p.ReallyRefreshContents = s00_componente_codigo_scsCompositeMVRepetidor_ReallyRefreshContents;
	p.RenderRepetidor = s00_componente_codigo_scsCompositeMVRepetidor_RenderRepetidor;
	p.RetornaValorCampo = s00_componente_codigo_scsCompositeMVRepetidor_RetornaValorCampo;
	p.RetornaValorRepetidor = s00_componente_codigo_scsCompositeMVRepetidor_RetornaValorRepetidor;
	p.SetValorPropriedade = s00_componente_codigo_scsCompositeMVRepetidor_SetValorPropriedade;
	p.UtilizaObjetosZen = s00_componente_codigo_scsCompositeMVRepetidor_UtilizaObjetosZen;
	p.VerificaErro = s00_componente_codigo_scsCompositeMVRepetidor_VerificaErro;
	p.alterarCorLinha = s00_componente_codigo_scsCompositeMVRepetidor_alterarCorLinha;
	p.consultarRepetidor = s00_componente_codigo_scsCompositeMVRepetidor_consultarRepetidor;
	p.recuperarRepetidor = s00_componente_codigo_scsCompositeMVRepetidor_recuperarRepetidor;
	p.renderContents = s00_componente_codigo_scsCompositeMVRepetidor_renderContents;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsTablePane'] = 's00_componente_codigo_scsTablePane';
self.s00_componente_codigo_scsTablePane = function(index,id) {
	if (index>=0) {s00_componente_codigo_scsTablePane__init(this,index,id);}
}

self.s00_componente_codigo_scsTablePane__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_tablePane__init) ?zenMaster._ZEN_Component_tablePane__init(o,index,id):_ZEN_Component_tablePane__init(o,index,id);
	o.OnCreateResultSet = ''; // encrypted
	o.OnExecuteResultSet = ''; // encrypted
	o.columnName = '';
	o.countRows = '0';
	o.groupByClause = '';
	o.invalidMessage = 'Invalid Date';
	o.maxRows = '100';
	o.msgNoResult = 'No Results';
	o.orderByClause = '';
	o.queryClass = ''; // encrypted
	o.queryName = '';
	o.sql = ''; // encrypted
	o.tableName = ''; // encrypted
	o.whereClause = '';
}
function s00_componente_codigo_scsTablePane_serialize(set,s)
{
	var o = this;s[0]='1035744322';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.OnCreateResultSet;s[7]=o.OnExecuteResultSet;s[8]=o.align;s[9]=(o.autoExecute?1:0);s[10]=o.aux;s[11]=o.bodyHeight;s[12]=o.caption;s[13]=o.cellSpacing;s[14]=(o.clearSnapshot?1:0);s[15]=o.columnName;s[16]=set.serializeList(o,o.columns,true,'columns');s[17]=set.serializeList(o,o.conditions,true,'conditions');s[18]=o.containerStyle;s[19]=o.countRows;s[20]=o.currColumn;s[21]=o.currPage;s[22]=o.dataSource;s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=(o.enableToggleSelect?1:0);s[27]=o.enclosingClass;s[28]=o.enclosingStyle;s[29]=o.error;s[30]=o.extraColumnWidth;s[31]=(o.filtersDisabled?1:0);s[32]=(o.fixedHeaders?1:0);s[33]=o.groupByClause;s[34]=(o.hasFocus?1:0);s[35]=o.headerLayout;s[36]=o.height;s[37]=(o.hidden?1:0);s[38]=o.hint;s[39]=o.hintClass;s[40]=o.hintStyle;s[41]=(o.initialExecute?1:0);s[42]=o.invalidMessage;s[43]=o.label;s[44]=o.labelClass;s[45]=o.labelDisabledClass;s[46]=o.labelStyle;s[47]=o.lastFilter;s[48]=o.lastUpdate;s[49]=o.maxRows;s[50]=o.msgNoResult;s[51]=(o.multiSelect?1:0);s[52]=(o.nowrap?1:0);s[53]=o.onafterdrag;s[54]=o.onbeforedrag;s[55]=o.ondblclick;s[56]=o.ondrag;s[57]=o.ondrop;s[58]=o.onheaderClick;s[59]=o.onhide;s[60]=o.onkeypress;s[61]=o.onmouseoverClass;s[62]=o.onmultiselect;s[63]=o.onrefresh;s[64]=o.onselectrow;s[65]=o.onshow;s[66]=o.onunselectrow;s[67]=o.onupdate;s[68]=o.orderByClause;s[69]=o.overlayMode;s[70]=o.pageSize;s[71]=set.serializeList(o,o.parameters,true,'parameters');s[72]=o.queryClass;s[73]=o.queryName;s[74]=(o.refreshRequired?1:0);s[75]=o.renderFlag;s[76]=o.rowCount;s[77]=(o.rowSelect?1:0);s[78]=o.selectedIndex;s[79]=o.selectedRows;s[80]=(o.showFilters?1:0);s[81]=(o.showLabel?1:0);s[82]=o.showQuery;s[83]=(o.showRowNumbers?1:0);s[84]=(o.showRowSelector?1:0);s[85]=(o.showValueInTooltip?1:0);s[86]=(o.showZebra?1:0);s[87]=o.slice;s[88]=o.snapshotId;s[89]=o.sortOrder;s[90]=o.sql;s[91]=o.tableName;s[92]=o.title;s[93]=o.tuple;s[94]=(o.unlockSession?1:0);s[95]=(o.useKeys?1:0);s[96]=(o.useSnapshot?1:0);s[97]=o.valign;s[98]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[99]=o.valueColumn;s[100]=(o.visible?1:0);s[101]=o.whereClause;s[102]=o.width;
}
function s00_componente_codigo_scsTablePane_getSettings(s)
{
	s['name'] = 'string';
	s['columnName'] = 'string';
	s['countRows'] = 'integer';
	s['groupByClause'] = 'string';
	s['maxRows'] = 'integer';
	s['orderByClause'] = 'string';
	s['queryClass'] = 'className';
	s['queryName'] = 'classMember:QUERY';
	s['sql'] = 'sql';
	s['tableName'] = 'string';
	s['whereClause'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_codigo_scsTablePane_packRows = function() {
if (this.hidden) return;
if (zenIsIE) {
this.packRowsIE();
} else {
/* Início Personalizacao Shift */
if (!this.bodyHeight) return; // If it wasn't set, this isn't an issue
if (this.fixedHeaders == false) return;
if (!navigator) return; // Should never be true in a runtime situation
var isWebkit=(navigator.userAgent.indexOf("WebKit")>=0);
var isFF3=(navigator.userAgent.indexOf("Firefox")>=0);
if (!(isFF3 || isWebkit)) return; // Either early Firefox or unsupported platform
var eDiv=this.getEnclosingDiv();
if (eDiv.offsetWidth==0 || eDiv.offsetHeight==0) return; // Not yet visible
var tHead = document.getElementById("tpHead_"+this.index)
var tbody = document.getElementById("tpBody_"+this.index)
if((tbody.offsetHeight >= tbody.children[0].offsetHeight) || (navigator.userAgent.match(/iPad/i))) {
for(var i=0;i<tHead.children.length;i++) {
tHead.children[i].lastElementChild.style.width = "0px"
tHead.children[i].lastElementChild.style.display = "none"
}
} else {
for(var i=0;i<tHead.children.length;i++) {
tHead.children[i].lastElementChild.style.width = "12px"
tHead.children[i].lastElementChild.style.display = ""
}
}
var firstTr = new Object()
if((this.fixedHeaders!=false) && (tbody.children[0].children[0].children[0].children[0].className != "tpNoResults")) {
firstTr = tbody.children[0].children[0].children[0]
for(var j=0; j<firstTr.children.length; j++) {
var wBorder = parseInt(window.getComputedStyle(tHead.children[0].children[j],null).borderWidth)
var lPadding = parseInt(window.getComputedStyle(tHead.children[0].children[j],null).paddingLeft)
var rPadding = parseInt(window.getComputedStyle(tHead.children[0].children[j],null).paddingRight)
if(!isWebkit) {
tHead.children[0].children[j].width = parseInt(window.getComputedStyle(firstTr.children[j],null).width) - wBorder - lPadding - rPadding - 1 + "px";
tHead.children[0].children[j].style.width = parseInt(window.getComputedStyle(firstTr.children[j],null).width) + "px";
} else {
tHead.children[0].children[j].style.width = parseInt(window.getComputedStyle(firstTr.children[j],null).width) - wBorder - lPadding - rPadding - 1 + "px";
}
}
}
/* Final Personalizacao Shift*/
}
return;
/*
var tDiv=this.findElement("tpTable"); // used to be eDiv.firstChild;
var tHead=this.findElement("tpHead");
var tBody=this.findElement("tpBody");
if (isFF3) { // Wants to spread rows
var oldBodyH=tBody.offsetHeight;
if (!eDiv.forcedHeight) eDiv.baseHeight=eDiv.style.height;
eDiv.style.height=eDiv.clientHeight+"px";
tBody.style.height="";
eDiv.forcedHeight=true;
if (tBody.offsetHeight>oldBodyH) { // no correction needed, revert settings
var h="20.0em";
if (this.bodyHeight) h=this.bodyHeight;
tBody.style.height=h;
eDiv.style.height=eDiv.baseHeight;
eDiv.forcedHeight=false;
}
}
else { // Webkit shortens the table height to match the rows
if (!eDiv.targetBodyHeight) {
var h="20.0em";
if (this.bodyHeight) h=this.bodyHeight;
var tmp=document.createElement("DIV");
tmp.style.position="absolute";
tmp.style.height=h;
tmp.style.display="block";
document.body.appendChild(tmp);
eDiv.targetBodyHeight=tmp.clientHeight;
document.body.removeChild(tmp);
}
if (tBody.clientHeight<eDiv.targetBodyHeight) {
if (!eDiv.forcedHeight) {
eDiv.baseHeight=eDiv.style.height;
eDiv.forcedHeight=true;
var h=eDiv.clientHeight+eDiv.targetBodyHeight-tBody.clientHeight;
eDiv.style.height=h+"px";
}
}
else if (eDiv.forcedHeight) {
eDiv.style.height=eDiv.baseHeight;
eDiv.forcedHeight=false;
}
}*/
}

self.s00_componente_codigo_scsTablePane_FetchRowFromSnapshot = function(pIndex,pID,pRow,pCurrColumn,pSortOrder) {
	return zenClassMethod(this,'FetchRowFromSnapshot','L,L,L,L,L','BOOLEAN',arguments);
}

self.s00_componente_codigo_scsTablePane_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_codigo_scsTablePane__Loader = function() {
	zenLoadClass('_ZEN_Component_tablePane');
	s00_componente_codigo_scsTablePane.prototype = zenCreate('_ZEN_Component_tablePane',-1);
	var p = s00_componente_codigo_scsTablePane.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_codigo_scsTablePane;
	p.superClass = ('undefined' == typeof _ZEN_Component_tablePane) ? zenMaster._ZEN_Component_tablePane.prototype:_ZEN_Component_tablePane.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.codigo.scsTablePane';
	p._type = 'scsTablePane';
	p.serialize = s00_componente_codigo_scsTablePane_serialize;
	p.getSettings = s00_componente_codigo_scsTablePane_getSettings;
	p.FetchRowFromSnapshot = s00_componente_codigo_scsTablePane_FetchRowFromSnapshot;
	p.ReallyRefreshContents = s00_componente_codigo_scsTablePane_ReallyRefreshContents;
	p.packRows = s00_componente_codigo_scsTablePane_packRows;
}
/* EOF */