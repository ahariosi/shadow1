#!/bin/bash

#Arquivos da Instancia 01 = /binario
#Arquivos da Instancia 02 = /binario1
ULTIMO_ARQUIVO=`ls -t /binario/cache/mgr/Backup/FullDBList* | head -1`
DATA=`date +%d/%m/%y`
HORA_INICIAL=`cat $ULTIMO_ARQUIVO | grep '*** The time is:' | awk '{print $6}' | cut -d: -f 1,2`
HORA_FINAL=`cat $ULTIMO_ARQUIVO | grep 'Backup pass 3 complete at' | awk '{print $7}' | cut -d: -f 1,2`
RESULTADO=`cat $ULTIMO_ARQUIVO | grep '***FINISHED BACKUP***'`
ESPERADO="***FINISHED BACKUP***"
ARQ_SAIDA="/opt/scripts/auxiliar/01/meio.html"
DIA_PRIMEIRO="01"
DATA_ATUAL=`date +%d`
VERIFICA_INTEGRIDADE="/opt/scripts/auxiliar/01/verificacao_arquivo.conf"

#Carrega variavel onde está armazenado o ultimo backup executado
source $VERIFICA_INTEGRIDADE


#Verifica se é o primeiro dia do mes, se for, apaga o conteudo do arquivo meio.html, para inicio de um novo mes.
if [ "$DATA_ATUAL" == "$DIA_PRIMEIRO" ]
then
	echo -n > $ARQ_SAIDA
fi

#Verifica se a rotina roudou no dia anterior, se sim, realiza o backup, se nao, falhas foram encontradas e a rotina nem rodou
if [ "$ULTIMO_ARQUIVO" != "$ULTIMO_BACKUP_REALIZADO" ]
then
        if [ "$RESULTADO" == "$ESPERADO" ]
	then
      		
		echo '<tr style="height: 26px;">' >> $ARQ_SAIDA
		echo '<td style="background-color: green; height: 26px; text-align: center;">&nbsp; &nbsp; &nbsp;&nbsp;</td>' >> $ARQ_SAIDA
		echo '<td style="height: 26px; text-align: left;">&nbsp;&nbsp;</td>' >> $ARQ_SAIDA
		echo '<td style="height: 26px; text-align: left;">Rotina de Backup Executada com Exito</td>' >> $ARQ_SAIDA
		echo '<td style="text-align: center; height: 26px;">&nbsp;&nbsp;</td>' >> $ARQ_SAIDA
		echo '<td style="text-align: center; height: 26px;">'$DATA'</td>' >> $ARQ_SAIDA
		echo '<td style="text-align: center; height: 26px;">&nbsp;&nbsp;</td>' >> $ARQ_SAIDA
		echo '<td style="text-align: center; height: 26px;">'$HORA_INICIAL'</td>' >> $ARQ_SAIDA
		echo '<td style="text-align: center; height: 27px;">&nbsp;</td>' >> $ARQ_SAIDA
		echo '<td style="text-align: center; height: 26px;">'$HORA_FINAL'</td>' >> $ARQ_SAIDA
		echo '</tr>' >> $ARQ_SAIDA
		
		#Altera o a variavel de ultimo backup realizado
		echo "ULTIMO_BACKUP_REALIZADO="$ULTIMO_ARQUIVO"" > $VERIFICA_INTEGRIDADE

	else

		echo '<tr style="height: 26px;">' >> $ARQ_SAIDA
		echo '<td style="background-color: yellow; height: 26px; text-align: center;">&nbsp;</td>' >> $ARQ_SAIDA
		echo '<td style="height: 26px; text-align: left;">&nbsp;&nbsp;</td>' >> $ARQ_SAIDA
		echo '<td style="height: 26px; text-align: left;">Rotina de Backup Concluida com Falhas</td>' >> $ARQ_SAIDA
		echo '<td style="text-align: center; height: 26px;">&nbsp;&nbsp;</td>' >> $ARQ_SAIDA
		echo '<td style="text-align: center; height: 26px;">'$DATA'</td>' >> $ARQ_SAIDA
		echo '<td style="text-align: center; height: 26px;">&nbsp;&nbsp;</td>' >> $ARQ_SAIDA
		echo '<td style="text-align: center; height: 26px;">'$HORA_INICIAL'</td>' >> $ARQ_SAIDA
		echo '<td style="text-align: center; height: 27px;">&nbsp;</td>' >> $ARQ_SAIDA
		echo '<td style="text-align: center; height: 26px;">'$HORA_FINAL'</td>' >> $ARQ_SAIDA
		echo '</tr>' >> $ARQ_SAIDA

		#Altera o a variavel de ultimo backup realizado
                echo "ULTIMO_BACKUP_REALIZADO="$ULTIMO_ARQUIVO"" > $VERIFICA_INTEGRIDADE

	fi
else
	echo '<tr style="height: 26px;">' >> $ARQ_SAIDA
	echo '<td style="background-color: red; height: 26px; text-align: center;">&nbsp; &nbsp; &nbsp;&nbsp;</td>' >> $ARQ_SAIDA
	echo '<td style="height: 26px; text-align: left;">&nbsp;&nbsp;</td>' >> $ARQ_SAIDA
	echo '<td style="height: 26px; text-align: left;">Rotina de Backup nao Executada</td>' >> $ARQ_SAIDA
	echo '<td style="text-align: center; height: 26px;">&nbsp;&nbsp;</td>' >> $ARQ_SAIDA
	echo '<td style="text-align: center; height: 26px;">'$DATA'</td>' >> $ARQ_SAIDA
	echo '<td style="text-align: center; height: 26px;">&nbsp;&nbsp;</td>' >> $ARQ_SAIDA
	echo '<td style="text-align: center; height: 26px;">'N/A'</td>' >> $ARQ_SAIDA
	echo '<td style="text-align: center; height: 27px;">&nbsp;</td>' >> $ARQ_SAIDA
	echo '<td style="text-align: center; height: 26px;">'N/A'</td>' >> $ARQ_SAIDA
	echo '</tr>' >> $ARQ_SAIDA
fi

#Montagem do E-mail
echo -n > /opt/scripts/auxiliar/01/backup.html
cat /opt/scripts/auxiliar/01/inicio.html >> /opt/scripts/auxiliar/01/backup.html
cat /opt/scripts/auxiliar/01/meio.html >> /opt/scripts/auxiliar/01/backup.html
cat /opt/scripts/auxiliar/01/fim.html >> /opt/scripts/auxiliar/01/backup.html

#Falata enviar e-mail agora

ENVIA_EMAIL="/opt/sendEmail/sendEmail"
SMTP_MAIL_FROM=alerta@shift.com.br
MAIL_TO="tecnologia@nabucolopes.com.br, tecnologia@shift.com.br"
ASSUNTO="Resumo da rotina de backup servidor DB-PROD-NABUCOLOPES"
PARAMETROS_CORPO="message-content-type=html message-charset=iso-8859-1 message-file="
CORPO_MAIL="/opt/scripts/auxiliar/01/backup.html"
SMTP_SERVER=smtp.office365.com:587
SMTP_LOGIN=alerta@shift.com.br
SMTP_PASSWD=2xRKx5Ko1fOq5G4v

$ENVIA_EMAIL -o tls=yes -f $SMTP_MAIL_FROM -t $MAIL_TO -u $ASSUNTO -m -o message-content-type=html message-charset=iso-8859-1 message-file=$CORPO_MAIL -s $SMTP_SERVER -xu $SMTP_LOGIN -xp $SMTP_PASSWD

