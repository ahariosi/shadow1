/*** Zen Module: s00_componente2_codigo ***/

self._zenClassIdx['scsTablePane'] = 's00_componente2_codigo_scsTablePane';
self.s00_componente2_codigo_scsTablePane = function(index,id) {
	if (index>=0) {s00_componente2_codigo_scsTablePane__init(this,index,id);}
}

self.s00_componente2_codigo_scsTablePane__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_tablePane__init) ?zenMaster._ZEN_Component_tablePane__init(o,index,id):_ZEN_Component_tablePane__init(o,index,id);
	o.OnCreateResultSet = ''; // encrypted
	o.OnExecuteResultSet = ''; // encrypted
	o.columnName = '';
	o.countRows = '0';
	o.groupByClause = '';
	o.invalidMessage = 'Invalid Date';
	o.maxRows = '100';
	o.msgNoResult = 'No Results';
	o.orderByClause = '';
	o.queryClass = ''; // encrypted
	o.queryName = '';
	o.sql = ''; // encrypted
	o.tableName = ''; // encrypted
	o.whereClause = '';
}
function s00_componente2_codigo_scsTablePane_serialize(set,s)
{
	var o = this;s[0]='1035744322';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.OnCreateResultSet;s[7]=o.OnExecuteResultSet;s[8]=o.align;s[9]=(o.autoExecute?1:0);s[10]=o.aux;s[11]=o.bodyHeight;s[12]=o.caption;s[13]=o.cellSpacing;s[14]=(o.clearSnapshot?1:0);s[15]=o.columnName;s[16]=set.serializeList(o,o.columns,true,'columns');s[17]=set.serializeList(o,o.conditions,true,'conditions');s[18]=o.containerStyle;s[19]=o.countRows;s[20]=o.currColumn;s[21]=o.currPage;s[22]=o.dataSource;s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=(o.enableToggleSelect?1:0);s[27]=o.enclosingClass;s[28]=o.enclosingStyle;s[29]=o.error;s[30]=o.extraColumnWidth;s[31]=(o.filtersDisabled?1:0);s[32]=(o.fixedHeaders?1:0);s[33]=o.groupByClause;s[34]=(o.hasFocus?1:0);s[35]=o.headerLayout;s[36]=o.height;s[37]=(o.hidden?1:0);s[38]=o.hint;s[39]=o.hintClass;s[40]=o.hintStyle;s[41]=(o.initialExecute?1:0);s[42]=o.invalidMessage;s[43]=o.label;s[44]=o.labelClass;s[45]=o.labelDisabledClass;s[46]=o.labelStyle;s[47]=o.lastFilter;s[48]=o.lastUpdate;s[49]=o.maxRows;s[50]=o.msgNoResult;s[51]=(o.multiSelect?1:0);s[52]=(o.nowrap?1:0);s[53]=o.onafterdrag;s[54]=o.onbeforedrag;s[55]=o.ondblclick;s[56]=o.ondrag;s[57]=o.ondrop;s[58]=o.onheaderClick;s[59]=o.onhide;s[60]=o.onkeypress;s[61]=o.onmouseoverClass;s[62]=o.onmultiselect;s[63]=o.onrefresh;s[64]=o.onselectrow;s[65]=o.onshow;s[66]=o.onunselectrow;s[67]=o.onupdate;s[68]=o.orderByClause;s[69]=o.overlayMode;s[70]=o.pageSize;s[71]=set.serializeList(o,o.parameters,true,'parameters');s[72]=o.queryClass;s[73]=o.queryName;s[74]=(o.refreshRequired?1:0);s[75]=o.renderFlag;s[76]=o.rowCount;s[77]=(o.rowSelect?1:0);s[78]=o.selectedIndex;s[79]=o.selectedRows;s[80]=(o.showFilters?1:0);s[81]=(o.showLabel?1:0);s[82]=o.showQuery;s[83]=(o.showRowNumbers?1:0);s[84]=(o.showRowSelector?1:0);s[85]=(o.showValueInTooltip?1:0);s[86]=(o.showZebra?1:0);s[87]=o.slice;s[88]=o.snapshotId;s[89]=o.sortOrder;s[90]=o.sql;s[91]=o.tableName;s[92]=o.title;s[93]=o.tuple;s[94]=(o.unlockSession?1:0);s[95]=(o.useKeys?1:0);s[96]=(o.useSnapshot?1:0);s[97]=o.valign;s[98]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[99]=o.valueColumn;s[100]=(o.visible?1:0);s[101]=o.whereClause;s[102]=o.width;
}
function s00_componente2_codigo_scsTablePane_getSettings(s)
{
	s['name'] = 'string';
	s['columnName'] = 'string';
	s['countRows'] = 'integer';
	s['groupByClause'] = 'string';
	s['maxRows'] = 'integer';
	s['orderByClause'] = 'string';
	s['queryClass'] = 'className';
	s['queryName'] = 'classMember:QUERY';
	s['sql'] = 'sql';
	s['tableName'] = 'string';
	s['whereClause'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente2_codigo_scsTablePane_onDisplayHandler = function() {
if (this.findElement("tpBody")) {
this.resizeHeaders();
}
}

self.s00_componente2_codigo_scsTablePane_onloadHandler = function() {
if (this.findElement("tpBody")) {
this.resizeHeaders();
}
var index = this.selectedIndex;
this.selectedIndex = -1;
this.selectRow(index,false);
}

self.s00_componente2_codigo_scsTablePane_resizeHeaders = function() {
var enc = this.getEnclosingDiv();
enc.style.width = '';
if(enc.style.width != '') return 1
var tpHead = $(enc).find('.tpTable')[0];
var tpBody = $(enc).find('.tpBodyFixed')[0];
var tpAux = $(enc).find('.tpAuxColumn')[0]
var clientW = tpBody.clientWidth;
var larguraRolagem = tpBody.offsetWidth - clientW;
var alturaCabecalho = $(enc).find('thead')[0].offsetHeight;
if(larguraRolagem > 0) {
tpBody.style.marginRight = larguraRolagem*(-1) + 'px';
enc.style.marginRight = larguraRolagem + 'px';
tpAux.style.right = larguraRolagem*(-1) + 'px';
tpAux.style.width = larguraRolagem + 'px';
if(alturaCabecalho > 0) {
tpAux.style.height = alturaCabecalho + 'px';
}
}
if(clientW > 0) {
tpHead.style.width = enc.offsetWidth + 'px';
tpBody.children[0].style.width = enc.offsetWidth + 'px';
}
return 1;
}

self.s00_componente2_codigo_scsTablePane_FetchRowFromSnapshot = function(pIndex,pID,pRow,pCurrColumn,pSortOrder) {
	return zenClassMethod(this,'FetchRowFromSnapshot','L,L,L,L,L','BOOLEAN',arguments);
}

self.s00_componente2_codigo_scsTablePane_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente2_codigo_scsTablePane__Loader = function() {
	zenLoadClass('_ZEN_Component_tablePane');
	s00_componente2_codigo_scsTablePane.prototype = zenCreate('_ZEN_Component_tablePane',-1);
	var p = s00_componente2_codigo_scsTablePane.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente2_codigo_scsTablePane;
	p.superClass = ('undefined' == typeof _ZEN_Component_tablePane) ? zenMaster._ZEN_Component_tablePane.prototype:_ZEN_Component_tablePane.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente2.codigo.scsTablePane';
	p._type = 'scsTablePane';
	p.serialize = s00_componente2_codigo_scsTablePane_serialize;
	p.getSettings = s00_componente2_codigo_scsTablePane_getSettings;
	p.FetchRowFromSnapshot = s00_componente2_codigo_scsTablePane_FetchRowFromSnapshot;
	p.ReallyRefreshContents = s00_componente2_codigo_scsTablePane_ReallyRefreshContents;
	p.onDisplayHandler = s00_componente2_codigo_scsTablePane_onDisplayHandler;
	p.onloadHandler = s00_componente2_codigo_scsTablePane_onloadHandler;
	p.resizeHeaders = s00_componente2_codigo_scsTablePane_resizeHeaders;
}
/* EOF */