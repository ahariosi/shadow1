
function Padrao_consultar(Locado){
	// sem esta linha o m�todo possibilitava a consulta do registro,
	// mesmo durante a edi��o de um registro.
	if (zenPage.CtrlEdicao) return;
	if (Locado) {
		zenPage.CtrlEdicao = 1;
	}
	var validado = zenPage.consultarInicio(Locado);
	
	//Limpa a mensagem da p�gina
	var boxMsg = zenPage.getComponentById("userMsg")
	boxMsg.setProperty("value","")
	boxMsg.setProperty("enclosingClass","")
	
	//Para a execu��o do consultar
	if (!validado) return
	
	zenPage.CtrlCampoModificado = 0	
	var novoId = zenPage.getComponentById("controleNovoId").getValue()
	try {
		var consultaLocado = 0;
		if (zenPage.MVContainer != "") {
			//Remove todos os containers
			
			//Conta quantos containers existe, para limp�-los.
			//var containers = zenPage.MVContainer.split(",");
			//var qtdcontainers = containers.length;			
			
			/*for (cont=0;cont<qtdcontainers;cont++) {
				var container = containers[cont]
				var obj = zenPage.getComponentById(container);
				obj.refreshContents(1);
			}*/
		}
		var id = zenPage.getComponentById("formularioCadastro.Id").getProperty("value").toUpperCase();
		
	    // sem esta linha o m�todo possibilitava a consulta do registro,
		// mesmo durante a inclus�o de um registro.
	    if (id == "*NOVO*") return;
	    if (id == ""){
			zenPage.getComponentById("formularioCadastro.Id").focus();
	    	return
	    }
	    if((zenPage.IdLivre == 1) && (!zenPage.validarCodigo(id)) && (zenPage.PesquisaLog == 0)){
			zenPage.alertaShift("C�digo deve ser num�rico.");
			return
		}
		if ((zenPage.IdLivre == 1) && (novoId == 1)) return
		zenPage.getComponentById("controleNovoId").setValue("0");
	    var dados = zenPage.getComponentById("controleDados");    	  
	    //if (zenPage.IdPermiteCodigoAlfa == 0)	    
	    
		if (zenPage.MVContainer != "") {    
			id = zenPage.GetId(id,Locado);   
		}else{
			id = zenPage.GetIdSemMV(id,Locado,zenPage.ClasseDado, zenPage.LockMultiplo);
		}
	    dados.setModelId(id);
	    if (!dados.hasData()) {
		    if (zenPage.IdLivre == 1){ //Quando IdLivre, se n�o existir ser� inclu�do;		    
			    zenPage.novo();
				zenPage.getComponentById("formularioCadastro.Id").setProperty("value",id);	
				zenPage.getComponentById("controleNovoId").setValue("0");
		    }else{
		    	zenPage.inicio();
		    	try{
			    	var msg = zenPage.TraduzirMensagemPadrao("DADOSNAOENCONTRADO")
		    	} catch (ex) {
			    	var msg = "Dados n\u00e3o encontrado."
		    	}
		    	zenPage.alertaShift(msg);
		    }
		    return
	    }
	    
    	zenPage.getComponentById("formularioCadastro.Id").setProperty("value",id);
    	zenPage.getComponentById("formularioCadastro.Id").onchangeHandler();
	    
		if (zenPage.UtilizaLog)
		{
			var versaoReg = zenPage.getComponentById("formularioCadastro.VersaoCheck").getValue();	
			if (versaoReg > 0 ) zenPage.getComponentById("grpLog").setProperty("hidden",0);
		}		
	   	if (Locado){		   			   	
			//if (zenPage.TrataLock(id,"LOCK")){		
			if (zenPage.LeituraLock){
				
				consultaLocado = 1;
				if (zenPage.getComponentById("grpNovo") != null)
					zenPage.getComponentById("grpNovo").setProperty("hidden",1);
				zenPage.getComponentById("formularioCadastro.Id").setProperty("readOnly","1");
				if (zenPage.getComponentById("grpFiltrar") != null)
					zenPage.getComponentById("grpFiltrar").setProperty("hidden",1);			
				if (zenPage.getComponentById("grpEditar") != null)
			    	zenPage.getComponentById("grpEditar").setProperty("hidden",1);
			    if (zenPage.getComponentById("grpSalvar") != null)
					zenPage.getComponentById("grpSalvar").setProperty("hidden",0);							    				
				if (zenPage.getComponentById("grpPesquisar") != null)
					zenPage.getComponentById("grpPesquisar").setProperty("hidden",1);
				if (zenPage.getComponentById("grpLog") != null)
					zenPage.getComponentById("grpLog").setProperty("hidden",1);
				if (zenPage.PermiteExclusao)
					zenPage.getComponentById("grpExcluir").setProperty("hidden",1);								
				zenPage.getComponentById("tempoLock").startTimer();				
			}else{
				Locado = 0
				if (zenPage.getComponentById("grpEditar") != null)
			    	zenPage.getComponentById("grpEditar").setProperty("hidden",0);			
			    if (zenPage.getComponentById("grpSalvar") != null)
					zenPage.getComponentById("grpSalvar").setProperty("hidden",1);
				if (zenPage.PermiteExclusao)
					zenPage.getComponentById("grpExcluir").setProperty("hidden",0);							    
				zenPage.CtrlEdicao = 0;
			}
			if (zenPage.getComponentById("grpImprimir") != null)
   	   			zenPage.getComponentById("grpImprimir").setProperty("hidden",1);
		}else{
			if (zenPage.getComponentById("grpEditar") != null)
				zenPage.getComponentById("grpEditar").setProperty("hidden",0);
			if (zenPage.PermiteExclusao)
				zenPage.getComponentById("grpExcluir").setProperty("hidden",0);	
			zenPage.CtrlCampoModificado = 1
			if (zenPage.PermiteImpressao){
				if (zenPage.getComponentById("grpImprimir") != null)
   	   				zenPage.getComponentById("grpImprimir").setProperty("hidden",0);
			}
		}
		// Preenche os campos MV (quando existir)
    	if ( id != "" ) zenPage.consultarMV();
	}catch (ex){
		zenExceptionHandler(ex,arguments,"Houve erro ao realizar a pesquisa");
		return
	}
		
	// Indica que o item esta locado, entao se tem MV deve habilitar o disabled
	if (consultaLocado == 1){
		if (zenPage.getComponentById("btAdicionar") != null)
			zenPage.getComponentById("btAdicionar").setProperty("disabled",0)
		for (i=1;i<=zenPage.QtdBotoesMV;i++){
			var idBotao = "btAdicionar"+i
			if (zenPage.getComponentById(idBotao) != null)
				zenPage.getComponentById(idBotao).setProperty("disabled",0)
		}
	}
	zenPage.consultarFinal(Locado);
}

function Padrao_novo(){
	var validado = zenPage.novoInicio();
	if (!validado) return
	zenPage.CtrlCampoModificado = 0
	var dados = zenPage.getComponentById("controleDados").createNewObject();
   	zenPage.getComponentById("formularioCadastro.Id").setValue("*NOVO*");
   	zenPage.getComponentById("formularioCadastro.Id").setProperty("readOnly","1");
   	zenPage.getComponentById("formularioCadastro.Id").onchangeHandler();
    zenPage.getComponentById("controleNovoId").setValue("1");
    if (zenPage.getComponentById("grpSalvar") != null)
    	zenPage.getComponentById("grpSalvar").setProperty("hidden",0);
    if (zenPage.getComponentById("grpNovo") != null)
    	zenPage.getComponentById("grpNovo").setProperty("hidden",1);
    if (zenPage.getComponentById("grpPesquisar") != null)
    	zenPage.getComponentById("grpPesquisar").setProperty("hidden",1);
    if (zenPage.getComponentById("grpFiltrar") != null)
    	zenPage.getComponentById("grpFiltrar").setProperty("hidden",1);
    if (zenPage.getComponentById("grpEditar") != null)
    	zenPage.getComponentById("grpEditar").setProperty("hidden",1);
	if (zenPage.getComponentById("grpLog") != null)
		zenPage.getComponentById("grpLog").setProperty("hidden",1);
    
    if (zenPage.PermiteExclusao)
		zenPage.getComponentById("grpExcluir").setProperty("hidden",1);
    
    var boxMsg = zenPage.getComponentById("userMsg")
	boxMsg.setProperty("value","")
	boxMsg.setProperty("enclosingClass","")

	if (zenPage.MVContainer != "") {
		var retorno= zenPage.VerificaRemoveTodos()
	}
	if (zenPage.getComponentById("btAdicionar") != null)
		zenPage.getComponentById("btAdicionar").setProperty("disabled",0)
	for (i=1;i<=zenPage.QtdBotoesMV;i++){
		var idBotao = "btAdicionar"+i
		if (zenPage.getComponentById(idBotao) != null)
			zenPage.getComponentById(idBotao).setProperty("disabled",0)
	}
	zenPage.novoFinal();
}


function Padrao_inicio() {
	var validado = zenPage.inicioInicio();
	
	// N�o apresenta a mensagem de Lock 
	if (zenPage.getComponentById("tempoLock") != null)
		zenPage.getComponentById("tempoLock").clearTimer()
	
	var boxMsg = zenPage.getComponentById("userMsg")
	boxMsg.setProperty("value","")
	boxMsg.setProperty("enclosingClass","")
	
	// N�o continua a execu��o do inicio
	if (!validado) return
	
	zenPage.CtrlCampoModificado = 0
	zenPage.PesquisaLog = 0
    if (zenPage.getComponentById("controleNovoId") != null)
	    zenPage.getComponentById("controleNovoId").setValue("0");
    if (zenPage.getComponentById("grpSalvar") != null)
    	zenPage.getComponentById("grpSalvar").setProperty("hidden",1);
	if (zenPage.getComponentById("grpEditar") != null)    
	    zenPage.getComponentById("grpEditar").setProperty("hidden",1);
	if (zenPage.getComponentById("grpNovo") != null)
	    zenPage.getComponentById("grpNovo").setProperty("hidden",0);
	if (zenPage.getComponentById("grpPesquisar") != null)
    	zenPage.getComponentById("grpPesquisar").setProperty("hidden",0);
	if (zenPage.getComponentById("grpFiltrar") != null)
	    zenPage.getComponentById("grpFiltrar").setProperty("hidden",0);	    
	if ( zenPage.PermiteExclusao && (zenPage.getComponentById("grpExcluir") != null) )
    	zenPage.getComponentById("grpExcluir").setProperty("hidden",1);
   	if (zenPage.getComponentById("grpLog") != null)
   	   	zenPage.getComponentById("grpLog").setProperty("hidden",1);
   	   	
   	if (zenPage.getComponentById("grpImprimir") != null)
   	   	zenPage.getComponentById("grpImprimir").setProperty("hidden",1);
   	   	
    var lock  = zenPage.getProperty("LeituraLock")
    if (lock && zenPage.getComponentById("formularioCadastro.Id") != null){
    	var id = zenPage.getComponentById("formularioCadastro.Id").getValue();
    	zenPage.TrataLock(id,"UNLOCK",zenPage.ClasseDado,zenPage.LockMultiplo)
	}
	if (zenPage.getComponentById("controleDados") != null)
		var dados = zenPage.getComponentById("controleDados").createNewObject();
		
	//Objetos utilizados quando o cadastro possui MV
	if (zenPage.getComponentById("btAdicionar") != null)
		zenPage.getComponentById("btAdicionar").setProperty("disabled",1)
	for (i=1;i<=zenPage.QtdBotoesMV;i++){
		var idBotao = "btAdicionar"+i
		if (zenPage.getComponentById(idBotao) != null)
			zenPage.getComponentById(idBotao).setProperty("disabled",1)
	}

	if (zenPage.MVContainer != "") {		
		var retorno= zenPage.VerificaRemoveTodos()
 	}
 	if (zenPage.getComponentById("formularioCadastro.Id") != null){
	 	zenPage.getComponentById("formularioCadastro.Id").setProperty("readOnly",0);
	    zenPage.getComponentById("formularioCadastro.Id").focus();
    }
    zenPage.CtrlEdicao = 0;
    zenPage.inicioFinal();
}

function Padrao_salvar() {
	try{
		var validado = zenPage.salvarInicio();
		if (!validado) return
	    var dados = zenPage.getComponentById("controleDados"); 
	    var form = zenPage.getComponentById("formularioCadastro")	    	    
	    if (form.isModified()){		    
	    	var novoId = zenPage.getComponentById("controleNovoId").getValue()	    	
	    	var idAnterior = zenPage.getComponentById("formularioCadastro.Id").getValue();//esse Id armazena o valor antes da altera��o.
	    	if (novoId == 1) {
   				zenPage.getComponentById("formularioCadastro.Id").setValue("-1");
	    	}
    		zenPage.getComponentById("formularioCadastro.Id").onchangeHandler();

		    zenPage.CtrlExibeMsg = 1;
		    var statusForm = form.save();
		    //Id controlado pelo cache
			var id = zenPage.getComponentById("formularioCadastro.Id").getValue();
		    if(id == "-1") zenPage.CtrlExibeMsg = 0;

			zenPage.salvarFinal(zenPage.CtrlExibeMsg);
			//Controle para exibi��o de mensagem de confirma��o de cadastro ou altera��o			
			if (zenPage.CtrlExibeMsg == 1){					
		    	var msg = zenPage.GetMensagemFinal(id)
		    	zenPage.inicio()
		    	var boxMsg = zenPage.getComponentById("userMsg")
				boxMsg.setProperty("value",msg)
				boxMsg.setProperty("enclosingClass","alerta_positivo")
				
		    } else {
				if (novoId == 1) {
					var id = zenPage.getComponentById("formularioCadastro.Id").setValue("*NOVO*")   	   
					var id = zenPage.getComponentById("formularioCadastro.Id").onchangeHandler()
				}else{				
					var id = zenPage.getComponentById("formularioCadastro.Id").setValue(idAnterior)   	   
					var id = zenPage.getComponentById("formularioCadastro.Id").onchangeHandler()				
				}
		    }		    
	    }
	    
	}catch (ex){		
		zenExceptionHandler(ex,arguments);			
	}
}


function Padrao_editar(Locado){
	var Locado = 1;
	// sem esta linha o m�todo possibilitava a consulta do registro,
	// mesmo durante a edi��o de um registro.
	if (zenPage.CtrlEdicao) return;
	if (Locado){ zenPage.CtrlEdicao = 1; }
	
	// Para a execu��o do consultar
	var validado = zenPage.editarInicio(Locado);
	if (!validado) return
	
	//Limpa a mensagem da p�gina
	var boxMsg = zenPage.getComponentById("userMsg")
	boxMsg.setProperty("value","")
	boxMsg.setProperty("enclosingClass","")
	
	
	zenPage.CtrlCampoModificado = 0	
	var novoId = zenPage.getComponentById("controleNovoId").getValue()
	try {
		var consultaLocado = 0;
		if (zenPage.MVContainer != "") {
			zenPage.removerTodosCliente();
		}
		var campoId = zen("formularioCadastro.Id");
		var id = campoId.getValue().toUpperCase();
		var objVersaoCheck = zen("formularioCadastro.VersaoCheck")
		if(objVersaoCheck){
			var versaoCheck = objVersaoCheck.getValue();
		}else{
			zenPage.CtrlEdicao = 0;
			zenPage.consultar(1);
			return;
		}

	    // sem esta linha o m�todo possibilitava a consulta do registro,
		// mesmo durante a inclus�o de um registro.
	    if (id == "*NOVO*") return;
	    if (id == ""){
			campoId.focus();
	    	return;
	    }
	    
	    if((zenPage.IdLivre == 1) && (!zenPage.validarCodigo(id)) && (zenPage.PesquisaLog == 0)){
		    try{
		    	var msg = zenPage.TraduzirMensagemPadrao("CODIGODEVESERNUMERICO")
	    	} catch (ex) {
		    	var msg = "C\u00f3digo deve ser num\u00e9rico."
	    	}
			zenPage.alertaShift(msg);
			return;
		}
		
		if ((zenPage.IdLivre == 1) && (novoId == 1)) return
		zen("controleNovoId").setValue("0");
	    var dados = zenPage.getComponentById("controleDados");    
	    	  
	    //if (zenPage.IdPermiteCodigoAlfa == 0)	    
		//id = zenPage.GetId(id,Locado);
	    //dados.setModelId(id);
	    
	    if (!dados.hasData()) {
		    if (zenPage.IdLivre == 1){ //Quando IdLivre, se n�o existir ser� inclu�do;		    
			    zenPage.novo();
				campoId.setProperty("value",id);	
				zenPage.getComponentById("controleNovoId").setValue("0");
		    }else{
		    	zenPage.inicio();
				try{
			    	var msg = zenPage.TraduzirMensagemPadrao("DADOSNAOENCONTRADO")
		    	} catch (ex) {
			    	var msg = "Dados n\u00e3o encontrado."
		    	}
		    	zenPage.alertaShift(msg);
		    }
		    return;
	    }else{
		 	// valida vers�o check para permitir edi��o;  
		 	var validado = zenPage.validarVersao(id,versaoCheck,zenPage.ClasseDado,zenPage.LockMultiplo);
		 	// caso seja diferente, consulta novamente com o lock;
		 	if(!validado){
			 	zenPage.CtrlEdicao = 0;
			 	zenPage.consultar(1);
			 	return;
		 	}
	    }
	    
	    
	    if(campoId.getValue() != id){
	    	campoId.setProperty("value",id);
    		campoId.onchangeHandler();
	    }
	    
		if ((zenPage.UtilizaLog)&&(versaoCheck > 0)){	
			zenPage.getComponentById("grpLog").setProperty("hidden",0);
		}		
		var grpEditar	= zen("grpEditar");
		var grpExcluir	= zen("grpExcluir");
		var grpImprimir	= zen("grpImprimir");
		if (Locado){		   			   	
			//if (zenPage.TrataLock(id,"LOCK")){
			var grpNovo		= zen("grpNovo");
			var grpFiltrar	= zen("grpFiltrar");
			var grpSalvar	= zen("grpSalvar");
			var grpPesquisar= zen("grpPesquisar");
			var grpLog		= zen("grpLog");
				
						
			if (zenPage.LeituraLock){
				consultaLocado = 1;
				if (grpNovo != null)			grpNovo.setHidden(1);
				if (grpFiltrar != null)			grpFiltrar.setHidden(1);
				if (grpEditar != null)			grpEditar.setHidden(1);
			    if (grpSalvar != null)			grpSalvar.setHidden(0);
				if (grpPesquisar != null)		grpPesquisar.setHidden(1);
				if (grpLog != null)				grpLog.setHidden(1);
				if (zenPage.PermiteExclusao)	grpExcluir.setHidden(1);
										
				campoId.setProperty("readOnly","1");
					
				zenPage.getComponentById("tempoLock").startTimer();				
			}else{
				Locado = 0
				if (grpEditar != null)			grpEditar.setHidden(0);
			    if (grpSalvar != null)			grpSalvar.setHidden(1);
				if (zenPage.PermiteExclusao)	grpExcluir.setHidden(0);							    
				zenPage.CtrlEdicao = 0;
			}
			if (grpImprimir != null) grpImprimir.setHidden(1);
		}else{
			if (grpEditar != null) 			grpEditar.setHidden(0);
			if (zenPage.PermiteExclusao)	grpExcluir.setHidden(0);
			if ((zenPage.PermiteImpressao)&&(grpImprimir != null)) grpImprimir.setHidden(0);
			zenPage.CtrlCampoModificado = 1
		}
		// Preenche os campos MV (quando existir)
    	if ( id != "" ) zenPage.consultarMV();
	}catch (ex){
		// Se der algum erro, chama o consultar antigo.
		zenPage.CtrlEdicao = 0;
		zenPage.consultar(1);
		return;
	}
		
	// Indica que o item esta locado, entao se tem MV deve habilitar o disabled
	if (consultaLocado == 1){
		if (zenPage.getComponentById("btAdicionar") != null)
			zenPage.getComponentById("btAdicionar").setProperty("disabled",0)
		for (i=1;i<=zenPage.QtdBotoesMV;i++){
			var idBotao = "btAdicionar"+i
			if (zenPage.getComponentById(idBotao) != null)
				zenPage.getComponentById(idBotao).setProperty("disabled",0)
		}
	}
	zenPage.editarFinal(Locado);
}
