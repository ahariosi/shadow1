/*** Zen Module: s00_util ***/

self._zenClassIdx['JsonProvider'] = 's00_util_JsonProvider';
self.s00_util_JsonProvider = function(index,id) {
	if (index>=0) {s00_util_JsonProvider__init(this,index,id);}
}

self.s00_util_JsonProvider__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Auxiliary_jsonProvider__init) ?zenMaster._ZEN_Auxiliary_jsonProvider__init(o,index,id):_ZEN_Auxiliary_jsonProvider__init(o,index,id);
}
function s00_util_JsonProvider_serialize(set,s)
{
	var o = this;s[0]='2092629197';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.OnGetArray;s[7]=o.OnGetTargetObject;s[8]=o.OnRenderJSON;s[9]=o.OnSubmitContent;s[10]=(o.alertOnError?1:0);s[11]=o.align;s[12]=o.autoRefresh;s[13]=o.aux;s[14]=o.containerStyle;s[15]=o.content;s[16]=o.contentType;s[17]=set.addObject(o.criteria,'criteria');s[18]=set.addObject(o.dataBag,'dataBag');s[19]=(o.dataLoaded?1:0);s[20]=(o.dataReadOnly?1:0);s[21]=o.defaultSeries;s[22]=o.documentId;s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.height;s[30]=(o.hidden?1:0);s[31]=o.hint;s[32]=o.hintClass;s[33]=o.hintStyle;s[34]=o.label;s[35]=o.labelClass;s[36]=o.labelDisabledClass;s[37]=o.labelStyle;s[38]=(o.modelChanged?1:0);s[39]=o.modelError;s[40]=o.modelId;s[41]=o.onafterdrag;s[42]=o.onbeforedrag;s[43]=o.oncreate;s[44]=o.ondelete;s[45]=o.ondrag;s[46]=o.ondrop;s[47]=o.onerror;s[48]=o.onhide;s[49]=o.onnotifyController;s[50]=o.onrefresh;s[51]=o.onsave;s[52]=o.onshow;s[53]=o.onupdate;s[54]=o.overlayMode;s[55]=set.serializeArray(o,o.parameters,true,'parameters');s[56]=o.propertyList;s[57]=(o.readOnly?1:0);s[58]=o.renderFlag;s[59]=o.seriesNameProperty;s[60]=(o.showLabel?1:0);s[61]=o.slice;s[62]=o.targetClass;s[63]=o.timerid;s[64]=o.title;s[65]=o.tuple;s[66]=o.valign;s[67]=(o.visible?1:0);s[68]=o.width;
}
function s00_util_JsonProvider_getSettings(s)
{
	s['name'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_util_JsonProvider_DeleteFromServer = function(pID) {
	return zenInstanceMethod(this,'DeleteFromServer','L','BOOLEAN',arguments);
}

self.s00_util_JsonProvider_ExecuteAction = function(pAction,pData) {
	return zenInstanceMethod(this,'ExecuteAction','L,L','BOOLEAN',arguments);
}

self.s00_util_JsonProvider_LoadFromServer = function() {
	return zenInstanceMethod(this,'LoadFromServer','','VARCHAR',arguments);
}

self.s00_util_JsonProvider_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_util_JsonProvider_RefreshFromServer = function() {
	return zenInstanceMethod(this,'RefreshFromServer','','BOOLEAN',arguments);
}

self.s00_util_JsonProvider_RefreshFromServerAsynch = function() {
	zenInstanceMethod(this,'RefreshFromServerAsynch','','',arguments);
}

self.s00_util_JsonProvider_SaveToServer = function() {
	return zenInstanceMethod(this,'SaveToServer','','VARCHAR',arguments);
}

self.s00_util_JsonProvider_SubmitToServer = function(pCommand,pContent,pTargetClass) {
	return zenInstanceMethod(this,'SubmitToServer','L,L,L','BOOLEAN',arguments);
}

self.s00_util_JsonProvider_SubmitToServerAsync = function(pCommand,pContent,pTargetClass) {
	zenInstanceMethod(this,'SubmitToServerAsync','L,L,L','',arguments);
}
self.s00_util_JsonProvider__Loader = function() {
	zenLoadClass('_ZEN_Auxiliary_jsonProvider');
	s00_util_JsonProvider.prototype = zenCreate('_ZEN_Auxiliary_jsonProvider',-1);
	var p = s00_util_JsonProvider.prototype;
	if (null==p) {return;}
	p.constructor = s00_util_JsonProvider;
	p.superClass = ('undefined' == typeof _ZEN_Auxiliary_jsonProvider) ? zenMaster._ZEN_Auxiliary_jsonProvider.prototype:_ZEN_Auxiliary_jsonProvider.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.util.JsonProvider';
	p._type = 'JsonProvider';
	p.serialize = s00_util_JsonProvider_serialize;
	p.getSettings = s00_util_JsonProvider_getSettings;
	p.DeleteFromServer = s00_util_JsonProvider_DeleteFromServer;
	p.ExecuteAction = s00_util_JsonProvider_ExecuteAction;
	p.LoadFromServer = s00_util_JsonProvider_LoadFromServer;
	p.ReallyRefreshContents = s00_util_JsonProvider_ReallyRefreshContents;
	p.RefreshFromServer = s00_util_JsonProvider_RefreshFromServer;
	p.RefreshFromServerAsynch = s00_util_JsonProvider_RefreshFromServerAsynch;
	p.SaveToServer = s00_util_JsonProvider_SaveToServer;
	p.SubmitToServer = s00_util_JsonProvider_SubmitToServer;
	p.SubmitToServerAsync = s00_util_JsonProvider_SubmitToServerAsync;
}

self._zenClassIdx['JsonArrayProvider'] = 's00_util_JsonArrayProvider';
self.s00_util_JsonArrayProvider = function(index,id) {
	if (index>=0) {s00_util_JsonArrayProvider__init(this,index,id);}
}

self.s00_util_JsonArrayProvider__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Auxiliary_jsonArrayProvider__init) ?zenMaster._ZEN_Auxiliary_jsonArrayProvider__init(o,index,id):_ZEN_Auxiliary_jsonArrayProvider__init(o,index,id);
	o.controller = '';
	o.controllerId = '';
	o.ongetcontroller = '';
	o.onnotifyView = '';
}
function s00_util_JsonArrayProvider_serialize(set,s)
{
	var o = this;s[0]='503773279';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.OnGetArray;s[7]=o.OnGetTargetObject;s[8]=o.OnRenderJSON;s[9]=o.OnSubmitContent;s[10]=(o.alertOnError?1:0);s[11]=o.align;s[12]=o.arrayName;s[13]=o.autoRefresh;s[14]=o.aux;s[15]=o.containerStyle;s[16]=o.content;s[17]=o.contentType;s[18]=o.controller;s[19]=o.controllerId;s[20]=set.addObject(o.criteria,'criteria');s[21]=set.addObject(o.dataBag,'dataBag');s[22]=(o.dataLoaded?1:0);s[23]=(o.dataReadOnly?1:0);s[24]=o.defaultSeries;s[25]=o.documentId;s[26]=(o.dragEnabled?1:0);s[27]=(o.dropEnabled?1:0);s[28]=(o.dynamic?1:0);s[29]=o.enclosingClass;s[30]=o.enclosingStyle;s[31]=o.error;s[32]=o.height;s[33]=(o.hidden?1:0);s[34]=o.hint;s[35]=o.hintClass;s[36]=o.hintStyle;s[37]=o.label;s[38]=o.labelClass;s[39]=o.labelDisabledClass;s[40]=o.labelStyle;s[41]=(o.modelChanged?1:0);s[42]=o.modelError;s[43]=o.modelId;s[44]=o.onafterdrag;s[45]=o.onbeforedrag;s[46]=o.oncreate;s[47]=o.ondelete;s[48]=o.ondrag;s[49]=o.ondrop;s[50]=o.onerror;s[51]=o.ongetcontroller;s[52]=o.onhide;s[53]=o.onnotifyController;s[54]=o.onnotifyView;s[55]=o.onrefresh;s[56]=o.onsave;s[57]=o.onshow;s[58]=o.onupdate;s[59]=o.overlayMode;s[60]=set.serializeArray(o,o.parameters,true,'parameters');s[61]=o.propertyList;s[62]=(o.readOnly?1:0);s[63]=o.renderFlag;s[64]=o.seriesNameProperty;s[65]=(o.showLabel?1:0);s[66]=o.slice;s[67]=o.targetClass;s[68]=o.timerid;s[69]=o.title;s[70]=o.tuple;s[71]=o.valign;s[72]=(o.visible?1:0);s[73]=o.width;
}
function s00_util_JsonArrayProvider_getSettings(s)
{
	s['name'] = 'string';
	s['controllerId'] = 'id';
	s['ongetcontroller'] = 'eventHandler';
	s['onnotifyView'] = 'eventHandler';
	this.invokeSuper('getSettings',arguments);
}

self.s00_util_JsonArrayProvider_connectToController = function() {
this.controller = '';
if (!zenIsMissing(this.controllerId)) {
if (this.composite) {
this.controller = this.composite.getChildById(this.controllerId);
}
else {
this.controller = zenPage.getComponentById(this.controllerId);
}
if (this.controller && this.controller.register) {
this.controller.register(this);
}
else {
alert('ZEN: Unable to connect component to dataController (' + this.id + ').');
}
if (this.controller) {
if ('' == this.controller.modelError) {
this.controller.loadModel(false);
}
}
}
}

self.s00_util_JsonArrayProvider_disconnectFromController = function() {
if (this.controller && this.controller.unregister) {
this.controller.unregister(this);
}
this.controller = '';
}

self.s00_util_JsonArrayProvider_getController = function() {
if (this.ongetcontroller) {
return zenInvokeCallbackMethod(this.ongetcontroller,this,'ongetcontroller','view',this);
}
return (null == this.controller || '' == this.controller) ? null : this.controller;
}

self.s00_util_JsonArrayProvider_notifyView = function(reason,data1,data2,data3) {
var ret = true;
if (this.onnotifyView) {
ret = zenInvokeCallbackMethod(this.onnotifyView,this,'onnotifyEvent','reason',reason,'data1',data1,'data2',data2,'data3',data3);
}
if (ret && this.notifyViewHandler) {
this.notifyViewHandler(reason,data1,data2,data3);
}
}

self.s00_util_JsonArrayProvider_sendEventToController = function(reason,data1,data2,data3) {
var controller = this.getController();
if (controller && controller.notifyController) {
controller.notifyController(this,reason,data1,data2,data3);
}
}

self.s00_util_JsonArrayProvider_setControllerId = function(id) {
this.disconnectFromController();
this.controllerId = id;
this.connectToController();
}

self.s00_util_JsonArrayProvider_DeleteFromServer = function(pID) {
	return zenInstanceMethod(this,'DeleteFromServer','L','BOOLEAN',arguments);
}

self.s00_util_JsonArrayProvider_ExecuteAction = function(pAction,pData) {
	return zenInstanceMethod(this,'ExecuteAction','L,L','BOOLEAN',arguments);
}

self.s00_util_JsonArrayProvider_LoadFromServer = function() {
	return zenInstanceMethod(this,'LoadFromServer','','VARCHAR',arguments);
}

self.s00_util_JsonArrayProvider_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_util_JsonArrayProvider_RefreshFromServer = function() {
	return zenInstanceMethod(this,'RefreshFromServer','','BOOLEAN',arguments);
}

self.s00_util_JsonArrayProvider_RefreshFromServerAsynch = function() {
	zenInstanceMethod(this,'RefreshFromServerAsynch','','',arguments);
}

self.s00_util_JsonArrayProvider_SaveToServer = function() {
	return zenInstanceMethod(this,'SaveToServer','','VARCHAR',arguments);
}

self.s00_util_JsonArrayProvider_SubmitToServer = function(pCommand,pContent,pTargetClass) {
	return zenInstanceMethod(this,'SubmitToServer','L,L,L','BOOLEAN',arguments);
}

self.s00_util_JsonArrayProvider_SubmitToServerAsync = function(pCommand,pContent,pTargetClass) {
	zenInstanceMethod(this,'SubmitToServerAsync','L,L,L','',arguments);
}
self.s00_util_JsonArrayProvider__Loader = function() {
	zenLoadClass('_ZEN_Auxiliary_jsonArrayProvider');
	s00_util_JsonArrayProvider.prototype = zenCreate('_ZEN_Auxiliary_jsonArrayProvider',-1);
	var p = s00_util_JsonArrayProvider.prototype;
	if (null==p) {return;}
	p.constructor = s00_util_JsonArrayProvider;
	p.superClass = ('undefined' == typeof _ZEN_Auxiliary_jsonArrayProvider) ? zenMaster._ZEN_Auxiliary_jsonArrayProvider.prototype:_ZEN_Auxiliary_jsonArrayProvider.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.util.JsonArrayProvider';
	p._type = 'JsonArrayProvider';
	p.serialize = s00_util_JsonArrayProvider_serialize;
	p.getSettings = s00_util_JsonArrayProvider_getSettings;
	p.DeleteFromServer = s00_util_JsonArrayProvider_DeleteFromServer;
	p.ExecuteAction = s00_util_JsonArrayProvider_ExecuteAction;
	p.LoadFromServer = s00_util_JsonArrayProvider_LoadFromServer;
	p.ReallyRefreshContents = s00_util_JsonArrayProvider_ReallyRefreshContents;
	p.RefreshFromServer = s00_util_JsonArrayProvider_RefreshFromServer;
	p.RefreshFromServerAsynch = s00_util_JsonArrayProvider_RefreshFromServerAsynch;
	p.SaveToServer = s00_util_JsonArrayProvider_SaveToServer;
	p.SubmitToServer = s00_util_JsonArrayProvider_SubmitToServer;
	p.SubmitToServerAsync = s00_util_JsonArrayProvider_SubmitToServerAsync;
	p.connectToController = s00_util_JsonArrayProvider_connectToController;
	p.disconnectFromController = s00_util_JsonArrayProvider_disconnectFromController;
	p.getController = s00_util_JsonArrayProvider_getController;
	p.notifyView = s00_util_JsonArrayProvider_notifyView;
	p.sendEventToController = s00_util_JsonArrayProvider_sendEventToController;
	p.setControllerId = s00_util_JsonArrayProvider_setControllerId;
}
/* EOF */