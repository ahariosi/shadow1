function mostarItensMenu(pGrupoMostrar,pGrupoEsconder,pTexto,pSistema) {
	$("#"+pGrupoEsconder).animate({"width":"0"},150);
	$("#"+pGrupoEsconder).hide(150);
	$("#"+pGrupoMostrar).animate({"width":"930px"},250);
	$("#"+pGrupoMostrar).show(250);
	
	var navegacao = document.getElementById("inicioNavegacao");

	var btNavegacao = document.createElement("a")
	btNavegacao.href="javascript:;"
	btNavegacao.onclick = function() {voltarNavegacaoMenu(pGrupoMostrar,this)};
	btNavegacao.innerHTML = String.fromCharCode(187)+"&nbsp;&nbsp;" + pTexto;
	btNavegacao.id = "navegacao"+navegacao.children.length;
	btNavegacao.grupoAberto = pGrupoMostrar;
	navegacao.appendChild(btNavegacao);
	zenPage.SistemaSelecionado = pSistema
}

function voltarNavegacaoMenu(pGrupoMostrar,pThis) {
	var todosSubMenus = $(".inicio-sub")
	for (var i = 0; i< todosSubMenus.length;i++) {
		if(todosSubMenus[i].style.width == "930px") {
			$(todosSubMenus[i]).animate({"width":"0"},150);
			$(todosSubMenus[i]).hide(150);				
		}
	}
	$("#"+pGrupoMostrar).animate({"width":"930px"},250);
	$("#"+pGrupoMostrar).show(250);

	var deletarBotoesNav = new Array()
	var idThisBotao = pThis.id.split("")[pThis.id.length-1]
	var navegacaoInicio = document.getElementById("inicioNavegacao")
	for (var j=0;j<navegacaoInicio.children.length; j++) {
		var idNavegacao = navegacaoInicio.children[j].id.split("");
		var numeroBotao = idNavegacao[idNavegacao.length-1]
		if(numeroBotao > idThisBotao) {
			deletarBotoesNav.push(navegacaoInicio.children[j])
		}
	}
	var cont = 0;
	for (cont in deletarBotoesNav) {
		navegacaoInicio.removeChild(deletarBotoesNav[cont])
	}
	var objExpando = zenPage.getComponentById("expandoMenu")
	if (objExpando.getProperty("expanded") == 0){
		objExpando.setProperty("expanded",1)
	}
}

function mostarMenu(pSistema,pNomeSistema,pVersao,pVersaoDEF,pVersaoS00) {
	var linkSistema = document.getElementById("bt_"+pSistema);
	var divLinkSistema = linkSistema.parentNode;
	var qtdSistemas = divLinkSistema.children.length;
	var i = 0;
	for(i=0; i < qtdSistemas; i++) {
		divLinkSistema.children[i].style.fontWeight = "";
		divLinkSistema.children[i].style.fontSize = "";
		divLinkSistema.children[i].style.color = "";
	}
	linkSistema.style.fontWeight = "bold";
	linkSistema.style.fontSize = "14px";
	linkSistema.style.color = "#333";	
	var posicaoLink = parseInt($(linkSistema).position().left);
	var tamanhoLink = parseInt(linkSistema.offsetWidth);
	var posicaoSeta = posicaoLink + (tamanhoLink/2) - 8;
	$("#setaSistema").animate({"left":""+posicaoSeta});

	var todosMenus = $(".menus")
	for (var i = 0; i< todosMenus.length;i++) {
		if(todosMenus[i].style.width == "930px") {
			$(todosMenus[i]).animate({"width":"0"},150);
			$(todosMenus[i]).hide(150);				
		}
	}
	$("#menuPrimario_"+pSistema).animate({"width":"930px"},250);
	$("#menuPrimario_"+pSistema).show(250);

	var linkMenu = document.getElementById("navegacao0");
	linkMenu.onclick = function() {voltarNavegacaoMenu('menuPrimario_'+pSistema,this)};
	
	var navegacao = document.getElementById("inicioNavegacao");
	if(navegacao.children.length > 1){
		$("#"+navegacao.children[navegacao.children.length-1].grupoAberto).hide();
	}
	while (navegacao.children.length > 1){
		navegacao.removeChild(navegacao.children[1]);
	}
	zenPage.tratarSistema(pSistema,pNomeSistema,pVersao,pVersaoDEF,pVersaoS00)	
}