/*** Zen Module: s00_componente_interface ***/

self._zenClassIdx['scsJsonButton'] = 's00_componente_interface_scsJsonButton';
self.s00_componente_interface_scsJsonButton = function(index,id) {
	if (index>=0) {s00_componente_interface_scsJsonButton__init(this,index,id);}
}

self.s00_componente_interface_scsJsonButton__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_object__init) ?zenMaster._ZEN_Component_object__init(o,index,id):_ZEN_Component_object__init(o,index,id);
	o.buttonClass = '';
	o.buttonStyle = '';
	o.caption = '';
	o.disableProperty = '';
	o.hiddenProperty = '';
	o.onclick = '';
	o.onmouseover = '';
	o.title = '';
}
function s00_componente_interface_scsJsonButton_serialize(set,s)
{
	var o = this;s[0]='2943774842';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.aux;s[7]=o.buttonClass;s[8]=o.buttonStyle;s[9]=o.caption;s[10]=o.disableProperty;s[11]=o.hiddenProperty;s[12]=o.onclick;s[13]=o.onmouseover;s[14]=o.onupdate;s[15]=o.renderFlag;s[16]=o.title;s[17]=o.tuple;s[18]=(o.visible?1:0);
}
function s00_componente_interface_scsJsonButton_getSettings(s)
{
	s['name'] = 'string';
	s['buttonClass'] = 'string';
	s['buttonStyle'] = 'string';
	s['caption'] = 'caption';
	s['disableProperty'] = 'string';
	s['hiddenProperty'] = 'string';
	s['onclick'] = 'string';
	s['onmouseover'] = 'string';
	s['title'] = 'caption';
	this.invokeSuper('getSettings',arguments);
}
self.s00_componente_interface_scsJsonButton__Loader = function() {
	zenLoadClass('_ZEN_Component_object');
	s00_componente_interface_scsJsonButton.prototype = zenCreate('_ZEN_Component_object',-1);
	var p = s00_componente_interface_scsJsonButton.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsJsonButton;
	p.superClass = ('undefined' == typeof _ZEN_Component_object) ? zenMaster._ZEN_Component_object.prototype:_ZEN_Component_object.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsJsonButton';
	p._type = 'scsJsonButton';
	p.serialize = s00_componente_interface_scsJsonButton_serialize;
	p.getSettings = s00_componente_interface_scsJsonButton_getSettings;
}

self._zenClassIdx['scsJsonComponents'] = 's00_componente_interface_scsJsonComponents';
self.s00_componente_interface_scsJsonComponents = function(index,id) {
	if (index>=0) {s00_componente_interface_scsJsonComponents__init(this,index,id);}
}

self.s00_componente_interface_scsJsonComponents__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_object__init) ?zenMaster._ZEN_Component_object__init(o,index,id):_ZEN_Component_object__init(o,index,id);
	o.colTitle = '';
	o.controlClass = '';
	o.controlStyle = '';
	o.disableProperty = '';
	o.enclosingClass = '';
	o.enclosingStyle = '';
	o.hiddenProperty = '';
	o.maxLength = '';
	o.textClass = '';
	o.textStyle = '';
	o.title = '';
	o.valueProperty = '';
	o.width = '';
}
function s00_componente_interface_scsJsonComponents_serialize(set,s)
{
	var o = this;s[0]='1025082052';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.aux;s[7]=o.colTitle;s[8]=o.controlClass;s[9]=o.controlStyle;s[10]=o.disableProperty;s[11]=o.enclosingClass;s[12]=o.enclosingStyle;s[13]=o.hiddenProperty;s[14]=o.maxLength;s[15]=o.onupdate;s[16]=o.renderFlag;s[17]=o.textClass;s[18]=o.textStyle;s[19]=o.title;s[20]=o.tuple;s[21]=o.valueProperty;s[22]=(o.visible?1:0);s[23]=o.width;
}
function s00_componente_interface_scsJsonComponents_getSettings(s)
{
	s['name'] = 'string';
	s['colTitle'] = 'caption';
	s['controlClass'] = 'string';
	s['controlStyle'] = 'string';
	s['disableProperty'] = 'string';
	s['enclosingClass'] = 'string';
	s['enclosingStyle'] = 'string';
	s['hiddenProperty'] = 'string';
	s['maxLength'] = 'integer';
	s['textClass'] = 'string';
	s['textStyle'] = 'string';
	s['title'] = 'caption';
	s['valueProperty'] = 'string';
	s['width'] = 'string';
	this.invokeSuper('getSettings',arguments);
}
self.s00_componente_interface_scsJsonComponents__Loader = function() {
	zenLoadClass('_ZEN_Component_object');
	s00_componente_interface_scsJsonComponents.prototype = zenCreate('_ZEN_Component_object',-1);
	var p = s00_componente_interface_scsJsonComponents.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsJsonComponents;
	p.superClass = ('undefined' == typeof _ZEN_Component_object) ? zenMaster._ZEN_Component_object.prototype:_ZEN_Component_object.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsJsonComponents';
	p._type = 'scsJsonComponents';
	p.serialize = s00_componente_interface_scsJsonComponents_serialize;
	p.getSettings = s00_componente_interface_scsJsonComponents_getSettings;
}

self._zenClassIdx['scsDashboard'] = 's00_componente_interface_scsDashboard';
self.s00_componente_interface_scsDashboard = function(index,id) {
	if (index>=0) {s00_componente_interface_scsDashboard__init(this,index,id);}
}

self.s00_componente_interface_scsDashboard__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_component__init) ?zenMaster._ZEN_Component_component__init(o,index,id):_ZEN_Component_component__init(o,index,id);
	o.scsWidgetList = '';
}
function s00_componente_interface_scsDashboard_serialize(set,s)
{
	var o = this;s[0]='4119025490';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.containerStyle;s[9]=(o.dragEnabled?1:0);s[10]=(o.dropEnabled?1:0);s[11]=(o.dynamic?1:0);s[12]=o.enclosingClass;s[13]=o.enclosingStyle;s[14]=o.error;s[15]=o.height;s[16]=(o.hidden?1:0);s[17]=o.hint;s[18]=o.hintClass;s[19]=o.hintStyle;s[20]=o.label;s[21]=o.labelClass;s[22]=o.labelDisabledClass;s[23]=o.labelStyle;s[24]=o.onafterdrag;s[25]=o.onbeforedrag;s[26]=o.ondrag;s[27]=o.ondrop;s[28]=o.onhide;s[29]=o.onrefresh;s[30]=o.onshow;s[31]=o.onupdate;s[32]=o.overlayMode;s[33]=o.renderFlag;s[34]=o.scsWidgetList;s[35]=(o.showLabel?1:0);s[36]=o.slice;s[37]=o.title;s[38]=o.tuple;s[39]=o.valign;s[40]=(o.visible?1:0);s[41]=o.width;
}
function s00_componente_interface_scsDashboard_getSettings(s)
{
	s['name'] = 'string';
	s['scsWidgetList'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsDashboard_criarListaLink = function(pLista,pColunas,pListaId) {
var _this = this
var lista = document.createElement("div");
lista.className = "row";
var classeColuna = "col-md-12";
if((!pColunas) || (pColunas == undefined) || (pColunas == 0)) pColunas = 1;
if(pColunas > 1) {
classeColuna = "col-md-"+ (12/pColunas);
}
var arrayLista = pLista.data
if((arrayLista.length == 0) && (pLista.mensagem)) {
var mensagem = document.createElement("div");
mensagem.innerHTML = pLista.mensagem;
return mensagem;
}
_.each(arrayLista,function(itemLista,i) {
var html = "";
var elItem = document.createElement("div");
elItem.id = "scsDashborad__listitem_"+_this.index+"_"+pListaId+"_"+itemLista.id;
elItem.className = "linkTopo "+ classeColuna;
if(itemLista.onDelete != undefined)	html += "<div class='icone_excluir icone'><input type='button' idlista="+pListaId+" onclick='"+itemLista.onDelete+";' /></div>";
if(itemLista.iconClass != undefined)html += "<span class='"+itemLista.iconClass+" thumb'>&#160;</span>";
html +=										"<span class='linkTopo__descricao'>";
if(itemLista.subTitle != undefined) html += 	"<i>"+itemLista.subTitle+"</i>"
html +=											itemLista.title;
"</span>"
if(itemLista.href != undefined)	{
var linkList = document.createElement("a");
linkList.className = "link";
linkList.href = "javascript:"+itemLista.href+";";
linkList.innerHTML = html;
linkList.setAttribute("idlista",pListaId);
if(itemLista.onDelete != undefined) linkList.setAttribute("str-ondelete",itemLista.onDelete);
elItem.appendChild(linkList);
_this.definirNavegacao(lista,linkList,i,pColunas);
} else {
elItem.innerHTML = html;
}
lista.appendChild(elItem);
})
return lista
}

self.s00_componente_interface_scsDashboard_definirNavegacao = function(pElementoLista,pElementoLink,i,pColunas) {
var _this = this;
pElementoLink.setAttribute("idxnavegacao",i);
pElementoLink.onkeydown = function() {
var proximo = false;
if(event.keyCode == zenPage.recuperarCodigoTecla("RIGHTARROW")) {
proximo = pElementoLista.querySelector(".link[idxnavegacao='"+(i+1)+"']");
} else if(event.keyCode == zenPage.recuperarCodigoTecla("UPARROW")) {
proximo = pElementoLista.querySelector(".link[idxnavegacao='"+(i-pColunas)+"']");
} else if(event.keyCode == zenPage.recuperarCodigoTecla("DOWNARROW")) {
proximo = pElementoLista.querySelector(".link[idxnavegacao='"+(i+pColunas)+"']");
} else if(event.keyCode == zenPage.recuperarCodigoTecla("LEFTARROW")) {
proximo = pElementoLista.querySelector(".link[idxnavegacao='"+(i-1)+"']");
} else if(event.keyCode == zenPage.recuperarCodigoTecla("DELETE")) {
var onDelete = this.getAttribute("str-ondelete");
if(onDelete && onDelete != undefined) {
eval(onDelete);
}
var links = pElementoLista.querySelectorAll(".link[idxnavegacao]");
_.each(links,function(linkList,cont) {
_this.definirNavegacao(pElementoLista,linkList,cont,pColunas);
});
proximo = pElementoLista.querySelector(".link[idxnavegacao='"+(i)+"']");
if(!proximo || proximo == undefined) proximo = pElementoLista.querySelector(".link[idxnavegacao='"+(i-1)+"']");
}
if(proximo && proximo != undefined) proximo.focus();
}
}

self.s00_componente_interface_scsDashboard_definirWidgets = function() {
var container = document.getElementById("scsDashboard__container_"+this.index);
container.innerHTML = "";
this.setProperty("scsWidgetList","favoritos,acessoTelas");
}

self.s00_componente_interface_scsDashboard_desenharAcessoTelas = function() {
var arrayAcessos = this.getArrayAcessoTelas();
var conteudo = this.criarListaLink(arrayAcessos,1,"acessoTelasDashboard");
this.incluirWidget($$$Text("Últimos acessos"),conteudo);
}

self.s00_componente_interface_scsDashboard_desenharFavoritos = function() {
var arrayFavoritos = this.getArrayFavoritos();
var conteudo = this.criarListaLink(arrayFavoritos,2,"favoritoDashboard");
this.incluirWidget($$$Text("Favoritos"),conteudo);
}

self.s00_componente_interface_scsDashboard_desenharWidgets = function(pWidget) {
var widgetList = pWidget.split(",");
for(var i in widgetList) {
var widget = widgetList[i];
switch(widget) {
case 'favoritos':
this.desenharFavoritos();
break;
case 'acessoTelas':
this.desenharAcessoTelas();
break;
default:
break;
}
}
return true;
}

self.s00_componente_interface_scsDashboard_excluirFavorito = function(pFavoritoId,pElementoBotao,pEvent) {
pEvent.preventDefault();
var retorno = this.DeletarFavorito(pFavoritoId);
if(retorno) {
var listItem = document.querySelectorAll("#scsDashborad__listitem_"+this.index+"_"+pElementoBotao.getAttribute('idlista')+"_"+pFavoritoId);
_.each(listItem,function(objItemList) {
objItemList.parentNode.removeChild(objItemList);
})
}
}

self.s00_componente_interface_scsDashboard_excluirUltimoAcesso = function(pUltimoAcessoId,pElementoBotao,pEvent) {
pEvent.preventDefault();
var retorno = this.DeletarUltimoAcesso(pUltimoAcessoId);
if(retorno) {
var listItem = document.querySelectorAll("#scsDashborad__listitem_"+this.index+"_"+pElementoBotao.getAttribute('idlista')+"_"+pUltimoAcessoId);
_.each(listItem,function(objItemList) {
objItemList.parentNode.removeChild(objItemList);
});
}
}

self.s00_componente_interface_scsDashboard_getArrayAcessoTelas = function() {
var strAcessoTelas = this.GetAcessoTelas(this.index);
var arrayAcessoTelas = zenPage.parseJSON(strAcessoTelas)
return arrayAcessoTelas;
}

self.s00_componente_interface_scsDashboard_getArrayFavoritos = function() {
var strFavoritos = this.GetFavoritos(this.index);
var arrayFavoritos = zenPage.parseJSON(strFavoritos)
return arrayFavoritos;
}

self.s00_componente_interface_scsDashboard_incluirWidget = function(pTítulo,pConteudo) {
var container = document.getElementById("scsDashboard__container_"+this.index);
var encWidget = document.createElement("div");
encWidget.className = "col-md-6";
var elWidget = document.createElement("div");
elWidget.className = "scsDashboard__widget";
var titleWidget = document.createElement("span");
titleWidget.className = "scsDashboard__widget__title";
titleWidget.innerHTML = pTítulo;
var headWidget = document.createElement("div");
headWidget.className = "scsDashboard__widget__header";
var contentWidget = document.createElement("div");
contentWidget.className = "scsDashboard__widget__content";
headWidget.appendChild(titleWidget);
elWidget.appendChild(headWidget);
contentWidget.appendChild(pConteudo);
elWidget.appendChild(contentWidget);
encWidget.appendChild(elWidget);
container.appendChild(encWidget);
}

self.s00_componente_interface_scsDashboard_onloadHandler = function() {
var container = document.createElement("div");
container.id = "scsDashboard__container_"+this.index;
container.className = "scsDashboard__container row";
this.getEnclosingDiv().appendChild(container);
}

self.s00_componente_interface_scsDashboard_setProperty = function(property,value,value2) {
switch(property) {
case 'hidden':
this.setHidden(value);
break;
case 'hint':
case 'hintClass':
case 'hintStyle':
this[property] = value;
var hint = this.getHintElement();
if (hint) {
switch(property) {
case 'hint':
hint.innerHTML = value;
break;
case 'hintClass':
hint.className = value;
break;
case 'hintStyle':
hint.style.cssText = value;
break;
}
}
else if (this.parent) {
this.parent.refreshContents();
}
break;
case 'label':
case 'labelClass':
case 'labelStyle':
this[property] = value;
var label = this.getLabelElement();
if (label) {
switch(property) {
case 'label':
label.innerHTML = value;
break;
case 'labelClass':
label.className = value;
break;
case 'labelStyle':
label.style.cssText = value;
break;
}
}
else if (this.parent) {
this.parent.refreshContents();
}
break;
case 'containerStyle':
case 'align':
case 'valign':
case 'width':
case 'height':
case 'slice':
this[property] = value;
if (this.parent) {
this.parent.refreshContents();
}
break;
case 'enclosingClass':
this.enclosingClass = value;
var enc = this.getEnclosingDiv();
enc.className = value;
break;
case 'enclosingStyle':
this.enclosingStyle = value;
var enc = this.getEnclosingDiv();
enc.style.cssText = value;
break;
case 'dragEnabled':
case 'dropEnabled':
this[property] = value;
break;
case 'scsWidgetList':
this.desenharWidgets(value);
break;
default:
return this.invokeSuper('setProperty',arguments);
break;
}
return true;
}

self.s00_componente_interface_scsDashboard_verificarPermissaoUsuario = function(pItemMenuId,pUsuarioId,pEndereco,pEnderecoServidor,pDescricaoCompleta,pJanelaAltura,pJanelaLargura,pNovaJanela,pSistema) {
var possuiPermissao = this.VerificarPermissaoUsuarioAcesso(pUsuarioId, pItemMenuId);
if (possuiPermissao == 1){
if(zenPage.SistemaSelecionado != pSistema) {
var infoSistema = zenPage.InformacoesSistema(pSistema);
zenPage.mostarMenu(pSistema, infoSistema.NomeSistema, infoSistema.Versao, infoSistema.VersaoDef, infoSistema.VersaoS00 ,0);
}
if (pNovaJanela == 0){
parent.zenPage.carregaFrame(pEndereco, "", pItemMenuId, pEnderecoServidor);
}
else{
parent.zenPage.carregaTela(pEndereco, pDescricaoCompleta, pJanelaAltura, pJanelaLargura, 0, 0, "", pItemMenuId, pEnderecoServidor);
}
}
else{
zenPage.alertaShift(zenPage.Mensagem["usuarioSemAcesso"]);
}
}

self.s00_componente_interface_scsDashboard_DeletarFavorito = function(pFavoritoId) {
	return zenClassMethod(this,'DeletarFavorito','L','STATUS',arguments);
}

self.s00_componente_interface_scsDashboard_DeletarUltimoAcesso = function(pUltimoAcessoId) {
	return zenClassMethod(this,'DeletarUltimoAcesso','L','STATUS',arguments);
}

self.s00_componente_interface_scsDashboard_GetAcessoTelas = function(pIndex) {
	return zenClassMethod(this,'GetAcessoTelas','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsDashboard_GetFavoritos = function(pIndex) {
	return zenClassMethod(this,'GetFavoritos','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsDashboard_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsDashboard_VerificarPermissaoUsuarioAcesso = function(pUsuarioId,pItemMenuId) {
	return zenClassMethod(this,'VerificarPermissaoUsuarioAcesso','L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsDashboard__Loader = function() {
	zenLoadClass('_ZEN_Component_component');
	s00_componente_interface_scsDashboard.prototype = zenCreate('_ZEN_Component_component',-1);
	var p = s00_componente_interface_scsDashboard.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsDashboard;
	p.superClass = ('undefined' == typeof _ZEN_Component_component) ? zenMaster._ZEN_Component_component.prototype:_ZEN_Component_component.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsDashboard';
	p._type = 'scsDashboard';
	p.serialize = s00_componente_interface_scsDashboard_serialize;
	p.getSettings = s00_componente_interface_scsDashboard_getSettings;
	p.DeletarFavorito = s00_componente_interface_scsDashboard_DeletarFavorito;
	p.DeletarUltimoAcesso = s00_componente_interface_scsDashboard_DeletarUltimoAcesso;
	p.GetAcessoTelas = s00_componente_interface_scsDashboard_GetAcessoTelas;
	p.GetFavoritos = s00_componente_interface_scsDashboard_GetFavoritos;
	p.ReallyRefreshContents = s00_componente_interface_scsDashboard_ReallyRefreshContents;
	p.VerificarPermissaoUsuarioAcesso = s00_componente_interface_scsDashboard_VerificarPermissaoUsuarioAcesso;
	p.criarListaLink = s00_componente_interface_scsDashboard_criarListaLink;
	p.definirNavegacao = s00_componente_interface_scsDashboard_definirNavegacao;
	p.definirWidgets = s00_componente_interface_scsDashboard_definirWidgets;
	p.desenharAcessoTelas = s00_componente_interface_scsDashboard_desenharAcessoTelas;
	p.desenharFavoritos = s00_componente_interface_scsDashboard_desenharFavoritos;
	p.desenharWidgets = s00_componente_interface_scsDashboard_desenharWidgets;
	p.excluirFavorito = s00_componente_interface_scsDashboard_excluirFavorito;
	p.excluirUltimoAcesso = s00_componente_interface_scsDashboard_excluirUltimoAcesso;
	p.getArrayAcessoTelas = s00_componente_interface_scsDashboard_getArrayAcessoTelas;
	p.getArrayFavoritos = s00_componente_interface_scsDashboard_getArrayFavoritos;
	p.incluirWidget = s00_componente_interface_scsDashboard_incluirWidget;
	p.onloadHandler = s00_componente_interface_scsDashboard_onloadHandler;
	p.setProperty = s00_componente_interface_scsDashboard_setProperty;
	p.verificarPermissaoUsuario = s00_componente_interface_scsDashboard_verificarPermissaoUsuario;
}

self._zenClassIdx['scsJsonCheck'] = 's00_componente_interface_scsJsonCheck';
self.s00_componente_interface_scsJsonCheck = function(index,id) {
	if (index>=0) {s00_componente_interface_scsJsonCheck__init(this,index,id);}
}

self.s00_componente_interface_scsJsonCheck__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_scsJsonComponents__init) ?zenMaster.s00_componente_interface_scsJsonComponents__init(o,index,id):s00_componente_interface_scsJsonComponents__init(o,index,id);
	o.caption = '';
	o.onchange = '';
	o.valueProperty = '';
}
function s00_componente_interface_scsJsonCheck_serialize(set,s)
{
	var o = this;s[0]='861288943';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.aux;s[7]=o.caption;s[8]=o.colTitle;s[9]=o.controlClass;s[10]=o.controlStyle;s[11]=o.disableProperty;s[12]=o.enclosingClass;s[13]=o.enclosingStyle;s[14]=o.hiddenProperty;s[15]=o.maxLength;s[16]=o.onchange;s[17]=o.onupdate;s[18]=o.renderFlag;s[19]=o.textClass;s[20]=o.textStyle;s[21]=o.title;s[22]=o.tuple;s[23]=o.valueProperty;s[24]=(o.visible?1:0);s[25]=o.width;
}
function s00_componente_interface_scsJsonCheck_getSettings(s)
{
	s['name'] = 'string';
	s['caption'] = 'caption';
	s['onchange'] = 'eventHandler';
	s['valueProperty'] = 'string';
	this.invokeSuper('getSettings',arguments);
}
self.s00_componente_interface_scsJsonCheck__Loader = function() {
	zenLoadClass('s00_componente_interface_scsJsonComponents');
	s00_componente_interface_scsJsonCheck.prototype = zenCreate('s00_componente_interface_scsJsonComponents',-1);
	var p = s00_componente_interface_scsJsonCheck.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsJsonCheck;
	p.superClass = ('undefined' == typeof s00_componente_interface_scsJsonComponents) ? zenMaster.s00_componente_interface_scsJsonComponents.prototype:s00_componente_interface_scsJsonComponents.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsJsonCheck';
	p._type = 'scsJsonCheck';
	p.serialize = s00_componente_interface_scsJsonCheck_serialize;
	p.getSettings = s00_componente_interface_scsJsonCheck_getSettings;
}

self._zenClassIdx['scsJsonColumn'] = 's00_componente_interface_scsJsonColumn';
self.s00_componente_interface_scsJsonColumn = function(index,id) {
	if (index>=0) {s00_componente_interface_scsJsonColumn__init(this,index,id);}
}

self.s00_componente_interface_scsJsonColumn__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_scsJsonComponents__init) ?zenMaster.s00_componente_interface_scsJsonComponents__init(o,index,id):s00_componente_interface_scsJsonComponents__init(o,index,id);
	o.align = 'left';
	o.buttons = new Array();
	o.checks = new Array();
	o.colName = '';
	o.combos = new Array();
	o.drawTypeColumn = '';
	o.ellipsis = false;
	o.ellipsisHeader = false;
	o.filter = 'TEXTO';
	o.filterClass = '';
	o.filterEnumDisplay = '';
	o.filterEnumValue = '';
	o.filterType = '';
	o.groupRow = false;
	o.header = '';
	o.headerCheckId = '';
	o.headerCheckable = false;
	o.headerCheckableClass = '';
	o.headerTitle = '';
	o.hidden = false;
	o.onDrawCell = '';
	o.onDrawHeader = '';
	o.onHeaderCheck = '';
	o.onSortColumn = '';
	o.sortColumn = false;
	o.texts = new Array();
	o.textsData = new Array();
	o.textsInteiro = new Array();
	o.textsMoeda = new Array();
	o.width = '';
}
function s00_componente_interface_scsJsonColumn_serialize(set,s)
{
	var o = this;s[0]='2100057382';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=set.serializeList(o,o.buttons,true,'buttons');s[9]=set.serializeList(o,o.checks,true,'checks');s[10]=o.colName;s[11]=o.colTitle;s[12]=set.serializeList(o,o.combos,true,'combos');s[13]=o.controlClass;s[14]=o.controlStyle;s[15]=o.disableProperty;s[16]=o.drawTypeColumn;s[17]=(o.ellipsis?1:0);s[18]=(o.ellipsisHeader?1:0);s[19]=o.enclosingClass;s[20]=o.enclosingStyle;s[21]=o.filter;s[22]=o.filterClass;s[23]=o.filterEnumDisplay;s[24]=o.filterEnumValue;s[25]=o.filterType;s[26]=(o.groupRow?1:0);s[27]=o.header;s[28]=o.headerCheckId;s[29]=(o.headerCheckable?1:0);s[30]=o.headerCheckableClass;s[31]=o.headerTitle;s[32]=(o.hidden?1:0);s[33]=o.hiddenProperty;s[34]=o.maxLength;s[35]=o.onDrawCell;s[36]=o.onDrawHeader;s[37]=o.onHeaderCheck;s[38]=o.onSortColumn;s[39]=o.onupdate;s[40]=o.renderFlag;s[41]=(o.sortColumn?1:0);s[42]=o.textClass;s[43]=o.textStyle;s[44]=set.serializeList(o,o.texts,true,'texts');s[45]=set.serializeList(o,o.textsData,true,'textsData');s[46]=set.serializeList(o,o.textsInteiro,true,'textsInteiro');s[47]=set.serializeList(o,o.textsMoeda,true,'textsMoeda');s[48]=o.title;s[49]=o.tuple;s[50]=o.valueProperty;s[51]=(o.visible?1:0);s[52]=o.width;
}
function s00_componente_interface_scsJsonColumn_getSettings(s)
{
	s['name'] = 'string';
	s['align'] = 'enum:center,left,right:center,left,right';
	s['buttons'] = 'string';
	s['checks'] = 'string';
	s['colName'] = 'string';
	s['combos'] = 'string';
	s['drawTypeColumn'] = 'string';
	s['ellipsis'] = 'boolean';
	s['ellipsisHeader'] = 'boolean';
	s['filter'] = 'enum:TEXTO,HORA,HORAPERIODO,MAIORIGUALQUE,MENORIGUALQUE,ENUM:TEXTO,HORA,HORAPERIODO,MAIORIGUALQUE,MENORIGUALQUE,ENUM';
	s['filterClass'] = 'string';
	s['filterEnumDisplay'] = 'string';
	s['filterEnumValue'] = 'string';
	s['filterType'] = 'enum:LIKE,STARTSWITH,EQUAL:LIKE,STARTSWITH,EQUAL';
	s['groupRow'] = 'boolean';
	s['header'] = 'caption';
	s['headerCheckId'] = 'string';
	s['headerCheckable'] = 'boolean';
	s['headerCheckableClass'] = 'string';
	s['headerTitle'] = 'caption';
	s['hidden'] = 'boolean';
	s['onDrawCell'] = 'string';
	s['onDrawHeader'] = 'string';
	s['onHeaderCheck'] = 'string';
	s['onSortColumn'] = 'string';
	s['sortColumn'] = 'boolean';
	s['texts'] = 'string';
	s['textsData'] = 'string';
	s['textsInteiro'] = 'string';
	s['textsMoeda'] = 'string';
	s['width'] = 'string';
	this.invokeSuper('getSettings',arguments);
}
self.s00_componente_interface_scsJsonColumn__Loader = function() {
	zenLoadClass('s00_componente_interface_scsJsonComponents');
	s00_componente_interface_scsJsonColumn.prototype = zenCreate('s00_componente_interface_scsJsonComponents',-1);
	var p = s00_componente_interface_scsJsonColumn.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsJsonColumn;
	p.superClass = ('undefined' == typeof s00_componente_interface_scsJsonComponents) ? zenMaster.s00_componente_interface_scsJsonComponents.prototype:s00_componente_interface_scsJsonComponents.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsJsonColumn';
	p._type = 'scsJsonColumn';
	p.serialize = s00_componente_interface_scsJsonColumn_serialize;
	p.getSettings = s00_componente_interface_scsJsonColumn_getSettings;
}

self._zenClassIdx['scsJsonCombo'] = 's00_componente_interface_scsJsonCombo';
self.s00_componente_interface_scsJsonCombo = function(index,id) {
	if (index>=0) {s00_componente_interface_scsJsonCombo__init(this,index,id);}
}

self.s00_componente_interface_scsJsonCombo__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_scsJsonComponents__init) ?zenMaster.s00_componente_interface_scsJsonComponents__init(o,index,id):s00_componente_interface_scsJsonComponents__init(o,index,id);
	o.Mensagem = new Object();
	o.dataProperty = '';
	o.dropdownAutoWidth = false;
	o.onchange = '';
	o.valueProperty = '';
}
function s00_componente_interface_scsJsonCombo_serialize(set,s)
{
	var o = this;s[0]='4171311709';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=set.serializeArray(o,o.Mensagem,false,'Mensagem');s[7]=o.aux;s[8]=o.colTitle;s[9]=o.controlClass;s[10]=o.controlStyle;s[11]=o.dataProperty;s[12]=o.disableProperty;s[13]=(o.dropdownAutoWidth?1:0);s[14]=o.enclosingClass;s[15]=o.enclosingStyle;s[16]=o.hiddenProperty;s[17]=o.maxLength;s[18]=o.onchange;s[19]=o.onupdate;s[20]=o.renderFlag;s[21]=o.textClass;s[22]=o.textStyle;s[23]=o.title;s[24]=o.tuple;s[25]=o.valueProperty;s[26]=(o.visible?1:0);s[27]=o.width;
}
function s00_componente_interface_scsJsonCombo_getSettings(s)
{
	s['name'] = 'string';
	s['Mensagem'] = 'string';
	s['dataProperty'] = 'string';
	s['dropdownAutoWidth'] = 'string';
	s['onchange'] = 'eventHandler';
	s['valueProperty'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsJsonCombo_onloadHandler = function() {
/* Select2 Brazilian Portuguese translation  */
var mensagem = this.Mensagem;
(function ($,mensagem) {
"use strict";
$.fn.select2.locales['pt-BR'] = {
formatNoMatches: function () { return mensagem["nenhumResultadoEncontrado"]; },
formatAjaxError: function () { return mensagem["erroBusca"]; },
formatInputTooShort: function (input, min) { var n = min - input.length; return mensagem["digite"] + " " + (min == 1 ? "" : mensagem["mais"]) + " " + n + " "+ mensagem["caracter" + (n == 1? "" : "es")]; },
formatInputTooLong: function (input, max) { var n = input.length - max; return mensagem["apague"] + " " + n + " "+mensagem["caracter"+(n == 1? "" : "es")]; },
formatSelectionTooBig: function (limit) { return mensagem["soEPossivelSelecionar"] +" " + limit + " " +mensagem["elemento"+(limit == 1 ? "" : "s")]; },
formatLoadMore: function (pageNumber) { return mensagem["carregandoResultados"]; },
formatSearching: function () { return mensagem["buscando"]; }
};
$.extend($.fn.select2.defaults, $.fn.select2.locales['pt-BR']);
})(jQuery,mensagem);
}
self.s00_componente_interface_scsJsonCombo__Loader = function() {
	zenLoadClass('s00_componente_interface_scsJsonComponents');
	s00_componente_interface_scsJsonCombo.prototype = zenCreate('s00_componente_interface_scsJsonComponents',-1);
	var p = s00_componente_interface_scsJsonCombo.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsJsonCombo;
	p.superClass = ('undefined' == typeof s00_componente_interface_scsJsonComponents) ? zenMaster.s00_componente_interface_scsJsonComponents.prototype:s00_componente_interface_scsJsonComponents.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsJsonCombo';
	p._type = 'scsJsonCombo';
	p.serialize = s00_componente_interface_scsJsonCombo_serialize;
	p.getSettings = s00_componente_interface_scsJsonCombo_getSettings;
	p.onloadHandler = s00_componente_interface_scsJsonCombo_onloadHandler;
}

self._zenClassIdx['scsJsonTable'] = 's00_componente_interface_scsJsonTable';
self.s00_componente_interface_scsJsonTable = function(index,id) {
	if (index>=0) {s00_componente_interface_scsJsonTable__init(this,index,id);}
}

self.s00_componente_interface_scsJsonTable__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_component__init) ?zenMaster._ZEN_Component_component__init(o,index,id):_ZEN_Component_component__init(o,index,id);
	o.AnoAtual = '';
	o.CheckDisabledPropertyName = '';
	o.Mensagem = new Object();
	o.beforeDeleteAllRows = '';
	o.beforeDeleteRow = '';
	o.bodyHeight = '';
	o.bodyResizable = false;
	o.columns = new Array();
	o.currentPage = '1';
	o.deleteColumnTitle = 'Excluir';
	o.groupMultiSelectColumnName = '';
	o.groupType = 'cascade';
	o.idColumn = '';
	o.invalidTimeMessage = 'Hora inválida';
	o.jsonContent = null;
	o.jsonContentInternal = null;
	o.mini = '';
	o.miniRow = false;
	o.multiSelect = false;
	o.navigator = false;
	o.navigatorPosition = 'right';
	o.onClear = '';
	o.onDeleteAllRows = '';
	o.onDeleteRow = '';
	o.onSort = '';
	o.ondblclick = '';
	o.onkeypress = '';
	o.onmultiSelectRow = '';
	o.onselectrow = '';
	o.pageSize = '0';
	o.resultados = false;
	o.resultadosPorPagina = false;
	o.rowFormatClass = '';
	o.rowFormatProperty = '';
	o.rowHover = false;
	o.rowSelect = false;
	o.scrollBody = true;
	o.scsShortcutKeys = '';
	o.showDeleteAllRows = false;
	o.showDeleteColumn = false;
	o.showHeaders = true;
	o.showZebra = true;
	o.sortColumnTitle = 'Arraste e solte para ordenar as linhas';
	o.sortable = false;
	o.onCreate();
}
function s00_componente_interface_scsJsonTable_serialize(set,s)
{
	var o = this;s[0]='1316445771';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.AnoAtual;s[7]=o.CheckDisabledPropertyName;s[8]=set.serializeArray(o,o.Mensagem,false,'Mensagem');s[9]=o.align;s[10]=o.aux;s[11]=o.beforeDeleteAllRows;s[12]=o.beforeDeleteRow;s[13]=o.bodyHeight;s[14]=(o.bodyResizable?1:0);s[15]=set.serializeList(o,o.columns,true,'columns');s[16]=o.containerStyle;s[17]=o.currentPage;s[18]=o.deleteColumnTitle;s[19]=(o.dragEnabled?1:0);s[20]=(o.dropEnabled?1:0);s[21]=(o.dynamic?1:0);s[22]=o.enclosingClass;s[23]=o.enclosingStyle;s[24]=o.error;s[25]=o.groupMultiSelectColumnName;s[26]=o.groupType;s[27]=o.height;s[28]=(o.hidden?1:0);s[29]=o.hint;s[30]=o.hintClass;s[31]=o.hintStyle;s[32]=o.idColumn;s[33]=o.invalidTimeMessage;s[34]=o.label;s[35]=o.labelClass;s[36]=o.labelDisabledClass;s[37]=o.labelStyle;s[38]=o.mini;s[39]=(o.miniRow?1:0);s[40]=(o.multiSelect?1:0);s[41]=(o.navigator?1:0);s[42]=o.navigatorPosition;s[43]=o.onClear;s[44]=o.onDeleteAllRows;s[45]=o.onDeleteRow;s[46]=o.onSort;s[47]=o.onafterdrag;s[48]=o.onbeforedrag;s[49]=o.ondblclick;s[50]=o.ondrag;s[51]=o.ondrop;s[52]=o.onhide;s[53]=o.onkeypress;s[54]=o.onmultiSelectRow;s[55]=o.onrefresh;s[56]=o.onselectrow;s[57]=o.onshow;s[58]=o.onupdate;s[59]=o.overlayMode;s[60]=o.pageSize;s[61]=o.renderFlag;s[62]=(o.resultados?1:0);s[63]=(o.resultadosPorPagina?1:0);s[64]=o.rowFormatClass;s[65]=o.rowFormatProperty;s[66]=(o.rowHover?1:0);s[67]=(o.rowSelect?1:0);s[68]=(o.scrollBody?1:0);s[69]=o.scsShortcutKeys;s[70]=(o.showDeleteAllRows?1:0);s[71]=(o.showDeleteColumn?1:0);s[72]=(o.showHeaders?1:0);s[73]=(o.showLabel?1:0);s[74]=(o.showZebra?1:0);s[75]=o.slice;s[76]=o.sortColumnTitle;s[77]=(o.sortable?1:0);s[78]=o.title;s[79]=o.tuple;s[80]=o.valign;s[81]=(o.visible?1:0);s[82]=o.width;
}
function s00_componente_interface_scsJsonTable_getSettings(s)
{
	s['name'] = 'string';
	s['AnoAtual'] = 'string';
	s['CheckDisabledPropertyName'] = 'string';
	s['Mensagem'] = 'string';
	s['beforeDeleteAllRows'] = 'string';
	s['beforeDeleteRow'] = 'string';
	s['bodyHeight'] = 'string';
	s['bodyResizable'] = 'boolean';
	s['columns'] = 'string';
	s['currentPage'] = 'integer';
	s['deleteColumnTitle'] = 'caption';
	s['groupMultiSelectColumnName'] = 'string';
	s['groupType'] = 'enum:all,cascade:all,cascade';
	s['idColumn'] = 'string';
	s['invalidTimeMessage'] = 'caption';
	s['mini'] = 'string';
	s['miniRow'] = 'boolean';
	s['multiSelect'] = 'boolean';
	s['navigator'] = 'boolean';
	s['navigatorPosition'] = 'enum:right,left';
	s['onClear'] = 'string';
	s['onDeleteAllRows'] = 'string';
	s['onDeleteRow'] = 'string';
	s['onSort'] = 'string';
	s['ondblclick'] = 'string';
	s['onkeypress'] = 'eventHandler';
	s['onmultiSelectRow'] = 'string';
	s['onselectrow'] = 'string';
	s['pageSize'] = 'integer';
	s['resultados'] = 'boolean';
	s['resultadosPorPagina'] = 'boolean';
	s['rowFormatClass'] = 'string';
	s['rowFormatProperty'] = 'string';
	s['rowHover'] = 'boolean';
	s['rowSelect'] = 'boolean';
	s['scrollBody'] = 'boolean';
	s['scsShortcutKeys'] = 'string';
	s['showDeleteAllRows'] = 'boolean';
	s['showDeleteColumn'] = 'boolean';
	s['showHeaders'] = 'boolean';
	s['showZebra'] = 'boolean';
	s['sortColumnTitle'] = 'caption';
	s['sortable'] = 'boolean';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsJsonTable_addRow = function(pData) {
this.drawRow(pData);
this.drawNavigator();
this.manterColunasOrdenadas();
}

self.s00_componente_interface_scsJsonTable_addRows = function(pData) {
if(!pData) return;
var total = pData.length;
for(var i=0;i<total;i++){
this.drawRow(pData[i]);
}
this.drawNavigator();
this.showPage(this.currentPage);
this.filter();
this.manterColunasOrdenadas();
}

self.s00_componente_interface_scsJsonTable_applyGroupRow = function(iCol,data,iLastData,iNewCell) {
var col = this.columns[iCol];
if(col.groupRow){
initialPos = 0;
if(this.pageSize > 0 && this.currentPage > 1) {
initialPos = this.pageSize * (this.currentPage - 1);
}
var lastData = this.jsonContentInternal[iLastData];
if(lastData != ""){
if(data[col.colName] == lastData[col.colName]){
if((this.groupType == "cascade")&&(iCol > 0)){
for(var iLastCol = iCol-1; iLastCol >= 0;iLastCol--){
var lastCol = this.columns[iLastCol];
if((lastCol.groupRow)&&((data[lastCol.colName] != lastData[lastCol.colName]))){
return "";
}
}
}
var stop = false;
while((iLastData >= initialPos)&&(!stop)){
lastData = this.jsonContentInternal[iLastData];
if(data[col.colName] == lastData[col.colName]){
if((this.groupType == "cascade")&&(iCol > 0)){
for(var iLastCol = iCol-1; iLastCol >= 0;iLastCol--){
var lastCol = this.columns[iLastCol];
if((lastCol.groupRow)&&((data[lastCol.colName] != lastData[lastCol.colName]))){
stop = true;
break;
}
}
}
if(!stop) iLastData--;
}else{
stop = true;
}
}
iLastData++;
if(iLastData != iNewCell){
return iLastData;
}
}
}
}
return "";
}

self.s00_componente_interface_scsJsonTable_clear = function() {
$("#tbody_"+this.getIdEscaped()+" > tr").remove();
this.jsonContent			= [];
this.jsonContentInternal	= [];
$("#thead_"+this.getIdEscaped()+" > tr > th > input").val("");
if(this.multiSelect){
document.getElementById("chk_"+this.id).checked = false;
}
if(this.navigator) {
var divNav = document.getElementById("nav_"+this.id);
divNav.innerHTML = "";
}
_.each(this.columns, function(col){
if(col.headerCheckable && col.headerCheckId){
var headerCheck = document.getElementById(col.headerCheckId);
if(headerCheck)headerCheck.checked = false;
}
});
if(this.onClear != "")
zenInvokeCallbackMethod(this.onClear,this,'onClear');
}

self.s00_componente_interface_scsJsonTable_clearFocusUseKeys = function() {
try {
var linhaFocus = document.querySelector("#tbody_" + this.id + ' .rowFocus');
if(linhaFocus && linhaFocus != undefined) {
linhaFocus.classList.remove('rowFocus');
document.getElementById("jsonTableUseKeys_"+this.index).setAttribute('rowfocus',-1);
}
} catch (ex) {
zenPage.alertaShift("clearFocusUseKeys(): "+zenPage.getMsgExcecao(ex));
}
}

self.s00_componente_interface_scsJsonTable_count = function() {
return this.jsonContentInternal.length;
}

self.s00_componente_interface_scsJsonTable_criarResultados = function() {
var _this = this;
var textContainer = document.createElement("div");
textContainer.style.cssText = "margin-top:3px;"
var labelNumRegistros = document.createElement("span");
labelNumRegistros.innerText = $$$Text("Resultados: ")+this.jsonContentInternal.length;
labelNumRegistros.className = "zenLabel labelColor";
labelNumRegistros.style.width = "100px";
textContainer.appendChild(labelNumRegistros);
return textContainer;
}

self.s00_componente_interface_scsJsonTable_criarResultadosPorPagina = function() {
var _this = this;
var selectContainer = document.createElement("div");
selectContainer.style.cssText = "margin-top:3px;"
var select = document.createElement("select");
select.id = "selectPageSize"+this.index;
[5,10,50,100,500].forEach(function(size){
var opt = document.createElement("option");
opt.value = size;
opt.text = size;
select.appendChild(opt);
});
this.setProperty("pageSize", this.getQtdRegistroPaginaLocal());
select.value = this.getProperty("pageSize");
select.addEventListener("change", function(evt){
var size = evt.srcElement.value;
_this.setProperty("pageSize", size);
_this.showPage(1);
_this.salvarQtdRegistroPaginaAtual(size);
});
var labelSelect = document.createElement("span");
labelSelect.innerText = $$$Text("Registros por página:");
labelSelect.className = "zenLabel labelColor";
selectContainer.appendChild(labelSelect);
selectContainer.appendChild(select);
return selectContainer;
}

self.s00_componente_interface_scsJsonTable_dblClick = function(pRow) {
if(this.ondblclick != "") {
var rowId = pRow.id;
var infoJson = _.findWhere(this.jsonContentInternal, {_rowId: rowId});
zenInvokeCallbackMethod(this.ondblclick,this,'ondblclick',"data",infoJson)
}
}

self.s00_componente_interface_scsJsonTable_deleteAllRows = function() {
var retorno = true;
try{
if(this.jsonContent.length == 0) return;
if(this.beforeDeleteAllRows != ""){
var ret = this.getContexto()[this.beforeDeleteAllRows]();
if(ret != true) return;
}
this.clear();
if(this.onDeleteAllRows != ""){
zenInvokeCallbackMethod(this.onDeleteAllRows,this,'onDeleteAllRows');
}
}catch(ex){
zenPage.exibirExcecao(ex);
retorno = false;
}
return retorno;
}

self.s00_componente_interface_scsJsonTable_drawColumn = function(newCell,col,pData) {
var mini = "";
if(this.miniRow){
mini = "--mini"
}
var title = ""
if(col.onDrawCell != ""){
var drawCellData;
if(typeof(col.onDrawCell) == "function"){
drawCellData = col.onDrawCell(pData,col);
}else{
drawCellData = this.getContexto()[col.onDrawCell](pData,col);
}
if(typeof(drawCellData) != "object"){
newCell.innerHTML = drawCellData;
}else{
if(!drawCellData.length){
newCell.appendChild(drawCellData);
}else{
for(var i = 0; i < drawCellData.length; i++){
newCell.appendChild(drawCellData[i]);
}
}
}
}else if((col.drawTypeColumn != "")&&(pData[col.drawTypeColumn] != "")&&(pData["drawDef"] != "")){
var divItem = "";
switch(pData[col.drawTypeColumn]){
case "text":
divItem = this.drawTextItem(pData["drawDef"],col,pData);
break;
case "textInteiro":
divItem = this.drawTextInteiroItem(pData["drawDef"],col,pData);
break;
case "combobox":
divItem = this.drawJsonComboItem(newCell,pData["drawDef"],col,pData);
break;
case "data":
divItem = this.drawTextDataItem(newCell,pData["drawDef"],col,pData);
break;
case "hora":
divItem = this.drawTextHoraItem(newCell,pData["drawDef"],col,pData);
break;
case "moeda":
divItem = this.drawTextMoedaItem(pData["drawDef"],col,pData);
break;
}
if(divItem != "") newCell.appendChild(divItem);
}else{
var desenhouItem = false;
if(col.buttons.length > 0){
this.drawJsonButton(newCell,col,pData);
desenhouItem = true;
}
if(col.texts.length > 0) {
this.drawText(newCell,col,pData);
desenhouItem = true;
}
if(col.textsMoeda.length > 0) {
this.drawTextMoeda(newCell,col,pData);
desenhouItem = true;
}
if(col.textsInteiro.length > 0) {
this.drawTextInteiro(newCell,col,pData);
desenhouItem = true;
}
if(col.textsData.length > 0) {
this.drawTextData(newCell,col,pData);
desenhouItem = true;
}
if(col.combos.length > 0) {
this.drawJsonCombo(newCell,col,pData);
desenhouItem = true;
}
if(col.checks.length > 0) {
this.drawJsonCheck(newCell,col,pData);
desenhouItem = true;
}
if (!desenhouItem){
if(col.colName && col.colName != "") {
var text = document.createTextNode(pData[col.colName]);
newCell.appendChild(text);
} else {
newCell.innerText = " ";
}
}
}
if(col.colTitle != ""){
title = pData[col.colTitle];
}else{
if(pData[col.colName] != undefined){
title = pData[col.colName];
}
}
newCell.setAttribute("title",title);
if(col.hidden){
newCell.style.display = "none";
}
if((pData["rowspan"]) && (pData["rowspan"][col.colName])){
newCell.rowSpan = pData["rowspan"][col.colName];
if(newCell.className.indexOf("not-select") == -1) newCell.className += " not-select";
}
newCell.style.width = col.width;
newCell.setAttribute("align", col.align);
newCell.className = "jsonTable__body__column"+mini+"";
if(col.enclosingClass != ""){
newCell.className = newCell.className+" "+col.enclosingClass;
}
if(col.ellipsis){
newCell.className += " ellipsis";
}
return newCell;
}

self.s00_componente_interface_scsJsonTable_drawDeleteButtonRow = function(newCell) {
var index = this.index;
var link = document.createElement('input');
var div = document.createElement('div');
div.className = "icone_excluir icone";
link.type = "button";
link.onclick = function(){ zenPage.getComponent(index).removeRowButton(this) };
link.title = this.deleteColumnTitle;
div.appendChild(link);
newCell.className = "jsonTable__body__column"+this.mini+" jsonTable__body__column--icon";
newCell.appendChild(div);
}

self.s00_componente_interface_scsJsonTable_drawJsonButton = function(newCell,col,dataInfo) {
var divButtonContainer = this.getContainer(newCell,col,dataInfo,"jsonTable__body__container-button clearfix");
newCell.appendChild(divButtonContainer);
var totalButtons = col.buttons.length;
for(var k=0; k<totalButtons; k++) {
var button = col.buttons[k];
var divButton = this.getDiv(newCell,col,dataInfo,button);
divButton.className = button.buttonClass;
divButton.style.cssText = button.buttonStyle;
divButtonContainer.appendChild(divButton);
var inputButton = document.createElement("input");
inputButton.setAttribute("type", "button");
inputButton.className = "button";
inputButton.setAttribute("value", button.caption);
inputButton.setAttribute("title", button.title);
inputButton.composite = this.composite;
inputButton.name = button.name;
divButton.appendChild(inputButton);
if(button.hiddenProperty != "" && dataInfo[button.hiddenProperty]) {
divButton.style.display = "none";
inputButton.style.display = "none";
if(totalButtons == 1)
divButtonContainer.appendChild(document.createTextNode(" "));
} else {
if(button.disableProperty != "" && dataInfo[button.disableProperty]) {
divButton.className += " jsonTable__body__button--disabled";
inputButton.disabled = true;
}
if(button.onclick != "") {
(function(pButton, pDataInfo){
inputButton.onclick = function(){zenInvokeCallbackMethod(pButton.onclick,this,'onclick',"jsonButton",pButton,"data",pDataInfo);}
})(button, dataInfo);
}
if(button.onmouseover != ""){
(function(pButton, pDataInfo){
inputButton.onmouseover = function(){zenInvokeCallbackMethod(pButton.onmouseover,this,'onmouseover',"jsonButton",pButton,"data",pDataInfo);}
})(button, dataInfo);
}
}
}
}

self.s00_componente_interface_scsJsonTable_drawJsonCheck = function(newCell,col,dataInfo) {
var totalChilds = col.checks.length;
for(var k=0; k<totalChilds; k++) {
var child = col.checks[k];
var div = this.getDiv(newCell,col,dataInfo,child);
newCell.appendChild(div);
var name = "jsonCheck_"+child.name;
var check = document.createElement("input");
check.setAttribute("row",newCell.row);
check.setAttribute("col",newCell.col);
var idChild = "";
if(child.id != "") idChild = child.id;
var id = "jsonCheck_"+this.getIdEscaped()+"_"+newCell.row+"_"+newCell.col+"_"+idChild;
check.setAttribute("type","checkbox");
check.setAttribute("id",id);
check.setAttribute("name",name);
check.setAttribute("className","jsonCheckBox");
if(child.disableProperty != ""){
if(dataInfo[child.disableProperty]){
check.setAttribute("disabled",true);
}
}
var checkjquery = $("#"+check.getAttribute("id"));
div.appendChild(check);
if(child.valueProperty != ""){
var value = dataInfo[child.valueProperty];
if((value != undefined) && (value.toString() != "")){
if(value){
check.setAttribute("checked",true);
}
}
if(child.onchange == ""){
check.onclick = function(){ dataInfo[child.valueProperty] = this.checked; }
}else{
(function(pchild, pcheck, pdataInfo){
pcheck.onchange =
function(){
zenInvokeCallbackMethod(pchild.onchange,this,'onchange',"child",pchild,"data",pdataInfo,"comp",pcheck);
}
})(child, check, dataInfo);
}
}
}
}

self.s00_componente_interface_scsJsonTable_drawJsonCombo = function(newCell,col,dataInfo) {
var divComboContainer = this.getContainer(newCell,col,dataInfo,"");
newCell.appendChild(divComboContainer);
var totalCombos = col.combos.length;
for(var k=0; k<totalCombos; k++) {
var combo = col.combos[k];
var divCombo = this.drawJsonComboItem(newCell,combo,col,dataInfo)
divComboContainer.appendChild(divCombo);
}
}

self.s00_componente_interface_scsJsonTable_drawJsonComboItem = function(newCell,combo,col,dataInfo) {
var divCombo = this.getDiv(newCell,col,dataInfo,combo);
var combobox = document.createElement("input");
combobox.id = "jsonComboBox_"+this.id+"_"+newCell.row+"_"+newCell.col;
combobox.className = "jsonComboBox";
combobox.composite = this.composite;
if(dataInfo[combo.valueProperty] == "" && (combo.onchange == "" || combo.onchange == null) && col.drawTypeColumn != ""){
combobox.onchange = function(){ dataInfo[combo.valueProperty] = this.value };
}
divCombo.appendChild(combobox);
if(combo.disableProperty != ""){
if(dataInfo[combo.disableProperty]){
combobox.setAttribute("disabled",true);
}
}
if(combo.hiddenProperty != ""){
if(dataInfo[combo.hiddenProperty]){
combobox.style.display = "none";
}
}
var combojquery = $(combobox);
var select2Config = {};
if(typeof(dataInfo[combo.dataProperty]) == "function"){
select2Config["data"] = dataInfo[combo.dataProperty]();
}else{
select2Config["data"] = dataInfo[combo.dataProperty];
};
if(combo.dropdownAutoWidth){
select2Config["dropdownAutoWidth"] = true;
}
combojquery.select2(select2Config);
if(combo.valueProperty){
var value = dataInfo[combo.valueProperty];
if((value != undefined) && (value.toString() != "")){
combojquery.val(value).trigger("change");
}
if(combo.onchange != undefined && combo.onchange != ""){
(function(pDefinicao, pComp, pDataInfo,jQueryCombo){
jQueryCombo.on("change", function (e) {
pDataInfo["_lastValue"+pDefinicao.valueProperty] = pDataInfo[pDefinicao.valueProperty];
pDataInfo[pDefinicao.valueProperty] = e.val;
zenInvokeCallbackMethod(pDefinicao.onchange,this,'onchange',"jsonComponente",pDefinicao,"data",pDataInfo,"componentHTML",pComp);
});
})(combo, combobox, dataInfo,combojquery);
}else{
combojquery.on("change", function (e) { dataInfo["_lastValue"+combo.valueProperty] = dataInfo[combo.valueProperty]; dataInfo[combo.valueProperty] = e.val; });
}
}else if(combo.onchange != ""){
(function(pDefinicao, pComp, pDataInfo,jQueryCombo){
jQueryCombo.on("change", function (e) {
zenInvokeCallbackMethod(pDefinicao.onchange,this,'onchange',"jsonComponente",pDefinicao,"data",pDataInfo,"componentHTML",pComp);
});
})(combo, combobox, dataInfo,combojquery);
}
return divCombo;
}

self.s00_componente_interface_scsJsonTable_drawMultiSelect = function(newCell,checked,desabilitarCheck,rowId) {
var index = this.index;
var chkSelect = document.createElement("input");
chkSelect.setAttribute("type","checkbox");
chkSelect.id = rowId + "_check";
chkSelect.onclick = function(){ zenPage.getComponent(index).selectRowButton(this) };
newCell.className = "jsonTable__body__column"+this.mini+" jsonTable__body__column--check";
if (desabilitarCheck) newCell.className = "jsonTable__body__column"+this.mini+" jsonTable__body__column--checkDisabled";
newCell.appendChild(chkSelect);
chkSelect.checked = checked;
if (desabilitarCheck) chkSelect.disabled = true;
}

self.s00_componente_interface_scsJsonTable_drawNavigator = function() {
var divNav = document.getElementById("nav_"+this.id);
if(!this.navigator) {
divNav.style.display = "none";
return;
}
divNav.innerHTML = "";
divNav.style.display = "";
var totalPages	= this.getTotalPages();
var compIndex	= this.index;
var divContainer = document.createElement("div");
divContainer.className = "jsonTable__nav";
if(this.navigatorPosition == "left"){
divContainer.style.left = "0";
divContainer.style.right = "auto";
}
var btnFirst = document.createElement("input");
btnFirst.className = "jsonTable__nav__button--arrow";
btnFirst.setAttribute("type", "button");
btnFirst.setAttribute("value", "|<");
var btnPrev = document.createElement("input");
btnPrev.className = "jsonTable__nav__button--arrow";
btnPrev.setAttribute("type", "button");
btnPrev.setAttribute("value", "<");
var btnNext = document.createElement("input");
btnNext.className = "jsonTable__nav__button--arrow";
btnNext.setAttribute("type", "button");
btnNext.setAttribute("value", ">");
var btnLast = document.createElement("input");
btnLast.className = "jsonTable__nav__button--arrow";
btnLast.setAttribute("type", "button");
btnLast.setAttribute("value", ">|");
divContainer.appendChild(btnFirst);
divContainer.appendChild(btnPrev);
var enclosingNav = document.createElement("div");
enclosingNav.id = "jsonTable_enclosingNav_"+this.index;
enclosingNav.className = "jsonTable__enclosing-nav";
enclosingNav.appendChild(divContainer);
divNav.appendChild(enclosingNav);
if(totalPages == 0) {
btnFirst.setAttribute("disabled", "disabled");
btnPrev.setAttribute("disabled", "disabled");
btnNext.setAttribute("disabled", "disabled");
btnLast.setAttribute("disabled", "disabled");
var btnPage = document.createElement("input");
btnPage.className = "jsonTable__nav__button--active";
btnPage.setAttribute("type", "button");
btnPage.setAttribute("value", "1");
btnPage.setAttribute("disabled", "disabled");
divContainer.appendChild(btnPage);
}else{
if(this.currentPage == 1) {
btnFirst.setAttribute("disabled", "disabled");
btnPrev.setAttribute("disabled", "disabled");
} else {
btnFirst.onclick = function(){ zenPage.getComponent(compIndex).showPage("first") };
btnPrev.onclick = function(){ zenPage.getComponent(compIndex).showPage("prev") };
}
if(this.currentPage == totalPages) {
btnNext.setAttribute("disabled", "disabled");
btnLast.setAttribute("disabled", "disabled");
} else {
btnNext.onclick = function(){ zenPage.getComponent(compIndex).showPage("next") };
btnLast.onclick = function(){ zenPage.getComponent(compIndex).showPage("last") };
}
var pageIndex = this.currentPage;
if(pageIndex <= 5) {
pageIndex = 1;
} else {
var mod = (pageIndex % 5);
if(mod > 0)
pageIndex -= mod - 1;
else
pageIndex -= 4;
}
var totalBtnPage = 0;
while(totalBtnPage < 5 && pageIndex <= totalPages) {	//pode ter no, máximo, 5 botões no navegador
var btnPage = document.createElement("input");
btnPage.className = "jsonTable__nav__button";
btnPage.setAttribute("type", "button");
btnPage.setAttribute("value", pageIndex);
if(pageIndex == this.currentPage) {
btnPage.className = "jsonTable__nav__button--active";
btnPage.setAttribute("disabled", "disabled");
} else {
btnPage.onclick = new Function("zenPage.getComponent("+compIndex+").showPage("+pageIndex+")");
}
divContainer.appendChild(btnPage);
pageIndex++;
totalBtnPage++;
}
}
divContainer.appendChild(btnNext);
divContainer.appendChild(btnLast);
var compResultados = [];
if(this.resultados){
compResultados.push(this.criarResultados());
}
if(this.resultadosPorPagina){
compResultados.push(this.criarResultadosPorPagina());
}
if(compResultados.length){
var divContainerResultados = document.createElement("div");
divContainerResultados.className = "clearfix boxForm";
divContainerResultados.style.cssText = "padding:0; border:0; background:transparent; width:300px;";
if(this.navigatorPosition == "left"){
divContainerResultados.style.marginLeft = "250px";
}
for(var i = 0; i < compResultados.length; i++){
divContainerResultados.appendChild(compResultados[i]);
}
enclosingNav.appendChild(divContainerResultados);
}
this.resizeHeaders();
}

self.s00_componente_interface_scsJsonTable_drawRow = function(pData) {
var rowId = "";
if(this.idColumn != "") {
var rowId = pData[this.idColumn];
}
if(rowId != "") {
rowId = "tr_"+this.id+"_"+rowId;
} else {
rowId = "tr_"+this.id+"_"+this.jsonContent.length;
}
pData["_rowId"] = rowId;	//Utilizando o prefixo "_" para evitar coincidir com uma propriedade do jSON
this.jsonContent.push(pData);
this.jsonContentInternal.push(pData);
var tbody = document.getElementById("tbody_"+this.id);
if(this.pageSize > 0 && tbody.rows.length >= this.pageSize) return;	//Para não apresentar mais linhas na página do que a quantidade definida
var initialPos = 0;
if(this.pageSize > 0 && this.currentPage > 1) {
initialPos = this.pageSize * this.currentPage;
}
if(this.jsonContent.length < initialPos) return;	//se a quantidade de itens ainda não for a necessária para exibir o conteúdo, não apresenta linhas
var index = this.index;
var newRow = tbody.insertRow(tbody.rows.length);
newRow.id = rowId;
if(this.showZebra){
if(tbody.rows.length % 2 == 0)
newRow.className += " odd";
}else{
newRow.className += " border";
}
if(this.rowHover) newRow.classList.add("use-hover");
if(this.rowSelect) {
newRow.onclick = function() {zenPage.getComponent(index).selectRow(this);}
newRow.ondblclick = function(){zenPage.getComponent(index).dblClick(this);}
}
if(this.rowFormatProperty && this.rowFormatProperty != "") {
if(pData[this.rowFormatProperty])
newRow.className += " "+this.rowFormatClass;
}
var headerCols = this.columns;
var totalCols = headerCols.length;
var cellIndex = 0;
if(this.sortable){
var newCell = newRow.insertCell(cellIndex);
cellIndex++;
var imgSort = document.createElement("img");
imgSort.setAttribute("src", "img/icons/arrows.gif");
imgSort.setAttribute("height", "12");
imgSort.setAttribute("width", "9");
imgSort.setAttribute("name", "sortColumn");
imgSort.setAttribute("alt", this.sortColumnTitle);
imgSort.setAttribute("title", this.sortColumnTitle);
imgSort.style.cursor = "move";
newCell.className = "jsonTable__body__column"+this.mini+" jsonTable__body__column--icon";
newCell.setAttribute("align", "center");
newCell.appendChild(imgSort);
}
var iLastData = this.jsonContent.length - 2;
if(this.multiSelect){
var drawms = true;
if((this.groupMultiSelectColumnName != "")&&(this.jsonContent.length > 1)){
var iCol = _.indexOf(headerCols,_.findWhere(headerCols,{colName: this.groupMultiSelectColumnName}))
var iRowSpan = this.applyGroupRow(iCol,pData,iLastData,(this.jsonContent.length - 1));
if((iRowSpan.toString() != "")&&(iRowSpan >= 0)){
var td = document.getElementById("tr_"+this.getIdEscaped()+"_"+iRowSpan+"_multiSelect");
if(td) td.rowSpan = td.rowSpan + 1;
if(td.className.indexOf("not-select") == -1) td.className += " not-select";
drawms = false;
}
}
if(drawms){
var desabilitarCheck = 0;
if ((this.CheckDisabledPropertyName != "") && (pData[this.CheckDisabledPropertyName] != null)) var desabilitarCheck = pData[this.CheckDisabledPropertyName]
var checked = pData["selected"] == true ? true : false;
var newCell = newRow.insertCell(cellIndex);
newCell.setAttribute("id",rowId+"_multiSelect");
cellIndex++;
this.drawMultiSelect(newCell,checked,desabilitarCheck,newRow.id);
}
}
for(var i = 0;i<totalCols;i++){
var col = headerCols[i];
if((col.colName != "")&&(pData[col.colName] == null)) continue;
if((col.groupRow)&&(this.jsonContent.length > 1)){
var iRowSpan = this.applyGroupRow(i,pData,iLastData,(this.jsonContent.length - 1));
if((iRowSpan.toString() != "")&&(iRowSpan >= 0)){
var td = document.getElementById("tr_"+this.getIdEscaped()+"_"+iRowSpan+"_"+i);
if(td) td.rowSpan = td.rowSpan + 1;
if(td.className.indexOf("not-select") == -1) td.className += " not-select";
continue;
}
}
var newCell = newRow.insertCell(cellIndex);
newCell.id = rowId+"_"+i;
newCell.setAttribute("id",rowId+"_"+i);
newCell.row = tbody.rows.length;
newCell.col = i.toString();
cellIndex++;
this.drawColumn(newCell, col, pData);
}
if(this.showDeleteColumn){
var newCell = newRow.insertCell(cellIndex);
cellIndex++;
this.drawDeleteButtonRow(newCell);
}
}

self.s00_componente_interface_scsJsonTable_drawTable = function() {
var mini = "";
if(this.miniRow){
mini = "--mini"
}
$("#tbody_"+this.getIdEscaped()+" > tr").remove();
var tbody = document.getElementById("tbody_"+this.id);
var total		= this.jsonContentInternal.length;
var headerCols	= this.columns;
var totalCols	= headerCols.length;
var compIndex	= this.index;
var initialPos	= 0;
var initialPos = 0;
if(this.pageSize > 0 && this.currentPage > 1) {
initialPos = this.pageSize * (this.currentPage - 1);
}
var allChecked = $("#chk_"+this.getIdEscaped()).attr("checked");
if(allChecked)
this.selectAll(true,0);
for(var j=0; j<totalCols; j++){
var col = headerCols[j];
if(col.onDrawHeader != ""){
var indiceColuna = (j+1);
var th = document.getElementById("thCol_"+indiceColuna+"_"+this.index);
if (typeof(th) != "undefined") th.innerHTML = this.getContexto()[col.onDrawHeader]();
}
}
for(var i=0; i<total;i++) {
if(i < initialPos) continue;
var cellIndex = 0;
if(tbody.rows && this.pageSize > 0 && tbody.rows.length >= this.pageSize) break;
var dataInfo = this.jsonContentInternal[i];
var newRow = tbody.insertRow(tbody.rows.length);
newRow.id = dataInfo["_rowId"];
if(this.showZebra) {
if(i % 2 > 0)
newRow.className += " odd";
newRow.className += " border2";
}else{
newRow.className += " border";
}
if(this.rowHover) newRow.className += " use-hover";
if(this.rowSelect) {
newRow.onclick = function() {zenPage.getComponent(compIndex).selectRow(this);}
newRow.ondblclick = function(){zenPage.getComponent(compIndex).dblClick(this);}
}
if(this.rowFormatProperty && this.rowFormatProperty != "") {
if(dataInfo[this.rowFormatProperty])
newRow.className += " "+this.rowFormatClass;
}
if(this.sortable){
var newCell = newRow.insertCell(cellIndex);
cellIndex++;
var imgSort = document.createElement("img");
imgSort.setAttribute("src", "img/icons/arrows.gif");
imgSort.setAttribute("height", "12");
imgSort.setAttribute("width", "9");
imgSort.setAttribute("name", "sortColumn");
imgSort.setAttribute("alt", this.sortColumnTitle);
imgSort.setAttribute("title", this.sortColumnTitle);
imgSort.style.cursor = "move";
newCell.className = "jsonTable__body__column"+mini+" jsonTable__body__column--icon";
newCell.setAttribute("align", "center");
newCell.appendChild(imgSort);
}
var iLastData = i-1;
if(this.multiSelect){
var drawms = true;
if((this.groupMultiSelectColumnName != "")&&(i>0)){
var iCol = _.indexOf(headerCols,_.findWhere(headerCols,{colName: this.groupMultiSelectColumnName}));
var iRowSpan = this.applyGroupRow(iCol,dataInfo,iLastData,i);
if((iRowSpan.toString() != "")&&(iRowSpan >= 0)){
iRowSpan = iRowSpan-initialPos;
var tr = tbody.rows[iRowSpan];
if(tr) td = tr.children[cellIndex+1];
if(td){
td.rowSpan = td.rowSpan + 1;
if(td.className.indexOf("not-select") == -1) td.className += " not-select";
}
drawms = false;
}
}
if(drawms){
var desabilitarCheck = 0;
if ((this.CheckDisabledPropertyName != "") && (dataInfo[this.CheckDisabledPropertyName] != null)) var desabilitarCheck = dataInfo[this.CheckDisabledPropertyName]
var checked = dataInfo["selected"] == true ? true : false;
var newCell = newRow.insertCell(cellIndex);
newCell.setAttribute("id",dataInfo["_rowId"]+"_multiSelect");
cellIndex++;
this.drawMultiSelect(newCell,checked,desabilitarCheck, newRow.id);
}
}
var extraCols = cellIndex;
for(var j=0; j<totalCols; j++){
var col = headerCols[j];
if((col.groupRow)&&(i>0)){
var iRowSpan = this.applyGroupRow(j,dataInfo,iLastData,i);
if((iRowSpan.toString() != "")&&(iRowSpan >= 0)){
iRowSpan = iRowSpan-initialPos;
var tr = tbody.rows[iRowSpan];
if(tr) td = tr.children[extraCols+j];
if(td){
td.rowSpan = td.rowSpan + 1;
if(td.className.indexOf("not-select") == -1) td.className += " not-select";
}
continue;
}
}
var newCell = newRow.insertCell(cellIndex);
newCell.row = i;
newCell.col = j;
newCell.id = dataInfo["_rowId"]+"_"+i;
newCell.setAttribute("id",dataInfo["_rowId"]+"_"+i);
if(col.groupRow){
newCell.rowSpan = 1;
if(newCell.className.indexOf("not-select") == -1) newCell.className += " not-select";
}
cellIndex++;
this.drawColumn(newCell, col, dataInfo);
}
if(this.showDeleteColumn){
var newCell = newRow.insertCell(cellIndex);
cellIndex++;
this.drawDeleteButtonRow(newCell);
}
cellIndex = 0;
}
this.verifyAllSelected();
this.drawNavigator();
}

self.s00_componente_interface_scsJsonTable_drawText = function(newCell,col,dataInfo) {
var divTextContainer = document.createElement("div");
divTextContainer.className = "jsonTable__body__container-button"
newCell.appendChild(divTextContainer);
var totalText = col.texts.length;
for(var k=0; k<totalText; k++) {
var textDef = col.texts[k];
var divText = this.drawTextItem(textDef,col,dataInfo);
divTextContainer.appendChild(divText);
}
}

self.s00_componente_interface_scsJsonTable_drawTextData = function(newCell,col,dataInfo) {
var divTextContainer = document.createElement("div");
divTextContainer.className = "jsonTable__body__container-button"
newCell.appendChild(divTextContainer);
var totalText = col.textsData.length;
for(var k=0;k<totalText;k++) {
var textDataDef = col.textsData[k];
var divText = this.drawTextDataItem(newCell,textDataDef,col,dataInfo);
divTextContainer.appendChild(divText);
}
}

self.s00_componente_interface_scsJsonTable_drawTextDataItem = function(newCell,data,col,dataInfo) {
var divText = document.createElement("div");
divText.className = col.textClass;
divText.style.cssText = col.textStyle;
var textData = zenPage.createComponentNS("http://www.e-lis.com.br/zen","scsCalendarData");
textData.size = 10;
textData.scsAcima = 1;
textData.composite = this.composite;
textData.AnoAtual = this.AnoAtual;
if(data.valueProperty != "" && (data.onchange == "" || data.onchange == null) && col.drawTypeColumn != ""){
textData.aux = dataInfo;
textData.setProperty("onchange", "zenPage.getComponent('" + this.index + "').inserirDataJson(zenThis,'" + this.index + "');");
if(dataInfo[data.valueProperty]){
textData.value = dataInfo[data.valueProperty];
}
}else if(dataInfo[col.valueProperty]){
textData.value = dataInfo[col.valueProperty];
}else{
if(dataInfo[col.colName]){
textData.value = dataInfo[col.colName];
}else{
textData.value = "";
}
}
textData.aux = {
"jsonTextData":data,
"data":dataInfo,
"component":textData
};
if (data.onchange != "" && data.onchange != null){
textData.onchange =
"var d = zenThis.aux; "+
"(function(){"+
data.onchange+
"})(d.jsonTextData, d.data, d.component)";
}
var textDataIndex = textData.index;
divText.setAttribute("zenIndex", textDataIndex);
textData = textData.renderContents();
divText.appendChild(textData);
return divText;
}

self.s00_componente_interface_scsJsonTable_drawTextHoraItem = function(newCell,hora,col,dataInfo) {
var divText = document.createElement("div");
divText.className = col.textClass;
divText.style.cssText = col.textStyle;
var text = document.createElement("input");
text.id = "time_"+this.index;
text.type = "text";
text.className = (col.controlClass == "") ? "text" : col.controlClass;
text.size = 8;
text.maxlength = 8;
text.composite = this.composite;
if(hora.valueProperty != "" && (hora.onchange == "" || hora.onchange == null) && col.drawTypeColumn != ""){
text.aux = dataInfo;
text.onchange =  new Function("zenPage.getComponent('" + this.index + "').inserirHoraJson(this,'" + this.index + "');");
if(dataInfo[hora.valueProperty]){
text.value = dataInfo[hora.valueProperty];
}
}
/*else if(dataInfo[col.valueProperty]){
text.value = dataInfo[col.valueProperty];
}else{
if(dataInfo[col.colName]){
text.value = dataInfo[col.colName];
}else{
text.value = "";
}
}
*/
text.style.cssText = col.controlStyle;
divText.appendChild(text);
return divText;
}

self.s00_componente_interface_scsJsonTable_drawTextInteiro = function(newCell,col,dataInfo) {
var divTextContainer = document.createElement("div");
divTextContainer.className = "jsonTable__body__container-button"
newCell.appendChild(divTextContainer);
var totalText = col.textsInteiro.length;
for(var k=0; k<totalText; k++) {
var textInteiroDef = col.textsInteiro[k];
var divText = this.drawTextInteiroItem(textInteiroDef,col,dataInfo);
divTextContainer.appendChild(divText);
}
}

self.s00_componente_interface_scsJsonTable_drawTextInteiroItem = function(textInteiroDef,col,dataInfo) {
var divText = document.createElement("div");
divText.className = textInteiroDef.textClass;
divText.style.cssText = textInteiroDef.textStyle;
var textInteiro = zenPage.createComponentNS("http://www.e-lis.com.br/zen","scsTextInteiro");
if(textInteiroDef.size){
textInteiro.size = textInteiroDef.size;
}else{
textInteiro.size = 10;
}
textInteiro.valorMinimo = textInteiroDef.valorMinimo;
textInteiro.valorMaximo = textInteiroDef.valorMaximo;
textInteiro.controlStyle = textInteiroDef.controlStyle;
textInteiro = textInteiro.renderContents();
textInteiro.composite = this.composite;
if(textInteiroDef.valueProperty != "" && (textInteiroDef.onchange == "" || textInteiroDef.onchange == null)){
textInteiro.onchange = function(){ dataInfo[textInteiroDef.valueProperty] = parseInt(this.value); };
if(dataInfo[textInteiroDef.valueProperty]){
textInteiro.value = dataInfo[textInteiroDef.valueProperty];
}
}else if(dataInfo[col.valueProperty]){
textInteiro.value = dataInfo[col.valueProperty];
}else{
if(dataInfo[col.colName]){
textInteiro.value = dataInfo[col.colName];
}else{
textInteiro.value = "";
}
}
divText.appendChild(textInteiro);
if (textInteiroDef.onchange != "" && textInteiroDef.onchange != null){
(function(pTextInteiroDef, pTextInteiro, pDataInfo){
textInteiro.onchange =
function(){
zenInvokeCallbackMethod(pTextInteiroDef.onchange,this,'onchange',"jsonTextInteiro",textInteiroDef,"data",pDataInfo,"componentHTML",pTextInteiro);
}
})(textInteiroDef, textInteiro, dataInfo);
}
return divText;
}

self.s00_componente_interface_scsJsonTable_drawTextItem = function(textDef,col,dataInfo) {
var divText = document.createElement("div");
divText.className = textDef.textClass;
divText.style.cssText = textDef.textStyle;
var text = document.createElement("input");
text.id = "control_"+this.index;
text.name = textDef.name;
text.type = "text";
text.className = (textDef.controlClass == "") ? "text" : textDef.controlClass;
if(textDef.size){
text.size = textDef.size;
}else{
text.size = 10;
}
text.maxLength = textDef.maxLength ? textDef.maxLength : 25;
text.composite = this.composite;
if(textDef.valueProperty != "" && (textDef.onchange == "" || textDef.onchange == null)){
text.onchange = function(){ dataInfo[textDef.valueProperty] = this.value; };
if(dataInfo[textDef.valueProperty]){
text.value = dataInfo[textDef.valueProperty];
}
}else if(dataInfo[col.valueProperty]){
text.value = dataInfo[col.valueProperty];
}else{
if(dataInfo[col.colName]){
text.value = dataInfo[col.colName];
}else{
text.value = "";
}
}
text.style.cssText = textDef.controlStyle;
divText.appendChild(text);
if (textDef.onchange != "" && textDef.onchange != null){
(function(pTextDef, pText, pDataInfo){
text.onchange =
function(){
zenInvokeCallbackMethod(pTextDef.onchange,this,'onchange',"jsonText",textDef,"data",pDataInfo,"componentHTML",pText);
}
})(textDef, text, dataInfo);
}
if (textDef.onkeypress != "" && textDef.onkeypress != null){
(function(pTextDef, pText, pDataInfo){
text.onkeypress =
function(event){
zenInvokeCallbackMethod(pTextDef.onkeypress,this,'onkeypress',"event",event);
}
})(textDef);
}
return divText;
}

self.s00_componente_interface_scsJsonTable_drawTextMoeda = function(newCell,col,dataInfo) {
var divTextContainer = document.createElement("div");
divTextContainer.className = "jsonTable__body__container-button"
newCell.appendChild(divTextContainer);
var totalText = col.textsMoeda.length;
for(var k=0; k<totalText; k++) {
var textMoedaDef = col.textsMoeda[k];
var divText = this.drawTextMoedaItem(textMoedaDef,col,dataInfo);
divTextContainer.appendChild(divText);
}
}

self.s00_componente_interface_scsJsonTable_drawTextMoedaItem = function(textMoedaDef,col,dataInfo) {
var divText = document.createElement("div");
divText.className = textMoedaDef.textClass;
divText.style.cssText = textMoedaDef.textStyle;
var textMoeda = zenPage.createComponentNS("http://www.e-lis.com.br/zen","scsTextMoeda");
if(textMoedaDef.size){
textMoeda.size = textMoedaDef.size;
}else{
textMoeda.size = 10;
}
if (textMoedaDef.casasDecimais != "") textMoeda.casasDecimais = textMoedaDef.casasDecimais;
if (textMoedaDef.valorMinimo != "") textMoeda.valorMinimo = textMoedaDef.valorMinimo;
if (textMoedaDef.valorMaximo != "") textMoeda.valorMaximo = textMoedaDef.valorMaximo;
if (textMoedaDef.positivo != "") textMoeda.positivo = textMoedaDef.positivo;
var compMoeda = textMoeda;
textMoeda = textMoeda.renderContents();
textMoeda.composite = this.composite;
if(textMoedaDef.valueProperty != "" && (textMoedaDef.onchange == "" || textMoedaDef.onchange == null)){
textMoeda.onchange = function(){
dataInfo[textMoedaDef.valueProperty] = this.getValue();
};
if(dataInfo[textMoedaDef.valueProperty]){
textMoeda.value = dataInfo[textMoedaDef.valueProperty];
}
}else if(dataInfo[col.valueProperty]){
textMoeda.value = dataInfo[col.valueProperty];
}else{
if(dataInfo[col.colName]){
textMoeda.value = dataInfo[col.colName];
}else{
textMoeda.value = "";
}
}
if (textMoeda.value != "") textMoeda.value = compMoeda.valorLogicalToDisplay(textMoeda.value);
divText.appendChild(textMoeda);
if (textMoedaDef.onchange != "" && textMoedaDef.onchange != null){
(function(pTextMoedaDef, pTextMoeda, pDataInfo){
textMoeda.onchange =
function(){
if(pTextMoedaDef.valueProperty != "") pDataInfo[pTextMoedaDef.valueProperty] = zenThis.value;
zenInvokeCallbackMethod(pTextMoedaDef.onchange,this,'onchange',"jsonTextMoeda",textMoedaDef,"data",pDataInfo,"componentHTML",pTextMoeda);
}
})(textMoedaDef, textMoeda, dataInfo);
}
return divText;
}

self.s00_componente_interface_scsJsonTable_filter = function() {
var colName				= "";
var filterType			= "";
var filterValue			= "";
this.jsonContentInternal= this.jsonContent.slice();
var arrayFilters = $("#thead_"+this.getIdEscaped()+" input.jsonTable__header__filter, #thead_"+this.getIdEscaped()+" select.jsonTable__header__filter");
var totalFilters = arrayFilters.length;
var curFilter	 = null;
for(var i=0; i<totalFilters; i++) {
curFilter	= $(arrayFilters[i]);
colName		= curFilter.attr("colName");
filterType	= curFilter.attr("filterType");
filterValue	= curFilter.val().toLowerCase();
if(filterValue == "") continue;
switch(filterType) {
case "LIKE": {
this.jsonContentInternal = _.filter(this.jsonContentInternal, function(obj) {
if(typeof obj[colName] == "string")
return obj[colName].toLowerCase().indexOf(filterValue) > -1;
else{
if(obj[colName] && obj[colName].toString){
return obj[colName].toString().toLowerCase().indexOf(filterValue) > -1;
}else{
return false;
}
}
});
break;
}
case "STARTSWITH": {
this.jsonContentInternal = _.filter(this.jsonContentInternal, function(obj) {
if(typeof obj[colName] == "string")
return obj[colName].toLowerCase().indexOf(filterValue) == 0;
else{
if(obj[colName] && obj[colName].toString){
return obj[colName].toString().toLowerCase().indexOf(filterValue) == 0;
}else{
return false;
}
}
});
break;
}
case "EQUAL": {
this.jsonContentInternal = _.filter(this.jsonContentInternal, function(obj) {
if(typeof obj[colName] == "string")
return obj[colName].toLowerCase() == filterValue;
else{
if(obj[colName] && obj[colName].toString){
return obj[colName].toString().toLowerCase() == filterValue;
}else{
return obj[colName] == filterValue;
}
}
});
break;
}
case "MAIORIGUALQUE": {
this.jsonContentInternal = _.filter(this.jsonContentInternal, function(obj) {
if(typeof obj[colName] == "string")
return obj[colName].toLowerCase() >= filterValue;
else{
if(obj[colName] && obj[colName].toString){
return obj[colName].toString().toLowerCase() >= filterValue;
}else{
return obj[colName] >= filterValue;
}
}
});
break;
}
case "MENORIGUALQUE": {
this.jsonContentInternal = _.filter(this.jsonContentInternal, function(obj) {
if(typeof obj[colName] == "string")
return obj[colName].toLowerCase() <= filterValue;
else{
if(obj[colName] && obj[colName].toString){
return obj[colName].toString().toLowerCase() <= filterValue;
}else{
return obj[colName] <= filterValue;
}
}
});
break;
}
default:
break;
}
}
this.currentPage = 1;
this.drawTable();
}

self.s00_componente_interface_scsJsonTable_filtrarHora = function(pPeriodo,pId,pId2) {
var zsm = zenSynchronousMode;
zenSynchronousMode = true;
var componenteFiltro = document.getElementById(pId);
var valor = componenteFiltro.value;
var v = this.shiftParseTime(valor);
if ((-1 == v) || (v == null)) {
valor = "";
/*zenPage.alertaShift(this.invalidTimeMessage);*/
componenteFiltro.value = ""
componenteFiltro.focus();
return false;
} else {
valor = v;
}
var novoValor = this.formatarValor(valor);
componenteFiltro.value = novoValor;
if (parseInt(pPeriodo)){
var componenteFiltro2 = document.getElementById(pId2);
if ((componenteFiltro.value == "") && (componenteFiltro2.value != "") || ((componenteFiltro.value != "") && (componenteFiltro2.value == ""))){
return false;
}
var valor2 = componenteFiltro2.value;
var v2 = this.shiftParseTime(valor2);
if ((-1 == v2) || (v2 == null)) {
valor2 = "";
/*zenPage.alertaShift(this.invalidTimeMessage);*/
componenteFiltro2.value = ""
componenteFiltro2.focus();
return false;
} else {
valor2 = v2;
}
var novoValor2 = this.formatarValor(valor2);
componenteFiltro2.value = novoValor2;
}
this.filter();
zenSynchronousMode = zsm;
}

self.s00_componente_interface_scsJsonTable_focus = function() {
if(this.rowSelect) {
var pInput = document.getElementById("jsonTableUseKeys_"+this.index);
pInput.focus();
}
}

self.s00_componente_interface_scsJsonTable_formatarCampo = function(pValor) {
if ((pValor != undefined) && (pValor != "")){
var pass = pValor;
}else{
var val = this.findElement('control');
var pass = val.value;
}
val.value = this.formatarValor(pass);
}

self.s00_componente_interface_scsJsonTable_formatarHora = function(pId) {
var zsm = zenSynchronousMode;
zenSynchronousMode = true;
var componenteHora = document.getElementById(pId);
var horaDigitada = componenteHora.value;
var horaFormatada = this.shiftParseTime(horaDigitada);
if ((-1 == horaFormatada) || (horaFormatada == null)) {
valor = "";
componenteHora.value = ""
componenteHora.focus();
return false;
}
var horaFormatada = this.formatarValor(horaFormatada);
componenteHora.value = horaFormatada;
zenSynchronousMode = zsm;
}

self.s00_componente_interface_scsJsonTable_formatarValor = function(pValor) {
var expr = /[0123456789]/;
var valor = pValor;
for(i=0; i<valor.length; i++){
var lchar = pValor.charAt(i);
var nchar = pValor.charAt(i+1);
if(i==0){
if ((lchar.search(expr) != 0) || (lchar>2)){
pValor = "";
}
}else if(i==1){
if(lchar.search(expr) != 0){
var tst1 = pValor.substring(0,(i));
pValor = tst1;
continue;
}
if ((nchar != ':') && (nchar != '')){
var tst1 = pValor.substring(0, (i)+1);
if(nchar.search(expr) != 0)
var tst2 = pValor.substring(i+2, valor.length);
else
var tst2 = pValor.substring(i+1, valor.length);
pValor = tst1 + ':' + tst2;
}
}else if(i==4){
if(lchar.search(expr) != 0){
var tst1 = pValor.substring(0, (i));
pValor = tst1;
continue;
}
if	((nchar != ':') && (nchar != '')){
var tst1 = pValor.substring(0, (i)+1);
if(nchar.search(expr) != 0)
var tst2 = pValor.substring(i+2, valor.length);
else
var tst2 = pValor.substring(i+1, valor.length);
pValor = tst1 + ':' + tst2;
}
}
if(i>=6){
if(lchar.search(expr) != 0) {
var tst1 = pValor.substring(0, (i));
pValor = tst1;
}
}
}
if(valor.length>8){
pValor = pValor.substring(0, 8);
}
return pValor;
}

self.s00_componente_interface_scsJsonTable_getContainer = function(newCell,col,dataInfo,className) {
var container = document.createElement("div");
container.className = className;
return container;
}

self.s00_componente_interface_scsJsonTable_getContexto = function() {
try{
if (this.composite)
return this.composite
else
return zenPage
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsJsonTable_getDiv = function(newCell,col,dataInfo,comp) {
var div = document.createElement("div");
if((comp.title != undefined)&&(comp.title != "")) div.setAttribute("title", comp.title);
if(comp.enclosingClass != "") div.className = comp.enclosingClass;
if(comp.width != "") div.style.width = comp.width;
if(comp.enclosingStyle != "") div.style.cssText = comp.enclosingStyle;
if(comp.hiddenProperty != "" && dataInfo[comp.hiddenProperty]) {
div.style.display = "none";
}
return div;
}

self.s00_componente_interface_scsJsonTable_getHeightLocal = function() {
var alturaDiv = localStorage.getItem("alturaDiv");
if(alturaDiv != undefined) {
alturaDiv = JSON.parse(alturaDiv);
var url = window.location.href;
url = url.split("/");
var nomeClasse = url[url.length-1].split("?")[0];
var pIdElemento = "scsJsonTable_body_"+this.index;
if(alturaDiv[nomeClasse+"-"+pIdElemento] != undefined) {
document.getElementById(pIdElemento).style.height = alturaDiv[nomeClasse+"-"+pIdElemento] + "px";
}
}
}

self.s00_componente_interface_scsJsonTable_getIdEscaped = function() {
var retorno = "";
try{
retorno = this.id;
retorno = retorno.replace(/\./g,"\\.");
}catch(ex){
zenPage.exibirExcecao(ex);
retorno = false;
}
return retorno;
}

self.s00_componente_interface_scsJsonTable_getJsonCheck = function(row,col,id) {
if(!id) id = "";
return document.getElementById("jsonCheck_"+this.getIdEscaped()+"_"+row+"_"+col+"_"+id);
}

self.s00_componente_interface_scsJsonTable_getOrderedContent = function() {
if(!this.sortable) {
return this.jsonContent;
}
var arrayJson	= [];
var arrayOrder	= $("#tbody_"+this.getIdEscaped()).sortable("toArray");
for(var i=0; i < arrayOrder.length; i++) {
var content = _.findWhere(this.jsonContent,{_rowId: arrayOrder[i]});
arrayJson.push(content);
}
return arrayJson;
}

self.s00_componente_interface_scsJsonTable_getPageContents = function() {
var initialPos = 0;
if(this.currentPage > 1){
initialPos = this.pageSize * (this.currentPage - 1);
}
var endPos = initialPos + parseInt(this.pageSize,10);
var page = this.jsonContent.slice(initialPos,endPos);
return page;
}

self.s00_componente_interface_scsJsonTable_getQtdRegistroPaginaLocal = function() {
var retorno = this.getProperty("pageSize");
var registrosPorPagina = localStorage.getItem("registrosPorPagina");
if(registrosPorPagina != undefined) {
registrosPorPagina = JSON.parse(registrosPorPagina);
var url = window.location.href;
url = url.split("/");
var nomeClasse = url[url.length-1].split("?")[0];
var pIdElemento = "selectPageSize"+this.index;
if(registrosPorPagina[nomeClasse+"-"+pIdElemento] != undefined) {
retorno = registrosPorPagina[nomeClasse+"-"+pIdElemento];
}
}
return retorno;
}

self.s00_componente_interface_scsJsonTable_getSelectedId = function() {
if(this.idColumn == ""){ alert("idColumn undefined on scsJsonTable:"+this.id); return; }
return _.pluck(_.where(this.jsonContentInternal,{selected:true}),this.idColumn);
}

self.s00_componente_interface_scsJsonTable_getSelectedList = function() {
return _.where(this.jsonContentInternal,{selected:true})
}

self.s00_componente_interface_scsJsonTable_getSelectedRow = function() {
try {
var row = $("#tbody_"+this.getIdEscaped()+" > tr.selected")[0];
if(!row) return;
var rowId = row.id;
var infoJson = _.findWhere(this.jsonContentInternal, {_rowId: rowId});
if(infoJson) return infoJson;
} catch (ex) {
zenPage.alertaShift("clearFocusUseKeys(): "+zenPage.getMsgExcecao(ex));
}
}

self.s00_componente_interface_scsJsonTable_getTotalPages = function() {
if(this.pageSize <= 0) return 1;
var totalPages = parseInt(this.jsonContentInternal.length / this.pageSize, 10);
if((this.jsonContentInternal.length % this.pageSize) > 0)
totalPages++;
return totalPages;
}

self.s00_componente_interface_scsJsonTable_inserirDataJson = function(pComponente,pJsonTable) {
pComponente.aux.data[pComponente.aux.data.drawDef.valueProperty] = pComponente.value;
}

self.s00_componente_interface_scsJsonTable_inserirHoraJson = function(pComponente,pJsonTable) {
zenPage.getComponent(pJsonTable).formatarHora(pComponente.id);
pComponente.aux[pComponente.aux.drawDef.valueProperty] = pComponente.value;
}

self.s00_componente_interface_scsJsonTable_inserirValorFloatJson = function(pComponente,pJsonTable) {
pComponente.aux.data[pComponente.aux.data.drawDef.valueProperty] = pComponente.value;
}

self.s00_componente_interface_scsJsonTable_isValid = function() {
var value = this.getValue();
if ('' == value) return true;
var strRegex = /^([0-1]{1}[0-9]{1}|[2]{1}[0-3]{1}):[0-5]{1}[0-9]{1}:[0-9]{2}$/;
var retorno = strRegex.test(value);
if (!retorno) return false;
var d = this.shiftParseTime(value);
if (-1 == d) return false;
return true;
}

self.s00_componente_interface_scsJsonTable_keyDownUseKeys = function(pEvent,pInput) {
try{
if(!pEvent || pEvent == undefined) return true;
var linhaAtual = parseInt(pInput.getAttribute("rowfocus"));
var tbody = document.getElementById("tbody_"+ this.id);
var linhaAntiga = document.querySelector("#tbody_" + this.id + ' .rowFocus');
if(!linhaAntiga || linhaAntiga == undefined) {
linhaAntiga = document.querySelector("#tbody_" + this.id + ' > tr.selected')
if(linhaAntiga && linhaAntiga != undefined) {
linhaAtual = linhaAntiga.rowIndex;
pInput.setAttribute("rowfocus",linhaAntiga.rowIndex);
}
}
if(tbody.children.length == 0) {
var primeiroFiltro = document.querySelector("#thead_"+this.id+" .jsonTable__header__filter");
if(primeiroFiltro && primeiroFiltro != undefined) {
primeiroFiltro.focus();
pInput.setAttribute("rowfocus",-1);
}
return true;
}
if(pEvent.keyCode == 40) {
if(tbody.children.length > linhaAtual) {
linhaAtual++;
var linhaFocus = tbody.children[linhaAtual];
if(linhaFocus && (linhaFocus != undefined)) {
if(linhaAntiga && (linhaAntiga != undefined)) linhaAntiga.classList.remove('rowFocus');
linhaFocus.classList.add('rowFocus');
pInput.setAttribute("rowfocus",linhaAtual);
}
}
} else if (pEvent.keyCode == 38) {
linhaAtual--;
var linhaFocus = tbody.children[linhaAtual];
if(linhaFocus && (linhaFocus != undefined)) {
if(linhaAntiga && (linhaAntiga != undefined)) linhaAntiga.classList.remove('rowFocus');
linhaFocus.classList.add('rowFocus');
pInput.setAttribute("rowfocus",linhaAtual);
} else {
var primeiroFiltro = document.querySelector("#thead_"+this.id+" .jsonTable__header__filter");
if(primeiroFiltro && primeiroFiltro != undefined) {
primeiroFiltro.focus();
linhaAntiga.classList.remove('rowFocus');
pInput.setAttribute("rowfocus",-1);
}
}
} else if (pEvent.keyCode == 13) {
linhaAntiga.click();
pEvent.preventDefault();
} else if(pEvent.keyCode == 46) {
if(this.showDeleteColumn) {
var evento = { keyCode: 40};
linhaAntiga.lastChild.querySelector('input').click();
pInput.setAttribute("rowfocus",parseInt(pInput.getAttribute("rowfocus")) - 1);
if(tbody.children.length <= linhaAtual) {
pInput.setAttribute("rowfocus",parseInt(pInput.getAttribute("rowfocus")) - 1);
}
this.keyDownUseKeys(evento,pInput);
}
}
else if(this.scsShortcutKeys != '') {
var atalhos = this.scsShortcutKeys.split(',');
for(var i in atalhos) {
itemAtalho = atalhos[i].split(':');
var codigoTecla = zenPage.recuperarCodigoTecla(itemAtalho[0]);
if(pEvent.keyCode == codigoTecla) {
var el = document.querySelector("#"+linhaAntiga.id+" [name='"+itemAtalho[1]+"']");
if(el && el != undefined) {
el.click();
return true;
}
}
}
}
return true;
}
catch (ex) {
zenPage.alertaShift("keyDownUseKeys(): "+zenPage.getMsgExcecao(ex));
}
}

self.s00_componente_interface_scsJsonTable_manterColunasOrdenadas = function() {
var retorno = true;
try {
var seletor = $("#thead_"+this.getIdEscaped()+" .jsonTable__imgSort").parent();
if(seletor.length > 0) {
var coluna = seletor[0];
var order = coluna.getAttribute("order");
var colName = coluna.getAttribute("colname");
if((order === "asc") || (order === "desc")) {
if(order === "asc") {
this.jsonContentInternal = _.sortBy(this.jsonContentInternal, colName);
}else if(order === "desc") {
this.jsonContentInternal = _.sortBy(this.jsonContentInternal, colName);
this.jsonContentInternal.reverse();
}
this.drawTable();
}
}
}catch(ex) {
throw ex;
}
return retorno;
}

self.s00_componente_interface_scsJsonTable_onCreate = function() {
this.jsonContent = [];
this.jsonContentInternal = [];
if(this.currentPage <= 0)
this.currentPage = 1;
}

self.s00_componente_interface_scsJsonTable_onDisplayHandler = function() {
this.resizeHeaders();
}

self.s00_componente_interface_scsJsonTable_onRefreshContents = function() {
if(this.bodyResizable) {
this.getHeightLocal();
this.setResizable();
}
}

self.s00_componente_interface_scsJsonTable_ondatechangeHandler = function() {
var ctrl = this.findElement('control');
zenASSERT(ctrl,'Unable to find input element',arguments);
var v = this.shiftParseTime(ctrl.value);
if ((-1 == v) || (v == null)) {
ctrl.value = "";
zenPage.alertaShift(this.invalidTimeMessage);
} else {
ctrl.value = v;
}
this.onchangeHandler();
}

self.s00_componente_interface_scsJsonTable_onfocusJsonTableHandler = function() {
if(this.rowSelect) {
var evento = {
keyCode: 40,
};
var pInput = document.getElementById("jsonTableUseKeys_"+this.index);
this.keyDownUseKeys(evento,pInput);
}
}

self.s00_componente_interface_scsJsonTable_onloadHandler = function() {
this.onDisplayHandler();
if(isNaN(this.pageSize))
this.pageSize = 0;
if(this.navigator && this.pageSize <= 0)
this.pageSize = 10;
if(this.sortable) {
var tBodyId		= "#tbody_"+this.getIdEscaped();
var onSort		= this.onSort;
var showZebra	= this.showZebra;
var compIndex	= this.index;
$.ajax({
url: "js/jquery-ui.min.js",
dataType: "script",
async: true,
success: function() {
$(document).ready(function() {
$(tBodyId).sortable({
cursor: "move",
handle: "img[name='sortColumn']",
helper: function(evt, el) {
var helper = el.clone();
var originals = el.children();
helper.children().each(function(index){
$(this).width(originals.eq(index).width()).height(originals.eq(index).height());
});
return helper;
},
scrollSensitivity: 40,
scrollSpeed: 5,
axis: "y",
forcePlaceholderSize: true,
placeholder: "jsonTable__sortable--placeholder",
start: function(event, ui) {
$(this).attr("data-previous-pos", ui.item.index());
ui.placeholder.html("<td colspan='"+ui.item.children().length+"' style='height:"+ui.helper[0].offsetHeight+"px'>&#160;</td>")
ui.helper.removeClass("odd").addClass("jsonTable__sortable--helper");
},
stop: function(event, ui) {
var previousPos = $(this).attr("data-previous-pos");
var currentPos	= ui.item.index();
$(this).removeAttr("data-previous-pos");
if(showZebra) {
$(tBodyId+" tr:even").removeClass("odd");
$(tBodyId+" tr:odd").addClass("odd");
}
var jsonContent = zenPage.getComponent(compIndex).jsonContent;
var infoJson = _.findWhere(jsonContent,{_rowId: ui.item[0].id});
if(onSort != "") {
var ret = zenPage.getComponent(compIndex).getContexto()[onSort](infoJson, previousPos, currentPos);
if(ret != true) {
$(tBodyId).sortable("cancel");
if(showZebra) {
$(tBodyId+" tr:even").removeClass("odd");
$(tBodyId+" tr:odd").addClass("odd");
}
}
}
}
});
});
}
});
}
var self = this;
if(this.bodyResizable) {
var compIndex = this.index;
this.getHeightLocal();
if(zenPage.JqueryResizableCarregado == true) {
this.setResizable()
} else {
$.ajax({
url: "js/jquery-ui-resizable.js",
dataType: "script",
async: false,
success: function() {
$(document).ready(function() {
zenPage.JqueryResizableCarregado = true;
self.setResizable();
});
}
});
}
}
$(window).bind('resize', function(e) {
window.resizeEvt;
$(window).resize(function()
{
clearTimeout(window.resizeEvt);
window.resizeEvt = setTimeout(function()
{
self.resizeHeaders();
}, 200);
});
});
}

self.s00_componente_interface_scsJsonTable_removeId = function(pId) {
if(this.idColumn == ""){ alert("idColumn undefined on scsJsonTable:"+this.id); return; }
var arrayId = pId.toString().split(",");
var qtdIds = arrayId.length;
for (var cId=0;cId<qtdIds;cId++){
var idRemover = "tr_"+this.id+"_"+arrayId[cId];
this.jsonContent		= _.reject(this.jsonContent, {_rowId: idRemover});
this.jsonContentInternal= _.reject(this.jsonContentInternal, {_rowId: idRemover});
}
this.drawTable();
}

self.s00_componente_interface_scsJsonTable_removeRowButton = function(pButton) {
var rowId = pButton.parentElement.parentElement.parentElement.id;
var jsonData = _.findWhere(this.jsonContentInternal, {_rowId: rowId});
if(this.beforeDeleteRow != ""){
var ret = this.getContexto()[this.beforeDeleteRow](jsonData);
if(ret != true) return;
}
this.jsonContent		= _.reject(this.jsonContent, {_rowId: rowId});
this.jsonContentInternal= _.reject(this.jsonContentInternal, {_rowId: rowId});
this.drawTable();
if(this.onDeleteRow != "")
zenInvokeCallbackMethod(this.onDeleteRow,this,'onDeleteRow',"data",jsonData);
}

self.s00_componente_interface_scsJsonTable_removeRows = function() {
var tbody = document.getElementById("tbody_"+this.id);
while(tbody.rows.length>0){
tbody.deleteRow(tbody.rows.length-1);
}
}

self.s00_componente_interface_scsJsonTable_resizeHeaders = function() {
var enc = this.getEnclosingDiv();
enc.style.width = '';
if(enc.style.width != '') return 1
var tpHead = $(enc).find('.jsonTable__header')[0];
var tpAux = $(enc).find('.jsonTable__aux')[0]
var tpNav = $(enc).find('.jsonTable__enclosing-nav')[0];
var alturaCabecalho = 0;
if(this.showHeaders) {
var alturaCabecalho = $(enc).find('thead')[0].offsetHeight;
} else {
tpHead.style.display = 'none';
tpAux.style.display = 'none';
}
var tpBody = $(enc).find('.jsonTable__body')[0].children[0];
if(this.scrollBody == false) {
tpBody.style.overflowY = 'auto';
}
var clientW = tpBody.clientWidth;
var larguraRolagem = tpBody.offsetWidth - clientW;
if(larguraRolagem > 0) {
tpBody.children[0].children[0].style.width = '';
tpBody.style.marginRight = larguraRolagem*(-1) + 'px';
enc.style.marginRight = larguraRolagem + 'px';
if(tpNav) tpNav.style.marginRight = larguraRolagem*(-1) + 'px';
if(this.showHeaders) {
tpAux.style.right = larguraRolagem*(-1) + 'px';
tpAux.style.width = larguraRolagem + 'px';
if(alturaCabecalho > 0) {
tpAux.style.height = alturaCabecalho + 'px';
}
}
}
if(clientW > 0) {
if(alturaCabecalho > 0) {
tpHead.style.width = '';
tpHead.style.width = enc.offsetWidth + 'px';
}
tpBody.children[0].children[0].style.width = enc.offsetWidth + 'px';
}
return 1;
}

self.s00_componente_interface_scsJsonTable_salvarAlturaAtual = function(height) {
var alturaDiv = localStorage.getItem("alturaDiv");
if(alturaDiv != undefined) {
alturaDiv = JSON.parse(alturaDiv);
} else {
alturaDiv = {};
}
var url = window.location.href;
url = url.split("/");
var nomeClasse = url[url.length-1].split("?")[0];
var pIdElemento = "scsJsonTable_body_"+this.index;
alturaDiv[nomeClasse+"-"+pIdElemento] = height;
localStorage.setItem("alturaDiv",JSON.stringify(alturaDiv));
}

self.s00_componente_interface_scsJsonTable_salvarQtdRegistroPaginaAtual = function(qtdRegistroPagina) {
var registrosPorPagina = localStorage.getItem("registrosPorPagina");
if(registrosPorPagina != undefined) {
registrosPorPagina = JSON.parse(registrosPorPagina);
} else {
registrosPorPagina = {};
}
var url = window.location.href;
url = url.split("/");
var nomeClasse = url[url.length-1].split("?")[0];
var pIdElemento = "selectPageSize"+this.index;
registrosPorPagina[nomeClasse+"-"+pIdElemento] = qtdRegistroPagina;
localStorage.setItem("registrosPorPagina",JSON.stringify(registrosPorPagina));
this.setProperty("pageSize", qtdRegistroPagina);
document.getElementById(pIdElemento).value = qtdRegistroPagina;
}

self.s00_componente_interface_scsJsonTable_selectAll = function(pChecked,invokeCallback) {
var checkDisabledPropertyName = this.CheckDisabledPropertyName
arrayInternal = this.jsonContentInternal;
_.each(this.jsonContent, function(value, key, list){
var desabilitarCheck = 0
if ((this.CheckDisabledPropertyName != "") && (value[checkDisabledPropertyName] != null)) var desabilitarCheck = value[checkDisabledPropertyName]
if ((!desabilitarCheck) && (_.contains(arrayInternal,value))) value.selected = pChecked;
});
delete arrayInternal;
_.each(this.jsonContentInternal, function(value, key, list){
var desabilitarCheck = 0
if ((this.CheckDisabledPropertyName != "") && (value[checkDisabledPropertyName] != null)) var desabilitarCheck = value[checkDisabledPropertyName]
if (!desabilitarCheck) value.selected = pChecked;
});
var checks = $("#"+this.getIdEscaped()+" .jsonTable__body__column--check input[type='checkbox']:enabled");
for(var i =0;i<checks.length;i++){
checks[i].checked = pChecked;
}
if (this.jsonContent.length != this.jsonContentInternal.length){
document.getElementById("chk_"+this.id).checked = "";
}
if((invokeCallback)&&(this.onmultiSelectRow != "")) zenInvokeCallbackMethod(this.onmultiSelectRow,this,'onselectrow',"id","all","data",null);
}

self.s00_componente_interface_scsJsonTable_selectRow = function(pRow) {
var zsm = zenSynchronousMode;
zenSynchronousMode = true;
var tBodyId	= "#tbody_"+this.getIdEscaped();
$(tBodyId+" tr").removeClass("selected");
if(this.showZebra) {
$(tBodyId+" tr:even").removeClass("odd");
$(tBodyId+" tr:odd").addClass("odd");
}
this.clearFocusUseKeys();
pRow.classList.add("selected");
zenSynchronousMode = zsm;
if(this.onselectrow != "") {
var rowId = pRow.id;
var infoJson = _.findWhere(this.jsonContentInternal, {_rowId: rowId});
if(!infoJson) return; //quando uma linha está sendo excluída
zenInvokeCallbackMethod(this.onselectrow,this,'onselectrow',"data",infoJson);
}
}

self.s00_componente_interface_scsJsonTable_selectRowButton = function(pButton) {
var rowId = pButton.parentElement.parentElement.id;
var rowData			=  _.findWhere(this.jsonContent,{_rowId: rowId});
var rowDataInternal	=  _.findWhere(this.jsonContentInternal,{_rowId: rowId});
rowData.selected		= pButton.checked;
rowDataInternal.selected= pButton.checked;
var id = "";
if(this.idColumn != "") id = rowData[this.idColumn];
this.verifyAllSelected();
if(this.onmultiSelectRow != "") zenInvokeCallbackMethod(this.onmultiSelectRow,this,'onselectrow',"id",id,"data",rowData);
}

self.s00_componente_interface_scsJsonTable_setColumnHidden = function(pColumn,pHidden) {
var display = pHidden?"none":"";
var headerCols = this.columns;
var totalCols = headerCols.length;
var colIndex = 0;
for(var i = 0;i<totalCols;i++){
var col = headerCols[i];
if(col.colName == pColumn){
colIndex = i;
this.columns[i].hidden = pHidden;
break;
}
};
if(this.multiSelect){
colIndex++;
}
var thead = document.getElementById("thead_"+this.id);
var tbody = document.getElementById("tbody_"+this.id);
var totalRows = thead.rows.length;
for(var i = 0;i<totalRows;i++){
thead.rows[i].cells[colIndex].style.display = display;
}
var totalRows = tbody.rows.length;
for(var i = 0;i<totalRows;i++){
tbody.rows[i].cells[colIndex].style.display = display;
}
}

self.s00_componente_interface_scsJsonTable_setDisabledFields = function(pDisabled) {
try{
$(this.getEnclosingDiv()).find("input").each(function() {
$(this).prop("disabled", pDisabled);
});
} catch (ex) {
zenPage.alertaShift("setFieldsDisable(): "+zenPage.getMsgExcecao(ex));
}
}

self.s00_componente_interface_scsJsonTable_setProperty = function(property,value,value2) {
switch(property) {
case 'hidden':
this.setHidden(value);
break;
case 'hint':
case 'hintClass':
case 'hintStyle':
this[property] = value;
var hint = this.getHintElement();
if (hint) {
switch(property) {
case 'hint':
hint.innerHTML = value;
break;
case 'hintClass':
hint.className = value;
break;
case 'hintStyle':
hint.style.cssText = value;
break;
}
}
else if (this.parent) {
this.parent.refreshContents();
}
break;
case 'label':
case 'labelClass':
case 'labelStyle':
this[property] = value;
var label = this.getLabelElement();
if (label) {
switch(property) {
case 'label':
label.innerHTML = value;
break;
case 'labelClass':
label.className = value;
break;
case 'labelStyle':
label.style.cssText = value;
break;
}
}
else if (this.parent) {
this.parent.refreshContents();
}
break;
case 'containerStyle':
case 'align':
case 'valign':
case 'width':
case 'height':
case 'slice':
this[property] = value;
if (this.parent) {
this.parent.refreshContents();
}
break;
case 'enclosingClass':
this.enclosingClass = value;
var enc = this.getEnclosingDiv();
enc.className = value;
break;
case 'enclosingStyle':
this.enclosingStyle = value;
var enc = this.getEnclosingDiv();
enc.style.cssText = value;
break;
case 'dragEnabled':
case 'dropEnabled':
this[property] = value;
break;
case 'bodyHeight':
this[property] = value;
document.getElementById("scsJsonTable_body_"+this.index).style.height = value;
break;
default:
return this.invokeSuper('setProperty',arguments);
break;
}
return true;
}

self.s00_componente_interface_scsJsonTable_setResizable = function() {
var pIdElemento = "scsJsonTable_body_"+this.index;
var _this = this;
$("#"+pIdElemento).resizable({
handles: "n, s",
minHeight: 40,
stop: function( event, ui ) {
_this.salvarAlturaAtual(ui.size.height);
}
});
}

self.s00_componente_interface_scsJsonTable_shiftParseTime = function(value) {
if (null == value || '' == value) return '';
var v = value.replace(/-/g,':');
v = v.replace(/ /g,':');
var p = v.split(':');
if (p.length >= 1) {
var hora = parseInt(p[0],10);
var minuto = 0;
if (null != p[1])
minuto = parseInt(p[1],10);
var segundo = 0;
if (null != p[2]) {
segundo = parseInt(p[2],10);
}
if (!isNaN(segundo) && !isNaN(minuto) && !isNaN(hora)) {
var d = new Date(NaN);
if (segundo >= 0 && segundo < 60) {
if (minuto >= 0 && minuto < 60) {
if (hora >= 0 && hora <= 23) {
d = new Date();
d.setHours(hora, minuto, segundo);
}
}
}
return this.shiftTimeToString(d);
}
}
}

self.s00_componente_interface_scsJsonTable_shiftTimeToString = function(d) {
if (isNaN(d.getTime())) {
return -1;
}
return  (d.getHours()<10?'0':'') + d.getHours() + ':' + (d.getMinutes()<10?'0':'') + (d.getMinutes()) + ':' +  (d.getSeconds()<10?'0':'') + (d.getSeconds());
}

self.s00_componente_interface_scsJsonTable_showPage = function(pPage) {
if(pPage == "first") {
this.currentPage = 1;
} else if(pPage == "prev") {
this.currentPage--;
} else if(pPage == "next") {
this.currentPage++;
} else if(pPage == "last") {
this.currentPage = this.getTotalPages();
} else {
if(isNaN(pPage)) return;
pPage = parseInt(pPage, 10);
if(pPage > this.getTotalPages())
return;
this.currentPage = pPage;
}
this.drawTable();
}

self.s00_componente_interface_scsJsonTable_sortColumn = function(pTH,pColName) {
var order = pTH.getAttribute("order");
$("#thead_"+this.getIdEscaped()+" .jsonTable__imgSort").remove();
$("#thead_"+this.getIdEscaped()+" > tr > th").removeAttr("order");
var novaOrder = ""
if(!order || order == "") {
this.jsonContentInternal = _.sortBy(this.jsonContentInternal, pColName);
pTH.setAttribute("order", "asc");
novaOrder = "asc";
var imgAsc = document.createElement("img");
imgAsc.className = "jsonTable__imgSort";
imgAsc.src = "img/icons/seta_azul_up.png";
pTH.appendChild(imgAsc);
} else if(order == "asc") {
this.jsonContentInternal = _.sortBy(this.jsonContentInternal, pColName);
this.jsonContentInternal.reverse();
pTH.setAttribute("order", "desc");
novaOrder = "desc";
var imgDesc = document.createElement("img");
imgDesc.className = "jsonTable__imgSort";
imgDesc.src = "img/icons/seta_azul.png";
pTH.appendChild(imgDesc);
} else {
this.filter();
pTH.setAttribute("order", "");
novaOrder = "";
}
var colName = pTH.getAttribute("colname");
var col = _.findWhere(this.columns, {'colName': colName});
if((col) && (col.onSortColumn != "") && col.onSortColumn && typeof(col.onSortColumn) == "function") {
this.getContexto()[col.onSortColumn](novaOrder);
}
this.drawTable();
}

self.s00_componente_interface_scsJsonTable_sortColumnByColName = function(pColName,pOrdenacao) {
var retorno = true;
try {
var seletor = $('.jsonTable__sortColumn[colname="'+pColName+'"]')
if(seletor.length > 0) {
var thColumn = seletor[0];
if(pOrdenacao === "asc") {
thColumn.setAttribute("order", "");
}else if(pOrdenacao === "desc") {
thColumn.setAttribute("order", "asc");
}else {
thColumn.setAttribute("order", "desc");
}
zen("jtbPedidos").sortColumn(thColumn, pColName);
}
}catch(ex) {
retorno = false;
zenPage.alertaShift("sortColumnByColName(): "+zenPage.getMsgExcecao(ex));
}
return retorno;
}

self.s00_componente_interface_scsJsonTable_teste = function() {
/*dados = [{ coluna1:"coluna1",coluna2:"coluna2",coluna3:"coluna3" },
{ coluna1:"coluna4",coluna2:"coluna5",coluna3:"coluna6" },
{ coluna1:"coluna7",coluna2:"coluna8",coluna3:"coluna9" }];*/
var dados = [];
var indice = 0;
var coluna = "";
var disabled1 = false;
var disabled2 = false;
for(var i=0; i < 300; i++) {
indice++;
coluna = "coluna"+indice;
disabled1 = i % 2 > 0;
disabled2 = i % 2 == 0;
dados.push({
coluna1: indice,
coluna2: coluna+""+(indice + Math.floor(Math.random() * 10 +1)),
coluna3: coluna,
disableButton1: disabled1,
disableButton2: disabled2
});
}
this.addRows(dados);
}

self.s00_componente_interface_scsJsonTable_verifyAllSelected = function() {
if(this.jsonContent.length != this.jsonContentInternal.length){
return false;
}
var unselected = _.find(this.jsonContentInternal, function(item){
if(item["selected"])
return false;
return true;
});
if(this.jsonContentInternal == null || this.jsonContentInternal.length == 0)
unselected = false;
$("#chk_"+this.getIdEscaped()).attr("checked", unselected == null ? true : false);
}

self.s00_componente_interface_scsJsonTable_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsJsonTable_validarStringHora = function(valor) {
	return zenInstanceMethod(this,'validarStringHora','L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsJsonTable__Loader = function() {
	zenLoadClass('_ZEN_Component_component');
	s00_componente_interface_scsJsonTable.prototype = zenCreate('_ZEN_Component_component',-1);
	var p = s00_componente_interface_scsJsonTable.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsJsonTable;
	p.superClass = ('undefined' == typeof _ZEN_Component_component) ? zenMaster._ZEN_Component_component.prototype:_ZEN_Component_component.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsJsonTable';
	p._type = 'scsJsonTable';
	p.serialize = s00_componente_interface_scsJsonTable_serialize;
	p.getSettings = s00_componente_interface_scsJsonTable_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsJsonTable_ReallyRefreshContents;
	p.addRow = s00_componente_interface_scsJsonTable_addRow;
	p.addRows = s00_componente_interface_scsJsonTable_addRows;
	p.applyGroupRow = s00_componente_interface_scsJsonTable_applyGroupRow;
	p.clear = s00_componente_interface_scsJsonTable_clear;
	p.clearFocusUseKeys = s00_componente_interface_scsJsonTable_clearFocusUseKeys;
	p.count = s00_componente_interface_scsJsonTable_count;
	p.criarResultados = s00_componente_interface_scsJsonTable_criarResultados;
	p.criarResultadosPorPagina = s00_componente_interface_scsJsonTable_criarResultadosPorPagina;
	p.dblClick = s00_componente_interface_scsJsonTable_dblClick;
	p.deleteAllRows = s00_componente_interface_scsJsonTable_deleteAllRows;
	p.drawColumn = s00_componente_interface_scsJsonTable_drawColumn;
	p.drawDeleteButtonRow = s00_componente_interface_scsJsonTable_drawDeleteButtonRow;
	p.drawJsonButton = s00_componente_interface_scsJsonTable_drawJsonButton;
	p.drawJsonCheck = s00_componente_interface_scsJsonTable_drawJsonCheck;
	p.drawJsonCombo = s00_componente_interface_scsJsonTable_drawJsonCombo;
	p.drawJsonComboItem = s00_componente_interface_scsJsonTable_drawJsonComboItem;
	p.drawMultiSelect = s00_componente_interface_scsJsonTable_drawMultiSelect;
	p.drawNavigator = s00_componente_interface_scsJsonTable_drawNavigator;
	p.drawRow = s00_componente_interface_scsJsonTable_drawRow;
	p.drawTable = s00_componente_interface_scsJsonTable_drawTable;
	p.drawText = s00_componente_interface_scsJsonTable_drawText;
	p.drawTextData = s00_componente_interface_scsJsonTable_drawTextData;
	p.drawTextDataItem = s00_componente_interface_scsJsonTable_drawTextDataItem;
	p.drawTextHoraItem = s00_componente_interface_scsJsonTable_drawTextHoraItem;
	p.drawTextInteiro = s00_componente_interface_scsJsonTable_drawTextInteiro;
	p.drawTextInteiroItem = s00_componente_interface_scsJsonTable_drawTextInteiroItem;
	p.drawTextItem = s00_componente_interface_scsJsonTable_drawTextItem;
	p.drawTextMoeda = s00_componente_interface_scsJsonTable_drawTextMoeda;
	p.drawTextMoedaItem = s00_componente_interface_scsJsonTable_drawTextMoedaItem;
	p.filter = s00_componente_interface_scsJsonTable_filter;
	p.filtrarHora = s00_componente_interface_scsJsonTable_filtrarHora;
	p.focus = s00_componente_interface_scsJsonTable_focus;
	p.formatarCampo = s00_componente_interface_scsJsonTable_formatarCampo;
	p.formatarHora = s00_componente_interface_scsJsonTable_formatarHora;
	p.formatarValor = s00_componente_interface_scsJsonTable_formatarValor;
	p.getContainer = s00_componente_interface_scsJsonTable_getContainer;
	p.getContexto = s00_componente_interface_scsJsonTable_getContexto;
	p.getDiv = s00_componente_interface_scsJsonTable_getDiv;
	p.getHeightLocal = s00_componente_interface_scsJsonTable_getHeightLocal;
	p.getIdEscaped = s00_componente_interface_scsJsonTable_getIdEscaped;
	p.getJsonCheck = s00_componente_interface_scsJsonTable_getJsonCheck;
	p.getOrderedContent = s00_componente_interface_scsJsonTable_getOrderedContent;
	p.getPageContents = s00_componente_interface_scsJsonTable_getPageContents;
	p.getQtdRegistroPaginaLocal = s00_componente_interface_scsJsonTable_getQtdRegistroPaginaLocal;
	p.getSelectedId = s00_componente_interface_scsJsonTable_getSelectedId;
	p.getSelectedList = s00_componente_interface_scsJsonTable_getSelectedList;
	p.getSelectedRow = s00_componente_interface_scsJsonTable_getSelectedRow;
	p.getTotalPages = s00_componente_interface_scsJsonTable_getTotalPages;
	p.inserirDataJson = s00_componente_interface_scsJsonTable_inserirDataJson;
	p.inserirHoraJson = s00_componente_interface_scsJsonTable_inserirHoraJson;
	p.inserirValorFloatJson = s00_componente_interface_scsJsonTable_inserirValorFloatJson;
	p.isValid = s00_componente_interface_scsJsonTable_isValid;
	p.keyDownUseKeys = s00_componente_interface_scsJsonTable_keyDownUseKeys;
	p.manterColunasOrdenadas = s00_componente_interface_scsJsonTable_manterColunasOrdenadas;
	p.onCreate = s00_componente_interface_scsJsonTable_onCreate;
	p.onDisplayHandler = s00_componente_interface_scsJsonTable_onDisplayHandler;
	p.onRefreshContents = s00_componente_interface_scsJsonTable_onRefreshContents;
	p.ondatechangeHandler = s00_componente_interface_scsJsonTable_ondatechangeHandler;
	p.onfocusJsonTableHandler = s00_componente_interface_scsJsonTable_onfocusJsonTableHandler;
	p.onloadHandler = s00_componente_interface_scsJsonTable_onloadHandler;
	p.removeId = s00_componente_interface_scsJsonTable_removeId;
	p.removeRowButton = s00_componente_interface_scsJsonTable_removeRowButton;
	p.removeRows = s00_componente_interface_scsJsonTable_removeRows;
	p.resizeHeaders = s00_componente_interface_scsJsonTable_resizeHeaders;
	p.salvarAlturaAtual = s00_componente_interface_scsJsonTable_salvarAlturaAtual;
	p.salvarQtdRegistroPaginaAtual = s00_componente_interface_scsJsonTable_salvarQtdRegistroPaginaAtual;
	p.selectAll = s00_componente_interface_scsJsonTable_selectAll;
	p.selectRow = s00_componente_interface_scsJsonTable_selectRow;
	p.selectRowButton = s00_componente_interface_scsJsonTable_selectRowButton;
	p.setColumnHidden = s00_componente_interface_scsJsonTable_setColumnHidden;
	p.setDisabledFields = s00_componente_interface_scsJsonTable_setDisabledFields;
	p.setProperty = s00_componente_interface_scsJsonTable_setProperty;
	p.setResizable = s00_componente_interface_scsJsonTable_setResizable;
	p.shiftParseTime = s00_componente_interface_scsJsonTable_shiftParseTime;
	p.shiftTimeToString = s00_componente_interface_scsJsonTable_shiftTimeToString;
	p.showPage = s00_componente_interface_scsJsonTable_showPage;
	p.sortColumn = s00_componente_interface_scsJsonTable_sortColumn;
	p.sortColumnByColName = s00_componente_interface_scsJsonTable_sortColumnByColName;
	p.teste = s00_componente_interface_scsJsonTable_teste;
	p.validarStringHora = s00_componente_interface_scsJsonTable_validarStringHora;
	p.verifyAllSelected = s00_componente_interface_scsJsonTable_verifyAllSelected;
}

self._zenClassIdx['scsJsonText'] = 's00_componente_interface_scsJsonText';
self.s00_componente_interface_scsJsonText = function(index,id) {
	if (index>=0) {s00_componente_interface_scsJsonText__init(this,index,id);}
}

self.s00_componente_interface_scsJsonText__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_scsJsonComponents__init) ?zenMaster.s00_componente_interface_scsJsonComponents__init(o,index,id):s00_componente_interface_scsJsonComponents__init(o,index,id);
	o.controlClass = '';
	o.onchange = '';
	o.size = '';
}
function s00_componente_interface_scsJsonText_serialize(set,s)
{
	var o = this;s[0]='2631461959';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.aux;s[7]=o.colTitle;s[8]=o.controlClass;s[9]=o.controlStyle;s[10]=o.disableProperty;s[11]=o.enclosingClass;s[12]=o.enclosingStyle;s[13]=o.hiddenProperty;s[14]=o.maxLength;s[15]=o.onchange;s[16]=o.onupdate;s[17]=o.renderFlag;s[18]=o.size;s[19]=o.textClass;s[20]=o.textStyle;s[21]=o.title;s[22]=o.tuple;s[23]=o.valueProperty;s[24]=(o.visible?1:0);s[25]=o.width;
}
function s00_componente_interface_scsJsonText_getSettings(s)
{
	s['name'] = 'string';
	s['controlClass'] = 'string';
	s['onchange'] = 'eventHandler';
	s['size'] = 'string';
	this.invokeSuper('getSettings',arguments);
}
self.s00_componente_interface_scsJsonText__Loader = function() {
	zenLoadClass('s00_componente_interface_scsJsonComponents');
	s00_componente_interface_scsJsonText.prototype = zenCreate('s00_componente_interface_scsJsonComponents',-1);
	var p = s00_componente_interface_scsJsonText.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsJsonText;
	p.superClass = ('undefined' == typeof s00_componente_interface_scsJsonComponents) ? zenMaster.s00_componente_interface_scsJsonComponents.prototype:s00_componente_interface_scsJsonComponents.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsJsonText';
	p._type = 'scsJsonText';
	p.serialize = s00_componente_interface_scsJsonText_serialize;
	p.getSettings = s00_componente_interface_scsJsonText_getSettings;
}

self._zenClassIdx['scsJsonTextData'] = 's00_componente_interface_scsJsonTextData';
self.s00_componente_interface_scsJsonTextData = function(index,id) {
	if (index>=0) {s00_componente_interface_scsJsonTextData__init(this,index,id);}
}

self.s00_componente_interface_scsJsonTextData__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_scsJsonComponents__init) ?zenMaster.s00_componente_interface_scsJsonComponents__init(o,index,id):s00_componente_interface_scsJsonComponents__init(o,index,id);
	o.onchange = '';
}
function s00_componente_interface_scsJsonTextData_serialize(set,s)
{
	var o = this;s[0]='1050258309';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.aux;s[7]=o.colTitle;s[8]=o.controlClass;s[9]=o.controlStyle;s[10]=o.disableProperty;s[11]=o.enclosingClass;s[12]=o.enclosingStyle;s[13]=o.hiddenProperty;s[14]=o.maxLength;s[15]=o.onchange;s[16]=o.onupdate;s[17]=o.renderFlag;s[18]=o.textClass;s[19]=o.textStyle;s[20]=o.title;s[21]=o.tuple;s[22]=o.valueProperty;s[23]=(o.visible?1:0);s[24]=o.width;
}
function s00_componente_interface_scsJsonTextData_getSettings(s)
{
	s['name'] = 'string';
	s['onchange'] = 'eventHandler';
	this.invokeSuper('getSettings',arguments);
}
self.s00_componente_interface_scsJsonTextData__Loader = function() {
	zenLoadClass('s00_componente_interface_scsJsonComponents');
	s00_componente_interface_scsJsonTextData.prototype = zenCreate('s00_componente_interface_scsJsonComponents',-1);
	var p = s00_componente_interface_scsJsonTextData.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsJsonTextData;
	p.superClass = ('undefined' == typeof s00_componente_interface_scsJsonComponents) ? zenMaster.s00_componente_interface_scsJsonComponents.prototype:s00_componente_interface_scsJsonComponents.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsJsonTextData';
	p._type = 'scsJsonTextData';
	p.serialize = s00_componente_interface_scsJsonTextData_serialize;
	p.getSettings = s00_componente_interface_scsJsonTextData_getSettings;
}

self._zenClassIdx['scsJsonTextInteiro'] = 's00_componente_interface_scsJsonTextInteiro';
self.s00_componente_interface_scsJsonTextInteiro = function(index,id) {
	if (index>=0) {s00_componente_interface_scsJsonTextInteiro__init(this,index,id);}
}

self.s00_componente_interface_scsJsonTextInteiro__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_scsJsonComponents__init) ?zenMaster.s00_componente_interface_scsJsonComponents__init(o,index,id):s00_componente_interface_scsJsonComponents__init(o,index,id);
	o.onchange = '';
	o.size = '';
	o.valorMaximo = '999999999999';
	o.valorMinimo = '-999999999999';
}
function s00_componente_interface_scsJsonTextInteiro_serialize(set,s)
{
	var o = this;s[0]='2186818959';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.aux;s[7]=o.colTitle;s[8]=o.controlClass;s[9]=o.controlStyle;s[10]=o.disableProperty;s[11]=o.enclosingClass;s[12]=o.enclosingStyle;s[13]=o.hiddenProperty;s[14]=o.maxLength;s[15]=o.onchange;s[16]=o.onupdate;s[17]=o.renderFlag;s[18]=o.size;s[19]=o.textClass;s[20]=o.textStyle;s[21]=o.title;s[22]=o.tuple;s[23]=o.valorMaximo;s[24]=o.valorMinimo;s[25]=o.valueProperty;s[26]=(o.visible?1:0);s[27]=o.width;
}
function s00_componente_interface_scsJsonTextInteiro_getSettings(s)
{
	s['name'] = 'string';
	s['onchange'] = 'eventHandler';
	s['size'] = 'integer';
	s['valorMaximo'] = 'integer';
	s['valorMinimo'] = 'integer';
	this.invokeSuper('getSettings',arguments);
}
self.s00_componente_interface_scsJsonTextInteiro__Loader = function() {
	zenLoadClass('s00_componente_interface_scsJsonComponents');
	s00_componente_interface_scsJsonTextInteiro.prototype = zenCreate('s00_componente_interface_scsJsonComponents',-1);
	var p = s00_componente_interface_scsJsonTextInteiro.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsJsonTextInteiro;
	p.superClass = ('undefined' == typeof s00_componente_interface_scsJsonComponents) ? zenMaster.s00_componente_interface_scsJsonComponents.prototype:s00_componente_interface_scsJsonComponents.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsJsonTextInteiro';
	p._type = 'scsJsonTextInteiro';
	p.serialize = s00_componente_interface_scsJsonTextInteiro_serialize;
	p.getSettings = s00_componente_interface_scsJsonTextInteiro_getSettings;
}

self._zenClassIdx['scsJsonTextMoeda'] = 's00_componente_interface_scsJsonTextMoeda';
self.s00_componente_interface_scsJsonTextMoeda = function(index,id) {
	if (index>=0) {s00_componente_interface_scsJsonTextMoeda__init(this,index,id);}
}

self.s00_componente_interface_scsJsonTextMoeda__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_scsJsonComponents__init) ?zenMaster.s00_componente_interface_scsJsonComponents__init(o,index,id):s00_componente_interface_scsJsonComponents__init(o,index,id);
	o.casasDecimais = '2';
	o.onchange = '';
	o.positivo = false;
	o.valorMaximo = '99999999';
	o.valorMinimo = '-99999999';
	o.valueProperty = '';
}
function s00_componente_interface_scsJsonTextMoeda_serialize(set,s)
{
	var o = this;s[0]='3843604172';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.aux;s[7]=o.casasDecimais;s[8]=o.colTitle;s[9]=o.controlClass;s[10]=o.controlStyle;s[11]=o.disableProperty;s[12]=o.enclosingClass;s[13]=o.enclosingStyle;s[14]=o.hiddenProperty;s[15]=o.maxLength;s[16]=o.onchange;s[17]=o.onupdate;s[18]=(o.positivo?1:0);s[19]=o.renderFlag;s[20]=o.textClass;s[21]=o.textStyle;s[22]=o.title;s[23]=o.tuple;s[24]=o.valorMaximo;s[25]=o.valorMinimo;s[26]=o.valueProperty;s[27]=(o.visible?1:0);s[28]=o.width;
}
function s00_componente_interface_scsJsonTextMoeda_getSettings(s)
{
	s['name'] = 'string';
	s['casasDecimais'] = 'integer';
	s['onchange'] = 'eventHandler';
	s['positivo'] = 'boolean';
	s['valorMaximo'] = 'float';
	s['valorMinimo'] = 'float';
	s['valueProperty'] = 'string';
	this.invokeSuper('getSettings',arguments);
}
self.s00_componente_interface_scsJsonTextMoeda__Loader = function() {
	zenLoadClass('s00_componente_interface_scsJsonComponents');
	s00_componente_interface_scsJsonTextMoeda.prototype = zenCreate('s00_componente_interface_scsJsonComponents',-1);
	var p = s00_componente_interface_scsJsonTextMoeda.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsJsonTextMoeda;
	p.superClass = ('undefined' == typeof s00_componente_interface_scsJsonComponents) ? zenMaster.s00_componente_interface_scsJsonComponents.prototype:s00_componente_interface_scsJsonComponents.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsJsonTextMoeda';
	p._type = 'scsJsonTextMoeda';
	p.serialize = s00_componente_interface_scsJsonTextMoeda_serialize;
	p.getSettings = s00_componente_interface_scsJsonTextMoeda_getSettings;
}

self._zenClassIdx['scsTablePaneTools'] = 's00_componente_interface_scsTablePaneTools';
self.s00_componente_interface_scsTablePaneTools = function(index,id) {
	if (index>=0) {s00_componente_interface_scsTablePaneTools__init(this,index,id);}
}

self.s00_componente_interface_scsTablePaneTools__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_component__init) ?zenMaster._ZEN_Component_component__init(o,index,id):_ZEN_Component_component__init(o,index,id);
	o.ComponenteTela = '';
	o.JSONLevels = '100';
	o.captionExportButton = '';
	o.jSONTableId = '';
	o.jsonContent = null;
	o.showExportButton = true;
	o.tablePaneId = '';
	o.titleExportButton = '';
	o.widthExportButton = '';
}
function s00_componente_interface_scsTablePaneTools_serialize(set,s)
{
	var o = this;s[0]='1203597987';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.ComponenteTela;s[7]=o.JSONLevels;s[8]=o.align;s[9]=o.aux;s[10]=o.captionExportButton;s[11]=o.containerStyle;s[12]=(o.dragEnabled?1:0);s[13]=(o.dropEnabled?1:0);s[14]=(o.dynamic?1:0);s[15]=o.enclosingClass;s[16]=o.enclosingStyle;s[17]=o.error;s[18]=o.height;s[19]=(o.hidden?1:0);s[20]=o.hint;s[21]=o.hintClass;s[22]=o.hintStyle;s[23]=o.jSONTableId;s[24]=o.label;s[25]=o.labelClass;s[26]=o.labelDisabledClass;s[27]=o.labelStyle;s[28]=o.onafterdrag;s[29]=o.onbeforedrag;s[30]=o.ondrag;s[31]=o.ondrop;s[32]=o.onhide;s[33]=o.onrefresh;s[34]=o.onshow;s[35]=o.onupdate;s[36]=o.overlayMode;s[37]=o.renderFlag;s[38]=(o.showExportButton?1:0);s[39]=(o.showLabel?1:0);s[40]=o.slice;s[41]=o.tablePaneId;s[42]=o.title;s[43]=o.titleExportButton;s[44]=o.tuple;s[45]=o.valign;s[46]=(o.visible?1:0);s[47]=o.width;s[48]=o.widthExportButton;
}
function s00_componente_interface_scsTablePaneTools_getSettings(s)
{
	s['name'] = 'string';
	s['ComponenteTela'] = 'string';
	s['JSONLevels'] = 'string';
	s['captionExportButton'] = 'string';
	s['jSONTableId'] = 'string';
	s['showExportButton'] = 'boolean';
	s['tablePaneId'] = 'string';
	s['titleExportButton'] = 'string';
	s['widthExportButton'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsTablePaneTools_exportarDadosCSV = function() {
var retorno = this.prepararJSONTabela()
var stringJSON = "{dadosJSON:"+this.toJSON(this.jsonContent)+"}"
var retorno = this.GerarArquivoCSV(stringJSON,this.ComponenteTela)
if (retorno.erro != ""){
zenPage.alertaShift(retorno.erro)
} else {
window.open(retorno.urlArquivo)
}
}

self.s00_componente_interface_scsTablePaneTools_parseJSON = function(pStringJson) {
try{
var tUsaEval = 1;
if(typeof(JSON) != "undefined"){
try {
pStringJson = JSON.parse(pStringJson);
tUsaEval = 0;
}catch (ex) {
tUsaEval = 1;
}
}
if (tUsaEval) {
if(pStringJson){
pStringJson = eval("("+pStringJson+")");
}else{
pStringJson = {};
}
}
}catch(ex){
if (ex) zenPage.alertaShift("parseJSON:" + zenPage.getMsgExcecao(ex));
}
return pStringJson;
}

self.s00_componente_interface_scsTablePaneTools_prepararJSONTabela = function() {
this.ComponenteTela = null
this.jsonContent = [];
if (this.jSONTableId != ""){
var componenteId = this.jSONTableId
var compJSON = zen(componenteId)
if (compJSON != null){
this.ComponenteTela = compJSON
this.jsonContent = compJSON.jsonContent
}
} else if (this.tablePaneId != "") {
var componenteId = this.tablePaneId
var compTabelaPane = zen(componenteId)
if (compTabelaPane != null){
this.ComponenteTela = compTabelaPane
var retorno = this.ConvertDataTablePaneToJson(compTabelaPane)
if (retorno.erro != ""){
zenPage.alertaShift(retorno.erro)
} else if (retorno.DadosJSON != ""){
var objetoJSON = this.parseJSON(retorno.DadosJSON);
this.jsonContent = objetoJSON["DadosJSON"];
}
}
}
if (this.ComponenteTela == null) zenPage.alertaShift("Componente "+componenteId+" não encontrado.")
return 1
}

self.s00_componente_interface_scsTablePaneTools_toJSON = function(obj,cycle,level) {
try {
cycle = ('undefined' == typeof cycle) ? Math.floor(Math.random()*1000000) : cycle;
level = ('undefined' == typeof level) ? 0 : level;
if (level > this.JSONLevels) {
alert('jsonProvider: too many levels in JSON object');
}
if ('object' == typeof obj && null != obj) {
if (null == obj.__cycle || cycle != obj.__cycle) {
obj.__cycle = cycle;
}
else if (cycle == obj.__cycle) {
return 'null';
}
}
var t = new Array();
switch (typeof obj) {
case 'boolean':
t[t.length] = obj ? 'true' : 'false';
break;
case 'string':
var text = obj.toString();
text = text.replace(/\\/g,'\\\\'); // escape any backslash
text = text.replace(/\'/g,"\\'"); // escape any single quotes
text = text.replace(/\"/g,'\\"');
t[t.length] = '\"' + text + '\"';
break;
case 'number':
t[t.length] = obj;
break;
case 'object':
if (null == obj) {
return 'null';
}
else if (obj.constructor == Function) {
return '';
}
else if (obj.constructor == Array) {
t[t.length] = '[';
for (var n = 0; n < obj.length; n++) {
var sub = this.toJSON(obj[n],cycle,level+1);
if (null == sub) return null;
t[t.length] = ((n>0)?',':'') + sub;
}
t[t.length] = ']';
}
else {
var pc = 0;
t[t.length] = '{';
for (var p in obj) {
if ('function' != typeof obj[p]) {
if ((p.indexOf('_')==-1)||(p=='_class')) {
var sub = this.toJSON(obj[p],cycle,level+1);
if (null == sub) return null;
t[t.length] = ((pc++>0)?',':'')+ '\"' + p + '\":' + sub + '';
}
}
}
t[t.length] = '}\n';
}
break;
case 'function':
break;
default:
break;
}
return t.join('').replace(":,", ":\"\",");
}
catch(ex) {
}
return null;
}

self.s00_componente_interface_scsTablePaneTools_ConvertDataTablePaneToJson = function(pTablePane) {
	return zenInstanceMethod(this,'ConvertDataTablePaneToJson','O','HANDLE',arguments);
}

self.s00_componente_interface_scsTablePaneTools_GerarArquivoCSV = function(pStringJSON,pTabela) {
	return zenClassMethod(this,'GerarArquivoCSV','L,O','HANDLE',arguments);
}

self.s00_componente_interface_scsTablePaneTools_GetQueryInfo = function(pTablePane) {
	return zenInstanceMethod(this,'GetQueryInfo','O','HANDLE',arguments);
}

self.s00_componente_interface_scsTablePaneTools_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsTablePaneTools__Loader = function() {
	zenLoadClass('_ZEN_Component_component');
	s00_componente_interface_scsTablePaneTools.prototype = zenCreate('_ZEN_Component_component',-1);
	var p = s00_componente_interface_scsTablePaneTools.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsTablePaneTools;
	p.superClass = ('undefined' == typeof _ZEN_Component_component) ? zenMaster._ZEN_Component_component.prototype:_ZEN_Component_component.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsTablePaneTools';
	p._type = 'scsTablePaneTools';
	p.serialize = s00_componente_interface_scsTablePaneTools_serialize;
	p.getSettings = s00_componente_interface_scsTablePaneTools_getSettings;
	p.ConvertDataTablePaneToJson = s00_componente_interface_scsTablePaneTools_ConvertDataTablePaneToJson;
	p.GerarArquivoCSV = s00_componente_interface_scsTablePaneTools_GerarArquivoCSV;
	p.GetQueryInfo = s00_componente_interface_scsTablePaneTools_GetQueryInfo;
	p.ReallyRefreshContents = s00_componente_interface_scsTablePaneTools_ReallyRefreshContents;
	p.exportarDadosCSV = s00_componente_interface_scsTablePaneTools_exportarDadosCSV;
	p.parseJSON = s00_componente_interface_scsTablePaneTools_parseJSON;
	p.prepararJSONTabela = s00_componente_interface_scsTablePaneTools_prepararJSONTabela;
	p.toJSON = s00_componente_interface_scsTablePaneTools_toJSON;
}

self._zenClassIdx['scsSelect2'] = 's00_componente_interface_scsSelect2';
self.s00_componente_interface_scsSelect2 = function(index,id) {
	if (index>=0) {s00_componente_interface_scsSelect2__init(this,index,id);}
}

self.s00_componente_interface_scsSelect2__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_control__init) ?zenMaster._ZEN_Component_control__init(o,index,id):_ZEN_Component_control__init(o,index,id);
	o.cellAlign = '';
	o.cellSize = '';
	o.cellStyle = '';
	o.cellVAlign = '';
	o.childrenCreated = false;
	o.dataProperty = '';
	o.displayList = '';
	o.dropdownWidth = 'auto';
	o.groupClass = 'group';
	o.groupStyle = '';
	o.labelPosition = 'top';
	o.layout = ''; // encrypted
	o.maxHeight = 'auto';
	o.multiple = false;
	o.size = '20';
	o.valueList = '';
}
function s00_componente_interface_scsSelect2_serialize(set,s)
{
	var o = this;s[0]='1420819855';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=(o.childrenCreated?1:0);s[14]=o.clientType;s[15]=o.containerStyle;s[16]=o.controlClass;s[17]=o.controlStyle;s[18]=o.dataBinding;s[19]=o.dataProperty;s[20]=(o.disabled?1:0);s[21]=o.displayList;s[22]=(o.dragEnabled?1:0);s[23]=(o.dropEnabled?1:0);s[24]=o.dropdownWidth;s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.groupClass;s[30]=o.groupStyle;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=(o.invalid?1:0);s[37]=o.invalidMessage;s[38]=o.label;s[39]=o.labelClass;s[40]=o.labelDisabledClass;s[41]=o.labelPosition;s[42]=o.labelStyle;s[43]=o.layout;s[44]=o.maxHeight;s[45]=(o.multiple?1:0);s[46]=o.onafterdrag;s[47]=o.onbeforedrag;s[48]=o.onblur;s[49]=o.onchange;s[50]=o.onclick;s[51]=o.ondblclick;s[52]=o.ondrag;s[53]=o.ondrop;s[54]=o.onfocus;s[55]=o.onhide;s[56]=o.onkeydown;s[57]=o.onkeypress;s[58]=o.onkeyup;s[59]=o.onmousedown;s[60]=o.onmouseout;s[61]=o.onmouseover;s[62]=o.onmouseup;s[63]=o.onrefresh;s[64]=o.onshow;s[65]=o.onsubmit;s[66]=o.ontouchend;s[67]=o.ontouchmove;s[68]=o.ontouchstart;s[69]=o.onupdate;s[70]=o.onvalidate;s[71]=o.originalValue;s[72]=o.overlayMode;s[73]=(o.readOnly?1:0);s[74]=o.renderFlag;s[75]=(o.required?1:0);s[76]=o.requiredMessage;s[77]=(o.showLabel?1:0);s[78]=o.size;s[79]=o.slice;s[80]=o.tabIndex;s[81]=o.title;s[82]=o.tuple;s[83]=o.valign;s[84]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[85]=o.valueList;s[86]=(o.visible?1:0);s[87]=o.width;
}
function s00_componente_interface_scsSelect2_getSettings(s)
{
	s['name'] = 'string';
	s['dataProperty'] = 'caption';
	s['displayList'] = 'caption';
	s['dropdownWidth'] = 'caption';
	s['maxHeight'] = 'caption';
	s['multiple'] = 'boolean';
	s['size'] = 'caption';
	s['valueList'] = 'caption';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsSelect2_atualizarSelecao = function(pDados,pNotOnChange) {
try{
if(typeof(pDados) == "object"){
$("#control_"+this.index).select2("data", pDados);
}else{
$("#control_"+this.index).select2("val",pDados)
if((pNotOnChange == undefined)||(pNotOnChange == 0)){
$("#control_"+this.index).trigger("change");
}
}
}catch(ex){
zenPage.alertaShift("atualizarSelecao() " + zenPage.getMsgExcecao(ex));
}
}

self.s00_componente_interface_scsSelect2_carregarSelect2 = function(pDados) {
try{
var _this = this
$("#control_"+this.index).select2({
data: pDados,
multiple: this.multiple,
dropdownAutoWidth: false
});
}catch(ex){
zenPage.alertaShift("carregarSelect2() " + zenPage.getMsgExcecao(ex));
}
}

self.s00_componente_interface_scsSelect2_focus = function() {
try{
$("#control_"+this.index).focus();
}catch(ex){
zenPage.alertaShift("focus() " + zenPage.getMsgExcecao(ex));
}
}

self.s00_componente_interface_scsSelect2_getProperty = function(property,key) {
switch(property) {
case 'value':
this.value = $("#control_"+this.index).select2("val");
return this.normalizeValue(this.value);
break
case 'data':
return $("#control_"+this.index).select2('data');
return this.normalizeValue(this.value);
break
return this.invokeSuper('getProperty',arguments);
}
}

self.s00_componente_interface_scsSelect2_limparSelect2 = function() {
try{
$("#control_"+this.index).select2("val","");
}catch(ex){
zenPage.alertaShift("limparSelect2() " + zenPage.getMsgExcecao(ex));
}
}

self.s00_componente_interface_scsSelect2_onchangeSelect2 = function() {
if(this.onchange != ""){
zenInvokeCallbackMethod(this.onchange,this,"onchange");
}
}

self.s00_componente_interface_scsSelect2_onloadHandler = function() {
var dados = [];
if(this.valueList != "") {
var arrayValue = this.valueList.split(",");
var arrayDisplay = this.displayList.split(",");
for(var i in arrayValue) {
dados.push({
id: arrayValue[i],
text: arrayDisplay[i]
})
}
}
this.carregarSelect2(dados);
}

self.s00_componente_interface_scsSelect2_renderContents = function() {
var _this = this;
var div = document.createElement("div");
div.className = "scsSelect2";
var ipt = document.createElement("input")
ipt.className = "control_"+this.index;
ipt.onchange = function() {
_this.onchangeSelect2();
};
ipt.style.width = (this.size*6.29) + "px";
ipt.style.maxHeight = this.maxHeight + "px";
div.appendChild(ipt);
return div;
}

self.s00_componente_interface_scsSelect2_setProperty = function(property,value,value2) {
switch(property) {
case 'hidden':
this.setHidden(value);
break;
case 'hint':
case 'hintClass':
case 'hintStyle':
this[property] = value;
var hint = this.getHintElement();
if (hint) {
switch(property) {
case 'hint':
hint.innerHTML = value;
break;
case 'hintClass':
hint.className = value;
break;
case 'hintStyle':
hint.style.cssText = value;
break;
}
}
else if (this.parent) {
this.parent.refreshContents();
}
break;
case 'label':
case 'labelClass':
case 'labelStyle':
this[property] = value;
var label = this.getLabelElement();
if (label) {
switch(property) {
case 'label':
label.innerHTML = value;
break;
case 'labelClass':
label.className = value;
break;
case 'labelStyle':
label.style.cssText = value;
break;
}
}
else if (this.parent) {
this.parent.refreshContents();
}
break;
case 'containerStyle':
case 'align':
case 'valign':
case 'width':
case 'height':
case 'slice':
this[property] = value;
if (this.parent) {
this.parent.refreshContents();
}
break;
case 'enclosingClass':
this.enclosingClass = value;
var enc = this.getEnclosingDiv();
enc.className = value;
break;
case 'enclosingStyle':
this.enclosingStyle = value;
var enc = this.getEnclosingDiv();
enc.style.cssText = value;
break;
case 'dragEnabled':
case 'dropEnabled':
this[property] = value;
break;
case 'data':
this.carregarSelect2(value);
break
case 'displayList':
this.displayList = value;
if(this.valueList != "" && this.displayList != ""){
this.onloadHandler();
}
break
case 'valueList':
this.valueList = value;
if(this.valueList != "" && this.displayList != ""){
this.onloadHandler();
}
break
case 'value':
this.atualizarSelecao(value);
break;
case 'enable':
$("#control_"+this.index).select2('enable',value);
break;
default:
return this.invokeSuper('setProperty',arguments);
break;
}
return true;
}

self.s00_componente_interface_scsSelect2_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsSelect2__Loader = function() {
	zenLoadClass('_ZEN_Component_control');
	s00_componente_interface_scsSelect2.prototype = zenCreate('_ZEN_Component_control',-1);
	var p = s00_componente_interface_scsSelect2.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsSelect2;
	p.superClass = ('undefined' == typeof _ZEN_Component_control) ? zenMaster._ZEN_Component_control.prototype:_ZEN_Component_control.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsSelect2';
	p._type = 'scsSelect2';
	p.serialize = s00_componente_interface_scsSelect2_serialize;
	p.getSettings = s00_componente_interface_scsSelect2_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsSelect2_ReallyRefreshContents;
	p.atualizarSelecao = s00_componente_interface_scsSelect2_atualizarSelecao;
	p.carregarSelect2 = s00_componente_interface_scsSelect2_carregarSelect2;
	p.focus = s00_componente_interface_scsSelect2_focus;
	p.getProperty = s00_componente_interface_scsSelect2_getProperty;
	p.limparSelect2 = s00_componente_interface_scsSelect2_limparSelect2;
	p.onchangeSelect2 = s00_componente_interface_scsSelect2_onchangeSelect2;
	p.onloadHandler = s00_componente_interface_scsSelect2_onloadHandler;
	p.renderContents = s00_componente_interface_scsSelect2_renderContents;
	p.setProperty = s00_componente_interface_scsSelect2_setProperty;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCalendarData'] = 's00_componente_interface_scsCalendarData';
self.s00_componente_interface_scsCalendarData = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCalendarData__init(this,index,id);}
}

self.s00_componente_interface_scsCalendarData__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_dateText__init) ?zenMaster._ZEN_Component_dateText__init(o,index,id):_ZEN_Component_dateText__init(o,index,id);
	o.AnoAtual = '';
	o.dayList = '';
	o.firstDayOfWeek = '0';
	o.format = 'DMY';
	o.invalidDateMessage = 'Invalid Date';
	o.maxDate = '';
	o.maxlength = '10';
	o.minDate = '';
	o.monthList = '';
	o.onkeypress = '';
	o.onshowPopup = '';
	o.scsAcima = false;
	o.scsEsquerda = false;
	o.scsTopo = '';
	o.separator = '\/';
	o.showTime = false;
	o.size = '15';
	o.timeCaption = '';
}
function s00_componente_interface_scsCalendarData_serialize(set,s)
{
	var o = this;s[0]='1880557713';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.AnoAtual;s[7]=o.align;s[8]=o.aux;s[9]=o.clientType;s[10]=o.containerStyle;s[11]=o.controlClass;s[12]=o.controlStyle;s[13]=o.dataBinding;s[14]=o.dayList;s[15]=o.defaultTime;s[16]=(o.disabled?1:0);s[17]=(o.dragEnabled?1:0);s[18]=(o.dropEnabled?1:0);s[19]=(o.dynamic?1:0);s[20]=o.enclosingClass;s[21]=o.enclosingStyle;s[22]=o.error;s[23]=o.firstDayOfWeek;s[24]=o.format;s[25]=o.height;s[26]=(o.hidden?1:0);s[27]=o.hint;s[28]=o.hintClass;s[29]=o.hintStyle;s[30]=o.image;s[31]=(o.invalid?1:0);s[32]=o.invalidDateMessage;s[33]=o.invalidMessage;s[34]=o.label;s[35]=o.labelClass;s[36]=o.labelDisabledClass;s[37]=o.labelStyle;s[38]=o.maxDate;s[39]=o.maxlength;s[40]=o.minDate;s[41]=o.monthList;s[42]=o.onafterdrag;s[43]=o.onbeforedrag;s[44]=o.onblur;s[45]=o.onchange;s[46]=o.onclick;s[47]=o.ondblclick;s[48]=o.ondrag;s[49]=o.ondrop;s[50]=o.onfocus;s[51]=o.onhide;s[52]=o.onkeydown;s[53]=o.onkeypress;s[54]=o.onkeyup;s[55]=o.onmousedown;s[56]=o.onmouseout;s[57]=o.onmouseover;s[58]=o.onmouseup;s[59]=o.onrefresh;s[60]=o.onshow;s[61]=o.onshowPopup;s[62]=o.onsubmit;s[63]=o.ontouchend;s[64]=o.ontouchmove;s[65]=o.ontouchstart;s[66]=o.onupdate;s[67]=o.onvalidate;s[68]=o.originalValue;s[69]=o.overlayMode;s[70]=(o.readOnly?1:0);s[71]=o.renderFlag;s[72]=(o.required?1:0);s[73]=o.requiredMessage;s[74]=(o.scsAcima?1:0);s[75]=(o.scsEsquerda?1:0);s[76]=o.scsTopo;s[77]=o.separator;s[78]=(o.showLabel?1:0);s[79]=(o.showTime?1:0);s[80]=o.size;s[81]=o.slice;s[82]=o.tabIndex;s[83]=o.timeCaption;s[84]=o.title;s[85]=o.tuple;s[86]=o.valign;s[87]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[88]=(o.visible?1:0);s[89]=o.width;
}
function s00_componente_interface_scsCalendarData_getSettings(s)
{
	s['name'] = 'string';
	s['AnoAtual'] = 'string';
	s['dayList'] = 'csv';
	s['firstDayOfWeek'] = 'integer';
	s['format'] = 'enum:MDY,DMY,YMD';
	s['maxDate'] = 'string';
	s['maxlength'] = 'integer';
	s['minDate'] = 'string';
	s['monthList'] = 'csv';
	s['onkeypress'] = 'eventHandler';
	s['onshowPopup'] = 'eventHandler';
	s['scsAcima'] = 'boolean';
	s['scsEsquerda'] = 'boolean';
	s['scsTopo'] = 'string';
	s['separator'] = 'enum:-,/,., ';
	s['showTime'] = 'boolean';
	s['size'] = 'integer';
	s['timeCaption'] = 'caption';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCalendarData_dataAtual = function() {
var ctrl = this.findElement('control');
var valor = ctrl.value;
var dataAlterada = this.preencherAnoJs(valor)
if (dataAlterada != valor){
ctrl.value = dataAlterada
valor = dataAlterada
}
if ((valor == "H") || (valor == "h")){
var d = new Date();
var data = ""
switch (this.format) {
case "YMD":
data = d.getFullYear() + this.separator + (d.getMonth()<9?'0':'') + (d.getMonth()+1) + this.separator + (d.getDate()<10?'0':'') + d.getDate();
break;
case "MDY":
data = (d.getMonth()<9?'0':'') + (d.getMonth()+1) + this.separator + (d.getDate()<10?'0':'') + d.getDate() + this.separator +  d.getFullYear();
break;
default:
data = (d.getDate()<10?'0':'') + d.getDate() + this.separator + (d.getMonth()<9?'0':'') + (d.getMonth()+1) + this.separator +  d.getFullYear();
break;
}
ctrl.value = data
}
this.ondatechangeHandler()
}

self.s00_componente_interface_scsCalendarData_formatDate = function(val) {
var v = val.toString().replace(/-/g,'/');
v = v.replace(/ /g,'/');
v = v.replace(/\./g,'/');
var t = v.split('/');
if (t.length>2) {
switch (this.format) {
case 'DMY':
val = t[2] + this.separator + t[1] + this.separator + t[0];
break;
case 'MDY':
val = t[2] + this.separator + t[0] + this.separator + t[1];
break;
case 'YMD':
val = t[0] + this.separator + t[1] + this.separator + t[2];
break;
}
}
return val;
}

self.s00_componente_interface_scsCalendarData_formatarCampo = function() {
var val = this.findElement('control');
var pass = val.value;
var expr = /[0123456789]/;
var separador = this.separator
for(i=0; i<pass.length; i++){
var lchar = val.value.charAt(i);
var nchar = val.value.charAt(i+1);
if(i==0){
if ((lchar.search(expr) != 0) || (lchar>3)){
val.value = "";
}
}else if(i==1){
if(lchar.search(expr) != 0){
var tst1 = val.value.substring(0,(i));
val.value = tst1;
continue;
}
if ((nchar != separador) && (nchar != '')){
var tst1 = val.value.substring(0, (i)+1);
if(nchar.search(expr) != 0)
var tst2 = val.value.substring(i+2, pass.length);
else
var tst2 = val.value.substring(i+1, pass.length);
val.value = tst1 + separador + tst2;
}
}else if(i==4){
if(lchar.search(expr) != 0){
var tst1 = val.value.substring(0, (i));
val.value = tst1;
continue;
}
if	((nchar != separador) && (nchar != '')){
var tst1 = val.value.substring(0, (i)+1);
if(nchar.search(expr) != 0)
var tst2 = val.value.substring(i+2, pass.length);
else
var tst2 = val.value.substring(i+1, pass.length);
val.value = tst1 + separador + tst2;
}
}
if(i>=6){
if(lchar.search(expr) != 0) {
var tst1 = val.value.substring(0, (i));
val.value = tst1;
}
}
}
if(pass.length>10)
val.value = val.value.substring(0, 10);
return true;
}

self.s00_componente_interface_scsCalendarData_preencherAnoJs = function(pData) {
if(this.format == "YMD") return pData;
var qtd = pData.toString().split(this.separator).length;
if(qtd != 2) return pData;
pData = pData.toString() + this.separator + this.AnoAtual
return pData;
}

self.s00_componente_interface_scsCalendarData_renderContents = function() {
if(this.AnoAtual == ""){
this.AnoAtual = this.GetAnoAtual();
}
this.format = "DMY";
this.separator = "/"
this.dayList = "D,S,T,Q,Q,S,S";
this.monthList = "Janeiro,Fevereiro,Março,Abril,Maio,Junho,Julho,Agosto,Setembro,Outubro,Novembro,Dezembro";
this.timeCaption = "Hora:";
var div = document.createElement("div");
div.className = this.enclosingClass;
if(this.label != ""){
var label = document.createElement("span");
label.innerText = this.label;
if(this.labelClass != ""){
label.className = this.labelClass;
}else{
label.className = "zenLabel";
}
if(this.labelStyle != ""){
label.setAttribute("style",this.labelStyle);
}
div.appendChild(label);
}
var input = document.createElement("input");
input.title = this.title;
input.className = this.controlClass;
input.id = "control_"+this.index;
input.type = "text";
input.size = this.size;
input.maxlength = this.maxlength;
input.onchange= new Function("zenPage.getComponent("+this.index+").dataAtual();");
input.onkeypress= new Function("zenPage.getComponent("+this.index+").formatarCampo();");
if(this.value != ""){
input.value = this.formatDate(this.value);
}
div.appendChild(input);
var img = document.createElement("img");
img.id = "_"+this.index;
img.setAttribute("src","/csp/broker/images/datetext.gif");
img.onclick = new Function("zenPage.getComponent("+this.index+").showDateSelector("+this.scsTopo+");");
img.className = "comboboxImgButton";
div.appendChild(img);
return div;
}

self.s00_componente_interface_scsCalendarData_setProperty = function(property,value,value2) {
var el = this.findElement('control');
switch(property) {
case 'maxlength':
this.maxlength = value;
if (el) {
el.maxlength = value;
}
break;
default:
return this.invokeSuper('setProperty',arguments);
}
return true;
}

self.s00_componente_interface_scsCalendarData_showDateSelector = function(pTopo) {
if (this.disabled || this.readOnly) return;
var ctrl = this.findElement('control');
zenASSERT(ctrl,'Unable to find input element',arguments);
var value = ctrl.value;
var top,left;
var top = zenGetTop(ctrl) + ctrl.offsetHeight - zenGetTopScroll(ctrl);
var left = zenGetLeft(ctrl) - zenGetLeftScroll(ctrl);
top += this.window.document.body.scrollTop;
left += this.window.document.body.scrollLeft;
var group = zenPage.createComponent('modalGroup');
group.setProperty('onaction','zenPage.getComponent('+this.index+').applyDate(group);');
var calParms = new Object();
if ('' != this.minDate) {
var minD = zenParseDate(this.minDate);
if (-1 != minD) {
var year = parseInt(minD.substr(0,4),10);
calParms['minDate'] = this.minDate;
calParms['startYear'] = year;
}
}
if ('' != this.maxDate) {
var maxD = zenParseDate(this.maxDate);
if (-1 != maxD) {
var year = parseInt(maxD.substr(0,4),10);
calParms['maxDate'] = this.maxDate;
calParms['endYear'] = year;
}
}
if ('' != value) {
value = this.unformatValue(value);
value = (-1 == value) ? '' : value;
}
if ('' == value) {
var now = new Date();
calParms['year'] = now.getFullYear();
calParms['month'] = now.getMonth() + 1;
}
calParms['dayList'] = this.dayList;
calParms['monthList'] = this.monthList;
calParms['firstDayOfWeek'] = this.firstDayOfWeek;
if (this.showTime) {
calParms['timeCaption'] = this.timeCaption;
calParms['showTime'] = this.showTime;
}
zenInvokeCallbackMethod(this.onshowPopup,this,'onshowPopup','settings',calParms);
if(this.scsAcima){
top = parseInt(top) - 145;
}
if(pTopo){
top = pTopo;
}
if(this.scsEsquerda){
left = parseInt(left) - parseInt(ctrl.offsetWidth) - 16;
}
group.show('','calendar',value,top,left,null,null,calParms);
for (var n = 0; n < group.children.length; n++) {
var child = group.children[n];
var divid = ('' == child.id) ? 'zen'+child.index : child.id;
}
var div = document.getElementById(divid)
div.className = ""
}

self.s00_componente_interface_scsCalendarData_unformatValue = function(val) {
if ('' != val) {
if ('-'!=this.separator || 'YMD' != this.format) {
val = this.formatDate(val);
if (this.showTime && t[3]) {
val += ' ' + t[3];
}
val = zenParseDate(val,this.showTime,'YMD','-');
}
}
return val
}

self.s00_componente_interface_scsCalendarData_GetAnoAtual = function() {
	return zenClassMethod(this,'GetAnoAtual','','VARCHAR',arguments);
}

self.s00_componente_interface_scsCalendarData_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsCalendarData__Loader = function() {
	zenLoadClass('_ZEN_Component_dateText');
	s00_componente_interface_scsCalendarData.prototype = zenCreate('_ZEN_Component_dateText',-1);
	var p = s00_componente_interface_scsCalendarData.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCalendarData;
	p.superClass = ('undefined' == typeof _ZEN_Component_dateText) ? zenMaster._ZEN_Component_dateText.prototype:_ZEN_Component_dateText.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCalendarData';
	p._type = 'scsCalendarData';
	p.serialize = s00_componente_interface_scsCalendarData_serialize;
	p.getSettings = s00_componente_interface_scsCalendarData_getSettings;
	p.GetAnoAtual = s00_componente_interface_scsCalendarData_GetAnoAtual;
	p.ReallyRefreshContents = s00_componente_interface_scsCalendarData_ReallyRefreshContents;
	p.dataAtual = s00_componente_interface_scsCalendarData_dataAtual;
	p.formatDate = s00_componente_interface_scsCalendarData_formatDate;
	p.formatarCampo = s00_componente_interface_scsCalendarData_formatarCampo;
	p.preencherAnoJs = s00_componente_interface_scsCalendarData_preencherAnoJs;
	p.renderContents = s00_componente_interface_scsCalendarData_renderContents;
	p.setProperty = s00_componente_interface_scsCalendarData_setProperty;
	p.showDateSelector = s00_componente_interface_scsCalendarData_showDateSelector;
	p.unformatValue = s00_componente_interface_scsCalendarData_unformatValue;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeMVRepetidor'] = 's00_componente_interface_scsCompositeMVRepetidor';
self.s00_componente_interface_scsCompositeMVRepetidor = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeMVRepetidor__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeMVRepetidor__init = function(o,index,id) {
	('undefined' == typeof s00_componente_codigo_scsCompositeMVRepetidor__init) ?zenMaster.s00_componente_codigo_scsCompositeMVRepetidor__init(o,index,id):s00_componente_codigo_scsCompositeMVRepetidor__init(o,index,id);
}
function s00_componente_interface_scsCompositeMVRepetidor_serialize(set,s)
{
	var o = this;s[0]='3669419288';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.clientType;s[9]=o.containerStyle;s[10]=o.controlClass;s[11]=o.controlStyle;s[12]=o.dataBinding;s[13]=o.delimitador;s[14]=o.delimitadorAtr;s[15]=o.delimitadorMV;s[16]=o.delimitadorSV;s[17]=(o.disabled?1:0);s[18]=(o.dragEnabled?1:0);s[19]=(o.dropEnabled?1:0);s[20]=(o.dynamic?1:0);s[21]=o.enclosingClass;s[22]=o.enclosingStyle;s[23]=o.error;s[24]=o.height;s[25]=(o.hidden?1:0);s[26]=o.hint;s[27]=o.hintClass;s[28]=o.hintStyle;s[29]=(o.invalid?1:0);s[30]=o.invalidMessage;s[31]=o.label;s[32]=o.labelClass;s[33]=o.labelDisabledClass;s[34]=o.labelStyle;s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onblur;s[38]=o.onchange;s[39]=o.onclick;s[40]=o.ondblclick;s[41]=o.ondrag;s[42]=o.ondrop;s[43]=o.onfocus;s[44]=o.onhide;s[45]=o.onkeydown;s[46]=o.onkeypress;s[47]=o.onkeyup;s[48]=o.onmousedown;s[49]=o.onmouseout;s[50]=o.onmouseover;s[51]=o.onmouseup;s[52]=o.onrefresh;s[53]=o.onshow;s[54]=o.onsubmit;s[55]=o.ontouchend;s[56]=o.ontouchmove;s[57]=o.ontouchstart;s[58]=o.onupdate;s[59]=o.onvalidate;s[60]=o.originalValue;s[61]=o.overlayMode;s[62]=(o.readOnly?1:0);s[63]=o.renderFlag;s[64]=(o.required?1:0);s[65]=o.requiredMessage;s[66]=o.scsAlign;s[67]=o.scsAlignValorGrid;s[68]=(o.scsApresentaNumeracao?1:0);s[69]=o.scsAtributoSubValue;s[70]=o.scsCamposPersistencia;s[71]=o.scsCaption;s[72]=o.scsClassCabecalhoLinha;s[73]=o.scsClassCabecalhoTabela;s[74]=o.scsClassColuna;s[75]=o.scsClassConteudoTabela;s[76]=o.scsClassLinha;s[77]=o.scsColunasPadrao;s[78]=o.scsDisabled;s[79]=o.scsDisplayList;s[80]=o.scsEditable;s[81]=o.scsEnclosingClass;s[82]=o.scsEnclosingStyle;s[83]=o.scsHidden;s[84]=o.scsId;s[85]=o.scsLabel;s[86]=o.scsLabelGrid;s[87]=o.scsLarguraColunaNumeracao;s[88]=o.scsLarguraColunaPadrao;s[89]=o.scsLarguraInternaComponente;s[90]=o.scsLinhaSelecaoAnterior;s[91]=o.scsLinhasIniciais;s[92]=o.scsMaxlength;s[93]=o.scsOnBlur;s[94]=o.scsOnChange;s[95]=o.scsOnClick;s[96]=o.scsOnClickLinha;s[97]=o.scsOnFocus;s[98]=o.scsOnKeyDown;s[99]=o.scsOnKeyPress;s[100]=o.scsOnKeyUp;s[101]=o.scsPosicaoIniciaBackground;s[102]=o.scsQtdCaracteresColunaGrid;s[103]=o.scsReadOnly;s[104]=o.scsSize;s[105]=o.scsSql;s[106]=o.scsSqlColuna;s[107]=o.scsSqlConvCodigoPropriedade;s[108]=o.scsSqlTabela;s[109]=o.scsStringMV;s[110]=o.scsStyleCabecalhoLinha;s[111]=o.scsStyleCabecalhoTabela;s[112]=o.scsStyleColuna;s[113]=o.scsStyleConteudoTabela;s[114]=o.scsStyleLinha;s[115]=o.scsTipo;s[116]=o.scsTiposObjetosPermitidos;s[117]=o.scsValue;s[118]=o.scsValueList;s[119]=o.scsWidth;s[120]=o.scsWidthColunas;s[121]=(o.showLabel?1:0);s[122]=o.slice;s[123]=o.tabIndex;s[124]=o.title;s[125]=o.tuple;s[126]=o.valign;s[127]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[128]=(o.visible?1:0);s[129]=o.width;
}
function s00_componente_interface_scsCompositeMVRepetidor_getSettings(s)
{
	s['name'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_AdicionaObjetosZen = function() {
	return zenInstanceMethod(this,'AdicionaObjetosZen','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_AdicionarItemRepetidorAjax = function(pAntesLinha,pLinhaEspecifica,pAtualizaLinha) {
	return zenInstanceMethod(this,'AdicionarItemRepetidorAjax','L,L,B','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_AdicionarSvRepetidorAjax = function(pAtributoSv,pAtributo,pMultivalue) {
	return zenInstanceMethod(this,'AdicionarSvRepetidorAjax','L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_AjustaLarguraComponente = function(pQtdLinhas) {
	return zenInstanceMethod(this,'AjustaLarguraComponente','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_AtualizaControlesLinhas = function(pLinha) {
	return zenInstanceMethod(this,'AtualizaControlesLinhas','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_AtualizaValorRepetidor = function(pValor,pLinha,pColuna,pSubValue) {
	return zenInstanceMethod(this,'AtualizaValorRepetidor','L,L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_AtualizaValorRepetidorAjax = function(pValor,pLinha,pColuna,pSubValor,pAtualiza) {
	return zenInstanceMethod(this,'AtualizaValorRepetidorAjax','L,L,L,L,B','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_CriaObjeto = function(pTipo) {
	return zenInstanceMethod(this,'CriaObjeto','L','HANDLE',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_DesenhaBackground = function() {
	return zenInstanceMethod(this,'DesenhaBackground','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_DesenhaColunaPadrao = function(pTipoColuna,pMetodo,pLinha,pColuna) {
	return zenInstanceMethod(this,'DesenhaColunaPadrao','L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_DesenhaLinha = function(pLinha,matrizObjetosZen) {
	return zenInstanceMethod(this,'DesenhaLinha','L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_DesenhaLinhaAjax = function(pLinha) {
	return zenInstanceMethod(this,'DesenhaLinhaAjax','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_DesenhaRepetidorColunaHtml = function(pTipoCampo,pColuna,pValorCampo,pLinha,matrizObjetosZen) {
	return zenInstanceMethod(this,'DesenhaRepetidorColunaHtml','L,L,L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_DesenhaTabela = function() {
	return zenInstanceMethod(this,'DesenhaTabela','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_ExcluirItemRepetidor = function(pLinha) {
	return zenInstanceMethod(this,'ExcluirItemRepetidor','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_ExcluirItemRepetidorAjax = function(pLinha) {
	return zenInstanceMethod(this,'ExcluirItemRepetidorAjax','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_ExcluirSvRepetidor = function(pAtributo,pMultivalue,pSubValue) {
	return zenInstanceMethod(this,'ExcluirSvRepetidor','L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_ExcluirSvRepetidorAjax = function(pAtributoSv,pAtributo,pMultivalue,pSubValue) {
	return zenInstanceMethod(this,'ExcluirSvRepetidorAjax','L,L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_InsereValorRepetidor = function(pValor,pLinha,pColuna) {
	return zenInstanceMethod(this,'InsereValorRepetidor','L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_InsereValorRepetidorAjax = function(pCol1,pCol2,pCol3,pCol4,pCol5,pCol6,pCol7,pCol8,pCol9,pCol10,pCol11,pCol12,pCol13,pCol14,pCol15,pCol16,pCol17,pCol18,pCol19,pCol20) {
	return zenInstanceMethod(this,'InsereValorRepetidorAjax','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_PreparaObjetosZen = function() {
	return zenInstanceMethod(this,'PreparaObjetosZen','','HANDLE',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_PreparaObjetosZenLinha = function(pLinha) {
	return zenInstanceMethod(this,'PreparaObjetosZenLinha','L','HANDLE',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_QtdColunas = function() {
	return zenInstanceMethod(this,'QtdColunas','','INTEGER',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_QtdLinhas = function() {
	return zenInstanceMethod(this,'QtdLinhas','','INTEGER',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_RenderRepetidor = function() {
	return zenInstanceMethod(this,'RenderRepetidor','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_RetornaValorRepetidor = function(pLinha,pColuna,pSubValor) {
	return zenInstanceMethod(this,'RetornaValorRepetidor','L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_UtilizaObjetosZen = function() {
	return zenInstanceMethod(this,'UtilizaObjetosZen','','BOOLEAN',arguments);
}

self.s00_componente_interface_scsCompositeMVRepetidor_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeMVRepetidor__Loader = function() {
	zenLoadClass('s00_componente_codigo_scsCompositeMVRepetidor');
	s00_componente_interface_scsCompositeMVRepetidor.prototype = zenCreate('s00_componente_codigo_scsCompositeMVRepetidor',-1);
	var p = s00_componente_interface_scsCompositeMVRepetidor.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeMVRepetidor;
	p.superClass = ('undefined' == typeof s00_componente_codigo_scsCompositeMVRepetidor) ? zenMaster.s00_componente_codigo_scsCompositeMVRepetidor.prototype:s00_componente_codigo_scsCompositeMVRepetidor.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeMVRepetidor';
	p._type = 'scsCompositeMVRepetidor';
	p.serialize = s00_componente_interface_scsCompositeMVRepetidor_serialize;
	p.getSettings = s00_componente_interface_scsCompositeMVRepetidor_getSettings;
	p.AdicionaObjetosZen = s00_componente_interface_scsCompositeMVRepetidor_AdicionaObjetosZen;
	p.AdicionarItemRepetidorAjax = s00_componente_interface_scsCompositeMVRepetidor_AdicionarItemRepetidorAjax;
	p.AdicionarSvRepetidorAjax = s00_componente_interface_scsCompositeMVRepetidor_AdicionarSvRepetidorAjax;
	p.AjustaLarguraComponente = s00_componente_interface_scsCompositeMVRepetidor_AjustaLarguraComponente;
	p.AjustaTamanhoValor = s00_componente_interface_scsCompositeMVRepetidor_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente_interface_scsCompositeMVRepetidor_ApresentaExcecao;
	p.AtualizaControlesLinhas = s00_componente_interface_scsCompositeMVRepetidor_AtualizaControlesLinhas;
	p.AtualizaValorRepetidor = s00_componente_interface_scsCompositeMVRepetidor_AtualizaValorRepetidor;
	p.AtualizaValorRepetidorAjax = s00_componente_interface_scsCompositeMVRepetidor_AtualizaValorRepetidorAjax;
	p.CriaObjeto = s00_componente_interface_scsCompositeMVRepetidor_CriaObjeto;
	p.DesenhaBackground = s00_componente_interface_scsCompositeMVRepetidor_DesenhaBackground;
	p.DesenhaColunaPadrao = s00_componente_interface_scsCompositeMVRepetidor_DesenhaColunaPadrao;
	p.DesenhaLinha = s00_componente_interface_scsCompositeMVRepetidor_DesenhaLinha;
	p.DesenhaLinhaAjax = s00_componente_interface_scsCompositeMVRepetidor_DesenhaLinhaAjax;
	p.DesenhaRepetidorColunaHtml = s00_componente_interface_scsCompositeMVRepetidor_DesenhaRepetidorColunaHtml;
	p.DesenhaTabela = s00_componente_interface_scsCompositeMVRepetidor_DesenhaTabela;
	p.ExcluirItemRepetidor = s00_componente_interface_scsCompositeMVRepetidor_ExcluirItemRepetidor;
	p.ExcluirItemRepetidorAjax = s00_componente_interface_scsCompositeMVRepetidor_ExcluirItemRepetidorAjax;
	p.ExcluirSvRepetidor = s00_componente_interface_scsCompositeMVRepetidor_ExcluirSvRepetidor;
	p.ExcluirSvRepetidorAjax = s00_componente_interface_scsCompositeMVRepetidor_ExcluirSvRepetidorAjax;
	p.GeraCheckBoxHtml = s00_componente_interface_scsCompositeMVRepetidor_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente_interface_scsCompositeMVRepetidor_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente_interface_scsCompositeMVRepetidor_GeraRadioHtml;
	p.GeraSV1Label = s00_componente_interface_scsCompositeMVRepetidor_GeraSV1Label;
	p.GeraSV1Text = s00_componente_interface_scsCompositeMVRepetidor_GeraSV1Text;
	p.GeraSelectHtml = s00_componente_interface_scsCompositeMVRepetidor_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente_interface_scsCompositeMVRepetidor_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente_interface_scsCompositeMVRepetidor_GeraTextHtml;
	p.GetValorPropriedade = s00_componente_interface_scsCompositeMVRepetidor_GetValorPropriedade;
	p.InsereValorRepetidor = s00_componente_interface_scsCompositeMVRepetidor_InsereValorRepetidor;
	p.InsereValorRepetidorAjax = s00_componente_interface_scsCompositeMVRepetidor_InsereValorRepetidorAjax;
	p.LimpaComponente = s00_componente_interface_scsCompositeMVRepetidor_LimpaComponente;
	p.PreparaObjetosZen = s00_componente_interface_scsCompositeMVRepetidor_PreparaObjetosZen;
	p.PreparaObjetosZenLinha = s00_componente_interface_scsCompositeMVRepetidor_PreparaObjetosZenLinha;
	p.QtdColunas = s00_componente_interface_scsCompositeMVRepetidor_QtdColunas;
	p.QtdLinhas = s00_componente_interface_scsCompositeMVRepetidor_QtdLinhas;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeMVRepetidor_ReallyRefreshContents;
	p.RenderRepetidor = s00_componente_interface_scsCompositeMVRepetidor_RenderRepetidor;
	p.RetornaValorCampo = s00_componente_interface_scsCompositeMVRepetidor_RetornaValorCampo;
	p.RetornaValorRepetidor = s00_componente_interface_scsCompositeMVRepetidor_RetornaValorRepetidor;
	p.SetValorPropriedade = s00_componente_interface_scsCompositeMVRepetidor_SetValorPropriedade;
	p.UtilizaObjetosZen = s00_componente_interface_scsCompositeMVRepetidor_UtilizaObjetosZen;
	p.VerificaErro = s00_componente_interface_scsCompositeMVRepetidor_VerificaErro;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsDataSelect'] = 's00_componente_interface_scsDataSelect';
self.s00_componente_interface_scsDataSelect = function(index,id) {
	if (index>=0) {s00_componente_interface_scsDataSelect__init(this,index,id);}
}

self.s00_componente_interface_scsDataSelect__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_dateSelect__init) ?zenMaster._ZEN_Component_dateSelect__init(o,index,id):_ZEN_Component_dateSelect__init(o,index,id);
	o.format = 'DM';
}
function s00_componente_interface_scsDataSelect_serialize(set,s)
{
	var o = this;s[0]='3501050812';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.clientType;s[9]=o.containerStyle;s[10]=o.controlClass;s[11]=o.controlStyle;s[12]=o.dataBinding;s[13]=(o.disabled?1:0);s[14]=(o.dragEnabled?1:0);s[15]=(o.dropEnabled?1:0);s[16]=(o.dynamic?1:0);s[17]=o.enclosingClass;s[18]=o.enclosingStyle;s[19]=o.error;s[20]=o.format;s[21]=o.height;s[22]=(o.hidden?1:0);s[23]=o.hint;s[24]=o.hintClass;s[25]=o.hintStyle;s[26]=(o.invalid?1:0);s[27]=o.invalidMessage;s[28]=o.label;s[29]=o.labelClass;s[30]=o.labelDisabledClass;s[31]=o.labelStyle;s[32]=o.maxYear;s[33]=o.minYear;s[34]=o.monthList;s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onblur;s[38]=o.onchange;s[39]=o.onclick;s[40]=o.ondblclick;s[41]=o.ondrag;s[42]=o.ondrop;s[43]=o.onfocus;s[44]=o.onhide;s[45]=o.onkeydown;s[46]=o.onkeypress;s[47]=o.onkeyup;s[48]=o.onmousedown;s[49]=o.onmouseout;s[50]=o.onmouseover;s[51]=o.onmouseup;s[52]=o.onrefresh;s[53]=o.onshow;s[54]=o.onsubmit;s[55]=o.ontouchend;s[56]=o.ontouchmove;s[57]=o.ontouchstart;s[58]=o.onupdate;s[59]=o.onvalidate;s[60]=o.originalValue;s[61]=o.overlayMode;s[62]=(o.readOnly?1:0);s[63]=o.renderFlag;s[64]=(o.required?1:0);s[65]=o.requiredMessage;s[66]=(o.shortMonth?1:0);s[67]=(o.showLabel?1:0);s[68]=(o.showMonthNumber?1:0);s[69]=o.slice;s[70]=o.tabIndex;s[71]=o.title;s[72]=o.tuple;s[73]=o.valign;s[74]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[75]=(o.visible?1:0);s[76]=o.width;
}
function s00_componente_interface_scsDataSelect_getSettings(s)
{
	s['name'] = 'string';
	s['format'] = 'enum:MDY,DMY,YMD,DM,MD,YM,MY,Y,M';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsDataSelect_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsDataSelect__Loader = function() {
	zenLoadClass('_ZEN_Component_dateSelect');
	s00_componente_interface_scsDataSelect.prototype = zenCreate('_ZEN_Component_dateSelect',-1);
	var p = s00_componente_interface_scsDataSelect.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsDataSelect;
	p.superClass = ('undefined' == typeof _ZEN_Component_dateSelect) ? zenMaster._ZEN_Component_dateSelect.prototype:_ZEN_Component_dateSelect.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsDataSelect';
	p._type = 'scsDataSelect';
	p.serialize = s00_componente_interface_scsDataSelect_serialize;
	p.getSettings = s00_componente_interface_scsDataSelect_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsDataSelect_ReallyRefreshContents;
}

self._zenClassIdx['scsNumber'] = 's00_componente_interface_scsNumber';
self.s00_componente_interface_scsNumber = function(index,id) {
	if (index>=0) {s00_componente_interface_scsNumber__init(this,index,id);}
}

self.s00_componente_interface_scsNumber__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_text__init) ?zenMaster._ZEN_Component_text__init(o,index,id):_ZEN_Component_text__init(o,index,id);
	o.max = '';
	o.min = '';
	o.step = '';
}
function s00_componente_interface_scsNumber_serialize(set,s)
{
	var o = this;s[0]='1609572052';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=(o.autocomplete?1:0);s[8]=o.aux;s[9]=o.clientType;s[10]=o.containerStyle;s[11]=o.controlClass;s[12]=o.controlStyle;s[13]=o.dataBinding;s[14]=(o.disabled?1:0);s[15]=(o.dragEnabled?1:0);s[16]=(o.dropEnabled?1:0);s[17]=(o.dynamic?1:0);s[18]=o.enclosingClass;s[19]=o.enclosingStyle;s[20]=o.error;s[21]=o.height;s[22]=(o.hidden?1:0);s[23]=o.hint;s[24]=o.hintClass;s[25]=o.hintStyle;s[26]=o.inputtype;s[27]=(o.invalid?1:0);s[28]=o.invalidMessage;s[29]=o.label;s[30]=o.labelClass;s[31]=o.labelDisabledClass;s[32]=o.labelStyle;s[33]=o.max;s[34]=o.maxlength;s[35]=o.min;s[36]=o.onafterdrag;s[37]=o.onbeforedrag;s[38]=o.onblur;s[39]=o.onchange;s[40]=o.onclick;s[41]=o.ondblclick;s[42]=o.ondrag;s[43]=o.ondrop;s[44]=o.onfocus;s[45]=o.onhide;s[46]=o.onkeydown;s[47]=o.onkeypress;s[48]=o.onkeyup;s[49]=o.onmousedown;s[50]=o.onmouseout;s[51]=o.onmouseover;s[52]=o.onmouseup;s[53]=o.onrefresh;s[54]=o.onshow;s[55]=o.onsubmit;s[56]=o.ontouchend;s[57]=o.ontouchmove;s[58]=o.ontouchstart;s[59]=o.onupdate;s[60]=o.onvalidate;s[61]=o.originalValue;s[62]=o.overlayMode;s[63]=o.placeholder;s[64]=(o.readOnly?1:0);s[65]=o.renderFlag;s[66]=(o.required?1:0);s[67]=o.requiredMessage;s[68]=(o.showLabel?1:0);s[69]=o.size;s[70]=o.slice;s[71]=(o.spellcheck?1:0);s[72]=o.step;s[73]=o.tabIndex;s[74]=o.title;s[75]=o.tuple;s[76]=o.valign;s[77]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[78]=(o.visible?1:0);s[79]=o.width;
}
function s00_componente_interface_scsNumber_getSettings(s)
{
	s['name'] = 'string';
	s['max'] = 'float';
	s['min'] = 'float';
	s['step'] = 'float';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsNumber_setProperty = function(property,value,value2) {
var el = this.findElement('control');
switch(property) {
case 'min':
this.min = value;
if (el) { el.min = value; }
break;
case 'max':
this.max = value;
if (el) { el.max = value; }
break;
case 'step':
this.step = value;
if (el) { el.step = value; }
break;
default:
return this.invokeSuper('setProperty',arguments);
}
return true;
}

self.s00_componente_interface_scsNumber_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsNumber__Loader = function() {
	zenLoadClass('_ZEN_Component_text');
	s00_componente_interface_scsNumber.prototype = zenCreate('_ZEN_Component_text',-1);
	var p = s00_componente_interface_scsNumber.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsNumber;
	p.superClass = ('undefined' == typeof _ZEN_Component_text) ? zenMaster._ZEN_Component_text.prototype:_ZEN_Component_text.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsNumber';
	p._type = 'scsNumber';
	p.serialize = s00_componente_interface_scsNumber_serialize;
	p.getSettings = s00_componente_interface_scsNumber_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsNumber_ReallyRefreshContents;
	p.setProperty = s00_componente_interface_scsNumber_setProperty;
}

self._zenClassIdx['scsPopupGroup'] = 's00_componente_interface_scsPopupGroup';
self.s00_componente_interface_scsPopupGroup = function(index,id) {
	if (index>=0) {s00_componente_interface_scsPopupGroup__init(this,index,id);}
}

self.s00_componente_interface_scsPopupGroup__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_group__init) ?zenMaster._ZEN_Component_group__init(o,index,id):_ZEN_Component_group__init(o,index,id);
	o.enclosingClass = 'scsPopupGroup';
	o.hidden = true;
	o.hintClass = 'scsPopupGroupClose';
	o.labelClass = 'scsPopupGroupTitle';
	o.maximized = false;
	o.onclose = '';
	o.onmaximize = '';
	o.onrestore = '';
	o.scsCanEndModal = false;
	o.scsCustomTrap = false;
	o.scsExibirFundoTransparente = true;
	o.scsFecharAoClicarFundo = false;
	o.scsHeaderStyle = '';
	o.scsLeft = '';
	o.scsPositionFixed = false;
	o.scsShowClose = false;
	o.scsShowMaximize = false;
	o.scsTitulo = '';
	o.scsTop = '';
}
function s00_componente_interface_scsPopupGroup_serialize(set,s)
{
	var o = this;s[0]='1227990866';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=o.containerStyle;s[14]=(o.disabled?1:0);s[15]=(o.dragEnabled?1:0);s[16]=(o.dropEnabled?1:0);s[17]=(o.dynamic?1:0);s[18]=o.enclosingClass;s[19]=o.enclosingStyle;s[20]=o.error;s[21]=o.groupClass;s[22]=o.groupStyle;s[23]=o.height;s[24]=(o.hidden?1:0);s[25]=o.hint;s[26]=o.hintClass;s[27]=o.hintStyle;s[28]=o.label;s[29]=o.labelClass;s[30]=o.labelDisabledClass;s[31]=o.labelPosition;s[32]=o.labelStyle;s[33]=o.layout;s[34]=(o.maximized?1:0);s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onclick;s[38]=o.onclose;s[39]=o.ondrag;s[40]=o.ondrop;s[41]=o.onhide;s[42]=o.onmaximize;s[43]=o.onrefresh;s[44]=o.onrestore;s[45]=o.onshow;s[46]=o.onupdate;s[47]=o.overlayMode;s[48]=o.renderFlag;s[49]=(o.scsCanEndModal?1:0);s[50]=(o.scsCustomTrap?1:0);s[51]=(o.scsExibirFundoTransparente?1:0);s[52]=(o.scsFecharAoClicarFundo?1:0);s[53]=o.scsHeaderStyle;s[54]=o.scsLeft;s[55]=(o.scsPositionFixed?1:0);s[56]=(o.scsShowClose?1:0);s[57]=(o.scsShowMaximize?1:0);s[58]=o.scsTitulo;s[59]=o.scsTop;s[60]=(o.showLabel?1:0);s[61]=o.slice;s[62]=o.title;s[63]=o.tuple;s[64]=o.valign;s[65]=(o.visible?1:0);s[66]=o.width;
}
function s00_componente_interface_scsPopupGroup_getSettings(s)
{
	s['name'] = 'string';
	s['hidden'] = 'boolean';
	s['maximized'] = 'string';
	s['onclose'] = 'string';
	s['onmaximize'] = 'string';
	s['onrestore'] = 'string';
	s['scsCanEndModal'] = 'string';
	s['scsCustomTrap'] = 'boolean';
	s['scsExibirFundoTransparente'] = 'boolean';
	s['scsFecharAoClicarFundo'] = 'boolean';
	s['scsHeaderStyle'] = 'string';
	s['scsLeft'] = 'integer';
	s['scsPositionFixed'] = 'boolean';
	s['scsShowClose'] = 'boolean';
	s['scsShowMaximize'] = 'boolean';
	s['scsTitulo'] = 'caption';
	s['scsTop'] = 'integer';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsPopupGroup_getZenPageMenu = function() {
var paginaZen = zenPage;
while(paginaZen._serverClass != "s00.iu.Menu") {
if(paginaZen.window.opener == null && paginaZen.window.parent != undefined) {
paginaZen = paginaZen.window.parent.zenPage;
} else {
paginaZen = paginaZen.window.opener.zenPage;
break;
}
}
return paginaZen;
}

self.s00_componente_interface_scsPopupGroup_onCanEndModalHandler = function() {
if ((this.scsCanEndModal) || (this.scsFecharAoClicarFundo)){
this.scsCanEndModal = false;
return true;
}
return false;
}

self.s00_componente_interface_scsPopupGroup_onCloseHandler = function() {
this.setHidden(1);
if(this.onclose != "") {
zenInvokeCallbackMethod(this.onclose,this,'onclose');
}
return true;
}

self.s00_componente_interface_scsPopupGroup_onEndModalHandler = function(zindex) {
if (!this.hidden){
this.setHidden(true);
if(this.scsCustomTrap == 1) {
var newTrap = document.getElementById('newTrap'+this.index);
newTrap.parentNode.removeChild(newTrap);
document.getElementById('zenMouseTrap').style.visibility = '';
}
}
}

self.s00_componente_interface_scsPopupGroup_onMaximizeHandler = function() {
var _this = this;
var enc = _this.getEnclosingDiv();
var btnMaximize = document.getElementById("scsPopupGroupMaximize"+_this.index);
if(!this.maximized) {
this.maximized = true;
enc.style.top = "10px";
enc.style.right = "5px";
enc.style.height = (document.body.offsetHeight - 20)+"px";
enc.style.left = "5px";
btnMaximize.classList.remove("scsPopupGroupButtonMaximize");
btnMaximize.classList.add("scsPopupGroupButtonRestore");
zenInvokeCallbackMethod(this.onmaximize,this,'onmaximize',"altura",document.body.offsetHeight-20-60);
} else {
this.maximized = false;
enc.style.top = "";
enc.style.right = "";
enc.style.height = "";
enc.style.left = "";
btnMaximize.classList.remove("scsPopupGroupButtonRestore");
btnMaximize.classList.add("scsPopupGroupButtonMaximize");
this.setHidden(1);
setTimeout(function() {
_this.setHidden(0);
zenInvokeCallbackMethod(_this.onrestore,_this,'onrestore');
},100);
}
var zenPageMenu = this.getZenPageMenu();
if(zenPageMenu != false) {
this.getZenPageMenu().setCookie(zenPage._serverClass+"_"+_this.id+"_maximized",this.maximized,1);
}
}

self.s00_componente_interface_scsPopupGroup_onRefreshContents = function() {
for (var n = 0; n < this.children.length; n++) {
var child = this.children[n];
if (child.onRefreshContents) child.onRefreshContents();
zenInvokeCallbackMethod(child.onrefresh,child,'onrefresh');
}
if(this.getHidden() == 0) {
this.onshowScsPopupGroup(this.getEnclosingDiv(),0);
}
}

self.s00_componente_interface_scsPopupGroup_onStartModalHandler = function(zindex) {
if (this.hidden){
this.setHidden(false);
}
var enc  = this.getEnclosingDiv();
enc.style.zIndex = zindex;
var hint = this.getHintElement();
var label = this.getLabelElement();
if (hint){
hint.style.zIndex = (zindex+1);
}
if (label){
label.style.zIndex = (zindex+1);
}
if(this.scsCustomTrap == 1) {
document.getElementById('zenMouseTrap').style.visibility = 'hidden';
var newTrap = document.createElement('div');
newTrap.id = 'newTrap'+this.index;
newTrap.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:'+(zindex-1)+';opacity:.5;filter:alpha(opacity=50);background:#FFF;';
this.getEnclosingDiv().parentNode.appendChild(newTrap);
}
}

self.s00_componente_interface_scsPopupGroup_onshowScsPopupGroup = function(enc,ms) {
$("body").css("overflow", "hidden");
enc.style.width = "";
enc.style.height = "";
enc.style.display = "block";
enc.style.opacity = "0";
this.posicionarModal(0);
return 1;
}

self.s00_componente_interface_scsPopupGroup_posicionarModal = function(pAnimation,pWidth,pHeight) {
var self = this;
var divComp = self.getEnclosingDiv();
if(pAnimation != 0) divComp.style.transition = "all .6s ease-in-out";
var posScrollTop = 0;
if(document.documentElement && document.documentElement.scrollTop) {
posScrollTop = document.documentElement.scrollTop;
} else {
posScrollTop = document.body.scrollTop;
}
var posScrollLeft = 0;
if(document.documentElement && document.documentElement.scrollLeft) {
posScrollLeft = document.documentElement.scrollLeft;
} else {
posScrollLeft = document.body.scrollLeft;
}
var id = setInterval(function(){
var larguraJanela   = $(window).width();
if(self.scsPositionFixed) {
divComp.style.position = "fixed";
posScrollTop = 0;
posScrollLeft = 0;
} else {
var containerJanela = $("body").find(".page-container")[0];
if(containerJanela) {
larguraJanela   = containerJanela.offsetWidth;
}
}
var alturaJanela    = $(window).height();
var widthWindow = divComp.offsetWidth;
if (widthWindow > 0){
var posLeft,posTop;
if(pWidth && pHeight) {
posLeft = (larguraJanela - pWidth)/2;
posTop = (alturaJanela - pHeight)/2;
divComp.style.width  = pWidth + "px";
divComp.style.height = pHeight + "px";
} else {
posLeft         = (larguraJanela - divComp.offsetWidth)/2;
posTop          = (alturaJanela - divComp.offsetHeight)/2;
}
if(self.scsTop){
divComp.style.top   = (parseInt(self.scsTop,10)+ posScrollTop) + "px";
}else{
divComp.style.top   = (parseInt(posTop,10)+ posScrollTop) + "px";
}
if(self.scsLeft){
divComp.style.left   = (parseInt(self.scsLeft,10)+ posScrollLeft) + "px";
}else{
divComp.style.left  = parseInt(posLeft,10)+"px";
}
divComp.style.opacity = 1;
var label = self.getLabelElement();
if (label) {
if(pAnimation != 0) label.style.transition = "all .6s ease-in-out";
$(label).fadeIn(300);
label.style.top = (parseInt(divComp.style.top) +12) + "px";
label.style.left = (parseInt(divComp.style.left) + 20) + "px";
}
var hint = self.getHintElement();
if (hint) {
if(pAnimation != 0) hint.style.transition = "all .6s ease-in-out";
$(hint).fadeIn(300);
hint.innerHTML = '<input type="button" title="Fechar" onclick="zenPage.getComponent('+self.index+').onCloseHandler()" value="X"/>'
hint.style.top = (parseInt(divComp.style.top) + 12) + "px";
hint.style.left = (parseInt(divComp.style.left) + divComp.offsetWidth -30) + "px";
}
clearInterval(id);
}
}, 200);
}

self.s00_componente_interface_scsPopupGroup_setHidden = function(flag) {
if (zenPage.modalStack){
var compModal = zenPage.modalStack[zenPage.modalStack.length - 1];
if (compModal == this){
if (flag){
this.scsCanEndModal = true;
zenPage.endModal();
return;
} else {
return;
}
}
}
var enc = this.getEnclosingDiv();
zenASSERT(enc,"Unable to find enclosing element.",arguments);
if (flag) {
zenInvokeCallbackMethod(this.onhide,this,'onhide');
}
else {
zenInvokeCallbackMethod(this.onshow,this,'onshow');
}
this.hidden = flag;
if(flag) {
enc.style.display = "none";
var label = this.getLabelElement();
if (label) label.style.transition = "";
var hint = this.getHintElement();
if (hint) hint.style.transition = "";
enc.style.transition = "";
if(zenPage.PopupAberta != undefined) {
zenPage.PopupAberta = 0
}
$("body").css("overflow", "");
if(!this.scsExibirFundoTransparente){
document.getElementById("zenMouseTrap").style.visibility = "visible";
}
} else {
this.onshowScsPopupGroup(enc,0);
if(zenPage.PopupAberta != undefined) {
zenPage.PopupAberta = this.index
}
zenPage.startModal(this);
if(!this.scsExibirFundoTransparente){
document.getElementById("zenMouseTrap").style.visibility = "hidden";
}
}
var label = this.getLabelElement();
if (label) {
label.style.display = this.hidden ? 'none' : '';
}
var hint = this.getHintElement();
if (hint) {
hint.style.display = this.hidden ? 'none' : '';
}
if (!flag) {
if (this.exposeComponent) {
setTimeout('zenPage.getComponent('+this.index+').exposeComponent();',0);
}
}
if(this.scsShowMaximize && !flag) {
var zenPageMenu = this.getZenPageMenu();
if(zenPageMenu) {
var cacheMaximized = zenPageMenu.getCookie(zenPage._serverClass+"_"+this.id+"_maximized");
if (cacheMaximized) {
this.maximized = false;
this.onMaximizeHandler();
}
}
}else{
enc.style.top = "";
enc.style.right = "";
enc.style.height = "";
enc.style.left = "";
}
}

self.s00_componente_interface_scsPopupGroup_setProperty = function(property,value,value2) {
var compMaximize = document.getElementById("scsPopupGroupMaximize"+this.index);
switch(property) {
case "scsTitulo":
var compTitulo = document.getElementById("scsPopupGroupTitulo"+this.index);
if(compTitulo)compTitulo.innerHTML = value;
this.scsTitulo = value;
break;
case "scsShowClose":
var compFechar = document.getElementById("scsPopupGroupClose"+this.index);
if(compFechar)compFechar.style.display = value ? "" : "none";
this.scsShowClose = value;
break;
case "scsHeaderStyle":
var compHeader = document.getElementById("scsPopupGroupHeader"+this.index);
if(compHeader)compHeader.style.cssText = value;
break;
case "scsShowMaximize":
var compMaximize = document.getElementById("scsPopupGroupMaximize"+this.index);
if(compMaximize)compMaximize.style.display = value ? "" : "none";
this.scsShowMaximize = value;
this.maximized = !value;
break;
case "scsShowMaximize":
if(compMaximize)compMaximize.style.display = value ? "" : "none";
this.scsShowMaximize = value;
this.maximized = !value;
break;
default:
return this.invokeSuper('setProperty',arguments);
}
return true;
}

self.s00_componente_interface_scsPopupGroup_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsPopupGroup__Loader = function() {
	zenLoadClass('_ZEN_Component_group');
	s00_componente_interface_scsPopupGroup.prototype = zenCreate('_ZEN_Component_group',-1);
	var p = s00_componente_interface_scsPopupGroup.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsPopupGroup;
	p.superClass = ('undefined' == typeof _ZEN_Component_group) ? zenMaster._ZEN_Component_group.prototype:_ZEN_Component_group.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsPopupGroup';
	p._type = 'scsPopupGroup';
	p.serialize = s00_componente_interface_scsPopupGroup_serialize;
	p.getSettings = s00_componente_interface_scsPopupGroup_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsPopupGroup_ReallyRefreshContents;
	p.getZenPageMenu = s00_componente_interface_scsPopupGroup_getZenPageMenu;
	p.onCanEndModalHandler = s00_componente_interface_scsPopupGroup_onCanEndModalHandler;
	p.onCloseHandler = s00_componente_interface_scsPopupGroup_onCloseHandler;
	p.onEndModalHandler = s00_componente_interface_scsPopupGroup_onEndModalHandler;
	p.onMaximizeHandler = s00_componente_interface_scsPopupGroup_onMaximizeHandler;
	p.onRefreshContents = s00_componente_interface_scsPopupGroup_onRefreshContents;
	p.onStartModalHandler = s00_componente_interface_scsPopupGroup_onStartModalHandler;
	p.onshowScsPopupGroup = s00_componente_interface_scsPopupGroup_onshowScsPopupGroup;
	p.posicionarModal = s00_componente_interface_scsPopupGroup_posicionarModal;
	p.setHidden = s00_componente_interface_scsPopupGroup_setHidden;
	p.setProperty = s00_componente_interface_scsPopupGroup_setProperty;
}

self._zenClassIdx['scsRange'] = 's00_componente_interface_scsRange';
self.s00_componente_interface_scsRange = function(index,id) {
	if (index>=0) {s00_componente_interface_scsRange__init(this,index,id);}
}

self.s00_componente_interface_scsRange__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_text__init) ?zenMaster._ZEN_Component_text__init(o,index,id):_ZEN_Component_text__init(o,index,id);
	o.max = '';
	o.min = '';
	o.orientacao = 'horizontal';
	o.step = '';
	o.tamanhoSlider = '100';
}
function s00_componente_interface_scsRange_serialize(set,s)
{
	var o = this;s[0]='364513946';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=(o.autocomplete?1:0);s[8]=o.aux;s[9]=o.clientType;s[10]=o.containerStyle;s[11]=o.controlClass;s[12]=o.controlStyle;s[13]=o.dataBinding;s[14]=(o.disabled?1:0);s[15]=(o.dragEnabled?1:0);s[16]=(o.dropEnabled?1:0);s[17]=(o.dynamic?1:0);s[18]=o.enclosingClass;s[19]=o.enclosingStyle;s[20]=o.error;s[21]=o.height;s[22]=(o.hidden?1:0);s[23]=o.hint;s[24]=o.hintClass;s[25]=o.hintStyle;s[26]=o.inputtype;s[27]=(o.invalid?1:0);s[28]=o.invalidMessage;s[29]=o.label;s[30]=o.labelClass;s[31]=o.labelDisabledClass;s[32]=o.labelStyle;s[33]=o.max;s[34]=o.maxlength;s[35]=o.min;s[36]=o.onafterdrag;s[37]=o.onbeforedrag;s[38]=o.onblur;s[39]=o.onchange;s[40]=o.onclick;s[41]=o.ondblclick;s[42]=o.ondrag;s[43]=o.ondrop;s[44]=o.onfocus;s[45]=o.onhide;s[46]=o.onkeydown;s[47]=o.onkeypress;s[48]=o.onkeyup;s[49]=o.onmousedown;s[50]=o.onmouseout;s[51]=o.onmouseover;s[52]=o.onmouseup;s[53]=o.onrefresh;s[54]=o.onshow;s[55]=o.onsubmit;s[56]=o.ontouchend;s[57]=o.ontouchmove;s[58]=o.ontouchstart;s[59]=o.onupdate;s[60]=o.onvalidate;s[61]=o.orientacao;s[62]=o.originalValue;s[63]=o.overlayMode;s[64]=o.placeholder;s[65]=(o.readOnly?1:0);s[66]=o.renderFlag;s[67]=(o.required?1:0);s[68]=o.requiredMessage;s[69]=(o.showLabel?1:0);s[70]=o.size;s[71]=o.slice;s[72]=(o.spellcheck?1:0);s[73]=o.step;s[74]=o.tabIndex;s[75]=o.tamanhoSlider;s[76]=o.title;s[77]=o.tuple;s[78]=o.valign;s[79]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[80]=(o.visible?1:0);s[81]=o.width;
}
function s00_componente_interface_scsRange_getSettings(s)
{
	s['name'] = 'string';
	s['max'] = 'float';
	s['min'] = 'float';
	s['orientacao'] = 'enum:horizontal,vertical:Horizontal,Vertical';
	s['step'] = 'float';
	s['tamanhoSlider'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsRange_browserValido = function() {
var broswer = navigator.userAgent.toLowerCase();
var valido = true;
if (broswer.indexOf('msie') != -1){
if ((parseInt(broswer.split('msie')[1])) < 9){
valido = false;;
}
}
return valido
}

self.s00_componente_interface_scsRange_onloadHandler = function() {
this.setProperty("tamanhoSlider",this.tamanhoSlider)
}

self.s00_componente_interface_scsRange_setProperty = function(property,value,value2) {
var el = this.findElement('control');
var div = document.getElementById("scsRange_"+this.id);
switch(property) {
case 'min':
this.min = value;
if (el) { el.min = value; }
break;
case 'max':
this.max = value;
if (el) { el.max = value; }
break;
case 'step':
this.step = value;
if (el) { el.step = value; }
break;
case 'orientacao':
this.orientacao = value;
break;
case 'tamanhoSlider':
this.tamanhoSlider = value;
if(div){
var medidasAlinhamento = (parseFloat(this.tamanhoSlider)/2)-8
div.style.width = value+"px";
div.style.left = -medidasAlinhamento+"px";
div.style.top = +medidasAlinhamento+"px";
}
if(!this.browserValido()){
value=30;
}
if (el) { el.style.width = value+"px"; }
break;
default:
return this.invokeSuper('setProperty',arguments);
}
return true;
}

self.s00_componente_interface_scsRange_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsRange__Loader = function() {
	zenLoadClass('_ZEN_Component_text');
	s00_componente_interface_scsRange.prototype = zenCreate('_ZEN_Component_text',-1);
	var p = s00_componente_interface_scsRange.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsRange;
	p.superClass = ('undefined' == typeof _ZEN_Component_text) ? zenMaster._ZEN_Component_text.prototype:_ZEN_Component_text.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsRange';
	p._type = 'scsRange';
	p.serialize = s00_componente_interface_scsRange_serialize;
	p.getSettings = s00_componente_interface_scsRange_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsRange_ReallyRefreshContents;
	p.browserValido = s00_componente_interface_scsRange_browserValido;
	p.onloadHandler = s00_componente_interface_scsRange_onloadHandler;
	p.setProperty = s00_componente_interface_scsRange_setProperty;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsTextData'] = 's00_componente_interface_scsTextData';
self.s00_componente_interface_scsTextData = function(index,id) {
	if (index>=0) {s00_componente_interface_scsTextData__init(this,index,id);}
}

self.s00_componente_interface_scsTextData__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_dateText__init) ?zenMaster._ZEN_Component_dateText__init(o,index,id):_ZEN_Component_dateText__init(o,index,id);
	o.dayList = '';
	o.firstDayOfWeek = '0';
	o.format = 'DMY';
	o.invalidDateMessage = 'Invalid Date';
	o.maxDate = '';
	o.minDate = '';
	o.monthList = '';
	o.onkeypress = '';
	o.onshowPopup = '';
	o.separator = '\/';
	o.showTime = false;
	o.size = '15';
	o.timeCaption = '';
}
function s00_componente_interface_scsTextData_serialize(set,s)
{
	var o = this;s[0]='1363603186';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.clientType;s[9]=o.containerStyle;s[10]=o.controlClass;s[11]=o.controlStyle;s[12]=o.dataBinding;s[13]=o.dayList;s[14]=o.defaultTime;s[15]=(o.disabled?1:0);s[16]=(o.dragEnabled?1:0);s[17]=(o.dropEnabled?1:0);s[18]=(o.dynamic?1:0);s[19]=o.enclosingClass;s[20]=o.enclosingStyle;s[21]=o.error;s[22]=o.firstDayOfWeek;s[23]=o.format;s[24]=o.height;s[25]=(o.hidden?1:0);s[26]=o.hint;s[27]=o.hintClass;s[28]=o.hintStyle;s[29]=o.image;s[30]=(o.invalid?1:0);s[31]=o.invalidDateMessage;s[32]=o.invalidMessage;s[33]=o.label;s[34]=o.labelClass;s[35]=o.labelDisabledClass;s[36]=o.labelStyle;s[37]=o.maxDate;s[38]=o.minDate;s[39]=o.monthList;s[40]=o.onafterdrag;s[41]=o.onbeforedrag;s[42]=o.onblur;s[43]=o.onchange;s[44]=o.onclick;s[45]=o.ondblclick;s[46]=o.ondrag;s[47]=o.ondrop;s[48]=o.onfocus;s[49]=o.onhide;s[50]=o.onkeydown;s[51]=o.onkeypress;s[52]=o.onkeyup;s[53]=o.onmousedown;s[54]=o.onmouseout;s[55]=o.onmouseover;s[56]=o.onmouseup;s[57]=o.onrefresh;s[58]=o.onshow;s[59]=o.onshowPopup;s[60]=o.onsubmit;s[61]=o.ontouchend;s[62]=o.ontouchmove;s[63]=o.ontouchstart;s[64]=o.onupdate;s[65]=o.onvalidate;s[66]=o.originalValue;s[67]=o.overlayMode;s[68]=(o.readOnly?1:0);s[69]=o.renderFlag;s[70]=(o.required?1:0);s[71]=o.requiredMessage;s[72]=o.separator;s[73]=(o.showLabel?1:0);s[74]=(o.showTime?1:0);s[75]=o.size;s[76]=o.slice;s[77]=o.tabIndex;s[78]=o.timeCaption;s[79]=o.title;s[80]=o.tuple;s[81]=o.valign;s[82]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[83]=(o.visible?1:0);s[84]=o.width;
}
function s00_componente_interface_scsTextData_getSettings(s)
{
	s['name'] = 'string';
	s['dayList'] = 'csv';
	s['firstDayOfWeek'] = 'integer';
	s['format'] = 'enum:MDY,DMY,YMD';
	s['maxDate'] = 'string';
	s['minDate'] = 'string';
	s['monthList'] = 'csv';
	s['onkeypress'] = 'eventHandler';
	s['onshowPopup'] = 'eventHandler';
	s['separator'] = 'enum:-,/,., ';
	s['showTime'] = 'boolean';
	s['size'] = 'integer';
	s['timeCaption'] = 'caption';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsTextData_dataAtual = function() {
var ctrl = this.findElement('control');
var valor = ctrl.value;
if ((valor == "H") || (valor == "h")){
var d = new Date();
var data = ""
switch (this.format) {
case "YMD":
data = d.getFullYear() + this.separator + (d.getMonth()<9?'0':'') + (d.getMonth()+1) + this.separator + (d.getDate()<10?'0':'') + d.getDate();
break;
case "MDY":
data = (d.getMonth()<9?'0':'') + (d.getMonth()+1) + this.separator + (d.getDate()<10?'0':'') + d.getDate() + this.separator +  d.getFullYear();
break;
default:
data = (d.getDate()<10?'0':'') + d.getDate() + this.separator + (d.getMonth()<9?'0':'') + (d.getMonth()+1) + this.separator +  d.getFullYear();
break;
}
ctrl.value = data
}
this.ondatechangeHandler()
}

self.s00_componente_interface_scsTextData_formatarCampo = function() {
var val = this.findElement('control');
var pass = val.value;
var expr = /[0123456789]/;
var separador = this.separator
for(i=0; i<pass.length; i++){
var lchar = val.value.charAt(i);
var nchar = val.value.charAt(i+1);
if(i==0){
if ((lchar.search(expr) != 0) || (lchar>3)){
val.value = "";
}
}else if(i==1){
if(lchar.search(expr) != 0){
var tst1 = val.value.substring(0,(i));
val.value = tst1;
continue;
}
if ((nchar != separador) && (nchar != '')){
var tst1 = val.value.substring(0, (i)+1);
if(nchar.search(expr) != 0)
var tst2 = val.value.substring(i+2, pass.length);
else
var tst2 = val.value.substring(i+1, pass.length);
val.value = tst1 + separador + tst2;
}
}else if(i==4){
if(lchar.search(expr) != 0){
var tst1 = val.value.substring(0, (i));
val.value = tst1;
continue;
}
if	((nchar != separador) && (nchar != '')){
var tst1 = val.value.substring(0, (i)+1);
if(nchar.search(expr) != 0)
var tst2 = val.value.substring(i+2, pass.length);
else
var tst2 = val.value.substring(i+1, pass.length);
val.value = tst1 + separador + tst2;
}
}
if(i>=6){
if(lchar.search(expr) != 0) {
var tst1 = val.value.substring(0, (i));
val.value = tst1;
}
}
}
if(pass.length>10)
val.value = val.value.substring(0, 10);
return true;
}

self.s00_componente_interface_scsTextData_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsTextData__Loader = function() {
	zenLoadClass('_ZEN_Component_dateText');
	s00_componente_interface_scsTextData.prototype = zenCreate('_ZEN_Component_dateText',-1);
	var p = s00_componente_interface_scsTextData.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsTextData;
	p.superClass = ('undefined' == typeof _ZEN_Component_dateText) ? zenMaster._ZEN_Component_dateText.prototype:_ZEN_Component_dateText.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsTextData';
	p._type = 'scsTextData';
	p.serialize = s00_componente_interface_scsTextData_serialize;
	p.getSettings = s00_componente_interface_scsTextData_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsTextData_ReallyRefreshContents;
	p.dataAtual = s00_componente_interface_scsTextData_dataAtual;
	p.formatarCampo = s00_componente_interface_scsTextData_formatarCampo;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsTextHora'] = 's00_componente_interface_scsTextHora';
self.s00_componente_interface_scsTextHora = function(index,id) {
	if (index>=0) {s00_componente_interface_scsTextHora__init(this,index,id);}
}

self.s00_componente_interface_scsTextHora__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_text__init) ?zenMaster._ZEN_Component_text__init(o,index,id):_ZEN_Component_text__init(o,index,id);
	o.invalidTimeMessage = 'Hora inválida';
	o.onkeypress = '';
}
function s00_componente_interface_scsTextHora_serialize(set,s)
{
	var o = this;s[0]='3767234261';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=(o.autocomplete?1:0);s[8]=o.aux;s[9]=o.clientType;s[10]=o.containerStyle;s[11]=o.controlClass;s[12]=o.controlStyle;s[13]=o.dataBinding;s[14]=(o.disabled?1:0);s[15]=(o.dragEnabled?1:0);s[16]=(o.dropEnabled?1:0);s[17]=(o.dynamic?1:0);s[18]=o.enclosingClass;s[19]=o.enclosingStyle;s[20]=o.error;s[21]=o.height;s[22]=(o.hidden?1:0);s[23]=o.hint;s[24]=o.hintClass;s[25]=o.hintStyle;s[26]=o.inputtype;s[27]=(o.invalid?1:0);s[28]=o.invalidMessage;s[29]=o.invalidTimeMessage;s[30]=o.label;s[31]=o.labelClass;s[32]=o.labelDisabledClass;s[33]=o.labelStyle;s[34]=o.maxlength;s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onblur;s[38]=o.onchange;s[39]=o.onclick;s[40]=o.ondblclick;s[41]=o.ondrag;s[42]=o.ondrop;s[43]=o.onfocus;s[44]=o.onhide;s[45]=o.onkeydown;s[46]=o.onkeypress;s[47]=o.onkeyup;s[48]=o.onmousedown;s[49]=o.onmouseout;s[50]=o.onmouseover;s[51]=o.onmouseup;s[52]=o.onrefresh;s[53]=o.onshow;s[54]=o.onsubmit;s[55]=o.ontouchend;s[56]=o.ontouchmove;s[57]=o.ontouchstart;s[58]=o.onupdate;s[59]=o.onvalidate;s[60]=o.originalValue;s[61]=o.overlayMode;s[62]=o.placeholder;s[63]=(o.readOnly?1:0);s[64]=o.renderFlag;s[65]=(o.required?1:0);s[66]=o.requiredMessage;s[67]=(o.showLabel?1:0);s[68]=o.size;s[69]=o.slice;s[70]=(o.spellcheck?1:0);s[71]=o.tabIndex;s[72]=o.title;s[73]=o.tuple;s[74]=o.valign;s[75]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[76]=(o.visible?1:0);s[77]=o.width;
}
function s00_componente_interface_scsTextHora_getSettings(s)
{
	s['name'] = 'string';
	s['invalidTimeMessage'] = 'caption';
	s['onkeypress'] = 'eventHandler';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsTextHora_formatarCampo = function() {
var val = this.findElement('control');
var pass = val.value;
var expr = /[0123456789]/;
for(i=0; i<pass.length; i++){
var lchar = val.value.charAt(i);
var nchar = val.value.charAt(i+1);
if(i==0){
if ((lchar.search(expr) != 0) || (lchar>2)){
val.value = "";
}
}else if(i==1){
if(lchar.search(expr) != 0){
var tst1 = val.value.substring(0,(i));
val.value = tst1;
continue;
}
if ((nchar != ':') && (nchar != '')){
var tst1 = val.value.substring(0, (i)+1);
if(nchar.search(expr) != 0)
var tst2 = val.value.substring(i+2, pass.length);
else
var tst2 = val.value.substring(i+1, pass.length);
val.value = tst1 + ':' + tst2;
}
}else if(i==4){
if(lchar.search(expr) != 0){
var tst1 = val.value.substring(0, (i));
val.value = tst1;
continue;
}
if	((nchar != ':') && (nchar != '')){
var tst1 = val.value.substring(0, (i)+1);
if(nchar.search(expr) != 0)
var tst2 = val.value.substring(i+2, pass.length);
else
var tst2 = val.value.substring(i+1, pass.length);
val.value = tst1 + ':' + tst2;
}
}
if(i>=6){
if(lchar.search(expr) != 0) {
var tst1 = val.value.substring(0, (i));
val.value = tst1;
}
}
}
if(pass.length>8)
val.value = val.value.substring(0, 8);
return true;
}

self.s00_componente_interface_scsTextHora_isValid = function() {
var value = this.getValue();
if ('' == value) return true;
var strRegex = /^([0-1]{1}[0-9]{1}|[2]{1}[0-3]{1}):[0-5]{1}[0-9]{1}:[0-9]{2}$/;
var retorno = strRegex.test(value);
if (!retorno) return false;
var d = this.shiftParseTime(value);
if (-1 == d) return false;
return true;
}

self.s00_componente_interface_scsTextHora_ondatechangeHandler = function() {
var ctrl = this.findElement('control');
zenASSERT(ctrl,'Unable to find input element',arguments);
var v = this.shiftParseTime(ctrl.value);
if ((-1 == v) || (v == null)) {
ctrl.value = "";
zenPage.alertaShift(this.invalidTimeMessage);
} else {
ctrl.value = v;
}
this.onchangeHandler();
}

self.s00_componente_interface_scsTextHora_shiftParseTime = function(value) {
if (null == value || '' == value) return '';
var v = value.replace(/-/g,':');
v = v.replace(/ /g,':');
var p = v.split(':');
if (p.length >= 1) {
var hora = parseInt(p[0],10);
var minuto = 0;
if (null != p[1])
minuto = parseInt(p[1],10);
var segundo = 0;
if (null != p[2]) {
segundo = parseInt(p[2],10);
}
if (!isNaN(segundo) && !isNaN(minuto) && !isNaN(hora)) {
var d = new Date(NaN);
if (segundo >= 0 && segundo < 60) {
if (minuto >= 0 && minuto < 60) {
if (hora >= 0 && hora <= 23) {
d = new Date();
d.setHours(hora, minuto, segundo);
}
}
}
return this.shiftTimeToString(d);
}
}
}

self.s00_componente_interface_scsTextHora_shiftTimeToString = function(d) {
if (isNaN(d.getTime())) {
return -1;
}
return  (d.getHours()<10?'0':'') + d.getHours() + ':' + (d.getMinutes()<10?'0':'') + (d.getMinutes()) + ':' +  (d.getSeconds()<10?'0':'') + (d.getSeconds());
}

self.s00_componente_interface_scsTextHora_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsTextHora_validarStringHora = function(valor) {
	return zenInstanceMethod(this,'validarStringHora','L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsTextHora__Loader = function() {
	zenLoadClass('_ZEN_Component_text');
	s00_componente_interface_scsTextHora.prototype = zenCreate('_ZEN_Component_text',-1);
	var p = s00_componente_interface_scsTextHora.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsTextHora;
	p.superClass = ('undefined' == typeof _ZEN_Component_text) ? zenMaster._ZEN_Component_text.prototype:_ZEN_Component_text.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsTextHora';
	p._type = 'scsTextHora';
	p.serialize = s00_componente_interface_scsTextHora_serialize;
	p.getSettings = s00_componente_interface_scsTextHora_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsTextHora_ReallyRefreshContents;
	p.formatarCampo = s00_componente_interface_scsTextHora_formatarCampo;
	p.isValid = s00_componente_interface_scsTextHora_isValid;
	p.ondatechangeHandler = s00_componente_interface_scsTextHora_ondatechangeHandler;
	p.shiftParseTime = s00_componente_interface_scsTextHora_shiftParseTime;
	p.shiftTimeToString = s00_componente_interface_scsTextHora_shiftTimeToString;
	p.validarStringHora = s00_componente_interface_scsTextHora_validarStringHora;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsTextInteiro'] = 's00_componente_interface_scsTextInteiro';
self.s00_componente_interface_scsTextInteiro = function(index,id) {
	if (index>=0) {s00_componente_interface_scsTextInteiro__init(this,index,id);}
}

self.s00_componente_interface_scsTextInteiro__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_text__init) ?zenMaster._ZEN_Component_text__init(o,index,id):_ZEN_Component_text__init(o,index,id);
	o.controlClass = 'text inteiro';
	o.invalidIntMessage = 'Número inválido';
	o.positivo = false;
	o.valorMaximo = '999999999999';
	o.valorMinimo = '-999999999999';
}
function s00_componente_interface_scsTextInteiro_serialize(set,s)
{
	var o = this;s[0]='618429378';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=(o.autocomplete?1:0);s[8]=o.aux;s[9]=o.clientType;s[10]=o.containerStyle;s[11]=o.controlClass;s[12]=o.controlStyle;s[13]=o.dataBinding;s[14]=(o.disabled?1:0);s[15]=(o.dragEnabled?1:0);s[16]=(o.dropEnabled?1:0);s[17]=(o.dynamic?1:0);s[18]=o.enclosingClass;s[19]=o.enclosingStyle;s[20]=o.error;s[21]=o.height;s[22]=(o.hidden?1:0);s[23]=o.hint;s[24]=o.hintClass;s[25]=o.hintStyle;s[26]=o.inputtype;s[27]=(o.invalid?1:0);s[28]=o.invalidIntMessage;s[29]=o.invalidMessage;s[30]=o.label;s[31]=o.labelClass;s[32]=o.labelDisabledClass;s[33]=o.labelStyle;s[34]=o.maxlength;s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onblur;s[38]=o.onchange;s[39]=o.onclick;s[40]=o.ondblclick;s[41]=o.ondrag;s[42]=o.ondrop;s[43]=o.onfocus;s[44]=o.onhide;s[45]=o.onkeydown;s[46]=o.onkeypress;s[47]=o.onkeyup;s[48]=o.onmousedown;s[49]=o.onmouseout;s[50]=o.onmouseover;s[51]=o.onmouseup;s[52]=o.onrefresh;s[53]=o.onshow;s[54]=o.onsubmit;s[55]=o.ontouchend;s[56]=o.ontouchmove;s[57]=o.ontouchstart;s[58]=o.onupdate;s[59]=o.onvalidate;s[60]=o.originalValue;s[61]=o.overlayMode;s[62]=o.placeholder;s[63]=(o.positivo?1:0);s[64]=(o.readOnly?1:0);s[65]=o.renderFlag;s[66]=(o.required?1:0);s[67]=o.requiredMessage;s[68]=(o.showLabel?1:0);s[69]=o.size;s[70]=o.slice;s[71]=(o.spellcheck?1:0);s[72]=o.tabIndex;s[73]=o.title;s[74]=o.tuple;s[75]=o.valign;s[76]=o.valorMaximo;s[77]=o.valorMinimo;s[78]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[79]=(o.visible?1:0);s[80]=o.width;
}
function s00_componente_interface_scsTextInteiro_getSettings(s)
{
	s['name'] = 'string';
	s['invalidIntMessage'] = 'caption';
	s['positivo'] = 'boolean';
	s['valorMaximo'] = 'integer';
	s['valorMinimo'] = 'integer';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsTextInteiro_isValid = function(valor) {
if (!isNaN(valor))
{
var val = parseInt(valor,10);
if (this.positivo && (val < 0))
{
this.invalidIntMessage = "Não é permitido números negativos";
return -1;
}
else if (val > this.valorMaximo)
{
this.invalidIntMessage = "Valor acima do número máximo permitido";
return -1;
}
else if (val < this.valorMinimo)
{
this.invalidIntMessage = "Valor abaixo do número mínimo permitido";
return -1;
}
else
return valor;
}
else
return -1;
}

self.s00_componente_interface_scsTextInteiro_onintchangeHandler = function() {
var ctrl = this.findElement('control');
zenASSERT(ctrl,'Unable to find input element',arguments);
var v = this.isValid(ctrl.value);
if (-1 == v) {
ctrl.value = "";
alert(this.invalidIntMessage);
} else {
ctrl.value = v;
}
this.onchangeHandler();
}

self.s00_componente_interface_scsTextInteiro_renderContents = function() {
var textInteiro = document.createElement("input");
textInteiro.id = "control_"+this.index;
textInteiro.type = "text";
textInteiro.className = this.controlClass;
textInteiro.style.cssText = "text-align:right;"+this.controlStyle;
textInteiro.value = this.value;
textInteiro.size = (this.size==undefined || this.size=="") ? 10:this.size;
textInteiro.maxlength = this.maxlength;
textInteiro.onkeypress = new Function("zenPage.getComponent("+this.index+").somenteNumero(event);");
textInteiro.onblur = new Function("zenPage.getComponent("+this.index+").onintchangeHandler();");
return textInteiro;
}

self.s00_componente_interface_scsTextInteiro_somenteNumero = function(e) {
var ctrl = this.findElement('control');
var valor = ctrl.value
zenASSERT(ctrl,'Unable to find input element',arguments);
var tecla = e.keyCode;
if(tecla > 47 && tecla < 58) { // numeros de 0 a 9 e os caracteres ",";".";"+"
return true;
} else {
if((tecla != 8) && (tecla != 13) && (tecla != 9)) {
e.keyCode = 0;
return false;
} else {
return true;
}
}
}

self.s00_componente_interface_scsTextInteiro_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsTextInteiro__Loader = function() {
	zenLoadClass('_ZEN_Component_text');
	s00_componente_interface_scsTextInteiro.prototype = zenCreate('_ZEN_Component_text',-1);
	var p = s00_componente_interface_scsTextInteiro.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsTextInteiro;
	p.superClass = ('undefined' == typeof _ZEN_Component_text) ? zenMaster._ZEN_Component_text.prototype:_ZEN_Component_text.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsTextInteiro';
	p._type = 'scsTextInteiro';
	p.serialize = s00_componente_interface_scsTextInteiro_serialize;
	p.getSettings = s00_componente_interface_scsTextInteiro_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsTextInteiro_ReallyRefreshContents;
	p.isValid = s00_componente_interface_scsTextInteiro_isValid;
	p.onintchangeHandler = s00_componente_interface_scsTextInteiro_onintchangeHandler;
	p.renderContents = s00_componente_interface_scsTextInteiro_renderContents;
	p.somenteNumero = s00_componente_interface_scsTextInteiro_somenteNumero;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsTextMoeda'] = 's00_componente_interface_scsTextMoeda';
self.s00_componente_interface_scsTextMoeda = function(index,id) {
	if (index>=0) {s00_componente_interface_scsTextMoeda__init(this,index,id);}
}

self.s00_componente_interface_scsTextMoeda__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_text__init) ?zenMaster._ZEN_Component_text__init(o,index,id):_ZEN_Component_text__init(o,index,id);
	o.SeparadorDecimal = ',';
	o.SeparadorMilhar = '.';
	o.ValorComparar = '';
	o.casasDecimais = '2';
	o.invalidRealMessage = 'Número inválido';
	o.maxLenInteiro = '';
	o.positivo = false;
	o.valorAntigo = '';
	o.valorMaximo = '99999999';
	o.valorMinimo = '-99999999';
}
function s00_componente_interface_scsTextMoeda_serialize(set,s)
{
	var o = this;s[0]='3522747077';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.SeparadorDecimal;s[7]=o.SeparadorMilhar;s[8]=o.ValorComparar;s[9]=o.align;s[10]=(o.autocomplete?1:0);s[11]=o.aux;s[12]=o.casasDecimais;s[13]=o.clientType;s[14]=o.containerStyle;s[15]=o.controlClass;s[16]=o.controlStyle;s[17]=o.dataBinding;s[18]=(o.disabled?1:0);s[19]=(o.dragEnabled?1:0);s[20]=(o.dropEnabled?1:0);s[21]=(o.dynamic?1:0);s[22]=o.enclosingClass;s[23]=o.enclosingStyle;s[24]=o.error;s[25]=o.height;s[26]=(o.hidden?1:0);s[27]=o.hint;s[28]=o.hintClass;s[29]=o.hintStyle;s[30]=o.inputtype;s[31]=(o.invalid?1:0);s[32]=o.invalidMessage;s[33]=o.invalidRealMessage;s[34]=o.label;s[35]=o.labelClass;s[36]=o.labelDisabledClass;s[37]=o.labelStyle;s[38]=o.maxLenInteiro;s[39]=o.maxlength;s[40]=o.onafterdrag;s[41]=o.onbeforedrag;s[42]=o.onblur;s[43]=o.onchange;s[44]=o.onclick;s[45]=o.ondblclick;s[46]=o.ondrag;s[47]=o.ondrop;s[48]=o.onfocus;s[49]=o.onhide;s[50]=o.onkeydown;s[51]=o.onkeypress;s[52]=o.onkeyup;s[53]=o.onmousedown;s[54]=o.onmouseout;s[55]=o.onmouseover;s[56]=o.onmouseup;s[57]=o.onrefresh;s[58]=o.onshow;s[59]=o.onsubmit;s[60]=o.ontouchend;s[61]=o.ontouchmove;s[62]=o.ontouchstart;s[63]=o.onupdate;s[64]=o.onvalidate;s[65]=o.originalValue;s[66]=o.overlayMode;s[67]=o.placeholder;s[68]=(o.positivo?1:0);s[69]=(o.readOnly?1:0);s[70]=o.renderFlag;s[71]=(o.required?1:0);s[72]=o.requiredMessage;s[73]=(o.showLabel?1:0);s[74]=o.size;s[75]=o.slice;s[76]=(o.spellcheck?1:0);s[77]=o.tabIndex;s[78]=o.title;s[79]=o.tuple;s[80]=o.valign;s[81]=o.valorAntigo;s[82]=o.valorMaximo;s[83]=o.valorMinimo;s[84]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[85]=(o.visible?1:0);s[86]=o.width;
}
function s00_componente_interface_scsTextMoeda_getSettings(s)
{
	s['name'] = 'string';
	s['SeparadorDecimal'] = 'string';
	s['SeparadorMilhar'] = 'string';
	s['ValorComparar'] = 'string';
	s['casasDecimais'] = 'integer';
	s['invalidRealMessage'] = 'caption';
	s['maxLenInteiro'] = 'integer';
	s['positivo'] = 'boolean';
	s['valorAntigo'] = 'string';
	s['valorMaximo'] = 'float';
	s['valorMinimo'] = 'float';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsTextMoeda_formatarValor = function(pValor,pInterno) {
if (pValor == "") return pValor
if (pInterno == 1){
pValor = this.valorDisplayToLogical(pValor)
} else {
var msg = "";
var vrInterno = this.valorDisplayToLogical(pValor)
if (vrInterno == ""){
msg = "Número inválido."
zenPage.alertaShift(msg)
pValor = ""
this.value = ""
} else if ((this.positivo == 1) && (parseFloat(vrInterno) < 0)){
this.invalidRealMessage = "Não é permitido números negativos."
zenPage.alertaShift(this.invalidRealMessage)
pValor = ""
this.value = ""
} else if (parseFloat(vrInterno) > parseFloat(this.valorMaximo)) {
this.invalidRealMessage = "Valor acima do número máximo permitido"
zenPage.alertaShift(this.invalidRealMessage)
pValor = ""
this.value = ""
} else if (parseFloat(vrInterno) < parseFloat(this.valorMinimo)){
this.invalidRealMessage = "Valor abaixo do número mínimo permitido"
zenPage.alertaShift(this.invalidRealMessage)
pValor = ""
this.value = ""
} else {
this.value = vrInterno
pValor = this.valorLogicalToDisplay(vrInterno)
}
}
return pValor
}

self.s00_componente_interface_scsTextMoeda_onrealchangeHandler = function() {
var ctrl = this.findElement('control');
var valorFormatado = this.formatarValor(ctrl.value,0);
var valorInterno   = this.formatarValor(ctrl.value,1);
this.ValorComparar = this.value
ctrl.value = valorFormatado;
this.value = this.formatarValor(valorFormatado,1);
this.onchangeHandler();
}

self.s00_componente_interface_scsTextMoeda_renderContents = function() {
var textMoeda = document.createElement("input");
textMoeda.id = "control_"+this.index;
textMoeda.type = "text";
textMoeda.className = this.controlClass;
textMoeda.value = this.value;
textMoeda.size = (this.size==undefined || this.size=="") ? 10:this.size;
textMoeda.maxlength = this.maxlength;
textMoeda.onkeypress = new Function("zenPage.getComponent("+this.index+").somenteNumero(event);");
textMoeda.onkeyup = new Function("zenPage.getComponent("+this.index+").verificarTotal();");
textMoeda.onblur = new Function("zenPage.getComponent("+this.index+").onrealchangeHandler();");
textMoeda.getValue = new Function("return zenPage.getComponent("+this.index+").formatarValor(this.value,1);");
return textMoeda;
}

self.s00_componente_interface_scsTextMoeda_setProperty = function(property,value,value2) {
var el = this.findElement('control');
switch(property) {
case 'size':
this.size = value;
if (el) { el.size = value; }
break;
case 'maxlength':
this.maxlength = value;
if (el) { el.maxlength = value; }
break;
case 'value':
var value = parseFloat(value)
if (!isNaN(value)){
this.value = value;
el.value = this.valorLogicalToDisplay(value);
} else {
this.value = "";
el.value = "";
}
this.ValorComparar = this.value
break;
default:
return this.invokeSuper('setProperty',arguments);
}
return true;
}

self.s00_componente_interface_scsTextMoeda_somenteNumero = function(e) {
var ctrl = this.findElement('control');
var valor = ctrl.value
zenASSERT(ctrl,'Unable to find input element',arguments);
var tecla = e.keyCode;
if(tecla > 43 && tecla < 58) { // numeros de 0 a 9 e os caracteres ",";".";"+"
return true;
} else {
if(tecla != 8) {
e.keyCode = 0;
return false;
}
}
}

self.s00_componente_interface_scsTextMoeda_totalParInteiro = function(pValor) {
if (this.maxLenInteiro == "") return 1
var separadorDecimal = this.SeparadorDecimal
var separadorNumero  =  this.SeparadorMilhar
var auxValor         = pValor
auxValor             = auxValor.toString()
auxValor             = auxValor.split(separadorDecimal)
var parInteiro       = ""
var decimal          = ""
if (auxValor.length == 2){
parInteiro       = auxValor[0]
decimal          = auxValor[1]
} else if (auxValor.length == 1){
parInteiro = auxValor[0]
}
while (parInteiro.indexOf(separadorNumero) != -1) {
parInteiro = parInteiro.replace(separadorNumero, "");
}
var tamanhoInteiro = parInteiro.length
var tamanhoDecimal = decimal.length
if((parseInt(tamanhoInteiro) > parseInt(this.maxLenInteiro)) || (parseInt(tamanhoDecimal) > parseInt(this.casasDecimais))){
return 0
} else {
return 1
}
}

self.s00_componente_interface_scsTextMoeda_unformatValue = function(val) {
return this.value
}

self.s00_componente_interface_scsTextMoeda_valorDisplayToLogical = function(pValor) {
var pValorErro       = ""
if (pValor == null) var pValor = ""
pValor = pValor.toString()
var separadorDecimal = this.SeparadorDecimal
var separadorNumero  = this.SeparadorMilhar
while (pValor.indexOf(separadorNumero) != -1) {
pValor = pValor.replace(separadorNumero, "");
}
pValor = pValor.replace(separadorDecimal,".")
var ValidChars = "0123456789.-+"
for(var c=0;c<pValor.length;c++){
caracter = pValor.charAt(c)
if (ValidChars.indexOf(caracter) == -1) {
return pValorErro
}
}
return pValor
}

self.s00_componente_interface_scsTextMoeda_valorLogicalToDisplay = function(pValor) {
if (pValor == null) var pValor = ""
pValor = pValor.toString()
var pQtdDecimal      = this.casasDecimais
var pValorErro       = ""
var separadorDecimal = this.SeparadorDecimal
var separadorNumero  = this.SeparadorMilhar
var tamanhoGrupo     = 3
if (pQtdDecimal == null) pQtdDecimal = 2
if (pValorErro == null) pValorErro = ""
if (pValor == "") return pValorErro
var qtd = 0
var ValidChars = "0123456789.-"
pValor = pValor.split(".")
qtd = pValor.length
var valorDecimal = ""
var valorInteiro = ""
if (qtd == 2) {
qtdDecimal = pValor[1].length
for (var c=0;c<pQtdDecimal;c++) {
caracter = pValor[1].charAt(c)
if (ValidChars.indexOf(caracter) == -1) {
return pValorErro
}
if (pValor[1].charAt(c) == "") {
valorDecimal += "0"
}else {
valorDecimal += pValor[1].charAt(c)
}
}
qtdInteiro = pValor[0].length;
if ((qtdInteiro == 0) || (pValor[0] == "-")){
qtdInteiro++;
pValor[0] = pValor[0] + "0";
}
var cont = 0
for (var c=parseInt(qtdInteiro-1);c>-1;c--) {
caracter = pValor[0].charAt(c)
if (ValidChars.indexOf(caracter) == -1) {
return pValorErro
}
var proxSinal = false;
if (c == 1){
var proxCaracter = pValor[0].charAt(0);
if (isNaN(proxCaracter)){
proxSinal = true;
}
}
valorInteiro = pValor[0].charAt(c) + valorInteiro
cont = cont + 1
if ((c > 0) && (eval(cont%tamanhoGrupo) == 0 ) && (!proxSinal)){
valorInteiro = separadorNumero + valorInteiro
}
}
if (valorInteiro == "") valorInteiro = 0
}else if (qtd == 1) {
for (var c=0;c<pQtdDecimal;c++) {
valorDecimal += "0"
}
qtdInteiro = pValor[0].length;
if ((qtdInteiro == 0) || (pValor[0] == "-")){
qtdInteiro++;
pValor[0] = pValor[0] + "0";
}
var cont = 0
for (var c=parseInt(qtdInteiro-1);c>-1;c--) {
caracter = pValor[0].charAt(c)
if (ValidChars.indexOf(caracter) == -1) {
return pValorErro
}
valorInteiro = caracter + valorInteiro
cont = cont + 1
var proxSinal = false;
if (c == 1){
var proxCaracter = pValor[0].charAt(0);
if (isNaN(proxCaracter)){
proxSinal = true;
}
}
if ((c > 0) && (eval(cont%3) == 0) && (!proxSinal)){
valorInteiro = "." + valorInteiro
}
}
} else {
return pValorErro
}
if ((pQtdDecimal != undefined) && (pQtdDecimal == "0")){
valorRetorno = valorInteiro
}else{
valorRetorno = valorInteiro + separadorDecimal + valorDecimal
}
return valorRetorno;
}

self.s00_componente_interface_scsTextMoeda_verificarTotal = function() {
var ctrl = this.findElement('control');
var valor = ctrl.value
var retorno = this.totalParInteiro(valor)
if (retorno == 0){
ctrl.value = this.valorAntigo;
this.value = this.formatarValor(this.valorAntigo,1);
} else {
this.valorAntigo = valor
}
}

self.s00_componente_interface_scsTextMoeda_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsTextMoeda__Loader = function() {
	zenLoadClass('_ZEN_Component_text');
	s00_componente_interface_scsTextMoeda.prototype = zenCreate('_ZEN_Component_text',-1);
	var p = s00_componente_interface_scsTextMoeda.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsTextMoeda;
	p.superClass = ('undefined' == typeof _ZEN_Component_text) ? zenMaster._ZEN_Component_text.prototype:_ZEN_Component_text.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsTextMoeda';
	p._type = 'scsTextMoeda';
	p.serialize = s00_componente_interface_scsTextMoeda_serialize;
	p.getSettings = s00_componente_interface_scsTextMoeda_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsTextMoeda_ReallyRefreshContents;
	p.formatarValor = s00_componente_interface_scsTextMoeda_formatarValor;
	p.onrealchangeHandler = s00_componente_interface_scsTextMoeda_onrealchangeHandler;
	p.renderContents = s00_componente_interface_scsTextMoeda_renderContents;
	p.setProperty = s00_componente_interface_scsTextMoeda_setProperty;
	p.somenteNumero = s00_componente_interface_scsTextMoeda_somenteNumero;
	p.totalParInteiro = s00_componente_interface_scsTextMoeda_totalParInteiro;
	p.unformatValue = s00_componente_interface_scsTextMoeda_unformatValue;
	p.valorDisplayToLogical = s00_componente_interface_scsTextMoeda_valorDisplayToLogical;
	p.valorLogicalToDisplay = s00_componente_interface_scsTextMoeda_valorLogicalToDisplay;
	p.verificarTotal = s00_componente_interface_scsTextMoeda_verificarTotal;
}

self._zenClassIdx['scsTooltip'] = 's00_componente_interface_scsTooltip';
self.s00_componente_interface_scsTooltip = function(index,id) {
	if (index>=0) {s00_componente_interface_scsTooltip__init(this,index,id);}
}

self.s00_componente_interface_scsTooltip__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_group__init) ?zenMaster._ZEN_Component_group__init(o,index,id):_ZEN_Component_group__init(o,index,id);
	o.alinharPara = '';
	o.enclosingClass = 'scsTooltipGroup';
	o.hidden = true;
	o.scsCustomTrap = false;
	o.scsDropAlign = '';
	o.scsIdTarget = '';
	o.scsShowArrow = true;
	o.scsTitulo = '';
}
function s00_componente_interface_scsTooltip_serialize(set,s)
{
	var o = this;s[0]='942905572';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.alinharPara;s[8]=o.aux;s[9]=o.cellAlign;s[10]=o.cellSize;s[11]=o.cellStyle;s[12]=o.cellVAlign;s[13]=set.serializeList(o,o.children,true,'children');s[14]=o.containerStyle;s[15]=(o.disabled?1:0);s[16]=(o.dragEnabled?1:0);s[17]=(o.dropEnabled?1:0);s[18]=(o.dynamic?1:0);s[19]=o.enclosingClass;s[20]=o.enclosingStyle;s[21]=o.error;s[22]=o.groupClass;s[23]=o.groupStyle;s[24]=o.height;s[25]=(o.hidden?1:0);s[26]=o.hint;s[27]=o.hintClass;s[28]=o.hintStyle;s[29]=o.label;s[30]=o.labelClass;s[31]=o.labelDisabledClass;s[32]=o.labelPosition;s[33]=o.labelStyle;s[34]=o.layout;s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onclick;s[38]=o.ondrag;s[39]=o.ondrop;s[40]=o.onhide;s[41]=o.onrefresh;s[42]=o.onshow;s[43]=o.onupdate;s[44]=o.overlayMode;s[45]=o.renderFlag;s[46]=(o.scsCustomTrap?1:0);s[47]=o.scsDropAlign;s[48]=o.scsIdTarget;s[49]=(o.scsShowArrow?1:0);s[50]=o.scsTitulo;s[51]=(o.showLabel?1:0);s[52]=o.slice;s[53]=o.title;s[54]=o.tuple;s[55]=o.valign;s[56]=(o.visible?1:0);s[57]=o.width;
}
function s00_componente_interface_scsTooltip_getSettings(s)
{
	s['name'] = 'string';
	s['alinharPara'] = 'string';
	s['hidden'] = 'boolean';
	s['scsCustomTrap'] = 'boolean';
	s['scsDropAlign'] = 'enum:right,left';
	s['scsIdTarget'] = 'string';
	s['scsShowArrow'] = 'boolean';
	s['scsTitulo'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsTooltip_posicionarDropdown = function() {
var componente = this.scsIdTarget;
if(this.composite != null){
componente = this.composite.id + "." + componente;
}
var el = document.getElementById(componente);
var targetEl = el;
var pDrop = this.getEnclosingDiv();
var xPos = 0;
var yPos = 0;
while (el) {
if (el.tagName == "BODY") {
var xScroll = el.scrollLeft || document.documentElement.scrollLeft;
var yScroll = el.scrollTop || document.documentElement.scrollTop;
xPos += (el.offsetLeft - xScroll + el.clientLeft);
yPos += (el.offsetTop - yScroll + el.clientTop);
} else {
xPos += (el.offsetLeft - el.scrollLeft + el.clientLeft);
yPos += (el.offsetTop - el.scrollTop + el.clientTop);
}
el = el.offsetParent;
}
var styleLeft = ""
var styleTop = ""
if((document.body.offsetWidth > (xPos + pDrop.offsetWidth)) && this.scsDropAlign == "") {
styleLeft = "left: " + (xPos + (targetEl.offsetWidth/2) - (pDrop.offsetWidth/2)) + "px;";
this.alinharPara = "centro";
} else if(this.scsDropAlign == "left") {
styleLeft = "left: " + (xPos) + "px;";
this.alinharPara = "esquerda";
} else {
styleLeft = "left: " + (xPos-pDrop.offsetWidth + targetEl.offsetWidth) + "px;";
this.alinharPara = "direita";
}
styleTop = "top:" +(yPos + targetEl.offsetHeight + 15) + "px;"
return styleLeft + styleTop;
}

self.s00_componente_interface_scsTooltip_posicionarSeta = function(pArrow) {
var componente = this.scsIdTarget;
if(this.composite != null){
componente = this.composite.id + "." + componente;
}
var el = document.getElementById(componente);
var retorno = ""
if(this.alinharPara == "esquerda") {
retorno = "left:"+((el.offsetWidth/2)-15-8)+"px";
} else if (this.alinharPara == "centro") {
retorno = "left:" + ((this.getEnclosingDiv().offsetWidth/2) - pArrow.offsetWidth - 10) + "px;";
} else if (this.alinharPara == "direita") {
retorno = "right:" + ((el.offsetWidth/2) - (pArrow.offsetWidth/2) - 10) + "px;";
}
return retorno;
}

self.s00_componente_interface_scsTooltip_setHidden = function(flag) {
var enc = this.getEnclosingDiv();
zenASSERT(enc,"Unable to find enclosing element.",arguments);
if (flag) {
zenInvokeCallbackMethod(this.onhide,this,'onhide');
}
else {
zenInvokeCallbackMethod(this.onshow,this,'onshow');
}
this.hidden = flag;
enc.style.display = this.hidden ? 'none' : '';
var componente = this.scsIdTarget;
if(this.composite != null){
componente = this.composite.id + "." + componente;
}
var targetEl = document.getElementById(componente);
if (!flag) {
if(this.scsIdTarget != "") {
this.getEnclosingDiv().style.cssText = this.posicionarDropdown();
var arrow = document.getElementById("scsTooltipGroupArrow_"+this.index);
arrow.style.cssText = this.posicionarSeta(arrow);
targetEl.classList.add("activeTooltip");
if(!this.scsCustomTrap) {
var tooltip = this;
$(window).click(function() {
tooltip.setHidden(true);
targetEl.classList.remove("activeTooltip");
});
$('#'+this.scsIdTarget+', #'+this.getEnclosingDiv().id).click(function(event){
event.stopPropagation();
});
} else {
var customTrap = document.createElement("div");
customTrap.id = "scsTooltipGroupTrap_"+this.index;
customTrap.innerHTML = "&#160;"
customTrap.style.cssText = "position: fixed; top:0;left:0;right:0;bottom:0;z-index: 998;background: rgba(0,0,0,0);"
var self = this;
customTrap.onclick = function() {
customTrap.parentNode.removeChild(customTrap);
targetEl.classList.remove("activeTooltip");
self.setHidden(true);
}
document.body.appendChild(customTrap);
}
}
if (this.exposeComponent) {
setTimeout('zenPage.getComponent('+this.index+').exposeComponent();',0);
}
if (null == zenPage.modalStack) {
zenPage.modalStack = new Array();
}
zenPage.modalStack[zenPage.modalStack.length] = this;
} else {
if(this.scsCustomTrap) {
var customTrap = document.getElementById("scsTooltipGroupTrap_"+this.index);
if(customTrap) {
customTrap.parentNode.removeChild(customTrap);
targetEl.classList.remove("activeTooltip");
}
}
if (zenPage.modalStack) {
var compModal = zenPage.modalStack[zenPage.modalStack.length - 1];
if(compModal == this){
modalGroup = zenPage.modalStack.pop();
}
}
}
}

self.s00_componente_interface_scsTooltip_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsTooltip__Loader = function() {
	zenLoadClass('_ZEN_Component_group');
	s00_componente_interface_scsTooltip.prototype = zenCreate('_ZEN_Component_group',-1);
	var p = s00_componente_interface_scsTooltip.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsTooltip;
	p.superClass = ('undefined' == typeof _ZEN_Component_group) ? zenMaster._ZEN_Component_group.prototype:_ZEN_Component_group.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsTooltip';
	p._type = 'scsTooltip';
	p.serialize = s00_componente_interface_scsTooltip_serialize;
	p.getSettings = s00_componente_interface_scsTooltip_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsTooltip_ReallyRefreshContents;
	p.posicionarDropdown = s00_componente_interface_scsTooltip_posicionarDropdown;
	p.posicionarSeta = s00_componente_interface_scsTooltip_posicionarSeta;
	p.setHidden = s00_componente_interface_scsTooltip_setHidden;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/Padrao'] = 's00_componente_interface_Padrao';
self.s00_componente_interface_Padrao = function(index,id) {
	if (index>=0) {s00_componente_interface_Padrao__init(this,index,id);}
}

self.s00_componente_interface_Padrao__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_composite__init) ?zenMaster._ZEN_Component_composite__init(o,index,id):_ZEN_Component_composite__init(o,index,id);
}
function s00_componente_interface_Padrao_serialize(set,s)
{
	var o = this;s[0]='4096323540';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=(o.childrenCreated?1:0);s[14]=o.containerStyle;s[15]=(o.disabled?1:0);s[16]=(o.dragEnabled?1:0);s[17]=(o.dropEnabled?1:0);s[18]=(o.dynamic?1:0);s[19]=o.enclosingClass;s[20]=o.enclosingStyle;s[21]=o.error;s[22]=o.groupClass;s[23]=o.groupStyle;s[24]=o.height;s[25]=(o.hidden?1:0);s[26]=o.hint;s[27]=o.hintClass;s[28]=o.hintStyle;s[29]=o.label;s[30]=o.labelClass;s[31]=o.labelDisabledClass;s[32]=o.labelPosition;s[33]=o.labelStyle;s[34]=o.layout;s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onclick;s[38]=o.ondrag;s[39]=o.ondrop;s[40]=o.onhide;s[41]=o.onrefresh;s[42]=o.onshow;s[43]=o.onupdate;s[44]=o.overlayMode;s[45]=o.renderFlag;s[46]=(o.showLabel?1:0);s[47]=o.slice;s[48]=o.title;s[49]=o.tuple;s[50]=o.valign;s[51]=(o.visible?1:0);s[52]=o.width;
}
function s00_componente_interface_Padrao_getSettings(s)
{
	s['name'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_Padrao_getCampo = function(campo,propriedade) {
var componente = this.getChildById(campo);
return componente.getProperty(propriedade);
}

self.s00_componente_interface_Padrao_removeComp = function() {
zenThis.composite.setProperty('hidden', true);
}

self.s00_componente_interface_Padrao_setCampo = function(campo,valor,propriedade) {
var componente = this.getChildById(campo);
componente.setProperty(propriedade, valor);
}

self.s00_componente_interface_Padrao_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_Padrao__Loader = function() {
	zenLoadClass('_ZEN_Component_composite');
	s00_componente_interface_Padrao.prototype = zenCreate('_ZEN_Component_composite',-1);
	var p = s00_componente_interface_Padrao.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_Padrao;
	p.superClass = ('undefined' == typeof _ZEN_Component_composite) ? zenMaster._ZEN_Component_composite.prototype:_ZEN_Component_composite.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.Padrao';
	p._type = 'Padrao';
	p.serialize = s00_componente_interface_Padrao_serialize;
	p.getSettings = s00_componente_interface_Padrao_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_Padrao_ReallyRefreshContents;
	p.getCampo = s00_componente_interface_Padrao_getCampo;
	p.removeComp = s00_componente_interface_Padrao_removeComp;
	p.setCampo = s00_componente_interface_Padrao_setCampo;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsAlertaModal'] = 's00_componente_interface_scsAlertaModal';
self.s00_componente_interface_scsAlertaModal = function(index,id) {
	if (index>=0) {s00_componente_interface_scsAlertaModal__init(this,index,id);}
}

self.s00_componente_interface_scsAlertaModal__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_modalGroup__init) ?zenMaster._ZEN_Component_modalGroup__init(o,index,id):_ZEN_Component_modalGroup__init(o,index,id);
	o.okCaption = 'OK';
	o.visualizarModal = '1';
}
function s00_componente_interface_scsAlertaModal_serialize(set,s)
{
	var o = this;s[0]='1058462860';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=o.containerStyle;s[14]=(o.disabled?1:0);s[15]=(o.dragEnabled?1:0);s[16]=(o.dropEnabled?1:0);s[17]=(o.dynamic?1:0);s[18]=o.enclosingClass;s[19]=o.enclosingStyle;s[20]=o.error;s[21]=o.groupClass;s[22]=o.groupStyle;s[23]=o.groupTitle;s[24]=o.groupType;s[25]=o.height;s[26]=(o.hidden?1:0);s[27]=o.hint;s[28]=o.hintClass;s[29]=o.hintStyle;s[30]=o.label;s[31]=o.labelClass;s[32]=o.labelDisabledClass;s[33]=o.labelPosition;s[34]=o.labelStyle;s[35]=o.layout;s[36]=o.okCaption;s[37]=o.onaction;s[38]=o.onafterdrag;s[39]=o.onbeforedrag;s[40]=o.onclick;s[41]=o.ondrag;s[42]=o.ondrop;s[43]=o.onhide;s[44]=o.onhideGroup;s[45]=o.onrefresh;s[46]=o.onshow;s[47]=o.onshowGroup;s[48]=o.onupdate;s[49]=o.overlayMode;s[50]=o.renderFlag;s[51]=o.seed;s[52]=(o.showLabel?1:0);s[53]=o.slice;s[54]=o.title;s[55]=o.tuple;s[56]=o.valign;s[57]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[58]=(o.visible?1:0);s[59]=o.visualizarModal;s[60]=o.width;
}
function s00_componente_interface_scsAlertaModal_getSettings(s)
{
	s['name'] = 'string';
	s['visualizarModal'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsAlertaModal_fecharModal = function(fechar) {
if (fechar) {
this.visualizarModal = 0
zenPage.endModal();
} else {
this.visualizarModal = 1
}
}

self.s00_componente_interface_scsAlertaModal_onEndModalHandler = function(zindex) {
var grupoTitulo = this.groupTitle
var tipo = this.groupType
var valor = this.value
var topPosition = this._top
var leftPosition = this._left
var tamanho = this._width
var div = self.document.getElementById('zenFloatingDiv');
div.style.display = "none";
zenTrapTAB = (null == this._oldTrapTAB) ? false : this._oldTrapTAB;
if (zenPage && 'dynamic' == this.groupType) {
this.visible = false;
zenPage.removeChild(this);
}
div.onmousedown = null;
div.onmouseup = null;
div.onmousemove = null;
zenInvokeCallbackMethod(this.onhideGroup,this,'onhideGroup','group',this);
if (this.visualizarModal == 1) {
this.show(grupoTitulo,tipo,valor,topPosition,leftPosition,'300');
}
}

self.s00_componente_interface_scsAlertaModal_onStartModalHandler = function(zindex) {
var div = self.document.getElementById('zenFloatingDiv');
zenASSERT(div,'Unable to find floating div',arguments);
var update = false;
div.className = 'modalGroup';
div.onmousedown = null;
div.onmouseup = null;
div.onmousemove = null;
div.style.width = (this._width == null) ? 'auto' : this._width;
div.style.height = (this._height == null) ? 'auto' : this._height;
contents = this.value;
var html = new Array();
if ('' != this.groupTitle) {
html[html.length] = '<div class="modalGroupTitle" onselectstart="return false;" onmousedown="zenPage.getComponent('+this.index+').mousedownHandler(event);">';
html[html.length] = '<table border="1" cellpadding="0" cellspacing="0"><tr><td width="90%" align="left">' + this.groupTitle + '</td></tr></table>';
html[html.length] = '</div>';
}
if ('' != contents) {
html[html.length] = '<div class="modalGroupBody">';
html[html.length] = contents;
html[html.length] = '</div>';
html[html.length] = '<div class="modalGroupFooter">';
html[html.length] = '<input type="button" id="btnOk"" value="'+this.okCaption+'" align="right" onclick="zenPage.getComponent('+this.index+').fecharModal(1);" />';
html[html.length] = '<input type="button" value="Cancelar" align="right" onclick="zenPage.getComponent('+this.index+').fecharModal(1);" />';
html[html.length] = '</div>';
}
for (var n = 0; n < this.children.length; n++) {
var child = this.children[n];
var divid = ('' == child.id) ? 'zen'+child.index : child.id;
html[html.length] = '<div id="'+divid+'" class="modalGroupBody"></div>';
}
div.innerHTML = html.join('');
for (var n = 0; n < this.children.length; n++) {
var child = this.children[n];
if (child.renderContents) {
child.renderContents();
}
else {
child.refreshContents();
}
}
var top = this._top;
var left = this._left;
div.style.top = top + 'px';
div.style.left = left + 'px';
zenInvokeCallbackMethod(this.onshowGroup,this,'onshowGroup','group',this);
this._oldTrapTAB = zenTrapTAB;
zenTrapTAB = true;
div.style.zIndex = zindex;
div.style.display = "";
div.focus();
}

self.s00_componente_interface_scsAlertaModal_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsAlertaModal__Loader = function() {
	zenLoadClass('_ZEN_Component_modalGroup');
	s00_componente_interface_scsAlertaModal.prototype = zenCreate('_ZEN_Component_modalGroup',-1);
	var p = s00_componente_interface_scsAlertaModal.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsAlertaModal;
	p.superClass = ('undefined' == typeof _ZEN_Component_modalGroup) ? zenMaster._ZEN_Component_modalGroup.prototype:_ZEN_Component_modalGroup.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsAlertaModal';
	p._type = 'scsAlertaModal';
	p.serialize = s00_componente_interface_scsAlertaModal_serialize;
	p.getSettings = s00_componente_interface_scsAlertaModal_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsAlertaModal_ReallyRefreshContents;
	p.fecharModal = s00_componente_interface_scsAlertaModal_fecharModal;
	p.onEndModalHandler = s00_componente_interface_scsAlertaModal_onEndModalHandler;
	p.onStartModalHandler = s00_componente_interface_scsAlertaModal_onStartModalHandler;
}

self._zenClassIdx['scsPopupConfirm'] = 's00_componente_interface_scsPopupConfirm';
self.s00_componente_interface_scsPopupConfirm = function(index,id) {
	if (index>=0) {s00_componente_interface_scsPopupConfirm__init(this,index,id);}
}

self.s00_componente_interface_scsPopupConfirm__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_composite__init) ?zenMaster._ZEN_Component_composite__init(o,index,id):_ZEN_Component_composite__init(o,index,id);
	o.scsLabel = 'Atenção';
}
function s00_componente_interface_scsPopupConfirm_serialize(set,s)
{
	var o = this;s[0]='1737430567';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=(o.childrenCreated?1:0);s[14]=o.containerStyle;s[15]=(o.disabled?1:0);s[16]=(o.dragEnabled?1:0);s[17]=(o.dropEnabled?1:0);s[18]=(o.dynamic?1:0);s[19]=o.enclosingClass;s[20]=o.enclosingStyle;s[21]=o.error;s[22]=o.groupClass;s[23]=o.groupStyle;s[24]=o.height;s[25]=(o.hidden?1:0);s[26]=o.hint;s[27]=o.hintClass;s[28]=o.hintStyle;s[29]=o.label;s[30]=o.labelClass;s[31]=o.labelDisabledClass;s[32]=o.labelPosition;s[33]=o.labelStyle;s[34]=o.layout;s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onclick;s[38]=o.ondrag;s[39]=o.ondrop;s[40]=o.onhide;s[41]=o.onrefresh;s[42]=o.onshow;s[43]=o.onupdate;s[44]=o.overlayMode;s[45]=o.renderFlag;s[46]=o.scsLabel;s[47]=(o.showLabel?1:0);s[48]=o.slice;s[49]=o.title;s[50]=o.tuple;s[51]=o.valign;s[52]=(o.visible?1:0);s[53]=o.width;
}
function s00_componente_interface_scsPopupConfirm_getSettings(s)
{
	s['name'] = 'string';
	s['scsLabel'] = 'caption';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsPopupConfirm_confirmShift = function(pMsg,pOk,pCancelar) {
document.body.focus()
zenSetProp(this.id+".labelConfirmNaoProntos","value",pMsg);
zen(this.id+".btOkConfirm").getEnclosingDiv().children[0].onclick = pOk;
zen(this.id+".btCancelarConfirm").getEnclosingDiv().children[0].onclick = pCancelar;
this.setHidden(0)
}

self.s00_componente_interface_scsPopupConfirm_setHidden = function(flag) {
zenSetProp(this.id+".popupConfirm","hidden",flag);
/*var enc = this.getEnclosingDiv();
zenASSERT(enc,"Unable to find enclosing element.",arguments);
if (flag) {
zenInvokeCallbackMethod(this.onhide,this,'onhide');
}
else {
zenInvokeCallbackMethod(this.onshow,this,'onshow');
}
this.hidden = flag;
enc.style.display = this.hidden ? 'none' : '';
var label = this.getLabelElement();
if (label) {
label.style.display = this.hidden ? 'none' : '';
}
var hint = this.getHintElement();
if (hint) {
hint.style.display = this.hidden ? 'none' : '';
}
if (!flag) {
if (this.exposeComponent) {
setTimeout('zenPage.getComponent('+this.index+').exposeComponent();',0);
}
}*/
}

self.s00_componente_interface_scsPopupConfirm_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsPopupConfirm__Loader = function() {
	zenLoadClass('_ZEN_Component_composite');
	s00_componente_interface_scsPopupConfirm.prototype = zenCreate('_ZEN_Component_composite',-1);
	var p = s00_componente_interface_scsPopupConfirm.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsPopupConfirm;
	p.superClass = ('undefined' == typeof _ZEN_Component_composite) ? zenMaster._ZEN_Component_composite.prototype:_ZEN_Component_composite.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsPopupConfirm';
	p._type = 'scsPopupConfirm';
	p.serialize = s00_componente_interface_scsPopupConfirm_serialize;
	p.getSettings = s00_componente_interface_scsPopupConfirm_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsPopupConfirm_ReallyRefreshContents;
	p.confirmShift = s00_componente_interface_scsPopupConfirm_confirmShift;
	p.setHidden = s00_componente_interface_scsPopupConfirm_setHidden;
}

self._zenClassIdx['scsCapturaImagem'] = 's00_componente_interface_scsCapturaImagem';
self.s00_componente_interface_scsCapturaImagem = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCapturaImagem__init(this,index,id);}
}

self.s00_componente_interface_scsCapturaImagem__init = function(o,index,id) {
	('undefined' == typeof s00_componente2_interface_Padrao__init) ?zenMaster.s00_componente2_interface_Padrao__init(o,index,id):s00_componente2_interface_Padrao__init(o,index,id);
	o.imageQuality = '0.5';
	o.imageType = 'image\/jpeg';
	o.isFlashFallback = null;
	o.miniaturas = null;
	o.modoSelecao = '1';
	o.oncancelar = '';
	o.onconfirmar = '';
	o.selecaoMiniaturas = null;
	o.width = '700';
}
function s00_componente_interface_scsCapturaImagem_serialize(set,s)
{
	var o = this;s[0]='947290830';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=(o.childrenCreated?1:0);s[14]=o.containerStyle;s[15]=(o.disabled?1:0);s[16]=(o.dragEnabled?1:0);s[17]=(o.dropEnabled?1:0);s[18]=(o.dynamic?1:0);s[19]=o.enclosingClass;s[20]=o.enclosingStyle;s[21]=o.error;s[22]=o.groupClass;s[23]=o.groupStyle;s[24]=o.height;s[25]=(o.hidden?1:0);s[26]=o.hint;s[27]=o.hintClass;s[28]=o.hintStyle;s[29]=o.imageQuality;s[30]=o.imageType;s[31]=o.label;s[32]=o.labelClass;s[33]=o.labelDisabledClass;s[34]=o.labelPosition;s[35]=o.labelStyle;s[36]=o.layout;s[37]=o.modoSelecao;s[38]=o.onafterdrag;s[39]=o.onbeforedrag;s[40]=o.oncancelar;s[41]=o.onclick;s[42]=o.onconfirmar;s[43]=o.ondrag;s[44]=o.ondrop;s[45]=o.onhide;s[46]=o.onrefresh;s[47]=o.onshow;s[48]=o.onupdate;s[49]=o.overlayMode;s[50]=o.renderFlag;s[51]=(o.showLabel?1:0);s[52]=o.slice;s[53]=o.title;s[54]=o.tuple;s[55]=o.valign;s[56]=(o.visible?1:0);s[57]=o.width;
}
function s00_componente_interface_scsCapturaImagem_getSettings(s)
{
	s['name'] = 'string';
	s['imageQuality'] = 'string';
	s['imageType'] = 'string';
	s['modoSelecao'] = 'integer';
	s['oncancelar'] = 'string';
	s['onconfirmar'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCapturaImagem_adicionarMiniatura = function(pMiniatura) {
var composite = zenPage.getComponent(this.index);
try{
var container = composite.getChildById("grpMiniaturas");
var miniatura = pMiniatura;
var divContainer = container.getEnclosingDiv();
divContainer.appendChild(miniatura.interface);
divContainer.scrollTop = divContainer.scrollTop + 100;
var miniaturas = composite.getProperty("miniaturas");
if(!composite.getMiniaturaById(miniatura.imagem.id)){
miniaturas.push(miniatura);
}else{
composite.setMiniaturaById(miniatura.imagem.id, miniatura);
}
composite.setProperty("miniaturas", miniaturas);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_adicionarSelecao = function(pId) {
var composite = zenPage.getComponent(this.index);
try{
var selecao = composite.getProperty("selecaoMiniaturas");
if(!selecao || selecao.constructor != Array){
selecao = new Array();
}
var idx = _.indexOf(selecao, pId);
if(idx == -1){
selecao.push(pId);
var selected = composite.getMiniaturaById(pId);
$(selected.interface).addClass("miniatura-selected");
}
composite.setProperty("selecaoMiniaturas", selecao);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_alerta = function(pMsg) {
try{
var composite = zenPage.getComponent(this.index);
if(composite.isFlashFallback){
zenPage.alertaShift(pMsg);
}else{
zenPage.alertaShift(pMsg, "", 2);
}
}catch(e){
zenPage.alertaShift(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_alternarSelecao = function(pId) {
var composite = zenPage.getComponent(this.index);
try{
var selecao = composite.getProperty("selecaoMiniaturas");
if(!selecao || selecao.constructor != Array){
selecao = new Array();
}
var idx = _.indexOf(selecao, pId);
var selected = composite.getMiniaturaById(pId);
if(idx == -1){
selecao.push(pId);
$(selected.interface).addClass("miniatura-selected");
}else{
selecao.splice(idx, 1);
$(selected.interface).removeClass("miniatura-selected");
}
composite.setProperty("selecaoMiniaturas", selecao);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_cancelar = function() {
var composite = zenPage.getComponent(this.index);
try{
composite.dispose();
if(composite.isFlashFallback){
setTimeout(function(){composite.onCancelarHandler();}, 100);
}else{
composite.onCancelarHandler();
}
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_confirmar = function() {
var composite = zenPage.getComponent(this.index);
try{
composite.dispose();
if(composite.isFlashFallback){
setTimeout(function(){composite.onConfirmarHandler();}, 100);
}else{
composite.onConfirmarHandler();
}
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_criarDadosImagem = function(pBase64Data) {
var retorno = null;
try{
var id = (new Date()).getTime();
retorno = {
"id": id,
"data": pBase64Data,
"nome": $$$Text("Imagem")+id
};
}catch(e){
retorno = null;
composite.alerta(e.description, "", 2);
}
return retorno;
}

self.s00_componente_interface_scsCapturaImagem_criarMiniatura = function(pDados) {
var composite = zenPage.getComponent(this.index);
var miniaura = null;
try{
var imagem = pDados.imagem;
var img = document.createElement("img");
img.className = "miniatura";
img.src = imagem.data;
var anchor = document.createElement("a");
anchor.className = "miniatura-container";
anchor.appendChild(img);
anchor.addEventListener("click", function(){
composite.selecionarMiniatura.apply(composite, [imagem.id]);
});
miniaura = new function(){
this.imagem = null;
this.interface = null;
this.getId = function(){
if(this.imagem){
return this.imagem.id;
}
}
this.getDados = function(){
if(this.imagem){
return this.imagem.data;
}
return null;
};
};
miniaura.imagem = imagem;
miniaura.interface = anchor;
}catch(e){
miniaura = null;
composite.alerta(e.description, "", 2);
}
return miniaura;
}

self.s00_componente_interface_scsCapturaImagem_dispose = function() {
var composite = zenPage.getComponent(this.index);
try{
composite.exibirCamera();
if(composite.cameraApp && composite.cameraApp.dispose){
composite.cameraApp.dispose();
}
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_drawImagem = function(pMiniatura) {
var composite = zenPage.getComponent(this.index);
try{
var miniatura = pMiniatura;
var base64Data = miniatura.imagem.data;
var img = composite.getChildById("imgVisualizacao");
img.setProperty("src", base64Data);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_executarRemocao = function() {
var composite = zenPage.getComponent(this.index);
try{
var selecao = composite.getProperty("selecaoMiniaturas");
_.each(selecao, function(pId){
var miniatura = composite.getMiniaturaById(pId);
composite.removerImagem(miniatura);
composite.removerMiniatura(miniatura);
});
var miniaturas = composite.getProperty("miniaturas");
if(miniaturas.length > 0){
composite.selecionarMiniatura(miniaturas[0].getId());
}else{
composite.exibirCamera();
}
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_executarSalvarImagens = function() {
var composite = zenPage.getComponent(this.index);
try{
composite.salvarImagensSelecao();
var botao = composite.getChildById("btnImagemSavar");
if(!botao.getProperty("hidden")){
composite.hideBotaoSalvar();
}
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_executarTxtNomeImagemKeyPress = function(pZenEvent) {
var composite = zenPage.getComponent(this.index);
try{
if(pZenEvent.keyCode != 13){
composite.showBotaoSalvar();
}else{
composite.executarSalvarImagens();
}
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_exibirCamera = function() {
var composite = zenPage.getComponent(this.index);
try{
composite.getChildById("grpCamera").setHidden(false);
composite.getChildById("grpCanvas").setHidden(true);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_exibirMiniaturasArmazenadas = function() {
var composite = zenPage.getComponent(this.index);
try{
var storage = composite.readFromStorage();
if(storage){
var imagens = storage.imagens;
_.each(imagens, function(imagem){
var miniaturaArmazenada = composite.criarMiniatura({"imagem": imagem});
var encontrou = _.find(composite.getProperty("miniaturas"), function(miniatura){
return miniaturaArmazenada.getId() == miniatura.getId();
});
if(!encontrou){
composite.adicionarMiniatura(miniaturaArmazenada);
}
});
}
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_exibirVisualizacao = function() {
var composite = zenPage.getComponent(this.index);
try{
composite.getChildById("grpCamera").setHidden(true);
composite.getChildById("grpCanvas").setHidden(false);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_findMiniaturaIndex = function(pId) {
var composite = zenPage.getComponent(this.index);
var retorno = -1;
try{
var miniaturas = composite.getProperty("miniaturas");
var ids = _.map(miniaturas, function(miniatura){
return miniatura.imagem.id;
});
retorno = _.indexOf(ids, pId);
}catch(e){
retorno = -1;
composite.alerta(e.description, "", 2);
}
return retorno;
}

self.s00_componente_interface_scsCapturaImagem_getLocalStorage = function() {
var retorno = localStorage;
try{
if(window.parent && (new RegExp(".*s00.iu.Menu.cls.*").test(window.parent.location.pathname))){
retorno = window.parent.localStorage;
}
}catch(e){
composite.alerta(e.description, "", 2);
}
return retorno;
}

self.s00_componente_interface_scsCapturaImagem_getLocalStorageKey = function() {
return this["_type"];
}

self.s00_componente_interface_scsCapturaImagem_getMiniaturaById = function(pId) {
var composite = zenPage.getComponent(this.index);
var retorno = null;
try{
var miniaturas = composite.getProperty("miniaturas");
/*var idx = composite.findMiniaturaIndex(pId);
if(idx > -1){
retorno = miniaturas[idx];
}*/
retorno = _.find(miniaturas, function(miniatura){
return miniatura.imagem.id == pId;
});
}catch(e){
retorno = null;
composite.alerta(e.description, "", 2);
}
return retorno;
}

self.s00_componente_interface_scsCapturaImagem_getProperty = function(property,key) {
switch(property){
case 'miniaturas':
case 'selecaoMiniaturas':
var value = this[property];
if(!value || value.constructor != Array){
value = new Array();
this.setProperty(property, value);
}
return value;
break;
default:
return this.invokeSuper('getProperty',arguments);
}
}

self.s00_componente_interface_scsCapturaImagem_getSelecaoMiniaturas = function() {
var composite = zenPage.getComponent(this.index);
var retorno = [];
try{
var selecao = composite.getProperty("selecaoMiniaturas");
_.each(selecao, function(pId){
var miniatura = composite.getMiniaturaById(pId);
retorno.push(miniatura);
});
}catch(e){
retorno = [];
composite.alerta(e.description, "", 2);
}
return retorno;
}

self.s00_componente_interface_scsCapturaImagem_getSnapshot = function() {
var composite = zenPage.getComponent(this.index);
try{
composite.cameraApp.getSnapshot();
composite.getChildById("camera").setProperty("hidden", true);
setTimeout(function(){
composite.getChildById("camera").setProperty("hidden", false);
}, composite.isFlashFallback ? 300 : 100);
var imageType = composite.getProperty("imageType");
var imageQuality = composite.getProperty("imageQuality");
var dadosImagem = composite.criarDadosImagem(composite.cameraApp.canvas.toDataURL(imageType, imageQuality));
var miniatura = composite.criarMiniatura({"imagem": dadosImagem});
composite.adicionarMiniatura(miniatura);
composite.salvarImagem(miniatura);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_hideBotaoSalvar = function() {
var composite = zenPage.getComponent(this.index);
try{
var botao = composite.getChildById("btnImagemSavar");
if(!botao.getProperty("hidden")){
botao.setHidden(true);
}
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_inicializarCamera = function() {
var composite = zenPage.getComponent(this.index);
(function () {
'use strict';
var App = {
init: function () {
if ( this.options ) {
this.pos = 0;
this.cam = null;
this.canvas = composite.getChildById("canvas").findElement("canvas");
this.ctx = this.canvas.getContext("2d");
this.ctx.clearRect(0, 0, this.options.width, this.options.height);
this.image = this.ctx.getImageData(0, 0, this.options.width, this.options.height);
getUserMedia(this.options, this.success, this.deviceError);
window.webcam = this.options;
}
},
options: {
"audio": false,
"video": true,
el: composite.getChildById("camera").getEnclosingDiv().id,
extern: null,
append: true,
width: 320,
height: 240,
mode: "callback",
swffile: "include/jscam_canvas_only.swf",
quality: 85,
context: "",
/****** Callbacks disparadas apenas pelo componente flash *******/
onCapture: function () {
window.webcam.save();
},
onSave: function (data) {
this.drawImageLine(data);
},
drawImageLine: function(data){
var col = data.split(";"),
img = App.image,
rgba = null,
w = this.width,
h = this.height,
ultimaPosImagem = 4 * w * h;
for (var i = 0; i < w; i++) {
rgba = this.long2RGBA(parseInt(col[i], 10));
img.data[App.pos + 0] = rgba.red
img.data[App.pos + 1] = rgba.green
img.data[App.pos + 2] = rgba.blue
img.data[App.pos + 3] = rgba.alpha
App.pos += 4;
}
if (App.pos >= ultimaPosImagem) {
App.ctx.putImageData(img, 0, 0);
App.pos = 0;
}
},
long2RGBA: function(longNumber){
var rgba = {};
rgba.red = (longNumber >> 16) & 0xff;	// red
rgba.green = (longNumber >> 8) & 0xff;	// green
rgba.blue = longNumber & 0xff;			// blue
rgba.alpha = 0xff;						// alpha (transparência)
return rgba;
}
/****** Callbacks disparadas apenas pelo componente flash *******/
},
success: function (stream) {
if (App.options.context === 'webrtc') {
var video = App.options.videoEl;
if ((typeof MediaStream !== "undefined" && MediaStream !== null) && stream instanceof MediaStream) {
return video.play();
} else {
var vendorURL = window.URL || window.webkitURL;
video.src = vendorURL ? vendorURL.createObjectURL(stream) : stream;
}
video.onerror = function () {
stream.stop();
};
}
},
deviceError: function (error) {
var msg = $$$Text("Não foi possível inicializar a câmera.");
if (error) msg += "\n\n("+JSON.stringify(error)+")"
composite.alerta(msg, "", 2);
},
getSnapshot: function () {
if (App.options.context === 'webrtc') {
var video = document.getElementsByTagName('video')[0];
App.canvas.width = video.videoWidth;
App.canvas.height = video.videoHeight;
App.canvas.getContext('2d').drawImage(video, 0, 0);
} else if(App.options.context === 'flash'){
window.webcam.capture();
}
},
dispose: function(){
if(navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia){
}else{
getUserMedia(this.options, function(){}, function(){});
}
}
};
App.init();
composite.cameraApp = App;
composite.isFlashFallback = App.options.context != "webrtc";
})();
composite.exibirMiniaturasArmazenadas();
}

self.s00_componente_interface_scsCapturaImagem_limparComponente = function() {
var composite = zenPage.getComponent(this.index);
try{
composite.limparMiniatura();
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_limparMiniatura = function() {
var composite = zenPage.getComponent(this.index);
try{
var container = composite.getChildById("grpMiniaturas");
var div = container.getEnclosingDiv();
for(var i = div.children.length - 1; div.children.length > 0; i--){
div.removeChild(div.children[i]);
}
composite.setProperty("miniaturas", new Array());
composite.setProperty("selecaoMiniaturas", new Array());
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_limparSelecao = function() {
var composite = zenPage.getComponent(this.index);
try{
var selecao = composite.getProperty("selecaoMiniaturas");
for(var i = 0; i < selecao.length; i++){
composite.removerSelecao(selecao[i]);
}
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_onCancelarHandler = function() {
if(this.oncancelar != "") {
zenInvokeCallbackMethod(this.oncancelar,this,"oncancelar");
}
}

self.s00_componente_interface_scsCapturaImagem_onConfirmarHandler = function() {
if(this.onconfirmar != "") {
zenInvokeCallbackMethod(this.onconfirmar,this,"onconfirmar");
}
}

self.s00_componente_interface_scsCapturaImagem_readFromStorage = function() {
var retorno = null;
var composite = zenPage.getComponent(this.index);
try{
var localStorage_ = composite.getLocalStorage();
var key = composite.getLocalStorageKey();
retorno = JSON.parse(localStorage_.getItem(key));
}catch(e){
retorno = null;
composite.alerta(e.description, "", 2);
}
return retorno;
}

self.s00_componente_interface_scsCapturaImagem_removerImagem = function(pMiniatura) {
var composite = zenPage.getComponent(this.index);
try{
var miniatura = pMiniatura;
composite.setProperty("selecaoMiniaturas", [miniatura.imagem.id]);
composite.removerImagensSelecao();
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_removerImagensSelecao = function() {
var composite = zenPage.getComponent(this.index);
try{
var storage = composite.readFromStorage();
if (!storage) storage = {};
if (!storage.imagens || storage.imagens.constructor != Array) storage.imagens = new Array();
var ids = _.map(storage.imagens, function(imagem){return imagem.id;});
var selecao = composite.getProperty("selecaoMiniaturas");
_.each(selecao, function(pId){
var miniatura = composite.getMiniaturaById(pId);
storage.imagens = _.reject(storage.imagens, function(imagem){return imagem.id == pId;});
});
composite.writeToStorage(storage);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_removerMiniatura = function(pMiniatura) {
var composite = zenPage.getComponent(this.index);
try{
var container = composite.getChildById("grpMiniaturas");
var miniatura = pMiniatura;
container.getEnclosingDiv().removeChild(miniatura.interface);
var miniaturas = composite.getProperty("miniaturas");
var idx = composite.findMiniaturaIndex(miniatura.imagem.id);
if(idx > -1){
miniaturas.splice(idx, 1);
}
composite.setProperty("miniaturas", miniaturas);
var selecao = composite.getProperty("selecaoMiniaturas");
idx = _.indexOf(selecao, miniatura.imagem.id);
if(idx > -1){
selecao.splice(idx, 1);
}
composite.setProperty("selecaoMiniaturas", selecao);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_removerMiniaturasSelecao = function() {
var composite = zenPage.getComponent(this.index);
try{
var selecao = composite.getProperty("selecaoMiniaturas");
_.each(selecao, function(pId){
var miniatura = composite.getMiniaturaById(pId);
composite.removerMiniatura(miniatura);
});
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_removerSelecao = function(pId) {
var composite = zenPage.getComponent(this.index);
try{
var selecao = composite.getProperty("selecaoMiniaturas");
if(!selecao || selecao.constructor != Array){
selecao = new Array();
}
var idx = _.indexOf(selecao, pId);
if(idx > -1){
selecao.splice(idx, 1);
var selected = composite.getMiniaturaById(pId);
$(selected.interface).removeClass("miniatura-selected");
}
composite.setProperty("selecaoMiniaturas", selecao);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_salvarImagem = function(pMiniatura) {
var composite = zenPage.getComponent(this.index);
try{
var miniatura = pMiniatura;
composite.setProperty("selecaoMiniaturas", [miniatura.imagem.id]);
composite.salvarImagensSelecao();
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_salvarImagensSelecao = function() {
var composite = zenPage.getComponent(this.index);
try{
var storage = composite.readFromStorage();
if (!storage) storage = {};
if (!storage.imagens || storage.imagens.constructor != Array) storage.imagens = new Array();
var ids = _.map(storage.imagens, function(imagem){return imagem.id;});
var selecao = composite.getProperty("selecaoMiniaturas");
_.each(selecao, function(pId){
var miniatura = composite.getMiniaturaById(pId);
var idx = _.indexOf(ids, pId);
if(idx == -1){
storage.imagens.push(miniatura.imagem);
}else{
storage.imagens[idx] = miniatura.imagem;
}
miniatura.imagem.nome = composite.getChildById("txtNomeImagem").getValue()
});
composite.writeToStorage(storage);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_selecionarMiniatura = function(pId) {
var composite = zenPage.getComponent(this.index);
try{
var modoSelecao = composite.getProperty("modoSelecao");
if(modoSelecao == 1){
composite.selecionarSomente(pId);
}else{
composite.alternarSelecao(pId);
}
var selected = composite.getMiniaturaById(pId);
composite.getChildById("txtNomeImagem").setValue(selected.imagem.nome);
composite.drawImagem(selected);
composite.exibirVisualizacao();
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_selecionarSomente = function(pId) {
var composite = zenPage.getComponent(this.index);
try{
var anteriormenteSelecionado = null;
var selecao = composite.getProperty("selecaoMiniaturas");
if(selecao.length > 0){
anteriormenteSelecionado = selecao[0];
selecao = new Array();
}
composite.removerSelecao(anteriormenteSelecionado);
composite.adicionarSelecao(pId);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_setMiniaturaById = function(pId,pMiniatura) {
var composite = zenPage.getComponent(this.index);
try{
var miniaturas = composite.getProperty("miniaturas");
var idx = composite.findMiniaturaIndex(pId);
if(idx > -1){
miniaturas[idx] = pMiniatura;
}
composite.setProperty("miniaturas", miniaturas);
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_setProperty = function(property,value,value2) {
switch(property){
case 'miniaturas':
case 'selecaoMiniaturas':
if(!value || value.constructor != Array){
value = new Array();
}
this[property] = value;
break;
default:
return this.invokeSuper('setProperty',arguments);
}
return true;
}

self.s00_componente_interface_scsCapturaImagem_showBotaoSalvar = function() {
var composite = zenPage.getComponent(this.index);
try{
var botao = composite.getChildById("btnImagemSavar");
var elButton = botao.findElement("control");
botao.setHidden(false);
$(elButton).removeClass("showBotaoSalvar");
$(elButton).removeClass("hideBotaoSalvar");
$(elButton).addClass("showBotaoSalvar");
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_voltarCamera = function() {
var composite = zenPage.getComponent(this.index);
try{
composite.limparSelecao();
composite.exibirCamera();
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_writeToStorage = function(pDados) {
var composite = zenPage.getComponent(this.index);
try{
var localStorage_ = composite.getLocalStorage();
var key = composite.getLocalStorageKey();
localStorage_.setItem(key, JSON.stringify(pDados));
}catch(e){
composite.alerta(e.description, "", 2);
}
}

self.s00_componente_interface_scsCapturaImagem_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsCapturaImagem__Loader = function() {
	zenLoadClass('s00_componente2_interface_Padrao');
	s00_componente_interface_scsCapturaImagem.prototype = zenCreate('s00_componente2_interface_Padrao',-1);
	var p = s00_componente_interface_scsCapturaImagem.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCapturaImagem;
	p.superClass = ('undefined' == typeof s00_componente2_interface_Padrao) ? zenMaster.s00_componente2_interface_Padrao.prototype:s00_componente2_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCapturaImagem';
	p._type = 'scsCapturaImagem';
	p.serialize = s00_componente_interface_scsCapturaImagem_serialize;
	p.getSettings = s00_componente_interface_scsCapturaImagem_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsCapturaImagem_ReallyRefreshContents;
	p.adicionarMiniatura = s00_componente_interface_scsCapturaImagem_adicionarMiniatura;
	p.adicionarSelecao = s00_componente_interface_scsCapturaImagem_adicionarSelecao;
	p.alerta = s00_componente_interface_scsCapturaImagem_alerta;
	p.alternarSelecao = s00_componente_interface_scsCapturaImagem_alternarSelecao;
	p.cancelar = s00_componente_interface_scsCapturaImagem_cancelar;
	p.confirmar = s00_componente_interface_scsCapturaImagem_confirmar;
	p.criarDadosImagem = s00_componente_interface_scsCapturaImagem_criarDadosImagem;
	p.criarMiniatura = s00_componente_interface_scsCapturaImagem_criarMiniatura;
	p.dispose = s00_componente_interface_scsCapturaImagem_dispose;
	p.drawImagem = s00_componente_interface_scsCapturaImagem_drawImagem;
	p.executarRemocao = s00_componente_interface_scsCapturaImagem_executarRemocao;
	p.executarSalvarImagens = s00_componente_interface_scsCapturaImagem_executarSalvarImagens;
	p.executarTxtNomeImagemKeyPress = s00_componente_interface_scsCapturaImagem_executarTxtNomeImagemKeyPress;
	p.exibirCamera = s00_componente_interface_scsCapturaImagem_exibirCamera;
	p.exibirMiniaturasArmazenadas = s00_componente_interface_scsCapturaImagem_exibirMiniaturasArmazenadas;
	p.exibirVisualizacao = s00_componente_interface_scsCapturaImagem_exibirVisualizacao;
	p.findMiniaturaIndex = s00_componente_interface_scsCapturaImagem_findMiniaturaIndex;
	p.getLocalStorage = s00_componente_interface_scsCapturaImagem_getLocalStorage;
	p.getLocalStorageKey = s00_componente_interface_scsCapturaImagem_getLocalStorageKey;
	p.getMiniaturaById = s00_componente_interface_scsCapturaImagem_getMiniaturaById;
	p.getProperty = s00_componente_interface_scsCapturaImagem_getProperty;
	p.getSelecaoMiniaturas = s00_componente_interface_scsCapturaImagem_getSelecaoMiniaturas;
	p.getSnapshot = s00_componente_interface_scsCapturaImagem_getSnapshot;
	p.hideBotaoSalvar = s00_componente_interface_scsCapturaImagem_hideBotaoSalvar;
	p.inicializarCamera = s00_componente_interface_scsCapturaImagem_inicializarCamera;
	p.limparComponente = s00_componente_interface_scsCapturaImagem_limparComponente;
	p.limparMiniatura = s00_componente_interface_scsCapturaImagem_limparMiniatura;
	p.limparSelecao = s00_componente_interface_scsCapturaImagem_limparSelecao;
	p.onCancelarHandler = s00_componente_interface_scsCapturaImagem_onCancelarHandler;
	p.onConfirmarHandler = s00_componente_interface_scsCapturaImagem_onConfirmarHandler;
	p.readFromStorage = s00_componente_interface_scsCapturaImagem_readFromStorage;
	p.removerImagem = s00_componente_interface_scsCapturaImagem_removerImagem;
	p.removerImagensSelecao = s00_componente_interface_scsCapturaImagem_removerImagensSelecao;
	p.removerMiniatura = s00_componente_interface_scsCapturaImagem_removerMiniatura;
	p.removerMiniaturasSelecao = s00_componente_interface_scsCapturaImagem_removerMiniaturasSelecao;
	p.removerSelecao = s00_componente_interface_scsCapturaImagem_removerSelecao;
	p.salvarImagem = s00_componente_interface_scsCapturaImagem_salvarImagem;
	p.salvarImagensSelecao = s00_componente_interface_scsCapturaImagem_salvarImagensSelecao;
	p.selecionarMiniatura = s00_componente_interface_scsCapturaImagem_selecionarMiniatura;
	p.selecionarSomente = s00_componente_interface_scsCapturaImagem_selecionarSomente;
	p.setMiniaturaById = s00_componente_interface_scsCapturaImagem_setMiniaturaById;
	p.setProperty = s00_componente_interface_scsCapturaImagem_setProperty;
	p.showBotaoSalvar = s00_componente_interface_scsCapturaImagem_showBotaoSalvar;
	p.voltarCamera = s00_componente_interface_scsCapturaImagem_voltarCamera;
	p.writeToStorage = s00_componente_interface_scsCapturaImagem_writeToStorage;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsComboBox'] = 's00_componente_interface_scsComboBox';
self.s00_componente_interface_scsComboBox = function(index,id) {
	if (index>=0) {s00_componente_interface_scsComboBox__init(this,index,id);}
}

self.s00_componente_interface_scsComboBox__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_combobox__init) ?zenMaster._ZEN_Component_combobox__init(o,index,id):_ZEN_Component_combobox__init(o,index,id);
}
function s00_componente_interface_scsComboBox_serialize(set,s)
{
	var o = this;s[0]='2269554070';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=(o.autocomplete?1:0);s[8]=o.aux;s[9]=o.buttonCaption;s[10]=o.buttonImage;s[11]=o.buttonImageDown;s[12]=o.buttonTitle;s[13]=o.clientType;s[14]=o.comboType;s[15]=o.containerStyle;s[16]=o.controlClass;s[17]=o.controlStyle;s[18]=o.dataBinding;s[19]=o.delay;s[20]=(o.disabled?1:0);s[21]=o.displayList;s[22]=(o.dragEnabled?1:0);s[23]=(o.dropEnabled?1:0);s[24]=o.dropdownHeight;s[25]=o.dropdownWidth;s[26]=(o.dynamic?1:0);s[27]=(o.editable?1:0);s[28]=o.enclosingClass;s[29]=o.enclosingStyle;s[30]=o.error;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=(o.hzScroll?1:0);s[37]=o.inputtype;s[38]=(o.invalid?1:0);s[39]=o.invalidMessage;s[40]=(o.isDropdownVisible?1:0);s[41]=o.label;s[42]=o.labelClass;s[43]=o.labelDisabledClass;s[44]=o.labelStyle;s[45]=o.maxlength;s[46]=o.onafterdrag;s[47]=o.onbeforedrag;s[48]=o.onblur;s[49]=o.onchange;s[50]=o.onclick;s[51]=o.ondblclick;s[52]=o.ondrag;s[53]=o.ondrop;s[54]=o.onfocus;s[55]=o.onhide;s[56]=o.onkeydown;s[57]=o.onkeypress;s[58]=o.onkeyup;s[59]=o.onmousedown;s[60]=o.onmouseout;s[61]=o.onmouseover;s[62]=o.onmouseup;s[63]=o.onrefresh;s[64]=o.onshow;s[65]=o.onsubmit;s[66]=o.ontouchend;s[67]=o.ontouchmove;s[68]=o.ontouchstart;s[69]=o.onupdate;s[70]=o.onvalidate;s[71]=set.serializeList(o,o.options,true,'options');s[72]=o.originalValue;s[73]=o.overlayMode;s[74]=o.placeholder;s[75]=(o.readOnly?1:0);s[76]=o.renderFlag;s[77]=(o.required?1:0);s[78]=o.requiredMessage;s[79]=(o.scrollIntoView?1:0);s[80]=o.selectedIndex;s[81]=(o.showLabel?1:0);s[82]=o.size;s[83]=o.slice;s[84]=(o.spellcheck?1:0);s[85]=o.tabIndex;s[86]=o.text;s[87]=o.title;s[88]=o.tuple;s[89]=(o.unrestricted?1:0);s[90]=o.valign;s[91]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[92]=o.valueList;s[93]=(o.visible?1:0);s[94]=o.width;
}
function s00_componente_interface_scsComboBox_getSettings(s)
{
	s['name'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsComboBox_appendOption = function(value,text,style) {
var option = zenPage.createComponent('option');
if (value != null) option.value = value;
option.text = (text != null) ? text : option.value;
if (style != null) option.style = style;
this.options[this.options.length] = option;
}

self.s00_componente_interface_scsComboBox_getOption = function(idx) {
return ('' == this.valueList) ? this.options[idx] : null;
}

self.s00_componente_interface_scsComboBox_getOptionCount = function() {
return ('' == this.valueList) ? this.options.length : this.valueList.split(';').length;
}

self.s00_componente_interface_scsComboBox_getOptionText = function(idx) {
var text;
if ('' != this.valueList) {
if ('' != this.displayList) {
text = this.displayList.split(';')[idx];
}
else {
text = this.valueList.split(';')[idx];
}
}
else {
text = this.options[idx].text;
}
return (null == text) ? '' : text;
}

self.s00_componente_interface_scsComboBox_getOptionValue = function(idx) {
var value;
if ('' != this.valueList) {
value = this.valueList.split(';')[idx];
}
else {
value = this.options[idx].value;
}
return (null == value) ? '' : value;
}

self.s00_componente_interface_scsComboBox_removeOption = function(index) {
this.options.splice(index,1);
}

self.s00_componente_interface_scsComboBox_renderDropdown = function() {
var div = this.getDropDownDiv();
zenASSERT(div,'Unable to find DropDown element',arguments);
var html = new Array();
html[html.length] = '<table class="comboboxTable" width="100%" border="0" cellpadding="0" cellspacing="0">';
if ('' != this.valueList) {
var values = this.valueList.split(';');
var texts = (''==this.displayList) ? values : this.displayList.split(';');
for (var n = 0; n < values.length; n++) {
var val = values[n];
var text = texts[n];
text = (''==text) ? '&#160;' : text;
html[html.length] = '<tr id="item_'+n+'_'+this.index+'" class="comboboxItem" onmousedown="zenPage.getComponent('+this.index+').itemMouseDown(event,'+n+');" onmouseup="zenPage.getComponent('+this.index+').itemMouseUp(event,'+n+');"><td width="100%"><a href="#">'+text+'<\/a><\/td><\/tr>';
}
}
else {
for (var n = 0; n < this.options.length; n++) {
var option = this.options[n];
var val = option.value;
var text = option.text.toString();
text = ('' == text) ? '&#160;' : text;
html[html.length] = '<tr id="item_'+n+'_'+this.index+'" class="comboboxItem" onmousedown="zenPage.getComponent('+this.index+').itemMouseDown(event,'+n+');" onmouseup="zenPage.getComponent('+this.index+').itemMouseUp(event,'+n+');"><td style="'+option.style+'" width="100%"><a href="#">'+text+'<\/a><\/td><\/tr>';
}
}
html[html.length] = '<\/table>';
div.innerHTML = html.join("");
zenPage.lastModalIndex = this.index;
var input = this.findElement('input');
zenASSERT(input,'Unable to find input element',arguments);
input.focus();
this.isDropdownVisible = true;
this.findSelectedItem();
}

self.s00_componente_interface_scsComboBox_resetOptions = function() {
this.valueList = '';
this.displayList = '';
this.options.length = 0;
this.selectedIndex = -1;
this.text = '';
this.setValue('');
}

self.s00_componente_interface_scsComboBox_setOption = function(index,value,text,style) {
var option = this.options[index];
if (null != option) {
if (value != null) option.value = value;
option.text = (text != null) ? text : option.value;
if (style != null) option.style = style;
}
}

self.s00_componente_interface_scsComboBox_setProperty = function(property,value,value2) {
switch(property) {
case 'valueList':
if (this.valueList != value) {
this.valueList = value;
this.setValue(this.getValue());
}
break;
case 'displayList':
if (this.displayList != value) {
this.displayList = value;
this.setValue(this.getValue());
}
break;
default:
return this.invokeSuper('setProperty',arguments);
}
return true;
}

self.s00_componente_interface_scsComboBox_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsComboBox__Loader = function() {
	zenLoadClass('_ZEN_Component_combobox');
	s00_componente_interface_scsComboBox.prototype = zenCreate('_ZEN_Component_combobox',-1);
	var p = s00_componente_interface_scsComboBox.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsComboBox;
	p.superClass = ('undefined' == typeof _ZEN_Component_combobox) ? zenMaster._ZEN_Component_combobox.prototype:_ZEN_Component_combobox.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsComboBox';
	p._type = 'scsComboBox';
	p.serialize = s00_componente_interface_scsComboBox_serialize;
	p.getSettings = s00_componente_interface_scsComboBox_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsComboBox_ReallyRefreshContents;
	p.appendOption = s00_componente_interface_scsComboBox_appendOption;
	p.getOption = s00_componente_interface_scsComboBox_getOption;
	p.getOptionCount = s00_componente_interface_scsComboBox_getOptionCount;
	p.getOptionText = s00_componente_interface_scsComboBox_getOptionText;
	p.getOptionValue = s00_componente_interface_scsComboBox_getOptionValue;
	p.removeOption = s00_componente_interface_scsComboBox_removeOption;
	p.renderDropdown = s00_componente_interface_scsComboBox_renderDropdown;
	p.resetOptions = s00_componente_interface_scsComboBox_resetOptions;
	p.setOption = s00_componente_interface_scsComboBox_setOption;
	p.setProperty = s00_componente_interface_scsComboBox_setProperty;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeContato'] = 's00_componente_interface_scsCompositeContato';
self.s00_componente_interface_scsCompositeContato = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeContato__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeContato__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.Atualizar = false;
	o.CamposTraducao = new Object();
	o.MensagensErro = new Object();
	o.PosicaoAtual = '0';
	o.TipoComponente = '';
	o.TotalPosicao = '0';
	o.delimitadorMV = '@VM';
	o.scsApresentaLabel = true;
	o.scsDddObrigatorio = false;
	o.scsDdiObrigatorio = false;
	o.scsDepartamentoObrigatorio = false;
	o.scsEmailObrigatorio = false;
	o.scsNomeObrigatorio = false;
	o.scsObsObrigatorio = false;
	o.scsRamalObrigatorio = false;
	o.scsTodosSomenteLeitura = false;
	o.strDdd = '';
	o.strDdi = '';
	o.strDepartamento = '';
	o.strEmail = '';
	o.strNome = '';
	o.strNumero = '';
	o.strObs = '';
	o.strRamal = '';
	o.strTipo = '';
}
function s00_componente_interface_scsCompositeContato_serialize(set,s)
{
	var o = this;s[0]='3698044372';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=(o.Atualizar?1:0);s[7]=set.serializeArray(o,o.CamposTraducao,false,'CamposTraducao');s[8]=set.serializeArray(o,o.MensagensErro,false,'MensagensErro');s[9]=o.PosicaoAtual;s[10]=o.TipoComponente;s[11]=o.TotalPosicao;s[12]=o.align;s[13]=o.aux;s[14]=o.cellAlign;s[15]=o.cellSize;s[16]=o.cellStyle;s[17]=o.cellVAlign;s[18]=set.serializeList(o,o.children,true,'children');s[19]=(o.childrenCreated?1:0);s[20]=o.containerStyle;s[21]=o.delimitadorMV;s[22]=(o.disabled?1:0);s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.groupClass;s[30]=o.groupStyle;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=o.label;s[37]=o.labelClass;s[38]=o.labelDisabledClass;s[39]=o.labelPosition;s[40]=o.labelStyle;s[41]=o.layout;s[42]=o.onafterdrag;s[43]=o.onbeforedrag;s[44]=o.onclick;s[45]=o.ondrag;s[46]=o.ondrop;s[47]=o.onhide;s[48]=o.onrefresh;s[49]=o.onshow;s[50]=o.onupdate;s[51]=o.overlayMode;s[52]=o.renderFlag;s[53]=(o.scsApresentaLabel?1:0);s[54]=(o.scsDddObrigatorio?1:0);s[55]=(o.scsDdiObrigatorio?1:0);s[56]=(o.scsDepartamentoObrigatorio?1:0);s[57]=(o.scsEmailObrigatorio?1:0);s[58]=(o.scsNomeObrigatorio?1:0);s[59]=(o.scsObsObrigatorio?1:0);s[60]=(o.scsRamalObrigatorio?1:0);s[61]=(o.scsTodosSomenteLeitura?1:0);s[62]=(o.showLabel?1:0);s[63]=o.slice;s[64]=o.strDdd;s[65]=o.strDdi;s[66]=o.strDepartamento;s[67]=o.strEmail;s[68]=o.strNome;s[69]=o.strNumero;s[70]=o.strObs;s[71]=o.strRamal;s[72]=o.strTipo;s[73]=o.title;s[74]=o.tuple;s[75]=o.valign;s[76]=(o.visible?1:0);s[77]=o.width;
}
function s00_componente_interface_scsCompositeContato_getSettings(s)
{
	s['name'] = 'string';
	s['Atualizar'] = 'string';
	s['CamposTraducao'] = 'string';
	s['MensagensErro'] = 'string';
	s['PosicaoAtual'] = 'string';
	s['TipoComponente'] = 'string';
	s['TotalPosicao'] = 'string';
	s['delimitadorMV'] = 'string';
	s['scsApresentaLabel'] = 'boolean';
	s['scsDddObrigatorio'] = 'boolean';
	s['scsDdiObrigatorio'] = 'boolean';
	s['scsDepartamentoObrigatorio'] = 'boolean';
	s['scsEmailObrigatorio'] = 'boolean';
	s['scsNomeObrigatorio'] = 'boolean';
	s['scsObsObrigatorio'] = 'boolean';
	s['scsRamalObrigatorio'] = 'boolean';
	s['scsTodosSomenteLeitura'] = 'boolean';
	s['strDdd'] = 'string';
	s['strDdi'] = 'string';
	s['strDepartamento'] = 'string';
	s['strEmail'] = 'string';
	s['strNome'] = 'string';
	s['strNumero'] = 'string';
	s['strObs'] = 'string';
	s['strRamal'] = 'string';
	s['strTipo'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeContato_RecuperarContato = function() {
var componente = zenPage.getComponent(this.index)
zenPage.getComponentById("formularioCadastro.ContatoTipo").setValue(componente.strTipo)
zenPage.getComponentById("formularioCadastro.ContatoTipo").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDdi").setValue(componente.strDdi)
zenPage.getComponentById("formularioCadastro.ContatoDdi").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDdd").setValue(componente.strDdd)
zenPage.getComponentById("formularioCadastro.ContatoDdd").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoNome").setValue(componente.strNome)
zenPage.getComponentById("formularioCadastro.ContatoNome").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoNumero").setValue(componente.strNumero)
zenPage.getComponentById("formularioCadastro.ContatoNumero").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoRamal").setValue(componente.strRamal)
zenPage.getComponentById("formularioCadastro.ContatoRamal").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDepartamento").setValue(componente.strDepartamento)
zenPage.getComponentById("formularioCadastro.ContatoDepartamento").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoEmail").setValue(componente.strEmail)
zenPage.getComponentById("formularioCadastro.ContatoEmail").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoObservacao").setValue(componente.strObs)
zenPage.getComponentById("formularioCadastro.ContatoObservacao").onchangeHandler()
}

self.s00_componente_interface_scsCompositeContato_adicionaContatoCliente = function() {
var tipo = this.getChildById("contatoTipo").getProperty("value");
var ddi = this.getChildById("contatoDdi").getProperty("value");
var ddd = this.getChildById("contatoDdd").getProperty("value");
var nome = this.getChildById("contatoNome").getProperty("value");
var numero = this.getChildById("contatoNumero").getProperty("value");
var ramal = this.getChildById("contatoRamal").getProperty("value");
var departamento = this.getChildById("contatoDepartamento").getProperty("value");
var email = this.getChildById("contatoEmail").getProperty("value");
var obs = this.getChildById("contatoObs").getProperty("value");
var erro = "";
if (this.removerEspacos(tipo) == ""){
erro += "- "+this.CamposTraducao["tipo"]+" \n";
}
if ((this.removerEspacos(ddi) == "") && (this.scsDdiObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ddi"]+" \n";
}
if ((this.removerEspacos(ddd) == "") && (this.scsDddObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ddd"]+" \n";
}
if ((this.removerEspacos(nome) == "") && (this.scsNomeObrigatorio) == 1){
erro += "- "+this.CamposTraducao["nome"]+" \n";
}
if (this.removerEspacos(numero) == ""){
erro += "- "+this.CamposTraducao["numero"]+" \n";
}
if ((this.removerEspacos(ramal) == "") && (this.scsRamalObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ramal"]+" \n";
}
if ((this.removerEspacos(departamento) == "") && (this.scsDepartamentoObrigatorio) == 1){
erro += "- "+this.CamposTraducao["departamento"]+" \n";
}
if ((this.removerEspacos(email) == "") && (this.scsEmailObrigatorio) == 1){
erro += "- "+this.CamposTraducao["email"]+" \n";
}
if ((this.removerEspacos(obs) == "") && (this.scsObsObrigatorio) == 1){
erro += "- "+this.CamposTraducao["observacoes"]+" \n";
}
if (erro != ""){
zenPage.alertaShift(this.MensagensErro["camposObrigatorios"]+"\n"+erro);
return 1;
}
if (this.Atualizar){
this.atualizaContatoCliente();
return 1;
}
if (this.strNumero == ""){
this.strTipo = tipo;
this.strDdd = ddd;
this.strDdi = ddi;
this.strNome = nome;
this.strNumero = numero;
this.strRamal = ramal;
this.strDepartamento = departamento;
this.strEmail = email;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strNome = this.strNome + this.delimitadorMV + nome;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strRamal = this.strRamal + this.delimitadorMV + ramal;
this.strDepartamento = this.strDepartamento + this.delimitadorMV + departamento;
this.strEmail = this.strEmail + this.delimitadorMV + email;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
this.TotalPosicao = this.strNumero.split(this.delimitadorMV).length;
this.limpaCamposCliente();
return 1;
}

self.s00_componente_interface_scsCompositeContato_alterarCorLinha = function(posLinha) {
var componente = zenPage.getComponent(this.index)
var qtdLinha = componente.TotalPosicao
var linha = 1
while(linha<=qtdLinha){
var aux = "linhaContato"+linha
var obj = document.getElementById(aux)
if ((linha%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (linha == posLinha){
obj.style.background = "#fbe091";
}else{
obj.style.background = zebra;
}
linha = linha + 1
}
}

self.s00_componente_interface_scsCompositeContato_atualizaBotoesPadraoCliente = function(pAcao) {
if (pAcao==1){
this.getChildById("btNovo").setHidden(true);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Adicionar contato");
this.Atualizar = 0;
btAcao.setProperty("onclick","zenThis.composite.adicionaContatoCliente(); zenThis.composite.atualizaGridHtmlCliente()");
btAcao.setProperty("enclosingClass","botao_i_add");
}else if (pAcao==2){
this.getChildById("btNovo").setHidden(false);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Atualizar contato");
this.Atualizar = 1;
btAcao.setProperty("onclick","zenThis.composite.adicionaContatoCliente(); zenThis.composite.atualizaGridHtmlCliente()");
btAcao.setProperty("enclosingClass","botao_i_refresh_red");
}
if (this.scsTodosSomenteLeitura){
this.getChildById("btNovo").setHidden(true);
this.getChildById("btAcao").setHidden(true);
}
return 1;
}

self.s00_componente_interface_scsCompositeContato_atualizaContatoCliente = function() {
var tipo = this.getChildById("contatoTipo").getProperty("value");
var ddi = this.getChildById("contatoDdi").getProperty("value");
var ddd = this.getChildById("contatoDdd").getProperty("value");
var nome = this.getChildById("contatoNome").getProperty("value");
var numero = this.getChildById("contatoNumero").getProperty("value");
var ramal = this.getChildById("contatoRamal").getProperty("value");
var departamento = this.getChildById("contatoDepartamento").getProperty("value");
var email = this.getChildById("contatoEmail").getProperty("value");
var obs = this.getChildById("contatoObs").getProperty("value");
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
var posicao = this.PosicaoAtual - 1;
tipoList.splice(posicao,1,tipo);
ddiList.splice(posicao,1,ddi);
dddList.splice(posicao,1,ddd);
nomeList.splice(posicao,1,nome);
numeroList.splice(posicao,1,numero);
ramalList.splice(posicao,1,ramal);
departamentoList.splice(posicao,1,departamento);
emailList.splice(posicao,1,email);
obsList.splice(posicao,1,obs);
this.strTipo = tipoList.join(this.delimitadorMV);
this.strDdi = ddiList.join(this.delimitadorMV);
this.strDdd = dddList.join(this.delimitadorMV);
this.strNome = nomeList.join(this.delimitadorMV);
this.strNumero = numeroList.join(this.delimitadorMV);
this.strRamal = ramalList.join(this.delimitadorMV);
this.strDepartamento = departamentoList.join(this.delimitadorMV);
this.strEmail = emailList.join(this.delimitadorMV);
this.strObs = obsList.join(this.delimitadorMV);
this.atualizaBotoesPadraoCliente(1);
this.limpaCamposCliente();
return 1;
}

self.s00_componente_interface_scsCompositeContato_atualizaGridHtmlCliente = function() {
var objGrid = this.getChildById("contatoGrid");
objGrid.setProperty("content",this.desenhaGridHtmlCliente());
return 1;
}

self.s00_componente_interface_scsCompositeContato_consultaContatoCliente = function(pPosicao) {
this.PosicaoAtual = pPosicao;
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
this.getChildById("contatoTipo").setProperty("value",tipoList[(pPosicao-1)]);
this.getChildById("contatoDdi").setProperty("value",ddiList[(pPosicao-1)]);
this.getChildById("contatoDdd").setProperty("value",dddList[(pPosicao-1)]);
this.getChildById("contatoNome").setProperty("value",nomeList[(pPosicao-1)]);
this.getChildById("contatoNumero").setProperty("value",numeroList[(pPosicao-1)]);
this.getChildById("contatoRamal").setProperty("value",ramalList[(pPosicao-1)]);
this.getChildById("contatoDepartamento").setProperty("value",departamentoList[(pPosicao-1)]);
this.getChildById("contatoEmail").setProperty("value",emailList[(pPosicao-1)]);
this.getChildById("contatoObs").setProperty("value",obsList[(pPosicao-1)]);
var retorno = this.atualizaBotoesPadraoCliente(2);
return 1;
}

self.s00_componente_interface_scsCompositeContato_consultarContato = function() {
var tipo = zenPage.getComponentById("formularioCadastro.ContatoTipo").getValue();
var ddi = zenPage.getComponentById("formularioCadastro.ContatoDdi").getValue();
var ddd = zenPage.getComponentById("formularioCadastro.ContatoDdd").getValue();
var nome = zenPage.getComponentById("formularioCadastro.ContatoNome").getValue();
var numero = zenPage.getComponentById("formularioCadastro.ContatoNumero").getValue();
var ramal = zenPage.getComponentById("formularioCadastro.ContatoRamal").getValue();
var departamento = zenPage.getComponentById("formularioCadastro.ContatoDepartamento").getValue();
var email = zenPage.getComponentById("formularioCadastro.ContatoEmail").getValue();
var obs = zenPage.getComponentById("formularioCadastro.ContatoObservacao").getValue();
var componente = zenPage.getComponent(this.index);
componente.strTipo = tipo;
componente.strDdi = ddd;
componente.strDdd = ddd;
componente.strNome = nome;
componente.strNumero = numero;
componente.strRamal = ramal;
componente.strDepartamento = departamento;
componente.strEmail = email;
componente.strObs = obs;
componente.atualizaGridHtmlCliente();
}

self.s00_componente_interface_scsCompositeContato_desenhaGridHtmlCliente = function() {
var strGridHtml = "";
var numeroList = this.strNumero.split(this.delimitadorMV);
this.TotalPosicao = numeroList.length;
if (this.TipoComponente == "scsCompositeContato2"){
strGridHtml += "<table cellpadding='0' class='scsCompositeContato2' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}else if (this.TipoComponente == "scsCompositeContato3"){
strGridHtml += "<table cellpadding='0' class='scsCompositeContato3' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}else if (this.TipoComponente == "scsCompositeContato4"){
strGridHtml += "<table cellpadding='0' style='width:100%;' class='scsCompositeContato4' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}
if (this.strNumero != ""){
var tipoList = this.strTipo.split("@VM");
var dddList = this.strDdd.split("@VM");
var nomeList = this.strNome.split("@VM");
var ramalList = this.strRamal.split("@VM");
var departamentoList = this.strDepartamento.split("@VM");
var emailList = this.strEmail.split("@VM");
var qtdMV = this.TotalPosicao;
for (i=0;i<qtdMV;i++){
var tipoContato = parseInt(tipoList[i]);
switch (tipoContato){
case 1:
tipoContato = "Residencial";
break;
case 2:
tipoContato = "Comercial";
break;
case 3:
tipoContato = "Celular";
break;
case 4:
tipoContato = "Fax";
break;
case 5:
tipoContato = "Outros";
break;
}
var ddd = dddList[i];
var nome = nomeList[i];
var numero = numeroList[i];
var ramal = ramalList[i];
var departamento = departamentoList[i];
var email = emailList[i];
var telefone = "("+ddd+") "+numero;
if (nome == "") nome = "&#160;";
if (ramal == "") ramal = "&#160;";
if (departamento == "") departamento = "&#160;";
if (email == "") email = "&#160;";
if (((i+1)%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (this.TipoComponente == "scsCompositeContato2"){
strGridHtml +=
"<tr style='cursor:pointer;' id='linhaContato"+(i+1)+"' bgcolor='"+zebra+"'>"+
"<td width='83px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoContato+"</td>"+
"<td width='212px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='111px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>"+
"<td width='73px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+ramal+"</td>"+
"<td width='88px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+departamento+"</td>"+
"<td width='188px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+email+"</td>"
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='30' align='rigth' style='border-right:0;vertical-align: middle;' noWrap='nowrap'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='30' align='center' style='border-right:0;vertical-align: middle;' noWrap='nowrap'><img alt='Excluir' style='cursor:pointer;' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}else if (this.TipoComponente == "scsCompositeContato3"){
strGridHtml +=
"<tr id='linhaContato"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='179' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='121' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='26' align='rigth' style='vertical-align: middle;border-right:0;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='26' align='center' style='vertical-align: middle;border-right:0;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}else if (this.TipoComponente == "scsCompositeContato4"){
strGridHtml +=
"<tr id='linhaContato"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='179' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='121' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='26' align='rigth' style='vertical-align: middle;border-right:0;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='26' align='center' style='vertical-align: middle;border-right:0;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}
}
}
strGridHtml += "</table>";
return strGridHtml;
}

self.s00_componente_interface_scsCompositeContato_excluirContatoCliente = function(pPosicao) {
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
tipoList.splice((pPosicao-1),1);
ddiList.splice((pPosicao-1),1);
dddList.splice((pPosicao-1),1);
nomeList.splice((pPosicao-1),1);
numeroList.splice((pPosicao-1),1);
ramalList.splice((pPosicao-1),1);
departamentoList.splice((pPosicao-1),1);
emailList.splice((pPosicao-1),1);
obsList.splice((pPosicao-1),1);
this.strTipo = tipoList.join(this.delimitadorMV);
this.strDdi = ddiList.join(this.delimitadorMV);
this.strDdd = dddList.join(this.delimitadorMV);
this.strNome = nomeList.join(this.delimitadorMV);
this.strNumero = numeroList.join(this.delimitadorMV);
this.strRamal = ramalList.join(this.delimitadorMV);
this.strDepartamento = departamentoList.join(this.delimitadorMV);
this.strEmail = emailList.join(this.delimitadorMV);
this.strObs = obsList.join(this.delimitadorMV);
this.TotalPosicao = this.TotalPosicao - 1;
this.PosicaoAtual = 0;
var retorno = this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1)
return 1;
}

self.s00_componente_interface_scsCompositeContato_limpaCamposCliente = function() {
this.getChildById("contatoTipo").setProperty("value","");
this.getChildById("contatoDdi").setProperty("value","");
this.getChildById("contatoDdd").setProperty("value","");
this.getChildById("contatoNome").setProperty("value","");
this.getChildById("contatoNumero").setProperty("value","");
this.getChildById("contatoRamal").setProperty("value","");
this.getChildById("contatoDepartamento").setProperty("value","");
this.getChildById("contatoEmail").setProperty("value","");
this.getChildById("contatoObs").setProperty("value","");
return 1;
}

self.s00_componente_interface_scsCompositeContato_limpaComponenteCliente = function() {
this.limpaCamposCliente();
if (this.strNumero == "")
return 1
this.strTipo = "";
this.strDdd = "";
this.strDdi = "";
this.strNome = "";
this.strNumero = "";
this.strRamal = "";
this.strDepartamento = "";
this.strEmail = "";
this.strObs = "";
var retorno = this.atualizaBotoesPadraoCliente(1);
var retorno = this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente_interface_scsCompositeContato_novo = function() {
this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1);
this.alterarCorLinha(0);
return 1;
}

self.s00_componente_interface_scsCompositeContato_refreshHTML = function() {
var retorno = zenPage.atualizaGridHtmlCliente();
}

self.s00_componente_interface_scsCompositeContato_removerEspacos = function(pString) {
return pString.replace(/\s/g,"");
}

self.s00_componente_interface_scsCompositeContato_AdicionaContato = function(atualiza) {
	return zenInstanceMethod(this,'AdicionaContato','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato_AtualizaContato = function() {
	return zenInstanceMethod(this,'AtualizaContato','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato_ConsultaContato = function(posicao) {
	return zenInstanceMethod(this,'ConsultaContato','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato_DesenhaGridHtml = function() {
	return zenInstanceMethod(this,'DesenhaGridHtml','','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato_ExcluirContato = function(posicao) {
	return zenInstanceMethod(this,'ExcluirContato','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato_LimpaCampos = function() {
	return zenInstanceMethod(this,'LimpaCampos','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeContato_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato_TodosSomenteLeitura = function(acao) {
	return zenInstanceMethod(this,'TodosSomenteLeitura','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeContato__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeContato.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeContato.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeContato;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeContato';
	p._type = 'scsCompositeContato';
	p.serialize = s00_componente_interface_scsCompositeContato_serialize;
	p.getSettings = s00_componente_interface_scsCompositeContato_getSettings;
	p.AdicionaContato = s00_componente_interface_scsCompositeContato_AdicionaContato;
	p.AjustaTamanhoValor = s00_componente_interface_scsCompositeContato_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente_interface_scsCompositeContato_ApresentaExcecao;
	p.AtualizaBotoesPadrao = s00_componente_interface_scsCompositeContato_AtualizaBotoesPadrao;
	p.AtualizaContato = s00_componente_interface_scsCompositeContato_AtualizaContato;
	p.AtualizaGridHtml = s00_componente_interface_scsCompositeContato_AtualizaGridHtml;
	p.ConsultaContato = s00_componente_interface_scsCompositeContato_ConsultaContato;
	p.DesenhaGridHtml = s00_componente_interface_scsCompositeContato_DesenhaGridHtml;
	p.ExcluirContato = s00_componente_interface_scsCompositeContato_ExcluirContato;
	p.GeraCheckBoxHtml = s00_componente_interface_scsCompositeContato_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente_interface_scsCompositeContato_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente_interface_scsCompositeContato_GeraRadioHtml;
	p.GeraSV1Label = s00_componente_interface_scsCompositeContato_GeraSV1Label;
	p.GeraSV1Text = s00_componente_interface_scsCompositeContato_GeraSV1Text;
	p.GeraSelectHtml = s00_componente_interface_scsCompositeContato_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente_interface_scsCompositeContato_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente_interface_scsCompositeContato_GeraTextHtml;
	p.GetValorPropriedade = s00_componente_interface_scsCompositeContato_GetValorPropriedade;
	p.LimpaCampos = s00_componente_interface_scsCompositeContato_LimpaCampos;
	p.LimpaComponente = s00_componente_interface_scsCompositeContato_LimpaComponente;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeContato_ReallyRefreshContents;
	p.RecuperarContato = s00_componente_interface_scsCompositeContato_RecuperarContato;
	p.RetornaValorCampo = s00_componente_interface_scsCompositeContato_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente_interface_scsCompositeContato_SetValorPropriedade;
	p.TodosSomenteLeitura = s00_componente_interface_scsCompositeContato_TodosSomenteLeitura;
	p.VerificaErro = s00_componente_interface_scsCompositeContato_VerificaErro;
	p.adicionaContatoCliente = s00_componente_interface_scsCompositeContato_adicionaContatoCliente;
	p.alterarCorLinha = s00_componente_interface_scsCompositeContato_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente_interface_scsCompositeContato_atualizaBotoesPadraoCliente;
	p.atualizaContatoCliente = s00_componente_interface_scsCompositeContato_atualizaContatoCliente;
	p.atualizaGridHtmlCliente = s00_componente_interface_scsCompositeContato_atualizaGridHtmlCliente;
	p.consultaContatoCliente = s00_componente_interface_scsCompositeContato_consultaContatoCliente;
	p.consultarContato = s00_componente_interface_scsCompositeContato_consultarContato;
	p.desenhaGridHtmlCliente = s00_componente_interface_scsCompositeContato_desenhaGridHtmlCliente;
	p.excluirContatoCliente = s00_componente_interface_scsCompositeContato_excluirContatoCliente;
	p.limpaCamposCliente = s00_componente_interface_scsCompositeContato_limpaCamposCliente;
	p.limpaComponenteCliente = s00_componente_interface_scsCompositeContato_limpaComponenteCliente;
	p.novo = s00_componente_interface_scsCompositeContato_novo;
	p.refreshHTML = s00_componente_interface_scsCompositeContato_refreshHTML;
	p.removerEspacos = s00_componente_interface_scsCompositeContato_removerEspacos;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeContato2'] = 's00_componente_interface_scsCompositeContato2';
self.s00_componente_interface_scsCompositeContato2 = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeContato2__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeContato2__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.Atualizar = false;
	o.CamposTraducao = new Object();
	o.MensagensErro = new Object();
	o.PosicaoAtual = '0';
	o.TipoComponente = '';
	o.TotalPosicao = '0';
	o.delimitadorMV = '@VM';
	o.scsApresentaLabel = true;
	o.scsDddObrigatorio = false;
	o.scsDdiObrigatorio = false;
	o.scsDepartamentoObrigatorio = false;
	o.scsEmailObrigatorio = false;
	o.scsNomeObrigatorio = false;
	o.scsObsObrigatorio = false;
	o.scsRamalObrigatorio = false;
	o.scsTodosSomenteLeitura = false;
	o.strDdd = '';
	o.strDdi = '';
	o.strDepartamento = '';
	o.strEmail = '';
	o.strNome = '';
	o.strNumero = '';
	o.strObs = '';
	o.strRamal = '';
	o.strTipo = '';
}
function s00_componente_interface_scsCompositeContato2_serialize(set,s)
{
	var o = this;s[0]='3698044372';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=(o.Atualizar?1:0);s[7]=set.serializeArray(o,o.CamposTraducao,false,'CamposTraducao');s[8]=set.serializeArray(o,o.MensagensErro,false,'MensagensErro');s[9]=o.PosicaoAtual;s[10]=o.TipoComponente;s[11]=o.TotalPosicao;s[12]=o.align;s[13]=o.aux;s[14]=o.cellAlign;s[15]=o.cellSize;s[16]=o.cellStyle;s[17]=o.cellVAlign;s[18]=set.serializeList(o,o.children,true,'children');s[19]=(o.childrenCreated?1:0);s[20]=o.containerStyle;s[21]=o.delimitadorMV;s[22]=(o.disabled?1:0);s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.groupClass;s[30]=o.groupStyle;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=o.label;s[37]=o.labelClass;s[38]=o.labelDisabledClass;s[39]=o.labelPosition;s[40]=o.labelStyle;s[41]=o.layout;s[42]=o.onafterdrag;s[43]=o.onbeforedrag;s[44]=o.onclick;s[45]=o.ondrag;s[46]=o.ondrop;s[47]=o.onhide;s[48]=o.onrefresh;s[49]=o.onshow;s[50]=o.onupdate;s[51]=o.overlayMode;s[52]=o.renderFlag;s[53]=(o.scsApresentaLabel?1:0);s[54]=(o.scsDddObrigatorio?1:0);s[55]=(o.scsDdiObrigatorio?1:0);s[56]=(o.scsDepartamentoObrigatorio?1:0);s[57]=(o.scsEmailObrigatorio?1:0);s[58]=(o.scsNomeObrigatorio?1:0);s[59]=(o.scsObsObrigatorio?1:0);s[60]=(o.scsRamalObrigatorio?1:0);s[61]=(o.scsTodosSomenteLeitura?1:0);s[62]=(o.showLabel?1:0);s[63]=o.slice;s[64]=o.strDdd;s[65]=o.strDdi;s[66]=o.strDepartamento;s[67]=o.strEmail;s[68]=o.strNome;s[69]=o.strNumero;s[70]=o.strObs;s[71]=o.strRamal;s[72]=o.strTipo;s[73]=o.title;s[74]=o.tuple;s[75]=o.valign;s[76]=(o.visible?1:0);s[77]=o.width;
}
function s00_componente_interface_scsCompositeContato2_getSettings(s)
{
	s['name'] = 'string';
	s['Atualizar'] = 'string';
	s['CamposTraducao'] = 'string';
	s['MensagensErro'] = 'string';
	s['PosicaoAtual'] = 'string';
	s['TipoComponente'] = 'string';
	s['TotalPosicao'] = 'string';
	s['delimitadorMV'] = 'string';
	s['scsApresentaLabel'] = 'boolean';
	s['scsDddObrigatorio'] = 'boolean';
	s['scsDdiObrigatorio'] = 'boolean';
	s['scsDepartamentoObrigatorio'] = 'boolean';
	s['scsEmailObrigatorio'] = 'boolean';
	s['scsNomeObrigatorio'] = 'boolean';
	s['scsObsObrigatorio'] = 'boolean';
	s['scsRamalObrigatorio'] = 'boolean';
	s['scsTodosSomenteLeitura'] = 'boolean';
	s['strDdd'] = 'string';
	s['strDdi'] = 'string';
	s['strDepartamento'] = 'string';
	s['strEmail'] = 'string';
	s['strNome'] = 'string';
	s['strNumero'] = 'string';
	s['strObs'] = 'string';
	s['strRamal'] = 'string';
	s['strTipo'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeContato2_RecuperarContato = function() {
var componente = zenPage.getComponent(this.index)
zenPage.getComponentById("formularioCadastro.ContatoTipo").setValue(componente.strTipo)
zenPage.getComponentById("formularioCadastro.ContatoTipo").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDdi").setValue(componente.strDdi)
zenPage.getComponentById("formularioCadastro.ContatoDdi").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDdd").setValue(componente.strDdd)
zenPage.getComponentById("formularioCadastro.ContatoDdd").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoNome").setValue(componente.strNome)
zenPage.getComponentById("formularioCadastro.ContatoNome").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoNumero").setValue(componente.strNumero)
zenPage.getComponentById("formularioCadastro.ContatoNumero").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoRamal").setValue(componente.strRamal)
zenPage.getComponentById("formularioCadastro.ContatoRamal").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDepartamento").setValue(componente.strDepartamento)
zenPage.getComponentById("formularioCadastro.ContatoDepartamento").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoEmail").setValue(componente.strEmail)
zenPage.getComponentById("formularioCadastro.ContatoEmail").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoObservacao").setValue(componente.strObs)
zenPage.getComponentById("formularioCadastro.ContatoObservacao").onchangeHandler()
}

self.s00_componente_interface_scsCompositeContato2_adicionaContatoCliente = function() {
var tipo = this.getChildById("contatoTipo").getProperty("value");
var ddi = this.getChildById("contatoDdi").getProperty("value");
var ddd = this.getChildById("contatoDdd").getProperty("value");
var nome = this.getChildById("contatoNome").getProperty("value");
var numero = this.getChildById("contatoNumero").getProperty("value");
var ramal = this.getChildById("contatoRamal").getProperty("value");
var departamento = this.getChildById("contatoDepartamento").getProperty("value");
var email = this.getChildById("contatoEmail").getProperty("value");
var obs = this.getChildById("contatoObs").getProperty("value");
var erro = "";
if (this.removerEspacos(tipo) == ""){
erro += "- "+this.CamposTraducao["tipo"]+" \n";
}
if ((this.removerEspacos(ddi) == "") && (this.scsDdiObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ddi"]+" \n";
}
if ((this.removerEspacos(ddd) == "") && (this.scsDddObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ddd"]+" \n";
}
if ((this.removerEspacos(nome) == "") && (this.scsNomeObrigatorio) == 1){
erro += "- "+this.CamposTraducao["nome"]+" \n";
}
if (this.removerEspacos(numero) == ""){
erro += "- "+this.CamposTraducao["numero"]+" \n";
}
if ((this.removerEspacos(ramal) == "") && (this.scsRamalObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ramal"]+" \n";
}
if ((this.removerEspacos(departamento) == "") && (this.scsDepartamentoObrigatorio) == 1){
erro += "- "+this.CamposTraducao["departamento"]+" \n";
}
if ((this.removerEspacos(email) == "") && (this.scsEmailObrigatorio) == 1){
erro += "- "+this.CamposTraducao["email"]+" \n";
}
if ((this.removerEspacos(obs) == "") && (this.scsObsObrigatorio) == 1){
erro += "- "+this.CamposTraducao["observacoes"]+" \n";
}
if (erro != ""){
zenPage.alertaShift(this.MensagensErro["camposObrigatorios"]+"\n"+erro);
return 1;
}
if (this.Atualizar){
this.atualizaContatoCliente();
return 1;
}
if (this.strNumero == ""){
this.strTipo = tipo;
this.strDdd = ddd;
this.strDdi = ddi;
this.strNome = nome;
this.strNumero = numero;
this.strRamal = ramal;
this.strDepartamento = departamento;
this.strEmail = email;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strNome = this.strNome + this.delimitadorMV + nome;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strRamal = this.strRamal + this.delimitadorMV + ramal;
this.strDepartamento = this.strDepartamento + this.delimitadorMV + departamento;
this.strEmail = this.strEmail + this.delimitadorMV + email;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
this.TotalPosicao = this.strNumero.split(this.delimitadorMV).length;
this.limpaCamposCliente();
return 1;
}

self.s00_componente_interface_scsCompositeContato2_alterarCorLinha = function(posLinha) {
var componente = zenPage.getComponent(this.index)
var qtdLinha = componente.TotalPosicao
var linha = 1
while(linha<=qtdLinha){
var aux = "linhaContato"+linha
var obj = document.getElementById(aux)
if ((linha%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (linha == posLinha){
obj.style.background = "#fbe091";
}else{
obj.style.background = zebra;
}
linha = linha + 1
}
}

self.s00_componente_interface_scsCompositeContato2_atualizaBotoesPadraoCliente = function(pAcao) {
if (pAcao==1){
this.getChildById("btNovo").setHidden(true);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Adicionar contato");
this.Atualizar = 0;
btAcao.setProperty("onclick","zenThis.composite.adicionaContatoCliente(); zenThis.composite.atualizaGridHtmlCliente()");
btAcao.setProperty("enclosingClass","botao_i_add");
}else if (pAcao==2){
this.getChildById("btNovo").setHidden(false);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Atualizar contato");
this.Atualizar = 1;
btAcao.setProperty("onclick","zenThis.composite.adicionaContatoCliente(); zenThis.composite.atualizaGridHtmlCliente()");
btAcao.setProperty("enclosingClass","botao_i_refresh_red");
}
if (this.scsTodosSomenteLeitura){
this.getChildById("btNovo").setHidden(true);
this.getChildById("btAcao").setHidden(true);
}
return 1;
}

self.s00_componente_interface_scsCompositeContato2_atualizaContatoCliente = function() {
var tipo = this.getChildById("contatoTipo").getProperty("value");
var ddi = this.getChildById("contatoDdi").getProperty("value");
var ddd = this.getChildById("contatoDdd").getProperty("value");
var nome = this.getChildById("contatoNome").getProperty("value");
var numero = this.getChildById("contatoNumero").getProperty("value");
var ramal = this.getChildById("contatoRamal").getProperty("value");
var departamento = this.getChildById("contatoDepartamento").getProperty("value");
var email = this.getChildById("contatoEmail").getProperty("value");
var obs = this.getChildById("contatoObs").getProperty("value");
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
var posicao = this.PosicaoAtual - 1;
tipoList.splice(posicao,1,tipo);
ddiList.splice(posicao,1,ddi);
dddList.splice(posicao,1,ddd);
nomeList.splice(posicao,1,nome);
numeroList.splice(posicao,1,numero);
ramalList.splice(posicao,1,ramal);
departamentoList.splice(posicao,1,departamento);
emailList.splice(posicao,1,email);
obsList.splice(posicao,1,obs);
this.strTipo = tipoList.join(this.delimitadorMV);
this.strDdi = ddiList.join(this.delimitadorMV);
this.strDdd = dddList.join(this.delimitadorMV);
this.strNome = nomeList.join(this.delimitadorMV);
this.strNumero = numeroList.join(this.delimitadorMV);
this.strRamal = ramalList.join(this.delimitadorMV);
this.strDepartamento = departamentoList.join(this.delimitadorMV);
this.strEmail = emailList.join(this.delimitadorMV);
this.strObs = obsList.join(this.delimitadorMV);
this.atualizaBotoesPadraoCliente(1);
this.limpaCamposCliente();
return 1;
}

self.s00_componente_interface_scsCompositeContato2_atualizaGridHtmlCliente = function() {
var objGrid = this.getChildById("contatoGrid");
objGrid.setProperty("content",this.desenhaGridHtmlCliente());
return 1;
}

self.s00_componente_interface_scsCompositeContato2_consultaContatoCliente = function(pPosicao) {
this.PosicaoAtual = pPosicao;
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
this.getChildById("contatoTipo").setProperty("value",tipoList[(pPosicao-1)]);
this.getChildById("contatoDdi").setProperty("value",ddiList[(pPosicao-1)]);
this.getChildById("contatoDdd").setProperty("value",dddList[(pPosicao-1)]);
this.getChildById("contatoNome").setProperty("value",nomeList[(pPosicao-1)]);
this.getChildById("contatoNumero").setProperty("value",numeroList[(pPosicao-1)]);
this.getChildById("contatoRamal").setProperty("value",ramalList[(pPosicao-1)]);
this.getChildById("contatoDepartamento").setProperty("value",departamentoList[(pPosicao-1)]);
this.getChildById("contatoEmail").setProperty("value",emailList[(pPosicao-1)]);
this.getChildById("contatoObs").setProperty("value",obsList[(pPosicao-1)]);
var retorno = this.atualizaBotoesPadraoCliente(2);
return 1;
}

self.s00_componente_interface_scsCompositeContato2_consultarContato = function() {
var tipo = zenPage.getComponentById("formularioCadastro.ContatoTipo").getValue();
var ddi = zenPage.getComponentById("formularioCadastro.ContatoDdi").getValue();
var ddd = zenPage.getComponentById("formularioCadastro.ContatoDdd").getValue();
var nome = zenPage.getComponentById("formularioCadastro.ContatoNome").getValue();
var numero = zenPage.getComponentById("formularioCadastro.ContatoNumero").getValue();
var ramal = zenPage.getComponentById("formularioCadastro.ContatoRamal").getValue();
var departamento = zenPage.getComponentById("formularioCadastro.ContatoDepartamento").getValue();
var email = zenPage.getComponentById("formularioCadastro.ContatoEmail").getValue();
var obs = zenPage.getComponentById("formularioCadastro.ContatoObservacao").getValue();
var componente = zenPage.getComponent(this.index);
componente.strTipo = tipo;
componente.strDdi = ddd;
componente.strDdd = ddd;
componente.strNome = nome;
componente.strNumero = numero;
componente.strRamal = ramal;
componente.strDepartamento = departamento;
componente.strEmail = email;
componente.strObs = obs;
componente.atualizaGridHtmlCliente();
}

self.s00_componente_interface_scsCompositeContato2_desenhaGridHtmlCliente = function() {
var strGridHtml = "";
var numeroList = this.strNumero.split(this.delimitadorMV);
this.TotalPosicao = numeroList.length;
if (this.TipoComponente == "scsCompositeContato2"){
strGridHtml += "<table cellpadding='0' class='scsCompositeContato2' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}else if (this.TipoComponente == "scsCompositeContato3"){
strGridHtml += "<table cellpadding='0' class='scsCompositeContato3' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}else if (this.TipoComponente == "scsCompositeContato4"){
strGridHtml += "<table cellpadding='0' style='width:100%;' class='scsCompositeContato4' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}
if (this.strNumero != ""){
var tipoList = this.strTipo.split("@VM");
var dddList = this.strDdd.split("@VM");
var nomeList = this.strNome.split("@VM");
var ramalList = this.strRamal.split("@VM");
var departamentoList = this.strDepartamento.split("@VM");
var emailList = this.strEmail.split("@VM");
var qtdMV = this.TotalPosicao;
for (i=0;i<qtdMV;i++){
var tipoContato = parseInt(tipoList[i]);
switch (tipoContato){
case 1:
tipoContato = "Residencial";
break;
case 2:
tipoContato = "Comercial";
break;
case 3:
tipoContato = "Celular";
break;
case 4:
tipoContato = "Fax";
break;
case 5:
tipoContato = "Outros";
break;
}
var ddd = dddList[i];
var nome = nomeList[i];
var numero = numeroList[i];
var ramal = ramalList[i];
var departamento = departamentoList[i];
var email = emailList[i];
var telefone = "("+ddd+") "+numero;
if (nome == "") nome = "&#160;";
if (ramal == "") ramal = "&#160;";
if (departamento == "") departamento = "&#160;";
if (email == "") email = "&#160;";
if (((i+1)%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (this.TipoComponente == "scsCompositeContato2"){
strGridHtml +=
"<tr style='cursor:pointer;' id='linhaContato"+(i+1)+"' bgcolor='"+zebra+"'>"+
"<td width='83px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoContato+"</td>"+
"<td width='212px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='111px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>"+
"<td width='73px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+ramal+"</td>"+
"<td width='88px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+departamento+"</td>"+
"<td width='188px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+email+"</td>"
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='30' align='rigth' style='border-right:0;vertical-align: middle;' noWrap='nowrap'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='30' align='center' style='border-right:0;vertical-align: middle;' noWrap='nowrap'><img alt='Excluir' style='cursor:pointer;' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}else if (this.TipoComponente == "scsCompositeContato3"){
strGridHtml +=
"<tr id='linhaContato"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='179' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='121' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='26' align='rigth' style='vertical-align: middle;border-right:0;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='26' align='center' style='vertical-align: middle;border-right:0;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}else if (this.TipoComponente == "scsCompositeContato4"){
strGridHtml +=
"<tr id='linhaContato"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='179' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='121' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='26' align='rigth' style='vertical-align: middle;border-right:0;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='26' align='center' style='vertical-align: middle;border-right:0;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}
}
}
strGridHtml += "</table>";
return strGridHtml;
}

self.s00_componente_interface_scsCompositeContato2_excluirContatoCliente = function(pPosicao) {
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
tipoList.splice((pPosicao-1),1);
ddiList.splice((pPosicao-1),1);
dddList.splice((pPosicao-1),1);
nomeList.splice((pPosicao-1),1);
numeroList.splice((pPosicao-1),1);
ramalList.splice((pPosicao-1),1);
departamentoList.splice((pPosicao-1),1);
emailList.splice((pPosicao-1),1);
obsList.splice((pPosicao-1),1);
this.strTipo = tipoList.join(this.delimitadorMV);
this.strDdi = ddiList.join(this.delimitadorMV);
this.strDdd = dddList.join(this.delimitadorMV);
this.strNome = nomeList.join(this.delimitadorMV);
this.strNumero = numeroList.join(this.delimitadorMV);
this.strRamal = ramalList.join(this.delimitadorMV);
this.strDepartamento = departamentoList.join(this.delimitadorMV);
this.strEmail = emailList.join(this.delimitadorMV);
this.strObs = obsList.join(this.delimitadorMV);
this.TotalPosicao = this.TotalPosicao - 1;
this.PosicaoAtual = 0;
var retorno = this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1)
return 1;
}

self.s00_componente_interface_scsCompositeContato2_limpaCamposCliente = function() {
this.getChildById("contatoTipo").setProperty("value","");
this.getChildById("contatoDdi").setProperty("value","");
this.getChildById("contatoDdd").setProperty("value","");
this.getChildById("contatoNome").setProperty("value","");
this.getChildById("contatoNumero").setProperty("value","");
this.getChildById("contatoRamal").setProperty("value","");
this.getChildById("contatoDepartamento").setProperty("value","");
this.getChildById("contatoEmail").setProperty("value","");
this.getChildById("contatoObs").setProperty("value","");
return 1;
}

self.s00_componente_interface_scsCompositeContato2_limpaComponenteCliente = function() {
this.limpaCamposCliente();
if (this.strNumero == "")
return 1
this.strTipo = "";
this.strDdd = "";
this.strDdi = "";
this.strNome = "";
this.strNumero = "";
this.strRamal = "";
this.strDepartamento = "";
this.strEmail = "";
this.strObs = "";
var retorno = this.atualizaBotoesPadraoCliente(1);
var retorno = this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente_interface_scsCompositeContato2_novo = function() {
this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1);
this.alterarCorLinha(0);
return 1;
}

self.s00_componente_interface_scsCompositeContato2_refreshHTML = function() {
var retorno = zenPage.atualizaGridHtmlCliente();
}

self.s00_componente_interface_scsCompositeContato2_removerEspacos = function(pString) {
return pString.replace(/\s/g,"");
}

self.s00_componente_interface_scsCompositeContato2_AdicionaContato = function(atualiza) {
	return zenInstanceMethod(this,'AdicionaContato','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato2_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato2_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato2_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato2_AtualizaContato = function() {
	return zenInstanceMethod(this,'AtualizaContato','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato2_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato2_ConsultaContato = function(posicao) {
	return zenInstanceMethod(this,'ConsultaContato','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato2_DesenhaGridHtml = function() {
	return zenInstanceMethod(this,'DesenhaGridHtml','','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato2_ExcluirContato = function(posicao) {
	return zenInstanceMethod(this,'ExcluirContato','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato2_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato2_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato2_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato2_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato2_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato2_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato2_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato2_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato2_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato2_LimpaCampos = function() {
	return zenInstanceMethod(this,'LimpaCampos','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato2_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato2_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeContato2_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato2_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato2_TodosSomenteLeitura = function(acao) {
	return zenInstanceMethod(this,'TodosSomenteLeitura','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato2_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeContato2__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeContato2.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeContato2.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeContato2;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeContato2';
	p._type = 'scsCompositeContato2';
	p.serialize = s00_componente_interface_scsCompositeContato2_serialize;
	p.getSettings = s00_componente_interface_scsCompositeContato2_getSettings;
	p.AdicionaContato = s00_componente_interface_scsCompositeContato2_AdicionaContato;
	p.AjustaTamanhoValor = s00_componente_interface_scsCompositeContato2_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente_interface_scsCompositeContato2_ApresentaExcecao;
	p.AtualizaBotoesPadrao = s00_componente_interface_scsCompositeContato2_AtualizaBotoesPadrao;
	p.AtualizaContato = s00_componente_interface_scsCompositeContato2_AtualizaContato;
	p.AtualizaGridHtml = s00_componente_interface_scsCompositeContato2_AtualizaGridHtml;
	p.ConsultaContato = s00_componente_interface_scsCompositeContato2_ConsultaContato;
	p.DesenhaGridHtml = s00_componente_interface_scsCompositeContato2_DesenhaGridHtml;
	p.ExcluirContato = s00_componente_interface_scsCompositeContato2_ExcluirContato;
	p.GeraCheckBoxHtml = s00_componente_interface_scsCompositeContato2_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente_interface_scsCompositeContato2_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente_interface_scsCompositeContato2_GeraRadioHtml;
	p.GeraSV1Label = s00_componente_interface_scsCompositeContato2_GeraSV1Label;
	p.GeraSV1Text = s00_componente_interface_scsCompositeContato2_GeraSV1Text;
	p.GeraSelectHtml = s00_componente_interface_scsCompositeContato2_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente_interface_scsCompositeContato2_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente_interface_scsCompositeContato2_GeraTextHtml;
	p.GetValorPropriedade = s00_componente_interface_scsCompositeContato2_GetValorPropriedade;
	p.LimpaCampos = s00_componente_interface_scsCompositeContato2_LimpaCampos;
	p.LimpaComponente = s00_componente_interface_scsCompositeContato2_LimpaComponente;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeContato2_ReallyRefreshContents;
	p.RecuperarContato = s00_componente_interface_scsCompositeContato2_RecuperarContato;
	p.RetornaValorCampo = s00_componente_interface_scsCompositeContato2_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente_interface_scsCompositeContato2_SetValorPropriedade;
	p.TodosSomenteLeitura = s00_componente_interface_scsCompositeContato2_TodosSomenteLeitura;
	p.VerificaErro = s00_componente_interface_scsCompositeContato2_VerificaErro;
	p.adicionaContatoCliente = s00_componente_interface_scsCompositeContato2_adicionaContatoCliente;
	p.alterarCorLinha = s00_componente_interface_scsCompositeContato2_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente_interface_scsCompositeContato2_atualizaBotoesPadraoCliente;
	p.atualizaContatoCliente = s00_componente_interface_scsCompositeContato2_atualizaContatoCliente;
	p.atualizaGridHtmlCliente = s00_componente_interface_scsCompositeContato2_atualizaGridHtmlCliente;
	p.consultaContatoCliente = s00_componente_interface_scsCompositeContato2_consultaContatoCliente;
	p.consultarContato = s00_componente_interface_scsCompositeContato2_consultarContato;
	p.desenhaGridHtmlCliente = s00_componente_interface_scsCompositeContato2_desenhaGridHtmlCliente;
	p.excluirContatoCliente = s00_componente_interface_scsCompositeContato2_excluirContatoCliente;
	p.limpaCamposCliente = s00_componente_interface_scsCompositeContato2_limpaCamposCliente;
	p.limpaComponenteCliente = s00_componente_interface_scsCompositeContato2_limpaComponenteCliente;
	p.novo = s00_componente_interface_scsCompositeContato2_novo;
	p.refreshHTML = s00_componente_interface_scsCompositeContato2_refreshHTML;
	p.removerEspacos = s00_componente_interface_scsCompositeContato2_removerEspacos;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeContato3'] = 's00_componente_interface_scsCompositeContato3';
self.s00_componente_interface_scsCompositeContato3 = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeContato3__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeContato3__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.Atualizar = false;
	o.CamposTraducao = new Object();
	o.MensagensErro = new Object();
	o.PosicaoAtual = '0';
	o.TipoComponente = '';
	o.TotalPosicao = '0';
	o.delimitadorMV = '@VM';
	o.scsApresentaLabel = true;
	o.scsDddObrigatorio = false;
	o.scsDdiObrigatorio = false;
	o.scsDepartamentoObrigatorio = false;
	o.scsEmailObrigatorio = false;
	o.scsNomeObrigatorio = false;
	o.scsObsObrigatorio = false;
	o.scsRamalObrigatorio = false;
	o.scsTodosSomenteLeitura = false;
	o.strDdd = '';
	o.strDdi = '';
	o.strDepartamento = '';
	o.strEmail = '';
	o.strNome = '';
	o.strNumero = '';
	o.strObs = '';
	o.strRamal = '';
	o.strTipo = '';
}
function s00_componente_interface_scsCompositeContato3_serialize(set,s)
{
	var o = this;s[0]='3698044372';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=(o.Atualizar?1:0);s[7]=set.serializeArray(o,o.CamposTraducao,false,'CamposTraducao');s[8]=set.serializeArray(o,o.MensagensErro,false,'MensagensErro');s[9]=o.PosicaoAtual;s[10]=o.TipoComponente;s[11]=o.TotalPosicao;s[12]=o.align;s[13]=o.aux;s[14]=o.cellAlign;s[15]=o.cellSize;s[16]=o.cellStyle;s[17]=o.cellVAlign;s[18]=set.serializeList(o,o.children,true,'children');s[19]=(o.childrenCreated?1:0);s[20]=o.containerStyle;s[21]=o.delimitadorMV;s[22]=(o.disabled?1:0);s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.groupClass;s[30]=o.groupStyle;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=o.label;s[37]=o.labelClass;s[38]=o.labelDisabledClass;s[39]=o.labelPosition;s[40]=o.labelStyle;s[41]=o.layout;s[42]=o.onafterdrag;s[43]=o.onbeforedrag;s[44]=o.onclick;s[45]=o.ondrag;s[46]=o.ondrop;s[47]=o.onhide;s[48]=o.onrefresh;s[49]=o.onshow;s[50]=o.onupdate;s[51]=o.overlayMode;s[52]=o.renderFlag;s[53]=(o.scsApresentaLabel?1:0);s[54]=(o.scsDddObrigatorio?1:0);s[55]=(o.scsDdiObrigatorio?1:0);s[56]=(o.scsDepartamentoObrigatorio?1:0);s[57]=(o.scsEmailObrigatorio?1:0);s[58]=(o.scsNomeObrigatorio?1:0);s[59]=(o.scsObsObrigatorio?1:0);s[60]=(o.scsRamalObrigatorio?1:0);s[61]=(o.scsTodosSomenteLeitura?1:0);s[62]=(o.showLabel?1:0);s[63]=o.slice;s[64]=o.strDdd;s[65]=o.strDdi;s[66]=o.strDepartamento;s[67]=o.strEmail;s[68]=o.strNome;s[69]=o.strNumero;s[70]=o.strObs;s[71]=o.strRamal;s[72]=o.strTipo;s[73]=o.title;s[74]=o.tuple;s[75]=o.valign;s[76]=(o.visible?1:0);s[77]=o.width;
}
function s00_componente_interface_scsCompositeContato3_getSettings(s)
{
	s['name'] = 'string';
	s['Atualizar'] = 'string';
	s['CamposTraducao'] = 'string';
	s['MensagensErro'] = 'string';
	s['PosicaoAtual'] = 'string';
	s['TipoComponente'] = 'string';
	s['TotalPosicao'] = 'string';
	s['delimitadorMV'] = 'string';
	s['scsApresentaLabel'] = 'boolean';
	s['scsDddObrigatorio'] = 'boolean';
	s['scsDdiObrigatorio'] = 'boolean';
	s['scsDepartamentoObrigatorio'] = 'boolean';
	s['scsEmailObrigatorio'] = 'boolean';
	s['scsNomeObrigatorio'] = 'boolean';
	s['scsObsObrigatorio'] = 'boolean';
	s['scsRamalObrigatorio'] = 'boolean';
	s['scsTodosSomenteLeitura'] = 'boolean';
	s['strDdd'] = 'string';
	s['strDdi'] = 'string';
	s['strDepartamento'] = 'string';
	s['strEmail'] = 'string';
	s['strNome'] = 'string';
	s['strNumero'] = 'string';
	s['strObs'] = 'string';
	s['strRamal'] = 'string';
	s['strTipo'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeContato3_RecuperarContato = function() {
var componente = zenPage.getComponent(this.index)
zenPage.getComponentById("formularioCadastro.ContatoTipo").setValue(componente.strTipo)
zenPage.getComponentById("formularioCadastro.ContatoTipo").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDdi").setValue(componente.strDdi)
zenPage.getComponentById("formularioCadastro.ContatoDdi").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDdd").setValue(componente.strDdd)
zenPage.getComponentById("formularioCadastro.ContatoDdd").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoNome").setValue(componente.strNome)
zenPage.getComponentById("formularioCadastro.ContatoNome").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoNumero").setValue(componente.strNumero)
zenPage.getComponentById("formularioCadastro.ContatoNumero").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoRamal").setValue(componente.strRamal)
zenPage.getComponentById("formularioCadastro.ContatoRamal").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDepartamento").setValue(componente.strDepartamento)
zenPage.getComponentById("formularioCadastro.ContatoDepartamento").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoEmail").setValue(componente.strEmail)
zenPage.getComponentById("formularioCadastro.ContatoEmail").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoObservacao").setValue(componente.strObs)
zenPage.getComponentById("formularioCadastro.ContatoObservacao").onchangeHandler()
}

self.s00_componente_interface_scsCompositeContato3_adicionaContatoCliente = function() {
var tipo = this.getChildById("contatoTipo").getProperty("value");
var ddi = this.getChildById("contatoDdi").getProperty("value");
var ddd = this.getChildById("contatoDdd").getProperty("value");
var nome = this.getChildById("contatoNome").getProperty("value");
var numero = this.getChildById("contatoNumero").getProperty("value");
var ramal = this.getChildById("contatoRamal").getProperty("value");
var departamento = this.getChildById("contatoDepartamento").getProperty("value");
var email = this.getChildById("contatoEmail").getProperty("value");
var obs = this.getChildById("contatoObs").getProperty("value");
var erro = "";
if (this.removerEspacos(tipo) == ""){
erro += "- "+this.CamposTraducao["tipo"]+" \n";
}
if ((this.removerEspacos(ddi) == "") && (this.scsDdiObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ddi"]+" \n";
}
if ((this.removerEspacos(ddd) == "") && (this.scsDddObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ddd"]+" \n";
}
if ((this.removerEspacos(nome) == "") && (this.scsNomeObrigatorio) == 1){
erro += "- "+this.CamposTraducao["nome"]+" \n";
}
if (this.removerEspacos(numero) == ""){
erro += "- "+this.CamposTraducao["numero"]+" \n";
}
if ((this.removerEspacos(ramal) == "") && (this.scsRamalObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ramal"]+" \n";
}
if ((this.removerEspacos(departamento) == "") && (this.scsDepartamentoObrigatorio) == 1){
erro += "- "+this.CamposTraducao["departamento"]+" \n";
}
if ((this.removerEspacos(email) == "") && (this.scsEmailObrigatorio) == 1){
erro += "- "+this.CamposTraducao["email"]+" \n";
}
if ((this.removerEspacos(obs) == "") && (this.scsObsObrigatorio) == 1){
erro += "- "+this.CamposTraducao["observacoes"]+" \n";
}
if (erro != ""){
zenPage.alertaShift(this.MensagensErro["camposObrigatorios"]+"\n"+erro);
return 1;
}
if (this.Atualizar){
this.atualizaContatoCliente();
return 1;
}
if (this.strNumero == ""){
this.strTipo = tipo;
this.strDdd = ddd;
this.strDdi = ddi;
this.strNome = nome;
this.strNumero = numero;
this.strRamal = ramal;
this.strDepartamento = departamento;
this.strEmail = email;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strNome = this.strNome + this.delimitadorMV + nome;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strRamal = this.strRamal + this.delimitadorMV + ramal;
this.strDepartamento = this.strDepartamento + this.delimitadorMV + departamento;
this.strEmail = this.strEmail + this.delimitadorMV + email;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
this.TotalPosicao = this.strNumero.split(this.delimitadorMV).length;
this.limpaCamposCliente();
return 1;
}

self.s00_componente_interface_scsCompositeContato3_alterarCorLinha = function(posLinha) {
var componente = zenPage.getComponent(this.index)
var qtdLinha = componente.TotalPosicao
var linha = 1
while(linha<=qtdLinha){
var aux = "linhaContato"+linha
var obj = document.getElementById(aux)
if ((linha%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (linha == posLinha){
obj.style.background = "#fbe091";
}else{
obj.style.background = zebra;
}
linha = linha + 1
}
}

self.s00_componente_interface_scsCompositeContato3_atualizaBotoesPadraoCliente = function(pAcao) {
if (pAcao==1){
this.getChildById("btNovo").setHidden(true);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Adicionar contato");
this.Atualizar = 0;
btAcao.setProperty("onclick","zenThis.composite.adicionaContatoCliente(); zenThis.composite.atualizaGridHtmlCliente()");
btAcao.setProperty("enclosingClass","botao_i_add");
}else if (pAcao==2){
this.getChildById("btNovo").setHidden(false);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Atualizar contato");
this.Atualizar = 1;
btAcao.setProperty("onclick","zenThis.composite.adicionaContatoCliente(); zenThis.composite.atualizaGridHtmlCliente()");
btAcao.setProperty("enclosingClass","botao_i_refresh_red");
}
if (this.scsTodosSomenteLeitura){
this.getChildById("btNovo").setHidden(true);
this.getChildById("btAcao").setHidden(true);
}
return 1;
}

self.s00_componente_interface_scsCompositeContato3_atualizaContatoCliente = function() {
var tipo = this.getChildById("contatoTipo").getProperty("value");
var ddi = this.getChildById("contatoDdi").getProperty("value");
var ddd = this.getChildById("contatoDdd").getProperty("value");
var nome = this.getChildById("contatoNome").getProperty("value");
var numero = this.getChildById("contatoNumero").getProperty("value");
var ramal = this.getChildById("contatoRamal").getProperty("value");
var departamento = this.getChildById("contatoDepartamento").getProperty("value");
var email = this.getChildById("contatoEmail").getProperty("value");
var obs = this.getChildById("contatoObs").getProperty("value");
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
var posicao = this.PosicaoAtual - 1;
tipoList.splice(posicao,1,tipo);
ddiList.splice(posicao,1,ddi);
dddList.splice(posicao,1,ddd);
nomeList.splice(posicao,1,nome);
numeroList.splice(posicao,1,numero);
ramalList.splice(posicao,1,ramal);
departamentoList.splice(posicao,1,departamento);
emailList.splice(posicao,1,email);
obsList.splice(posicao,1,obs);
this.strTipo = tipoList.join(this.delimitadorMV);
this.strDdi = ddiList.join(this.delimitadorMV);
this.strDdd = dddList.join(this.delimitadorMV);
this.strNome = nomeList.join(this.delimitadorMV);
this.strNumero = numeroList.join(this.delimitadorMV);
this.strRamal = ramalList.join(this.delimitadorMV);
this.strDepartamento = departamentoList.join(this.delimitadorMV);
this.strEmail = emailList.join(this.delimitadorMV);
this.strObs = obsList.join(this.delimitadorMV);
this.atualizaBotoesPadraoCliente(1);
this.limpaCamposCliente();
return 1;
}

self.s00_componente_interface_scsCompositeContato3_atualizaGridHtmlCliente = function() {
var objGrid = this.getChildById("contatoGrid");
objGrid.setProperty("content",this.desenhaGridHtmlCliente());
return 1;
}

self.s00_componente_interface_scsCompositeContato3_consultaContatoCliente = function(pPosicao) {
this.PosicaoAtual = pPosicao;
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
this.getChildById("contatoTipo").setProperty("value",tipoList[(pPosicao-1)]);
this.getChildById("contatoDdi").setProperty("value",ddiList[(pPosicao-1)]);
this.getChildById("contatoDdd").setProperty("value",dddList[(pPosicao-1)]);
this.getChildById("contatoNome").setProperty("value",nomeList[(pPosicao-1)]);
this.getChildById("contatoNumero").setProperty("value",numeroList[(pPosicao-1)]);
this.getChildById("contatoRamal").setProperty("value",ramalList[(pPosicao-1)]);
this.getChildById("contatoDepartamento").setProperty("value",departamentoList[(pPosicao-1)]);
this.getChildById("contatoEmail").setProperty("value",emailList[(pPosicao-1)]);
this.getChildById("contatoObs").setProperty("value",obsList[(pPosicao-1)]);
var retorno = this.atualizaBotoesPadraoCliente(2);
return 1;
}

self.s00_componente_interface_scsCompositeContato3_consultarContato = function() {
var tipo = zenPage.getComponentById("formularioCadastro.ContatoTipo").getValue();
var ddi = zenPage.getComponentById("formularioCadastro.ContatoDdi").getValue();
var ddd = zenPage.getComponentById("formularioCadastro.ContatoDdd").getValue();
var nome = zenPage.getComponentById("formularioCadastro.ContatoNome").getValue();
var numero = zenPage.getComponentById("formularioCadastro.ContatoNumero").getValue();
var ramal = zenPage.getComponentById("formularioCadastro.ContatoRamal").getValue();
var departamento = zenPage.getComponentById("formularioCadastro.ContatoDepartamento").getValue();
var email = zenPage.getComponentById("formularioCadastro.ContatoEmail").getValue();
var obs = zenPage.getComponentById("formularioCadastro.ContatoObservacao").getValue();
var componente = zenPage.getComponent(this.index);
componente.strTipo = tipo;
componente.strDdi = ddd;
componente.strDdd = ddd;
componente.strNome = nome;
componente.strNumero = numero;
componente.strRamal = ramal;
componente.strDepartamento = departamento;
componente.strEmail = email;
componente.strObs = obs;
componente.atualizaGridHtmlCliente();
}

self.s00_componente_interface_scsCompositeContato3_desenhaGridHtmlCliente = function() {
var strGridHtml = "";
var numeroList = this.strNumero.split(this.delimitadorMV);
this.TotalPosicao = numeroList.length;
if (this.TipoComponente == "scsCompositeContato2"){
strGridHtml += "<table cellpadding='0' class='scsCompositeContato2' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}else if (this.TipoComponente == "scsCompositeContato3"){
strGridHtml += "<table cellpadding='0' class='scsCompositeContato3' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}else if (this.TipoComponente == "scsCompositeContato4"){
strGridHtml += "<table cellpadding='0' style='width:100%;' class='scsCompositeContato4' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}
if (this.strNumero != ""){
var tipoList = this.strTipo.split("@VM");
var dddList = this.strDdd.split("@VM");
var nomeList = this.strNome.split("@VM");
var ramalList = this.strRamal.split("@VM");
var departamentoList = this.strDepartamento.split("@VM");
var emailList = this.strEmail.split("@VM");
var qtdMV = this.TotalPosicao;
for (i=0;i<qtdMV;i++){
var tipoContato = parseInt(tipoList[i]);
switch (tipoContato){
case 1:
tipoContato = "Residencial";
break;
case 2:
tipoContato = "Comercial";
break;
case 3:
tipoContato = "Celular";
break;
case 4:
tipoContato = "Fax";
break;
case 5:
tipoContato = "Outros";
break;
}
var ddd = dddList[i];
var nome = nomeList[i];
var numero = numeroList[i];
var ramal = ramalList[i];
var departamento = departamentoList[i];
var email = emailList[i];
var telefone = "("+ddd+") "+numero;
if (nome == "") nome = "&#160;";
if (ramal == "") ramal = "&#160;";
if (departamento == "") departamento = "&#160;";
if (email == "") email = "&#160;";
if (((i+1)%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (this.TipoComponente == "scsCompositeContato2"){
strGridHtml +=
"<tr style='cursor:pointer;' id='linhaContato"+(i+1)+"' bgcolor='"+zebra+"'>"+
"<td width='83px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoContato+"</td>"+
"<td width='212px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='111px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>"+
"<td width='73px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+ramal+"</td>"+
"<td width='88px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+departamento+"</td>"+
"<td width='188px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+email+"</td>"
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='30' align='rigth' style='border-right:0;vertical-align: middle;' noWrap='nowrap'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='30' align='center' style='border-right:0;vertical-align: middle;' noWrap='nowrap'><img alt='Excluir' style='cursor:pointer;' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}else if (this.TipoComponente == "scsCompositeContato3"){
strGridHtml +=
"<tr id='linhaContato"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='179' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='121' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='26' align='rigth' style='vertical-align: middle;border-right:0;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='26' align='center' style='vertical-align: middle;border-right:0;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}else if (this.TipoComponente == "scsCompositeContato4"){
strGridHtml +=
"<tr id='linhaContato"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='179' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='121' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='26' align='rigth' style='vertical-align: middle;border-right:0;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='26' align='center' style='vertical-align: middle;border-right:0;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}
}
}
strGridHtml += "</table>";
return strGridHtml;
}

self.s00_componente_interface_scsCompositeContato3_excluirContatoCliente = function(pPosicao) {
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
tipoList.splice((pPosicao-1),1);
ddiList.splice((pPosicao-1),1);
dddList.splice((pPosicao-1),1);
nomeList.splice((pPosicao-1),1);
numeroList.splice((pPosicao-1),1);
ramalList.splice((pPosicao-1),1);
departamentoList.splice((pPosicao-1),1);
emailList.splice((pPosicao-1),1);
obsList.splice((pPosicao-1),1);
this.strTipo = tipoList.join(this.delimitadorMV);
this.strDdi = ddiList.join(this.delimitadorMV);
this.strDdd = dddList.join(this.delimitadorMV);
this.strNome = nomeList.join(this.delimitadorMV);
this.strNumero = numeroList.join(this.delimitadorMV);
this.strRamal = ramalList.join(this.delimitadorMV);
this.strDepartamento = departamentoList.join(this.delimitadorMV);
this.strEmail = emailList.join(this.delimitadorMV);
this.strObs = obsList.join(this.delimitadorMV);
this.TotalPosicao = this.TotalPosicao - 1;
this.PosicaoAtual = 0;
var retorno = this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1)
return 1;
}

self.s00_componente_interface_scsCompositeContato3_limpaCamposCliente = function() {
this.getChildById("contatoTipo").setProperty("value","");
this.getChildById("contatoDdi").setProperty("value","");
this.getChildById("contatoDdd").setProperty("value","");
this.getChildById("contatoNome").setProperty("value","");
this.getChildById("contatoNumero").setProperty("value","");
this.getChildById("contatoRamal").setProperty("value","");
this.getChildById("contatoDepartamento").setProperty("value","");
this.getChildById("contatoEmail").setProperty("value","");
this.getChildById("contatoObs").setProperty("value","");
return 1;
}

self.s00_componente_interface_scsCompositeContato3_limpaComponenteCliente = function() {
this.limpaCamposCliente();
if (this.strNumero == "")
return 1
this.strTipo = "";
this.strDdd = "";
this.strDdi = "";
this.strNome = "";
this.strNumero = "";
this.strRamal = "";
this.strDepartamento = "";
this.strEmail = "";
this.strObs = "";
var retorno = this.atualizaBotoesPadraoCliente(1);
var retorno = this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente_interface_scsCompositeContato3_novo = function() {
this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1);
this.alterarCorLinha(0);
return 1;
}

self.s00_componente_interface_scsCompositeContato3_refreshHTML = function() {
var retorno = zenPage.atualizaGridHtmlCliente();
}

self.s00_componente_interface_scsCompositeContato3_removerEspacos = function(pString) {
return pString.replace(/\s/g,"");
}

self.s00_componente_interface_scsCompositeContato3_AdicionaContato = function(atualiza) {
	return zenInstanceMethod(this,'AdicionaContato','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato3_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato3_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato3_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato3_AtualizaContato = function() {
	return zenInstanceMethod(this,'AtualizaContato','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato3_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato3_ConsultaContato = function(posicao) {
	return zenInstanceMethod(this,'ConsultaContato','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato3_DesenhaGridHtml = function() {
	return zenInstanceMethod(this,'DesenhaGridHtml','','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato3_ExcluirContato = function(posicao) {
	return zenInstanceMethod(this,'ExcluirContato','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato3_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato3_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato3_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato3_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato3_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato3_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato3_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato3_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato3_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato3_LimpaCampos = function() {
	return zenInstanceMethod(this,'LimpaCampos','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato3_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato3_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeContato3_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato3_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato3_TodosSomenteLeitura = function(acao) {
	return zenInstanceMethod(this,'TodosSomenteLeitura','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato3_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeContato3__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeContato3.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeContato3.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeContato3;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeContato3';
	p._type = 'scsCompositeContato3';
	p.serialize = s00_componente_interface_scsCompositeContato3_serialize;
	p.getSettings = s00_componente_interface_scsCompositeContato3_getSettings;
	p.AdicionaContato = s00_componente_interface_scsCompositeContato3_AdicionaContato;
	p.AjustaTamanhoValor = s00_componente_interface_scsCompositeContato3_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente_interface_scsCompositeContato3_ApresentaExcecao;
	p.AtualizaBotoesPadrao = s00_componente_interface_scsCompositeContato3_AtualizaBotoesPadrao;
	p.AtualizaContato = s00_componente_interface_scsCompositeContato3_AtualizaContato;
	p.AtualizaGridHtml = s00_componente_interface_scsCompositeContato3_AtualizaGridHtml;
	p.ConsultaContato = s00_componente_interface_scsCompositeContato3_ConsultaContato;
	p.DesenhaGridHtml = s00_componente_interface_scsCompositeContato3_DesenhaGridHtml;
	p.ExcluirContato = s00_componente_interface_scsCompositeContato3_ExcluirContato;
	p.GeraCheckBoxHtml = s00_componente_interface_scsCompositeContato3_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente_interface_scsCompositeContato3_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente_interface_scsCompositeContato3_GeraRadioHtml;
	p.GeraSV1Label = s00_componente_interface_scsCompositeContato3_GeraSV1Label;
	p.GeraSV1Text = s00_componente_interface_scsCompositeContato3_GeraSV1Text;
	p.GeraSelectHtml = s00_componente_interface_scsCompositeContato3_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente_interface_scsCompositeContato3_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente_interface_scsCompositeContato3_GeraTextHtml;
	p.GetValorPropriedade = s00_componente_interface_scsCompositeContato3_GetValorPropriedade;
	p.LimpaCampos = s00_componente_interface_scsCompositeContato3_LimpaCampos;
	p.LimpaComponente = s00_componente_interface_scsCompositeContato3_LimpaComponente;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeContato3_ReallyRefreshContents;
	p.RecuperarContato = s00_componente_interface_scsCompositeContato3_RecuperarContato;
	p.RetornaValorCampo = s00_componente_interface_scsCompositeContato3_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente_interface_scsCompositeContato3_SetValorPropriedade;
	p.TodosSomenteLeitura = s00_componente_interface_scsCompositeContato3_TodosSomenteLeitura;
	p.VerificaErro = s00_componente_interface_scsCompositeContato3_VerificaErro;
	p.adicionaContatoCliente = s00_componente_interface_scsCompositeContato3_adicionaContatoCliente;
	p.alterarCorLinha = s00_componente_interface_scsCompositeContato3_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente_interface_scsCompositeContato3_atualizaBotoesPadraoCliente;
	p.atualizaContatoCliente = s00_componente_interface_scsCompositeContato3_atualizaContatoCliente;
	p.atualizaGridHtmlCliente = s00_componente_interface_scsCompositeContato3_atualizaGridHtmlCliente;
	p.consultaContatoCliente = s00_componente_interface_scsCompositeContato3_consultaContatoCliente;
	p.consultarContato = s00_componente_interface_scsCompositeContato3_consultarContato;
	p.desenhaGridHtmlCliente = s00_componente_interface_scsCompositeContato3_desenhaGridHtmlCliente;
	p.excluirContatoCliente = s00_componente_interface_scsCompositeContato3_excluirContatoCliente;
	p.limpaCamposCliente = s00_componente_interface_scsCompositeContato3_limpaCamposCliente;
	p.limpaComponenteCliente = s00_componente_interface_scsCompositeContato3_limpaComponenteCliente;
	p.novo = s00_componente_interface_scsCompositeContato3_novo;
	p.refreshHTML = s00_componente_interface_scsCompositeContato3_refreshHTML;
	p.removerEspacos = s00_componente_interface_scsCompositeContato3_removerEspacos;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeContato4'] = 's00_componente_interface_scsCompositeContato4';
self.s00_componente_interface_scsCompositeContato4 = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeContato4__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeContato4__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.Atualizar = false;
	o.CamposTraducao = new Object();
	o.MensagensErro = new Object();
	o.PosicaoAtual = '0';
	o.TipoComponente = 'scsCompositeContato4';
	o.TotalPosicao = '0';
	o.delimitadorMV = '@VM';
	o.scsApresentaLabel = true;
	o.scsDddObrigatorio = false;
	o.scsDdiObrigatorio = false;
	o.scsDepartamentoObrigatorio = false;
	o.scsEmailObrigatorio = false;
	o.scsNomeObrigatorio = false;
	o.scsObsObrigatorio = false;
	o.scsRamalObrigatorio = false;
	o.scsTodosSomenteLeitura = false;
	o.strDdd = '';
	o.strDdi = '';
	o.strDepartamento = '';
	o.strEmail = '';
	o.strNome = '';
	o.strNumero = '';
	o.strObs = '';
	o.strRamal = '';
	o.strTipo = '';
}
function s00_componente_interface_scsCompositeContato4_serialize(set,s)
{
	var o = this;s[0]='3698044372';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=(o.Atualizar?1:0);s[7]=set.serializeArray(o,o.CamposTraducao,false,'CamposTraducao');s[8]=set.serializeArray(o,o.MensagensErro,false,'MensagensErro');s[9]=o.PosicaoAtual;s[10]=o.TipoComponente;s[11]=o.TotalPosicao;s[12]=o.align;s[13]=o.aux;s[14]=o.cellAlign;s[15]=o.cellSize;s[16]=o.cellStyle;s[17]=o.cellVAlign;s[18]=set.serializeList(o,o.children,true,'children');s[19]=(o.childrenCreated?1:0);s[20]=o.containerStyle;s[21]=o.delimitadorMV;s[22]=(o.disabled?1:0);s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.groupClass;s[30]=o.groupStyle;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=o.label;s[37]=o.labelClass;s[38]=o.labelDisabledClass;s[39]=o.labelPosition;s[40]=o.labelStyle;s[41]=o.layout;s[42]=o.onafterdrag;s[43]=o.onbeforedrag;s[44]=o.onclick;s[45]=o.ondrag;s[46]=o.ondrop;s[47]=o.onhide;s[48]=o.onrefresh;s[49]=o.onshow;s[50]=o.onupdate;s[51]=o.overlayMode;s[52]=o.renderFlag;s[53]=(o.scsApresentaLabel?1:0);s[54]=(o.scsDddObrigatorio?1:0);s[55]=(o.scsDdiObrigatorio?1:0);s[56]=(o.scsDepartamentoObrigatorio?1:0);s[57]=(o.scsEmailObrigatorio?1:0);s[58]=(o.scsNomeObrigatorio?1:0);s[59]=(o.scsObsObrigatorio?1:0);s[60]=(o.scsRamalObrigatorio?1:0);s[61]=(o.scsTodosSomenteLeitura?1:0);s[62]=(o.showLabel?1:0);s[63]=o.slice;s[64]=o.strDdd;s[65]=o.strDdi;s[66]=o.strDepartamento;s[67]=o.strEmail;s[68]=o.strNome;s[69]=o.strNumero;s[70]=o.strObs;s[71]=o.strRamal;s[72]=o.strTipo;s[73]=o.title;s[74]=o.tuple;s[75]=o.valign;s[76]=(o.visible?1:0);s[77]=o.width;
}
function s00_componente_interface_scsCompositeContato4_getSettings(s)
{
	s['name'] = 'string';
	s['Atualizar'] = 'string';
	s['CamposTraducao'] = 'string';
	s['MensagensErro'] = 'string';
	s['PosicaoAtual'] = 'string';
	s['TipoComponente'] = 'string';
	s['TotalPosicao'] = 'string';
	s['delimitadorMV'] = 'string';
	s['scsApresentaLabel'] = 'boolean';
	s['scsDddObrigatorio'] = 'boolean';
	s['scsDdiObrigatorio'] = 'boolean';
	s['scsDepartamentoObrigatorio'] = 'boolean';
	s['scsEmailObrigatorio'] = 'boolean';
	s['scsNomeObrigatorio'] = 'boolean';
	s['scsObsObrigatorio'] = 'boolean';
	s['scsRamalObrigatorio'] = 'boolean';
	s['scsTodosSomenteLeitura'] = 'boolean';
	s['strDdd'] = 'string';
	s['strDdi'] = 'string';
	s['strDepartamento'] = 'string';
	s['strEmail'] = 'string';
	s['strNome'] = 'string';
	s['strNumero'] = 'string';
	s['strObs'] = 'string';
	s['strRamal'] = 'string';
	s['strTipo'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeContato4_RecuperarContato = function() {
var componente = zenPage.getComponent(this.index)
zenPage.getComponentById("formularioCadastro.ContatoTipo").setValue(componente.strTipo)
zenPage.getComponentById("formularioCadastro.ContatoTipo").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDdi").setValue(componente.strDdi)
zenPage.getComponentById("formularioCadastro.ContatoDdi").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDdd").setValue(componente.strDdd)
zenPage.getComponentById("formularioCadastro.ContatoDdd").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoNome").setValue(componente.strNome)
zenPage.getComponentById("formularioCadastro.ContatoNome").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoNumero").setValue(componente.strNumero)
zenPage.getComponentById("formularioCadastro.ContatoNumero").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoRamal").setValue(componente.strRamal)
zenPage.getComponentById("formularioCadastro.ContatoRamal").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDepartamento").setValue(componente.strDepartamento)
zenPage.getComponentById("formularioCadastro.ContatoDepartamento").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoEmail").setValue(componente.strEmail)
zenPage.getComponentById("formularioCadastro.ContatoEmail").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoObservacao").setValue(componente.strObs)
zenPage.getComponentById("formularioCadastro.ContatoObservacao").onchangeHandler()
}

self.s00_componente_interface_scsCompositeContato4_adicionaContatoCliente = function() {
var tipo = this.getChildById("contatoTipo").getProperty("value");
var ddi = this.getChildById("contatoDdi").getProperty("value");
var ddd = this.getChildById("contatoDdd").getProperty("value");
var nome = this.getChildById("contatoNome").getProperty("value");
var numero = this.getChildById("contatoNumero").getProperty("value");
var ramal = this.getChildById("contatoRamal").getProperty("value");
var departamento = this.getChildById("contatoDepartamento").getProperty("value");
var email = this.getChildById("contatoEmail").getProperty("value");
var obs = this.getChildById("contatoObs").getProperty("value");
var erro = "";
if (this.removerEspacos(tipo) == ""){
erro += "- "+this.CamposTraducao["tipo"]+" \n";
}
if ((this.removerEspacos(ddi) == "") && (this.scsDdiObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ddi"]+" \n";
}
if ((this.removerEspacos(ddd) == "") && (this.scsDddObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ddd"]+" \n";
}
if ((this.removerEspacos(nome) == "") && (this.scsNomeObrigatorio) == 1){
erro += "- "+this.CamposTraducao["nome"]+" \n";
}
if (this.removerEspacos(numero) == ""){
erro += "- "+this.CamposTraducao["numero"]+" \n";
}
if ((this.removerEspacos(ramal) == "") && (this.scsRamalObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ramal"]+" \n";
}
if ((this.removerEspacos(departamento) == "") && (this.scsDepartamentoObrigatorio) == 1){
erro += "- "+this.CamposTraducao["departamento"]+" \n";
}
if ((this.removerEspacos(email) == "") && (this.scsEmailObrigatorio) == 1){
erro += "- "+this.CamposTraducao["email"]+" \n";
}
if ((this.removerEspacos(obs) == "") && (this.scsObsObrigatorio) == 1){
erro += "- "+this.CamposTraducao["observacoes"]+" \n";
}
if (erro != ""){
zenPage.alertaShift(this.MensagensErro["camposObrigatorios"]+"\n"+erro);
return 1;
}
if (this.Atualizar){
this.atualizaContatoCliente();
return 1;
}
if (this.strNumero == ""){
this.strTipo = tipo;
this.strDdd = ddd;
this.strDdi = ddi;
this.strNome = nome;
this.strNumero = numero;
this.strRamal = ramal;
this.strDepartamento = departamento;
this.strEmail = email;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strNome = this.strNome + this.delimitadorMV + nome;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strRamal = this.strRamal + this.delimitadorMV + ramal;
this.strDepartamento = this.strDepartamento + this.delimitadorMV + departamento;
this.strEmail = this.strEmail + this.delimitadorMV + email;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
this.TotalPosicao = this.strNumero.split(this.delimitadorMV).length;
this.limpaCamposCliente();
return 1;
}

self.s00_componente_interface_scsCompositeContato4_alterarCorLinha = function(posLinha) {
var componente = zenPage.getComponent(this.index)
var qtdLinha = componente.TotalPosicao
var linha = 1
while(linha<=qtdLinha){
var aux = "linhaContato"+linha
var obj = document.getElementById(aux)
if ((linha%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (linha == posLinha){
obj.style.background = "#fbe091";
}else{
obj.style.background = zebra;
}
linha = linha + 1
}
}

self.s00_componente_interface_scsCompositeContato4_atualizaBotoesPadraoCliente = function(pAcao) {
if (pAcao==1){
this.getChildById("btNovo").setHidden(true);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Adicionar contato");
this.Atualizar = 0;
btAcao.setProperty("onclick","zenThis.composite.adicionaContatoCliente(); zenThis.composite.atualizaGridHtmlCliente()");
btAcao.setProperty("enclosingClass","botao_i_add");
}else if (pAcao==2){
this.getChildById("btNovo").setHidden(false);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Atualizar contato");
this.Atualizar = 1;
btAcao.setProperty("onclick","zenThis.composite.adicionaContatoCliente(); zenThis.composite.atualizaGridHtmlCliente()");
btAcao.setProperty("enclosingClass","botao_i_refresh_red");
}
if (this.scsTodosSomenteLeitura){
this.getChildById("btNovo").setHidden(true);
this.getChildById("btAcao").setHidden(true);
}
return 1;
}

self.s00_componente_interface_scsCompositeContato4_atualizaContatoCliente = function() {
var tipo = this.getChildById("contatoTipo").getProperty("value");
var ddi = this.getChildById("contatoDdi").getProperty("value");
var ddd = this.getChildById("contatoDdd").getProperty("value");
var nome = this.getChildById("contatoNome").getProperty("value");
var numero = this.getChildById("contatoNumero").getProperty("value");
var ramal = this.getChildById("contatoRamal").getProperty("value");
var departamento = this.getChildById("contatoDepartamento").getProperty("value");
var email = this.getChildById("contatoEmail").getProperty("value");
var obs = this.getChildById("contatoObs").getProperty("value");
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
var posicao = this.PosicaoAtual - 1;
tipoList.splice(posicao,1,tipo);
ddiList.splice(posicao,1,ddi);
dddList.splice(posicao,1,ddd);
nomeList.splice(posicao,1,nome);
numeroList.splice(posicao,1,numero);
ramalList.splice(posicao,1,ramal);
departamentoList.splice(posicao,1,departamento);
emailList.splice(posicao,1,email);
obsList.splice(posicao,1,obs);
this.strTipo = tipoList.join(this.delimitadorMV);
this.strDdi = ddiList.join(this.delimitadorMV);
this.strDdd = dddList.join(this.delimitadorMV);
this.strNome = nomeList.join(this.delimitadorMV);
this.strNumero = numeroList.join(this.delimitadorMV);
this.strRamal = ramalList.join(this.delimitadorMV);
this.strDepartamento = departamentoList.join(this.delimitadorMV);
this.strEmail = emailList.join(this.delimitadorMV);
this.strObs = obsList.join(this.delimitadorMV);
this.atualizaBotoesPadraoCliente(1);
this.limpaCamposCliente();
return 1;
}

self.s00_componente_interface_scsCompositeContato4_atualizaGridHtmlCliente = function() {
var objGrid = this.getChildById("contatoGrid");
objGrid.setProperty("content",this.desenhaGridHtmlCliente());
return 1;
}

self.s00_componente_interface_scsCompositeContato4_consultaContatoCliente = function(pPosicao) {
this.PosicaoAtual = pPosicao;
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
this.getChildById("contatoTipo").setProperty("value",tipoList[(pPosicao-1)]);
this.getChildById("contatoDdi").setProperty("value",ddiList[(pPosicao-1)]);
this.getChildById("contatoDdd").setProperty("value",dddList[(pPosicao-1)]);
this.getChildById("contatoNome").setProperty("value",nomeList[(pPosicao-1)]);
this.getChildById("contatoNumero").setProperty("value",numeroList[(pPosicao-1)]);
this.getChildById("contatoRamal").setProperty("value",ramalList[(pPosicao-1)]);
this.getChildById("contatoDepartamento").setProperty("value",departamentoList[(pPosicao-1)]);
this.getChildById("contatoEmail").setProperty("value",emailList[(pPosicao-1)]);
this.getChildById("contatoObs").setProperty("value",obsList[(pPosicao-1)]);
var retorno = this.atualizaBotoesPadraoCliente(2);
return 1;
}

self.s00_componente_interface_scsCompositeContato4_consultarContato = function() {
var tipo = zenPage.getComponentById("formularioCadastro.ContatoTipo").getValue();
var ddi = zenPage.getComponentById("formularioCadastro.ContatoDdi").getValue();
var ddd = zenPage.getComponentById("formularioCadastro.ContatoDdd").getValue();
var nome = zenPage.getComponentById("formularioCadastro.ContatoNome").getValue();
var numero = zenPage.getComponentById("formularioCadastro.ContatoNumero").getValue();
var ramal = zenPage.getComponentById("formularioCadastro.ContatoRamal").getValue();
var departamento = zenPage.getComponentById("formularioCadastro.ContatoDepartamento").getValue();
var email = zenPage.getComponentById("formularioCadastro.ContatoEmail").getValue();
var obs = zenPage.getComponentById("formularioCadastro.ContatoObservacao").getValue();
var componente = zenPage.getComponent(this.index);
componente.strTipo = tipo;
componente.strDdi = ddd;
componente.strDdd = ddd;
componente.strNome = nome;
componente.strNumero = numero;
componente.strRamal = ramal;
componente.strDepartamento = departamento;
componente.strEmail = email;
componente.strObs = obs;
componente.atualizaGridHtmlCliente();
}

self.s00_componente_interface_scsCompositeContato4_desenhaGridHtmlCliente = function() {
var strGridHtml = "";
var numeroList = this.strNumero.split(this.delimitadorMV);
this.TotalPosicao = numeroList.length;
if (this.TipoComponente == "scsCompositeContato2"){
strGridHtml += "<table cellpadding='0' class='scsCompositeContato2' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}else if (this.TipoComponente == "scsCompositeContato3"){
strGridHtml += "<table cellpadding='0' class='scsCompositeContato3' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}else if (this.TipoComponente == "scsCompositeContato4"){
strGridHtml += "<table cellpadding='0' style='width:100%;' class='scsCompositeContato4' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}
if (this.strNumero != ""){
var tipoList = this.strTipo.split("@VM");
var dddList = this.strDdd.split("@VM");
var nomeList = this.strNome.split("@VM");
var ramalList = this.strRamal.split("@VM");
var departamentoList = this.strDepartamento.split("@VM");
var emailList = this.strEmail.split("@VM");
var qtdMV = this.TotalPosicao;
for (i=0;i<qtdMV;i++){
var tipoContato = parseInt(tipoList[i]);
switch (tipoContato){
case 1:
tipoContato = "Residencial";
break;
case 2:
tipoContato = "Comercial";
break;
case 3:
tipoContato = "Celular";
break;
case 4:
tipoContato = "Fax";
break;
case 5:
tipoContato = "Outros";
break;
}
var ddd = dddList[i];
var nome = nomeList[i];
var numero = numeroList[i];
var ramal = ramalList[i];
var departamento = departamentoList[i];
var email = emailList[i];
var telefone = "("+ddd+") "+numero;
if (nome == "") nome = "&#160;";
if (ramal == "") ramal = "&#160;";
if (departamento == "") departamento = "&#160;";
if (email == "") email = "&#160;";
if (((i+1)%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (this.TipoComponente == "scsCompositeContato2"){
strGridHtml +=
"<tr style='cursor:pointer;' id='linhaContato"+(i+1)+"' bgcolor='"+zebra+"'>"+
"<td width='83px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoContato+"</td>"+
"<td width='212px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='111px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>"+
"<td width='73px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+ramal+"</td>"+
"<td width='88px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+departamento+"</td>"+
"<td width='188px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+email+"</td>"
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='30' align='rigth' style='border-right:0;vertical-align: middle;' noWrap='nowrap'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='30' align='center' style='border-right:0;vertical-align: middle;' noWrap='nowrap'><img alt='Excluir' style='cursor:pointer;' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}else if (this.TipoComponente == "scsCompositeContato3"){
strGridHtml +=
"<tr id='linhaContato"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='179' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='121' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='26' align='rigth' style='vertical-align: middle;border-right:0;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='26' align='center' style='vertical-align: middle;border-right:0;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}else if (this.TipoComponente == "scsCompositeContato4"){
strGridHtml +=
"<tr id='linhaContato"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='179' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='121' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='26' align='rigth' style='vertical-align: middle;border-right:0;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='26' align='center' style='vertical-align: middle;border-right:0;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}
}
}
strGridHtml += "</table>";
return strGridHtml;
}

self.s00_componente_interface_scsCompositeContato4_excluirContatoCliente = function(pPosicao) {
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
tipoList.splice((pPosicao-1),1);
ddiList.splice((pPosicao-1),1);
dddList.splice((pPosicao-1),1);
nomeList.splice((pPosicao-1),1);
numeroList.splice((pPosicao-1),1);
ramalList.splice((pPosicao-1),1);
departamentoList.splice((pPosicao-1),1);
emailList.splice((pPosicao-1),1);
obsList.splice((pPosicao-1),1);
this.strTipo = tipoList.join(this.delimitadorMV);
this.strDdi = ddiList.join(this.delimitadorMV);
this.strDdd = dddList.join(this.delimitadorMV);
this.strNome = nomeList.join(this.delimitadorMV);
this.strNumero = numeroList.join(this.delimitadorMV);
this.strRamal = ramalList.join(this.delimitadorMV);
this.strDepartamento = departamentoList.join(this.delimitadorMV);
this.strEmail = emailList.join(this.delimitadorMV);
this.strObs = obsList.join(this.delimitadorMV);
this.TotalPosicao = this.TotalPosicao - 1;
this.PosicaoAtual = 0;
var retorno = this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1)
return 1;
}

self.s00_componente_interface_scsCompositeContato4_limpaCamposCliente = function() {
this.getChildById("contatoTipo").setProperty("value","");
this.getChildById("contatoDdi").setProperty("value","");
this.getChildById("contatoDdd").setProperty("value","");
this.getChildById("contatoNome").setProperty("value","");
this.getChildById("contatoNumero").setProperty("value","");
this.getChildById("contatoRamal").setProperty("value","");
this.getChildById("contatoDepartamento").setProperty("value","");
this.getChildById("contatoEmail").setProperty("value","");
this.getChildById("contatoObs").setProperty("value","");
return 1;
}

self.s00_componente_interface_scsCompositeContato4_limpaComponenteCliente = function() {
this.limpaCamposCliente();
if (this.strNumero == "")
return 1
this.strTipo = "";
this.strDdd = "";
this.strDdi = "";
this.strNome = "";
this.strNumero = "";
this.strRamal = "";
this.strDepartamento = "";
this.strEmail = "";
this.strObs = "";
var retorno = this.atualizaBotoesPadraoCliente(1);
var retorno = this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente_interface_scsCompositeContato4_novo = function() {
this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1);
this.alterarCorLinha(0);
return 1;
}

self.s00_componente_interface_scsCompositeContato4_refreshHTML = function() {
var retorno = zenPage.atualizaGridHtmlCliente();
}

self.s00_componente_interface_scsCompositeContato4_removerEspacos = function(pString) {
return pString.replace(/\s/g,"");
}

self.s00_componente_interface_scsCompositeContato4_AdicionaContato = function(atualiza) {
	return zenInstanceMethod(this,'AdicionaContato','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato4_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato4_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato4_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato4_AtualizaContato = function() {
	return zenInstanceMethod(this,'AtualizaContato','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato4_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato4_ConsultaContato = function(posicao) {
	return zenInstanceMethod(this,'ConsultaContato','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato4_DesenhaGridHtml = function() {
	return zenInstanceMethod(this,'DesenhaGridHtml','','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato4_ExcluirContato = function(posicao) {
	return zenInstanceMethod(this,'ExcluirContato','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato4_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato4_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato4_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato4_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato4_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato4_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato4_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato4_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato4_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato4_LimpaCampos = function() {
	return zenInstanceMethod(this,'LimpaCampos','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato4_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato4_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeContato4_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeContato4_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato4_TodosSomenteLeitura = function(acao) {
	return zenInstanceMethod(this,'TodosSomenteLeitura','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeContato4_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeContato4__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeContato4.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeContato4.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeContato4;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeContato4';
	p._type = 'scsCompositeContato4';
	p.serialize = s00_componente_interface_scsCompositeContato4_serialize;
	p.getSettings = s00_componente_interface_scsCompositeContato4_getSettings;
	p.AdicionaContato = s00_componente_interface_scsCompositeContato4_AdicionaContato;
	p.AjustaTamanhoValor = s00_componente_interface_scsCompositeContato4_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente_interface_scsCompositeContato4_ApresentaExcecao;
	p.AtualizaBotoesPadrao = s00_componente_interface_scsCompositeContato4_AtualizaBotoesPadrao;
	p.AtualizaContato = s00_componente_interface_scsCompositeContato4_AtualizaContato;
	p.AtualizaGridHtml = s00_componente_interface_scsCompositeContato4_AtualizaGridHtml;
	p.ConsultaContato = s00_componente_interface_scsCompositeContato4_ConsultaContato;
	p.DesenhaGridHtml = s00_componente_interface_scsCompositeContato4_DesenhaGridHtml;
	p.ExcluirContato = s00_componente_interface_scsCompositeContato4_ExcluirContato;
	p.GeraCheckBoxHtml = s00_componente_interface_scsCompositeContato4_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente_interface_scsCompositeContato4_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente_interface_scsCompositeContato4_GeraRadioHtml;
	p.GeraSV1Label = s00_componente_interface_scsCompositeContato4_GeraSV1Label;
	p.GeraSV1Text = s00_componente_interface_scsCompositeContato4_GeraSV1Text;
	p.GeraSelectHtml = s00_componente_interface_scsCompositeContato4_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente_interface_scsCompositeContato4_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente_interface_scsCompositeContato4_GeraTextHtml;
	p.GetValorPropriedade = s00_componente_interface_scsCompositeContato4_GetValorPropriedade;
	p.LimpaCampos = s00_componente_interface_scsCompositeContato4_LimpaCampos;
	p.LimpaComponente = s00_componente_interface_scsCompositeContato4_LimpaComponente;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeContato4_ReallyRefreshContents;
	p.RecuperarContato = s00_componente_interface_scsCompositeContato4_RecuperarContato;
	p.RetornaValorCampo = s00_componente_interface_scsCompositeContato4_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente_interface_scsCompositeContato4_SetValorPropriedade;
	p.TodosSomenteLeitura = s00_componente_interface_scsCompositeContato4_TodosSomenteLeitura;
	p.VerificaErro = s00_componente_interface_scsCompositeContato4_VerificaErro;
	p.adicionaContatoCliente = s00_componente_interface_scsCompositeContato4_adicionaContatoCliente;
	p.alterarCorLinha = s00_componente_interface_scsCompositeContato4_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente_interface_scsCompositeContato4_atualizaBotoesPadraoCliente;
	p.atualizaContatoCliente = s00_componente_interface_scsCompositeContato4_atualizaContatoCliente;
	p.atualizaGridHtmlCliente = s00_componente_interface_scsCompositeContato4_atualizaGridHtmlCliente;
	p.consultaContatoCliente = s00_componente_interface_scsCompositeContato4_consultaContatoCliente;
	p.consultarContato = s00_componente_interface_scsCompositeContato4_consultarContato;
	p.desenhaGridHtmlCliente = s00_componente_interface_scsCompositeContato4_desenhaGridHtmlCliente;
	p.excluirContatoCliente = s00_componente_interface_scsCompositeContato4_excluirContatoCliente;
	p.limpaCamposCliente = s00_componente_interface_scsCompositeContato4_limpaCamposCliente;
	p.limpaComponenteCliente = s00_componente_interface_scsCompositeContato4_limpaComponenteCliente;
	p.novo = s00_componente_interface_scsCompositeContato4_novo;
	p.refreshHTML = s00_componente_interface_scsCompositeContato4_refreshHTML;
	p.removerEspacos = s00_componente_interface_scsCompositeContato4_removerEspacos;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeEndereco'] = 's00_componente_interface_scsCompositeEndereco';
self.s00_componente_interface_scsCompositeEndereco = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeEndereco__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeEndereco__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.Atualizar = false;
	o.BairroDescricao = '';
	o.BairroId = '';
	o.CEPObrigatorio = false;
	o.Cep = '';
	o.CidadeDescricao = '';
	o.CidadeId = '';
	o.Complemento = '';
	o.Estado = '';
	o.EstadoAux = '';
	o.ListaLink = new Object();
	o.Logradouro = '';
	o.MensagemErro = new Object();
	o.MostrarBarraTitulo = true;
	o.MostrarTitulo = true;
	o.MultiplosEnderecos = true;
	o.Numero = '';
	o.Pais = '';
	o.Parametros = new Object();
	o.PermiteEstrangeiro = false;
	o.PermitiCadastrarBairro = true;
	o.PosicaoAtual = '0';
	o.TipoEndereco = '';
	o.TipoLogradouro = '';
	o.TotalPosicao = '0';
	o.UsaTipoLogradouro = true;
	o.delimitador = '|';
	o.scsApresentaLabel = true;
	o.scsCampoPersistenciaNacionalidade = '';
	o.scsCamposPersistencia = 'formularioCadastro.EnderecoCep|formularioCadastro.EnderecoTipo|formularioCadastro.EnderecoPais|formularioCadastro.EnderecoEstado|formularioCadastro.EnderecoCidade|formularioCadastro.EnderecoBairro|formularioCadastro.EnderecoTipoLogradouro|formularioCadastro.EnderecoLogradouro|formularioCadastro.EnderecoNumero|formularioCadastro.EnderecoComplemento';
	o.scsCamposPersistenciaEstrangeiro = '';
	o.scsOnChangeEstrangeiro = '';
	o.scsTodosSomenteLeitura = false;
}
function s00_componente_interface_scsCompositeEndereco_serialize(set,s)
{
	var o = this;s[0]='396577539';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=(o.Atualizar?1:0);s[7]=o.BairroDescricao;s[8]=o.BairroId;s[9]=(o.CEPObrigatorio?1:0);s[10]=o.Cep;s[11]=o.CidadeDescricao;s[12]=o.CidadeId;s[13]=o.Complemento;s[14]=o.Estado;s[15]=o.EstadoAux;s[16]=set.serializeArray(o,o.ListaLink,false,'ListaLink');s[17]=o.Logradouro;s[18]=set.serializeArray(o,o.MensagemErro,false,'MensagemErro');s[19]=(o.MostrarBarraTitulo?1:0);s[20]=(o.MostrarTitulo?1:0);s[21]=(o.MultiplosEnderecos?1:0);s[22]=o.Numero;s[23]=o.Pais;s[24]=set.serializeArray(o,o.Parametros,false,'Parametros');s[25]=(o.PermiteEstrangeiro?1:0);s[26]=(o.PermitiCadastrarBairro?1:0);s[27]=o.PosicaoAtual;s[28]=o.TipoEndereco;s[29]=o.TipoLogradouro;s[30]=o.TotalPosicao;s[31]=(o.UsaTipoLogradouro?1:0);s[32]=o.align;s[33]=o.aux;s[34]=o.cellAlign;s[35]=o.cellSize;s[36]=o.cellStyle;s[37]=o.cellVAlign;s[38]=set.serializeList(o,o.children,true,'children');s[39]=(o.childrenCreated?1:0);s[40]=o.containerStyle;s[41]=o.delimitador;s[42]=(o.disabled?1:0);s[43]=(o.dragEnabled?1:0);s[44]=(o.dropEnabled?1:0);s[45]=(o.dynamic?1:0);s[46]=o.enclosingClass;s[47]=o.enclosingStyle;s[48]=o.error;s[49]=o.groupClass;s[50]=o.groupStyle;s[51]=o.height;s[52]=(o.hidden?1:0);s[53]=o.hint;s[54]=o.hintClass;s[55]=o.hintStyle;s[56]=o.label;s[57]=o.labelClass;s[58]=o.labelDisabledClass;s[59]=o.labelPosition;s[60]=o.labelStyle;s[61]=o.layout;s[62]=o.onafterdrag;s[63]=o.onbeforedrag;s[64]=o.onclick;s[65]=o.ondrag;s[66]=o.ondrop;s[67]=o.onhide;s[68]=o.onrefresh;s[69]=o.onshow;s[70]=o.onupdate;s[71]=o.overlayMode;s[72]=o.renderFlag;s[73]=(o.scsApresentaLabel?1:0);s[74]=o.scsCampoPersistenciaNacionalidade;s[75]=o.scsCamposPersistencia;s[76]=o.scsCamposPersistenciaEstrangeiro;s[77]=o.scsOnChangeEstrangeiro;s[78]=(o.scsTodosSomenteLeitura?1:0);s[79]=(o.showLabel?1:0);s[80]=o.slice;s[81]=o.title;s[82]=o.tuple;s[83]=o.valign;s[84]=(o.visible?1:0);s[85]=o.width;
}
function s00_componente_interface_scsCompositeEndereco_getSettings(s)
{
	s['name'] = 'string';
	s['Atualizar'] = 'string';
	s['BairroDescricao'] = 'string';
	s['BairroId'] = 'string';
	s['CEPObrigatorio'] = 'string';
	s['Cep'] = 'string';
	s['CidadeDescricao'] = 'string';
	s['CidadeId'] = 'string';
	s['Complemento'] = 'string';
	s['Estado'] = 'string';
	s['EstadoAux'] = 'string';
	s['ListaLink'] = 'string';
	s['Logradouro'] = 'string';
	s['MensagemErro'] = 'string';
	s['MostrarBarraTitulo'] = 'boolean';
	s['MostrarTitulo'] = 'boolean';
	s['MultiplosEnderecos'] = 'boolean';
	s['Numero'] = 'string';
	s['Pais'] = 'string';
	s['Parametros'] = 'string';
	s['PermiteEstrangeiro'] = 'boolean';
	s['PermitiCadastrarBairro'] = 'boolean';
	s['PosicaoAtual'] = 'string';
	s['TipoEndereco'] = 'string';
	s['TipoLogradouro'] = 'string';
	s['TotalPosicao'] = 'string';
	s['UsaTipoLogradouro'] = 'boolean';
	s['delimitador'] = 'string';
	s['scsApresentaLabel'] = 'string';
	s['scsCampoPersistenciaNacionalidade'] = 'string';
	s['scsCamposPersistencia'] = 'string';
	s['scsCamposPersistenciaEstrangeiro'] = 'string';
	s['scsOnChangeEstrangeiro'] = 'eventHandler';
	s['scsTodosSomenteLeitura'] = 'boolean';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_BuscarCep = function(pCep) {
return this.buscarCepCliente(pCep);
}

self.s00_componente_interface_scsCompositeEndereco_RecuperarEndereco = function() {
var componente = zenPage.getComponent(this.index);
if(!componente.MultiplosEnderecos){
var retorno = componente.incluirAlteracoes();
}
if (componente.scsCamposPersistencia != "") {
var camposPersistencia = (componente.scsCamposPersistencia).split(componente.delimitador);
zenPage.getComponentById(camposPersistencia[0]).setValue(componente.Cep);
zenPage.getComponentById(camposPersistencia[0]).onchangeHandler();
zenPage.getComponentById(camposPersistencia[1]).setValue(componente.TipoEndereco);
zenPage.getComponentById(camposPersistencia[1]).onchangeHandler();
if (zenPage.getComponentById(camposPersistencia[2]) != null){
zenPage.getComponentById(camposPersistencia[2]).setValue(componente.Pais);
zenPage.getComponentById(camposPersistencia[2]).onchangeHandler();
}
zenPage.getComponentById(camposPersistencia[3]).setValue(componente.Estado);
zenPage.getComponentById(camposPersistencia[3]).onchangeHandler();
zenPage.getComponentById(camposPersistencia[4]).setValue(componente.CidadeId);
zenPage.getComponentById(camposPersistencia[4]).onchangeHandler();
zenPage.getComponentById(camposPersistencia[5]).setValue(componente.BairroId);
zenPage.getComponentById(camposPersistencia[5]).onchangeHandler();
if (zenPage.getComponentById(camposPersistencia[6]) != null){
zenPage.getComponentById(camposPersistencia[6]).setValue(componente.TipoLogradouro);
zenPage.getComponentById(camposPersistencia[6]).onchangeHandler();
}
zenPage.getComponentById(camposPersistencia[7]).setValue(componente.Logradouro);
zenPage.getComponentById(camposPersistencia[7]).onchangeHandler();
zenPage.getComponentById(camposPersistencia[8]).setValue(componente.Numero);
zenPage.getComponentById(camposPersistencia[8]).onchangeHandler();
zenPage.getComponentById(camposPersistencia[9]).setValue(componente.Complemento);
zenPage.getComponentById(camposPersistencia[9]).onchangeHandler();
}
if (componente.scsCampoPersistenciaNacionalidade != ""){
var objCampoPersistenciaNacionalidade = zen(componente.scsCampoPersistenciaNacionalidade);
if (objCampoPersistenciaNacionalidade){
objCampoPersistenciaNacionalidade.setValue(+(componente.isEstrangeiro()));
objCampoPersistenciaNacionalidade.onchangeHandler();
}
}
if (componente.scsCamposPersistenciaEstrangeiro != ""){
var lCamposLocais = new Array();
lCamposLocais.push("txtCodigoPostalEstrangeiro");
lCamposLocais.push("txtCodigoPostal2Estrangeiro");
lCamposLocais.push("txtLogradouroEstrangeiro");
lCamposLocais.push("txtLogradouro2Estrangeiro");
lCamposLocais.push("txtCidadeEstrageiro");
lCamposLocais.push("txtEstadoEstrangeiro");
lCamposLocais.push("dtcPaisEstrangeiro");
lCamposLocais.push("txtNumeroEstrangeiro");
var lCamposPersistenciaEstrangeiro = componente.scsCamposPersistenciaEstrangeiro.split(componente.delimitador);
if (lCamposPersistenciaEstrangeiro.length == lCamposLocais.length){
for (var i=0, len=lCamposLocais.length; i < len; i++){
var objCampoLocal   = componente.getChildById(lCamposLocais[i]);
var objPersistencia = zen(lCamposPersistenciaEstrangeiro[i]);
if ((objCampoLocal) && (objPersistencia)) { // Verifica se ambos os componentes foram encontrados
objPersistencia.setValue(objCampoLocal.getValue());
objPersistencia.onchangeHandler();
}
}
}
}
}

self.s00_componente_interface_scsCompositeEndereco_alterarCampo = function(pCampo,pValor) {
if(this.Parametros[pCampo] != pValor){
this.Parametros[pCampo] = pValor
var campoAtual = this.getChildById(pCampo);
var camposLimpar = ""
var campoFoco 	 = ""
if(pCampo == "estado"){
camposLimpar = new Array("cidade","bairro","logradouro");
campoFoco = "cidade"
}else if(pCampo == "cidade"){
var dados = zenThis.composite.RetornarInformacoes("cidade",pValor);
this.getChildById("pais").setValue(dados["pais"]);
this.getChildById("estado").setValue(dados["estado"]);
campoAtual.setValue(campoAtual.getAuxValue());
camposLimpar = new Array("bairro","logradouro");
campoFoco = "logradouro"
}else if(pCampo == "bairro"){
campoAtual.setValue(campoAtual.getAuxValue());
camposLimpar = new Array("logradouro");
campoFoco = "logradouro";
}else if(pCampo == "logradouro"){
var dados = zenThis.composite.RetornarInformacoes("logradouro",pValor);
var bairro  = this.getChildById("bairro");
var cep	    = this.getChildById("cep");
var tipoEnd = this.getChildById("tipoEndereco");
campoAtual.setValue(campoAtual.getAuxValue());
cep.setValue(dados["cep"]);
bairro.setValue(dados["bairroDescricao"]);
this.Parametros["bairro"] = dados["bairroId"]
if(tipoEnd.getValue() == ""){
tipoEnd.focus();
}
}else if(pCampo == "pais"){
this.getChildById('paramEstadoPais').setProperty('value',campoAtual.getValue());
this.Parametros["paisId"] = campoAtual.getValue();
}
zenThis.composite.limparCampos(camposLimpar,campoFoco);
}
}

self.s00_componente_interface_scsCompositeEndereco_alterarCorLinha = function(posLinha) {
var comp = zenPage.getComponent(this.index);
var qtdLinha = comp.TotalPosicao;
var posAtual = comp.PosicaoAtual;
var linha = 1;
while(linha<=qtdLinha){
var aux = "linha_"+this.index+"_"+linha;
var obj = document.getElementById(aux);
if ((linha%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (linha == posLinha){
obj.style.background = "#fbe091";
}else{
obj.style.background = zebra;
}
linha = linha + 1;
}
}

self.s00_componente_interface_scsCompositeEndereco_atualizaBotoesPadraoCliente = function(pAcao) {
if (pAcao == 1){
this.getChildById("btNovo").setProperty("hidden",true);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Adicionar endereço");
this.Atualizar = 0;
btAcao.setProperty("onclick","zenThis.composite.incluirAlteracoes();");
btAcao.setProperty("enclosingClass","botao_i_add");
}else if(pAcao == 2){
this.getChildById("btNovo").setProperty("hidden",false);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Atualizar endereço");
this.Atualizar = 1;
btAcao.setProperty("onclick","zenThis.composite.incluirAlteracoes();");
btAcao.setProperty("enclosingClass","botao_i_refresh_red");
}
if (this.scsTodosSomenteLeitura){
this.getChildById("btNovo").setProperty("hidden",true);
this.getChildById("btAcao").setProperty("hidden",true);
}
return 1;
}

self.s00_componente_interface_scsCompositeEndereco_atualizaGridHtmlCliente = function() {
if(this.MultiplosEnderecos){
var objGridHtml = this.getChildById("grupoEnderecos");
objGridHtml.setProperty("content",this.desenhaGridHtmlCliente());
}
return 1;
}

self.s00_componente_interface_scsCompositeEndereco_atualizarComboBairro = function(pCidadeId,pBairroId) {
var campo = this.getChildById("bairro");
campo.clearCache();
this.Parametros["cidade"] = pCidadeId;
campo.setValue(pBairroId);
}

self.s00_componente_interface_scsCompositeEndereco_atualizarEnderecoCliente = function() {
try{
var cep 			= this.getChildById("cep").getValue();
var pais 			= this.getChildById("pais").getValue();
var estado 			= this.getChildById("estado").getValue();
var cidadeId 		= this.Parametros["cidade"]
var cidadeDescricao = this.getChildById("cidade").getValue();
var bairroId		= this.Parametros["bairro"]
var bairroDescricao = this.getChildById("bairro").getValue();
var tipoLogradouro 	= this.getChildById("tipoLogradouro").getValue();
var numero 			= this.getChildById("numero").getValue();
var complemento 	= this.getChildById("complemento").getValue();
var tipoEndereco 	= this.getChildById("tipoEndereco").getValue();
var logradouro 		= this.getChildById("logradouro").getValue();
var vm 				= "@VM";
cep = cep.replace(/-/g,"");
if (cep == "") cep = " ";
if(this.validarObrigatorios(logradouro, tipoEndereco, cep)){
var cepList 			= this.Cep.split(vm);
var tipoEnderecoList 	= this.TipoEndereco.split(vm);
var paisList 			= this.Pais.split(vm);
var estadoList 			= this.Estado.split(vm);
var cidadeIdList 		= this.CidadeId.split(vm);
var cidadeDescricaoList	= this.CidadeDescricao.split(vm);
var bairroIdList 		= this.BairroId.split(vm);
var bairroDescricaoList	= this.BairroDescricao.split(vm);
var tipoLogradouroList 	= this.TipoLogradouro.split(vm);
var logradouroList 		= this.Logradouro.split(vm);
var complementoList 	= this.Complemento.split(vm);
var numeroList 			= this.Numero.split(vm);
var posicao = this.PosicaoAtual - 1;
cepList.splice((posicao),1,cep);
tipoEnderecoList.splice((posicao),1,tipoEndereco);
paisList.splice((posicao),1,pais);
estadoList.splice((posicao),1,estado);
cidadeIdList.splice((posicao),1,cidadeId);
cidadeDescricaoList.splice((posicao),1,cidadeDescricao);
bairroIdList.splice((posicao),1,bairroId);
bairroDescricaoList.splice((posicao),1,bairroDescricao);
tipoLogradouroList.splice((posicao),1,tipoLogradouro);
logradouroList.splice((posicao),1,logradouro);
complementoList.splice((posicao),1,complemento);
numeroList.splice((posicao),1,numero);
this.TipoEndereco 	 = tipoEnderecoList.join(vm);
this.Cep 			 = cepList.join(vm);
this.Pais 			 = paisList.join(vm);
this.Estado 		 = estadoList.join(vm);
this.CidadeId 		 = cidadeIdList.join(vm);
this.CidadeDescricao = cidadeDescricaoList.join(vm);
this.BairroId 		 = bairroIdList.join(vm);
this.BairroDescricao = bairroDescricaoList.join(vm);
this.TipoLogradouro  = tipoLogradouroList.join(vm);
this.Logradouro 	 = logradouroList.join(vm);
this.Numero 		 = numeroList.join(vm);
this.Complemento 	 = complementoList.join(vm);
if(this.MultiplosEnderecos){
var retorno = this.limparCliente(1);
}
}
}catch (ex){
zenPage.alertaShift(ex.description);
}
return 1;
}

self.s00_componente_interface_scsCompositeEndereco_buscarCepCliente = function(pCep) {
try{
if (pCep == ""){
zenPage.alertaShift(this.MensagemErro["preenchaCep"])
return 0;
}
var cep = pCep.replace(/-/g,"");
var proxyRetorno = new zenProxy();
var temEndereco = this.RetornarEndereco(cep,proxyRetorno);
if(temEndereco){
var cidade 		   = this.getChildById("cidade");
var estado 		   = this.getChildById("estado");
var tipoLogradouro = this.getChildById("tipoLogradouro");
var logradouro	   = this.getChildById("logradouro");
var pais 	   	   = this.getChildById("pais");
var bairro	   	   = this.getChildById("bairro");
var tipoEndereco   = this.getChildById("tipoEndereco");
cidade.setValue(proxyRetorno.CidadeDescricao);
this.Parametros["cidade"] = proxyRetorno.CidadeId;
estado.setValue(proxyRetorno.Estado);
if (pais){
pais.setProperty("value",proxyRetorno.Pais);
}
if(proxyRetorno.CepVariosLogradouros == "1"){
this.Parametros["logradouro"] = "";
logradouro.setValue("");
this.Parametros["bairro"] = "";
bairro.setValue("");
bairro.focus();
}else{
this.Parametros["bairro"] = proxyRetorno.BairroId
bairro.setValue(proxyRetorno.BairroDescricao);
this.Parametros["logradouro"] = proxyRetorno.LogradouroDescricao
if (this.UsaTipoLogradouro){
tipoLogradouro.setValue(proxyRetorno.TipoLogradouro);
logradouro.setValue(proxyRetorno.LogradouroDescricao);
}else{
logradouro.setValue(proxyRetorno.TipoLogradouro+" "+proxyRetorno.LogradouroDescricao)
}
if(tipoEndereco.getValue() == ""){
tipoEndereco.focus();
}
}
}else{
zenPage.alertaShift(this.MensagemErro["cepNaoEncontrado"]);
}
return 1;
}catch (ex){
return 0;
this.limparCliente(1);
zenPage.alertaShift(this.MensagemErro["erroBuscarCep"]+"\n"+ex.description);
}
}

self.s00_componente_interface_scsCompositeEndereco_cadastrarBairro = function(multiplosEnderecos) {
var nomeJanela 	= "cadBairro";
var largura 	= 800;
var altura 		= 240;
if (multiplosEnderecos){
var estado = this.getChildById("estado").getValue();
var cidadeId = this.Parametros["cidade"];
}else{
var estado = zenPage.getComponentById("formularioCadastro.EnderecoEstado").getValue();
var cidadeId = zenPage.getComponentById("formularioCadastro.EnderecoCidade").getValue();
}
zenLaunchPopupWindow(
this.ListaLink["cadBairro"] + "&cidade=" +cidadeId+ "&estado=" + estado,
nomeJanela,
"status,scrollbars,resizable,width=" + largura + ",height=" + altura + "");
}

self.s00_componente_interface_scsCompositeEndereco_cadastrarCidade = function() {
var nomeJanela 	= "cadLocalidade";
var largura 	= 800;
var altura 		= 240;
zenLaunchPopupWindow(
this.ListaLink["cadLocalidade"],
nomeJanela,
"status,scrollbars,resizable,width=" + largura + ",height=" + altura + "");
}

self.s00_componente_interface_scsCompositeEndereco_cadastrarEstado = function() {
try{
var largura = 800;
var altura = 240;
zenLaunchPopupWindow(
this.ListaLink["cadEstado"],
"cadastroEstado",
"status,scrollbars,resizable,width=" + largura + ",height=" + altura + "");
}catch (ex){
zenPage.alertaShift(ex.description);
}
}

self.s00_componente_interface_scsCompositeEndereco_cadastrarLogradouro = function() {
var nomeJanela 	= "cadLogradouro";
var largura  	= 800;
var altura 	 	= 340;
var bairro 	 	= this.Parametros["bairro"];
var cidadeId 	= this.Parametros["cidade"];
var estado 		= this.getChildById("estado").getValue();
var pais 		= this.getChildById("pais").getValue();
zenLaunchPopupWindow(
this.ListaLink["cadLogradouro"] + "&bairro=" +bairro+ "&cidade=" +cidadeId+ "&estado=" +estado+ "&pais=" +pais,
nomeJanela,
"status,scrollbars,resizable,width=" + largura + ",height=" + altura + "");
}

self.s00_componente_interface_scsCompositeEndereco_consultarEndereco = function() {
var endereco = zenPage.getComponent(this.index);
var objCampoPersistenciaNacionalidade = zen(endereco.scsCampoPersistenciaNacionalidade);
if (objCampoPersistenciaNacionalidade){
endereco.getChildById("chkEstrangeiro").setValue(objCampoPersistenciaNacionalidade.getValue());
}else{
endereco.getChildById("chkEstrangeiro").setValue(false);
}
endereco.getChildById("chkEstrangeiro").onchangeHandler();
if (endereco.scsCamposPersistencia != ""){
var camposPersistencia = (endereco.scsCamposPersistencia).split(endereco.delimitador);
var cep = zenPage.getComponentById(camposPersistencia[0]).getValue();
var tipoEndereco = zenPage.getComponentById(camposPersistencia[1]).getValue();
if (zenPage.getComponentById(camposPersistencia[2]) != null){
var pais = zenPage.getComponentById(camposPersistencia[2]).getValue();
}else{
var pais = "";
}
var estado	 = zenPage.getComponentById(camposPersistencia[3]).getValue();
var cidadeId = zenPage.getComponentById(camposPersistencia[4]).getValue();
var bairro 	 = zenPage.getComponentById(camposPersistencia[5]).getValue();
if (zenPage.getComponentById(camposPersistencia[6])){
var tipoLogradouro = zenPage.getComponentById(camposPersistencia[6]).getValue();
}else{
var tipoLogradouro = "";
}
var logradouro 	= zenPage.getComponentById(camposPersistencia[7]).getValue();
var numero 		= zenPage.getComponentById(camposPersistencia[8]).getValue();
var complemento = zenPage.getComponentById(camposPersistencia[9]).getValue();
endereco.Cep 			 = cep;
endereco.TipoEndereco 	 = tipoEndereco;
endereco.Pais 			 = pais;
endereco.Estado 		 = estado
endereco.TotalPosicao 	 = cep!=""?cep.split("@VM").length:0
proxyDescricoes 		 = endereco.BuscarDescricaoCampos(cidadeId,bairro);
endereco.CidadeId 		 = cidadeId;
endereco.CidadeDescricao = proxyDescricoes.Cidades
endereco.BairroId 		 = bairro;
endereco.BairroDescricao = proxyDescricoes.Bairros;
endereco.TipoLogradouro  = tipoLogradouro;
endereco.Logradouro 	 = logradouro;
endereco.Numero 		 = numero;
endereco.Complemento 	 = complemento;
if(!endereco.MultiplosEnderecos){
endereco.proximoEnderecoCliente(1);
}
var retorno = endereco.atualizaGridHtmlCliente();
}
if (endereco.scsCamposPersistenciaEstrangeiro != ""){
var lCamposLocais = new Array();
lCamposLocais.push("txtCodigoPostalEstrangeiro");
lCamposLocais.push("txtCodigoPostal2Estrangeiro");
lCamposLocais.push("txtLogradouroEstrangeiro");
lCamposLocais.push("txtLogradouro2Estrangeiro");
lCamposLocais.push("txtCidadeEstrageiro");
lCamposLocais.push("txtEstadoEstrangeiro");
lCamposLocais.push("dtcPaisEstrangeiro");
lCamposLocais.push("txtNumeroEstrangeiro");
var lCamposPersistenciaEstrangeiro = endereco.scsCamposPersistenciaEstrangeiro.split(endereco.delimitador);
if (lCamposPersistenciaEstrangeiro.length == lCamposLocais.length){
for (var i=0, len=lCamposLocais.length; i < len; i++){
var objCampoLocal   = endereco.getChildById(lCamposLocais[i]);
var objPersistencia = zen(lCamposPersistenciaEstrangeiro[i]);
if ((objCampoLocal) && (objPersistencia)) { // Verifica se ambos os componentes foram encontrados
objCampoLocal.setValue(objPersistencia.getValue());
}
}
}
}
}

self.s00_componente_interface_scsCompositeEndereco_desenhaGridHtmlCliente = function() {
var strGridHtml = "";
var vm = "@VM";
strGridHtml += "<table cellpadding='0' class='scsCompositeEndereco' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
if (this.Cep != ""){
var cepList 			= this.Cep.split(vm);
var tipoEnderecoList 	= this.TipoEndereco.split(vm);
var tipoLogradouroList 	= this.TipoLogradouro.split(vm);
var logradouroList		= this.Logradouro.split(vm);
var cidadeList 			= this.CidadeDescricao.split(vm);
var complementoList 	= this.Complemento.split(vm);
var numeroList 			= this.Numero.split(vm);
var qtd = cepList.length;
for (i=0;i<qtd;i++){
var tipoEndereco = parseInt(tipoEnderecoList[i]);
switch(tipoEndereco){
case 1:
tipoEndereco = "Residencial";
break;
case 2:
tipoEndereco = "Comercial";
break;
case 3:
tipoEndereco = "Cobrança";
break;
case 4:
tipoEndereco = "Fiscal";
break;
}
var cep = cepList[i];
if (cep != ""){
var tipoLogradouro = tipoLogradouroList[i];
var logradouro 	   = logradouroList[i];
var cidade 		   = cidadeList[i];
var complemento    = complementoList[i];
var numero 		   = numeroList[i];
if(this.UsaTipoLogradouro){
if ((tipoLogradouro != "") && (tipoLogradouro != undefined)){
logradouro = tipoLogradouro + " " + logradouro;
}
}
if((numero != "") && (complemento != "")){
logradouro = logradouro + ", " + numero + " - " + complemento;
}else if (numero != ""){
logradouro = logradouro + ", " + numero;
}else if (complemento != ""){
logradouro = logradouro + " - " + complemento;
}
if (cep == " ") cep = "&#160;";
if (cidade == "") cidade = "&#160;";
if (tipoLogradouro == "") tipoLogradouro = "&#160;";
if (logradouro == "") logradouro = "&#160;";
if (((i+1)%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
strGridHtml +=
"<tr bgcolor='" + zebra + "' id='linha_"+this.index+"_"+(i+1)+"' onclick='zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")' style='cursor:hand;'>"+
"<td width='115' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").proximoEnderecoCliente("+(i+1)+");'>"+tipoEndereco+"</td>"+
"<td width='110' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").proximoEnderecoCliente("+(i+1)+");'>"+cep+"</td>"+
"<td width='281' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").proximoEnderecoCliente("+(i+1)+");'>"+cidade+"</td>"+
"<td width='274' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").proximoEnderecoCliente("+(i+1)+");'>"+logradouro+"</td>";
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td align='center' style='vertical-align: middle;border-right:0px'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td align='center' style='vertical-align: middle;border-right:0px'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirEnderecoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"
"</tr>";
}
}
}
}
strGridHtml += "</table>";
return strGridHtml;
}

self.s00_componente_interface_scsCompositeEndereco_excluirEnderecoCliente = function(pPosicao) {
var vm 					= "@VM";
var cepList 			= this.Cep.split(vm);
var tipoEnderecoList 	= this.TipoEndereco.split(vm);
var paisList 			= this.Pais.split(vm);
var estadoList 			= this.Estado.split(vm);
var cidadeIdList 		= this.CidadeId.split(vm);
var cidadeDescricaoList = this.CidadeDescricao.split(vm);
var bairroIdList		= this.BairroId.split(vm);
var bairroDescricaoList = this.BairroDescricao.split(vm);
var tipoLogradouroList 	= this.TipoLogradouro.split(vm);
var logradouroList 		= this.Logradouro.split(vm);
var complementoList 	= this.Complemento.split(vm);
var numeroList 			= this.Numero.split(vm);
cepList.splice((pPosicao-1),1);
tipoEnderecoList.splice((pPosicao-1),1);
paisList.splice((pPosicao-1),1);
estadoList.splice((pPosicao-1),1);
cidadeIdList.splice((pPosicao-1),1);
cidadeDescricaoList.splice((pPosicao-1),1);
bairroIdList.splice((pPosicao-1),1);
bairroDescricaoList.splice((pPosicao-1),1);
tipoLogradouroList.splice((pPosicao-1),1);
logradouroList.splice((pPosicao-1),1);
complementoList.splice((pPosicao-1),1);
numeroList.splice((pPosicao-1),1);
this.TipoEndereco 	 = tipoEnderecoList.join(vm);
this.Cep 			 = cepList.join(vm);
this.Pais 			 = paisList.join(vm);
this.Estado 		 = estadoList.join(vm);
this.CidadeId 		 = cidadeIdList.join(vm);
this.CidadeDescricao = cidadeDescricaoList.join(vm);
this.BairroId 		 = bairroIdList.join(vm);
this.BairroDescricao = bairroDescricaoList.join(vm);
this.TipoLogradouro  = tipoLogradouroList.join(vm);
this.Logradouro 	 = logradouroList.join(vm);
this.Complemento 	 = complementoList.join(vm);
this.Numero 		 = numeroList.join(vm);
this.TotalPosicao -= 1;
this.PosicaoAtual = 0;
this.Parametros["estado"]		= ""
this.Parametros["cidade"] 		= ""
this.Parametros["bairro"] 		= ""
this.Parametros["logradouro"] 	= ""
var retorno = this.limparCliente(1);
return 1;
}

self.s00_componente_interface_scsCompositeEndereco_incluirAlteracoes = function() {
if(this.Atualizar){
var retorno = this.atualizarEnderecoCliente();
}else{
var retorno = this.incluirEnderecoCliente();
}
this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente_interface_scsCompositeEndereco_incluirEnderecoCliente = function() {
var cep 		 	= this.getChildById("cep").getValue();
var pais 			= this.getChildById("pais").getValue();
var estado 			= this.getChildById("estado").getValue();
var cidadeId 		= this.Parametros["cidade"]
var cidadeDescricao = this.getChildById("cidade").getValue();
var bairroId		= this.Parametros["bairro"]
var bairroDescricao	= this.getChildById("bairro").getValue();
var tipoEndereco 	= this.getChildById("tipoEndereco").getValue();
var logradouro 	 	= this.getChildById("logradouro").getValue();
var tipoLogradouro 	= this.getChildById("tipoLogradouro").getValue();
var numero 			= this.getChildById("numero").getValue();
var complemento 	= this.getChildById("complemento").getValue();
var vm 				= "@VM";
cep = cep.replace(/-/g,"");
if (cep == "") cep = " ";
if(this.validarObrigatorios(logradouro, tipoEndereco, cep)){
if (this.Cep == ""){
this.Cep 			 = cep;
this.Pais 		 	 = pais;
this.Estado 		 = estado;
this.CidadeId 		 = cidadeId;
this.CidadeDescricao = cidadeDescricao;
this.BairroId 		 = bairroId;
this.BairroDescricao = bairroDescricao
this.TipoEndereco 	 = tipoEndereco;
this.TipoLogradouro  = tipoLogradouro;
this.Logradouro 	 = logradouro;
this.Numero 		 = numero;
this.Complemento 	 = complemento;
}else{
this.Cep 			 = this.Cep 		 	+ vm + cep;
this.Pais 			 = this.Pais 			+ vm + pais;
this.Estado 		 = this.Estado 			+ vm + estado;
this.CidadeId 		 = this.CidadeId 		+ vm + cidadeId;
this.CidadeDescricao = this.CidadeDescricao + vm + cidadeDescricao;
this.BairroId 		 = this.BairroId		+ vm + bairroId;
this.BairroDescricao = this.BairroDescricao + vm + bairroDescricao
this.TipoEndereco 	 = this.TipoEndereco 	+ vm + tipoEndereco;
this.TipoLogradouro  = this.TipoLogradouro 	+ vm + tipoLogradouro;
this.Logradouro 	 = this.Logradouro 		+ vm + logradouro;
this.Numero 		 = this.Numero			+ vm + numero;
this.Complemento 	 = this.Complemento 	+ vm + complemento;
}
this.TotalPosicao++;
var retorno = this.atualizaGridHtmlCliente();
if(this.MultiplosEnderecos){
var retorno = this.limparCliente(1);
}
}
return 1
}

self.s00_componente_interface_scsCompositeEndereco_isEstrangeiro = function() {
return (this.getChildById("chkEstrangeiro").getValue());
}

self.s00_componente_interface_scsCompositeEndereco_isNacional = function() {
return (!this.getChildById("chkEstrangeiro").getValue());
}

self.s00_componente_interface_scsCompositeEndereco_limpaComponenteCliente = function() {
var retorno = this.resetarCliente();
return 1;
}

self.s00_componente_interface_scsCompositeEndereco_limparCampos = function(pArrayCampos,pCampoFoco) {
if (pArrayCampos != ""){
for (i = 0; i < pArrayCampos.length; i++){
var campo = this.getChildById(pArrayCampos[i])
campo.setValue("");
}
this.getChildById(pCampoFoco).focus();
}
}

self.s00_componente_interface_scsCompositeEndereco_limparCliente = function(pMultiplosEnderecos) {
if (pMultiplosEnderecos){
this.Parametros["estado"] = ""
this.Parametros["cidade"] = ""
this.Parametros["bairro"] = ""
this.Parametros["logradouro"] = ""
this.getChildById("tipoEndereco").setProperty("value","");
this.getChildById("cep").setProperty("value","");
this.getChildById("pais").setProperty("value","");
this.getChildById("estado").setProperty("value","");
this.getChildById("cidade").setProperty("value","");
this.getChildById("bairro").setProperty("value","");
this.getChildById("tipoLogradouro").setProperty("value","");
this.getChildById("logradouro").setProperty("value","");
this.getChildById("numero").setProperty("value","");
this.getChildById("complemento").setProperty("value","");
this.PosicaoAtual = 0;
this.getChildById("cidade").focus();
this.atualizaBotoesPadraoCliente(1);
}else{
var enderecoCep 			= zenPage.getComponentById("formularioCadastro.EnderecoCep");
var enderecoTipo 			= zenPage.getComponentById("formularioCadastro.EnderecoTipo");
var enderecoPais 			= zenPage.getComponentById("formularioCadastro.EnderecoPais");
var enderecoEstado 			= zenPage.getComponentById("formularioCadastro.EnderecoEstado");
var enderecoCidade 			= zenPage.getComponentById("formularioCadastro.EnderecoCidade");
var enderecoBairro 			= zenPage.getComponentById("formularioCadastro.EnderecoBairro");
var enderecoNumero 			= zenPage.getComponentById("formularioCadastro.EnderecoNumero");
var enderecoLogradouro 		= zenPage.getComponentById("formularioCadastro.EnderecoLogradouro");
var enderecoComplemento		= zenPage.getComponentById("formularioCadastro.EnderecoComplemento");
var enderecoTipoLogradouro 	= zenPage.getComponentById("formularioCadastro.EnderecoTipoLogradouro");
if (enderecoCep != undefined) enderecoCep.setProperty("value","");
if (enderecoTipo != undefined) enderecoTipo.setProperty("value","");
if (enderecoPais != undefined) enderecoPais.setProperty("value","");
if (enderecoEstado != undefined) enderecoEstado.setProperty("value","");
if (enderecoCidade != undefined) enderecoCidade.setProperty("value","");
if (enderecoBairro != undefined) enderecoBairro.setProperty("value","");
if (enderecoNumero != undefined) enderecoNumero.setProperty("value","");
if (enderecoLogradouro != undefined) enderecoLogradouro.setProperty("value","");
if (enderecoComplemento != undefined) enderecoComplemento.setProperty("value","");
if (enderecoTipoLogradouro != undefined) enderecoTipoLogradouro.setProperty("value","");
}
return 1;
}

self.s00_componente_interface_scsCompositeEndereco_pesquisarBuscaCep = function(multiplosEnderecos) {
var vm = String.fromCharCode(253);
var nomeJanela = "buscaCEP"+ vm +"page"+ vm +"naoutilizado"+ vm +"formularioCadastro_EnderecoCep";
if ( multiplosEnderecos ){
var idComp = this.id;
idComp = idComp.replace(".","_");
nomeJanela = "buscaCEP"+ vm +"composite"+ vm +idComp+ vm +"cep";
}
zenLaunchPopupWindow(
's00.componente.interface.BuscaCep.cls',
nomeJanela,
'status,scrollbars,resizable,width=802,height=600');
}

self.s00_componente_interface_scsCompositeEndereco_proximoEnderecoCliente = function(pPosicao) {
this.PosicaoAtual 		= pPosicao;
var cep 				= this.Cep.split("@VM");
var tipoEndereco 		= this.TipoEndereco.split("@VM");
var pais 				= this.Pais.split("@VM");
var estado 				= this.Estado.split("@VM");
var cidadeId 			= this.CidadeId.split("@VM");
var cidadeDescricao 	= this.CidadeDescricao.split("@VM");
var bairroId			= this.BairroId.split("@VM");
var bairroDescricao		= this.BairroDescricao.split("@VM");
var tipoLogradouro 		= this.TipoLogradouro.split("@VM");
var logradouro 			= this.Logradouro.split("@VM");
var numero 				= this.Numero.split("@VM");
var complemento 		= this.Complemento.split("@VM");
this.Parametros["estado"]		= estado[(pPosicao-1)]
this.Parametros["cidade"] 		= cidadeId[(pPosicao-1)]
this.Parametros["bairro"] 		= bairroId[(pPosicao-1)]
this.Parametros["logradouro"] 	= logradouro[(pPosicao-1)]
this.getChildById("tipoEndereco").setProperty("value", tipoEndereco[(pPosicao-1)]);
this.getChildById("cep").setProperty("value", cep[(pPosicao-1)]);
this.getChildById("pais").setProperty("value", pais[(pPosicao-1)]);
this.getChildById("estado").setProperty("value", estado[(pPosicao-1)]);
this.getChildById("cidade").setProperty("value", cidadeDescricao[(pPosicao-1)]);
this.getChildById("bairro").setProperty("value", bairroDescricao[(pPosicao-1)]);
if (!this.getChildById("tipoLogradouro").getHidden()){
this.getChildById("tipoLogradouro").setProperty("value", tipoLogradouro[(pPosicao-1)]);
}
this.getChildById("logradouro").setProperty("value", logradouro[(pPosicao-1)]);
this.getChildById("numero").setProperty("value", numero[(pPosicao-1)]);
this.getChildById("complemento").setProperty("value", complemento[(pPosicao-1)]);
var retorno = this.atualizaBotoesPadraoCliente(2);
return 1;
}

self.s00_componente_interface_scsCompositeEndereco_resetarCliente = function() {
var retorno 				  = this.limparCliente(1);
this.TipoEndereco			  = "";
this.Cep 					  = "";
this.Pais 					  = "";
this.Estado 				  = "";
this.CidadeId 				  = "";
this.CidadeDescricao 		  = "";
this.BairroId 				  = "";
this.BairroDescricao		  = "";
this.TipoLogradouro 		  = "";
this.Logradouro 			  = "";
this.Numero 				  = "";
this.Complemento 			  = "";
this.Parametros["cidade"]	  = "";
this.Parametros["bairro"] 	  = "";
this.Parametros["logradouro"] = "";
this.TotalPosicao 			  = 0;
var lCamposLocais = new Array();
lCamposLocais.push("txtCodigoPostalEstrangeiro");
lCamposLocais.push("txtCodigoPostal2Estrangeiro");
lCamposLocais.push("txtLogradouroEstrangeiro");
lCamposLocais.push("txtLogradouro2Estrangeiro");
lCamposLocais.push("txtCidadeEstrageiro");
lCamposLocais.push("txtEstadoEstrangeiro");
lCamposLocais.push("dtcPaisEstrangeiro");
lCamposLocais.push("txtNumeroEstrangeiro");
this.selecionarEstrangeiro(false);
for (var i=0, len=lCamposLocais.length; i < len; i++){
var objCampoLocal = this.getChildById(lCamposLocais[i]);
objCampoLocal.setValue("");
objCampoLocal.onchangeHandler();
}
var retorno = this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente_interface_scsCompositeEndereco_selecionarEstrangeiro = function(pIsEstrangeiro) {
var retorno = true;
try{
var objChkEstrangeiro = this.getChildById("chkEstrangeiro");
if (objChkEstrangeiro.getValue() != pIsEstrangeiro){
objChkEstrangeiro.setValue(pIsEstrangeiro);
objChkEstrangeiro.onchangeHandler();
throw 0;
}
this.getChildById("btAcao").setHidden(pIsEstrangeiro);
this.getChildById("grpCamposNacional").setHidden(pIsEstrangeiro);
this.getChildById("grpListaEnderecoNacional").setHidden(pIsEstrangeiro);
this.getChildById("grpCamposEstrangeiro").setHidden(!pIsEstrangeiro);
this.getChildById("grpListaEnderecoEstrangeiro").setHidden(!pIsEstrangeiro);
var lEnderecoLbl = this.getChildById("enderecoTitulo").getProperty("aux");
if (lEnderecoLbl != ""){
lEnderecoLbl = lEnderecoLbl.split("|");
this.getChildById("enderecoTitulo").setValue((pIsEstrangeiro) ? lEnderecoLbl[1] : lEnderecoLbl[0]);
}
}catch(ex){
if (ex && ex.description) zenPage.alertaShift(ex.description);
retorno = false;
}
return retorno;
}

self.s00_componente_interface_scsCompositeEndereco_validarObrigatorios = function(pLogradouro,pTipoEndereco,pCep) {
if (this.isNacional()){
var erro = ""
if (pLogradouro == ""){
erro += " - Logradouro \n";
campoFoco = "logradouro"
}
if (pTipoEndereco == ""){
erro += " - Tipo de endereço \n";
campoFoco = "tipoEndereco"
}
if (this.CEPObrigatorio && pCep == ""){
erro += " - CEP \n";
campoFoco = "cep"
}
if (erro != ""){
zenPage.alertaShift(this.MensagemErro["camposObrigatorios"]+"\n"+erro);
this.getChildById(campoFoco).focus();
return 0;
}
}
return 1;
}

self.s00_componente_interface_scsCompositeEndereco_verificarCampoCidade = function() {
var campoCidade = this.getChildById("cidade")
if (campoCidade.getValue() == ""){
zenPage.alertaShift(this.MensagemErro["selecioneCidade"]);
campoCidade.focus();
}
}

self.s00_componente_interface_scsCompositeEndereco_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_AtualizarEndereco = function() {
	return zenInstanceMethod(this,'AtualizarEndereco','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_BuscarDescricaoCampos = function(pCidades,pBairros) {
	return zenClassMethod(this,'BuscarDescricaoCampos','L,L','HANDLE',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_DesenhaGridHtml = function() {
	return zenInstanceMethod(this,'DesenhaGridHtml','','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_ExcluirEndereco = function(posicao) {
	return zenInstanceMethod(this,'ExcluirEndereco','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_IncluirEndereco = function() {
	return zenInstanceMethod(this,'IncluirEndereco','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_Limpar = function(multiplosEnderecos) {
	return zenInstanceMethod(this,'Limpar','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_ProximoEndereco = function(posicao) {
	return zenInstanceMethod(this,'ProximoEndereco','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_Resetar = function() {
	return zenInstanceMethod(this,'Resetar','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_RetornarEndereco = function(pCep,pProxyRetorno) {
	return zenClassMethod(this,'RetornarEndereco','L,O','BOOLEAN',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_RetornarInformacoes = function(pCampo,pIdCampo) {
	return zenClassMethod(this,'RetornarInformacoes','L,L','ARRAYDT',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_TodosSomenteLeitura = function(acao) {
	return zenInstanceMethod(this,'TodosSomenteLeitura','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco_refreshHTML = function() {
	return zenInstanceMethod(this,'refreshHTML','','STATUS',arguments);
}
self.s00_componente_interface_scsCompositeEndereco__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeEndereco.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeEndereco.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeEndereco;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeEndereco';
	p._type = 'scsCompositeEndereco';
	p.serialize = s00_componente_interface_scsCompositeEndereco_serialize;
	p.getSettings = s00_componente_interface_scsCompositeEndereco_getSettings;
	p.AtualizaBotoesPadrao = s00_componente_interface_scsCompositeEndereco_AtualizaBotoesPadrao;
	p.AtualizaGridHtml = s00_componente_interface_scsCompositeEndereco_AtualizaGridHtml;
	p.AtualizarEndereco = s00_componente_interface_scsCompositeEndereco_AtualizarEndereco;
	p.BuscarCep = s00_componente_interface_scsCompositeEndereco_BuscarCep;
	p.BuscarDescricaoCampos = s00_componente_interface_scsCompositeEndereco_BuscarDescricaoCampos;
	p.DesenhaGridHtml = s00_componente_interface_scsCompositeEndereco_DesenhaGridHtml;
	p.ExcluirEndereco = s00_componente_interface_scsCompositeEndereco_ExcluirEndereco;
	p.IncluirEndereco = s00_componente_interface_scsCompositeEndereco_IncluirEndereco;
	p.LimpaComponente = s00_componente_interface_scsCompositeEndereco_LimpaComponente;
	p.Limpar = s00_componente_interface_scsCompositeEndereco_Limpar;
	p.ProximoEndereco = s00_componente_interface_scsCompositeEndereco_ProximoEndereco;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeEndereco_ReallyRefreshContents;
	p.RecuperarEndereco = s00_componente_interface_scsCompositeEndereco_RecuperarEndereco;
	p.Resetar = s00_componente_interface_scsCompositeEndereco_Resetar;
	p.RetornarEndereco = s00_componente_interface_scsCompositeEndereco_RetornarEndereco;
	p.RetornarInformacoes = s00_componente_interface_scsCompositeEndereco_RetornarInformacoes;
	p.TodosSomenteLeitura = s00_componente_interface_scsCompositeEndereco_TodosSomenteLeitura;
	p.alterarCampo = s00_componente_interface_scsCompositeEndereco_alterarCampo;
	p.alterarCorLinha = s00_componente_interface_scsCompositeEndereco_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente_interface_scsCompositeEndereco_atualizaBotoesPadraoCliente;
	p.atualizaGridHtmlCliente = s00_componente_interface_scsCompositeEndereco_atualizaGridHtmlCliente;
	p.atualizarComboBairro = s00_componente_interface_scsCompositeEndereco_atualizarComboBairro;
	p.atualizarEnderecoCliente = s00_componente_interface_scsCompositeEndereco_atualizarEnderecoCliente;
	p.buscarCepCliente = s00_componente_interface_scsCompositeEndereco_buscarCepCliente;
	p.cadastrarBairro = s00_componente_interface_scsCompositeEndereco_cadastrarBairro;
	p.cadastrarCidade = s00_componente_interface_scsCompositeEndereco_cadastrarCidade;
	p.cadastrarEstado = s00_componente_interface_scsCompositeEndereco_cadastrarEstado;
	p.cadastrarLogradouro = s00_componente_interface_scsCompositeEndereco_cadastrarLogradouro;
	p.consultarEndereco = s00_componente_interface_scsCompositeEndereco_consultarEndereco;
	p.desenhaGridHtmlCliente = s00_componente_interface_scsCompositeEndereco_desenhaGridHtmlCliente;
	p.excluirEnderecoCliente = s00_componente_interface_scsCompositeEndereco_excluirEnderecoCliente;
	p.incluirAlteracoes = s00_componente_interface_scsCompositeEndereco_incluirAlteracoes;
	p.incluirEnderecoCliente = s00_componente_interface_scsCompositeEndereco_incluirEnderecoCliente;
	p.isEstrangeiro = s00_componente_interface_scsCompositeEndereco_isEstrangeiro;
	p.isNacional = s00_componente_interface_scsCompositeEndereco_isNacional;
	p.limpaComponenteCliente = s00_componente_interface_scsCompositeEndereco_limpaComponenteCliente;
	p.limparCampos = s00_componente_interface_scsCompositeEndereco_limparCampos;
	p.limparCliente = s00_componente_interface_scsCompositeEndereco_limparCliente;
	p.pesquisarBuscaCep = s00_componente_interface_scsCompositeEndereco_pesquisarBuscaCep;
	p.proximoEnderecoCliente = s00_componente_interface_scsCompositeEndereco_proximoEnderecoCliente;
	p.refreshHTML = s00_componente_interface_scsCompositeEndereco_refreshHTML;
	p.resetarCliente = s00_componente_interface_scsCompositeEndereco_resetarCliente;
	p.selecionarEstrangeiro = s00_componente_interface_scsCompositeEndereco_selecionarEstrangeiro;
	p.validarObrigatorios = s00_componente_interface_scsCompositeEndereco_validarObrigatorios;
	p.verificarCampoCidade = s00_componente_interface_scsCompositeEndereco_verificarCampoCidade;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeEndereco3'] = 's00_componente_interface_scsCompositeEndereco3';
self.s00_componente_interface_scsCompositeEndereco3 = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeEndereco3__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeEndereco3__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.Atualizar = false;
	o.BairroDescricao = '';
	o.BairroId = '';
	o.CEPObrigatorio = false;
	o.Cep = '';
	o.CidadeDescricao = '';
	o.CidadeId = '';
	o.Complemento = '';
	o.Estado = '';
	o.EstadoAux = '';
	o.ListaLink = new Object();
	o.Logradouro = '';
	o.MensagemErro = new Object();
	o.MostrarBarraTitulo = true;
	o.MostrarTitulo = true;
	o.MultiplosEnderecos = true;
	o.Numero = '';
	o.Pais = '';
	o.Parametros = new Object();
	o.PermiteEstrangeiro = false;
	o.PermitiCadastrarBairro = true;
	o.PosicaoAtual = '0';
	o.TipoEndereco = '';
	o.TipoLogradouro = '';
	o.TotalPosicao = '0';
	o.UsaTipoLogradouro = true;
	o.delimitador = '|';
	o.scsApresentaLabel = true;
	o.scsCampoPersistenciaNacionalidade = '';
	o.scsCamposPersistencia = 'formularioCadastro.EnderecoCep|formularioCadastro.EnderecoTipo|formularioCadastro.EnderecoPais|formularioCadastro.EnderecoEstado|formularioCadastro.EnderecoCidade|formularioCadastro.EnderecoBairro|formularioCadastro.EnderecoTipoLogradouro|formularioCadastro.EnderecoLogradouro|formularioCadastro.EnderecoNumero|formularioCadastro.EnderecoComplemento';
	o.scsCamposPersistenciaEstrangeiro = '';
	o.scsOnChangeEstrangeiro = '';
	o.scsTodosSomenteLeitura = false;
}
function s00_componente_interface_scsCompositeEndereco3_serialize(set,s)
{
	var o = this;s[0]='396577539';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=(o.Atualizar?1:0);s[7]=o.BairroDescricao;s[8]=o.BairroId;s[9]=(o.CEPObrigatorio?1:0);s[10]=o.Cep;s[11]=o.CidadeDescricao;s[12]=o.CidadeId;s[13]=o.Complemento;s[14]=o.Estado;s[15]=o.EstadoAux;s[16]=set.serializeArray(o,o.ListaLink,false,'ListaLink');s[17]=o.Logradouro;s[18]=set.serializeArray(o,o.MensagemErro,false,'MensagemErro');s[19]=(o.MostrarBarraTitulo?1:0);s[20]=(o.MostrarTitulo?1:0);s[21]=(o.MultiplosEnderecos?1:0);s[22]=o.Numero;s[23]=o.Pais;s[24]=set.serializeArray(o,o.Parametros,false,'Parametros');s[25]=(o.PermiteEstrangeiro?1:0);s[26]=(o.PermitiCadastrarBairro?1:0);s[27]=o.PosicaoAtual;s[28]=o.TipoEndereco;s[29]=o.TipoLogradouro;s[30]=o.TotalPosicao;s[31]=(o.UsaTipoLogradouro?1:0);s[32]=o.align;s[33]=o.aux;s[34]=o.cellAlign;s[35]=o.cellSize;s[36]=o.cellStyle;s[37]=o.cellVAlign;s[38]=set.serializeList(o,o.children,true,'children');s[39]=(o.childrenCreated?1:0);s[40]=o.containerStyle;s[41]=o.delimitador;s[42]=(o.disabled?1:0);s[43]=(o.dragEnabled?1:0);s[44]=(o.dropEnabled?1:0);s[45]=(o.dynamic?1:0);s[46]=o.enclosingClass;s[47]=o.enclosingStyle;s[48]=o.error;s[49]=o.groupClass;s[50]=o.groupStyle;s[51]=o.height;s[52]=(o.hidden?1:0);s[53]=o.hint;s[54]=o.hintClass;s[55]=o.hintStyle;s[56]=o.label;s[57]=o.labelClass;s[58]=o.labelDisabledClass;s[59]=o.labelPosition;s[60]=o.labelStyle;s[61]=o.layout;s[62]=o.onafterdrag;s[63]=o.onbeforedrag;s[64]=o.onclick;s[65]=o.ondrag;s[66]=o.ondrop;s[67]=o.onhide;s[68]=o.onrefresh;s[69]=o.onshow;s[70]=o.onupdate;s[71]=o.overlayMode;s[72]=o.renderFlag;s[73]=(o.scsApresentaLabel?1:0);s[74]=o.scsCampoPersistenciaNacionalidade;s[75]=o.scsCamposPersistencia;s[76]=o.scsCamposPersistenciaEstrangeiro;s[77]=o.scsOnChangeEstrangeiro;s[78]=(o.scsTodosSomenteLeitura?1:0);s[79]=(o.showLabel?1:0);s[80]=o.slice;s[81]=o.title;s[82]=o.tuple;s[83]=o.valign;s[84]=(o.visible?1:0);s[85]=o.width;
}
function s00_componente_interface_scsCompositeEndereco3_getSettings(s)
{
	s['name'] = 'string';
	s['Atualizar'] = 'string';
	s['BairroDescricao'] = 'string';
	s['BairroId'] = 'string';
	s['CEPObrigatorio'] = 'string';
	s['Cep'] = 'string';
	s['CidadeDescricao'] = 'string';
	s['CidadeId'] = 'string';
	s['Complemento'] = 'string';
	s['Estado'] = 'string';
	s['EstadoAux'] = 'string';
	s['ListaLink'] = 'string';
	s['Logradouro'] = 'string';
	s['MensagemErro'] = 'string';
	s['MostrarBarraTitulo'] = 'boolean';
	s['MostrarTitulo'] = 'boolean';
	s['MultiplosEnderecos'] = 'boolean';
	s['Numero'] = 'string';
	s['Pais'] = 'string';
	s['Parametros'] = 'string';
	s['PermiteEstrangeiro'] = 'boolean';
	s['PermitiCadastrarBairro'] = 'boolean';
	s['PosicaoAtual'] = 'string';
	s['TipoEndereco'] = 'string';
	s['TipoLogradouro'] = 'string';
	s['TotalPosicao'] = 'string';
	s['UsaTipoLogradouro'] = 'boolean';
	s['delimitador'] = 'string';
	s['scsApresentaLabel'] = 'string';
	s['scsCampoPersistenciaNacionalidade'] = 'string';
	s['scsCamposPersistencia'] = 'string';
	s['scsCamposPersistenciaEstrangeiro'] = 'string';
	s['scsOnChangeEstrangeiro'] = 'eventHandler';
	s['scsTodosSomenteLeitura'] = 'boolean';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_BuscarCep = function(pCep) {
return this.buscarCepCliente(pCep);
}

self.s00_componente_interface_scsCompositeEndereco3_RecuperarEndereco = function() {
var componente = zenPage.getComponent(this.index);
if(!componente.MultiplosEnderecos){
var retorno = componente.incluirAlteracoes();
}
if (componente.scsCamposPersistencia != "") {
var camposPersistencia = (componente.scsCamposPersistencia).split(componente.delimitador);
zenPage.getComponentById(camposPersistencia[0]).setValue(componente.Cep);
zenPage.getComponentById(camposPersistencia[0]).onchangeHandler();
zenPage.getComponentById(camposPersistencia[1]).setValue(componente.TipoEndereco);
zenPage.getComponentById(camposPersistencia[1]).onchangeHandler();
if (zenPage.getComponentById(camposPersistencia[2]) != null){
zenPage.getComponentById(camposPersistencia[2]).setValue(componente.Pais);
zenPage.getComponentById(camposPersistencia[2]).onchangeHandler();
}
zenPage.getComponentById(camposPersistencia[3]).setValue(componente.Estado);
zenPage.getComponentById(camposPersistencia[3]).onchangeHandler();
zenPage.getComponentById(camposPersistencia[4]).setValue(componente.CidadeId);
zenPage.getComponentById(camposPersistencia[4]).onchangeHandler();
zenPage.getComponentById(camposPersistencia[5]).setValue(componente.BairroId);
zenPage.getComponentById(camposPersistencia[5]).onchangeHandler();
if (zenPage.getComponentById(camposPersistencia[6]) != null){
zenPage.getComponentById(camposPersistencia[6]).setValue(componente.TipoLogradouro);
zenPage.getComponentById(camposPersistencia[6]).onchangeHandler();
}
zenPage.getComponentById(camposPersistencia[7]).setValue(componente.Logradouro);
zenPage.getComponentById(camposPersistencia[7]).onchangeHandler();
zenPage.getComponentById(camposPersistencia[8]).setValue(componente.Numero);
zenPage.getComponentById(camposPersistencia[8]).onchangeHandler();
zenPage.getComponentById(camposPersistencia[9]).setValue(componente.Complemento);
zenPage.getComponentById(camposPersistencia[9]).onchangeHandler();
}
if (componente.scsCampoPersistenciaNacionalidade != ""){
var objCampoPersistenciaNacionalidade = zen(componente.scsCampoPersistenciaNacionalidade);
if (objCampoPersistenciaNacionalidade){
objCampoPersistenciaNacionalidade.setValue(+(componente.isEstrangeiro()));
objCampoPersistenciaNacionalidade.onchangeHandler();
}
}
if (componente.scsCamposPersistenciaEstrangeiro != ""){
var lCamposLocais = new Array();
lCamposLocais.push("txtCodigoPostalEstrangeiro");
lCamposLocais.push("txtCodigoPostal2Estrangeiro");
lCamposLocais.push("txtLogradouroEstrangeiro");
lCamposLocais.push("txtLogradouro2Estrangeiro");
lCamposLocais.push("txtCidadeEstrageiro");
lCamposLocais.push("txtEstadoEstrangeiro");
lCamposLocais.push("dtcPaisEstrangeiro");
lCamposLocais.push("txtNumeroEstrangeiro");
var lCamposPersistenciaEstrangeiro = componente.scsCamposPersistenciaEstrangeiro.split(componente.delimitador);
if (lCamposPersistenciaEstrangeiro.length == lCamposLocais.length){
for (var i=0, len=lCamposLocais.length; i < len; i++){
var objCampoLocal   = componente.getChildById(lCamposLocais[i]);
var objPersistencia = zen(lCamposPersistenciaEstrangeiro[i]);
if ((objCampoLocal) && (objPersistencia)) { // Verifica se ambos os componentes foram encontrados
objPersistencia.setValue(objCampoLocal.getValue());
objPersistencia.onchangeHandler();
}
}
}
}
}

self.s00_componente_interface_scsCompositeEndereco3_alterarCampo = function(pCampo,pValor) {
if(this.Parametros[pCampo] != pValor){
this.Parametros[pCampo] = pValor
var campoAtual = this.getChildById(pCampo);
var camposLimpar = ""
var campoFoco 	 = ""
if(pCampo == "estado"){
camposLimpar = new Array("cidade","bairro","logradouro");
campoFoco = "cidade"
}else if(pCampo == "cidade"){
var dados = zenThis.composite.RetornarInformacoes("cidade",pValor);
this.getChildById("pais").setValue(dados["pais"]);
this.getChildById("estado").setValue(dados["estado"]);
campoAtual.setValue(campoAtual.getAuxValue());
camposLimpar = new Array("bairro","logradouro");
campoFoco = "logradouro"
}else if(pCampo == "bairro"){
campoAtual.setValue(campoAtual.getAuxValue());
camposLimpar = new Array("logradouro");
campoFoco = "logradouro";
}else if(pCampo == "logradouro"){
var dados = zenThis.composite.RetornarInformacoes("logradouro",pValor);
var bairro  = this.getChildById("bairro");
var cep	    = this.getChildById("cep");
var tipoEnd = this.getChildById("tipoEndereco");
campoAtual.setValue(campoAtual.getAuxValue());
cep.setValue(dados["cep"]);
bairro.setValue(dados["bairroDescricao"]);
this.Parametros["bairro"] = dados["bairroId"]
if(tipoEnd.getValue() == ""){
tipoEnd.focus();
}
}else if(pCampo == "pais"){
this.getChildById('paramEstadoPais').setProperty('value',campoAtual.getValue());
this.Parametros["paisId"] = campoAtual.getValue();
}
zenThis.composite.limparCampos(camposLimpar,campoFoco);
}
}

self.s00_componente_interface_scsCompositeEndereco3_alterarCorLinha = function(posLinha) {
var comp = zenPage.getComponent(this.index);
var qtdLinha = comp.TotalPosicao;
var posAtual = comp.PosicaoAtual;
var linha = 1;
while(linha<=qtdLinha){
var aux = "linha_"+this.index+"_"+linha;
var obj = document.getElementById(aux);
if ((linha%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (linha == posLinha){
obj.style.background = "#fbe091";
}else{
obj.style.background = zebra;
}
linha = linha + 1;
}
}

self.s00_componente_interface_scsCompositeEndereco3_atualizaBotoesPadraoCliente = function(pAcao) {
if (pAcao == 1){
this.getChildById("btNovo").setProperty("hidden",true);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Adicionar endereço");
this.Atualizar = 0;
btAcao.setProperty("onclick","zenThis.composite.incluirAlteracoes();");
btAcao.setProperty("enclosingClass","botao_i_add");
}else if(pAcao == 2){
this.getChildById("btNovo").setProperty("hidden",false);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Atualizar endereço");
this.Atualizar = 1;
btAcao.setProperty("onclick","zenThis.composite.incluirAlteracoes();");
btAcao.setProperty("enclosingClass","botao_i_refresh_red");
}
if (this.scsTodosSomenteLeitura){
this.getChildById("btNovo").setProperty("hidden",true);
this.getChildById("btAcao").setProperty("hidden",true);
}
return 1;
}

self.s00_componente_interface_scsCompositeEndereco3_atualizaGridHtmlCliente = function() {
if(this.MultiplosEnderecos){
var objGridHtml = this.getChildById("grupoEnderecos");
objGridHtml.setProperty("content",this.desenhaGridHtmlCliente());
}
return 1;
}

self.s00_componente_interface_scsCompositeEndereco3_atualizarComboBairro = function(pCidadeId,pBairroId) {
var campo = this.getChildById("bairro");
campo.clearCache();
this.Parametros["cidade"] = pCidadeId;
campo.setValue(pBairroId);
}

self.s00_componente_interface_scsCompositeEndereco3_atualizarEnderecoCliente = function() {
try{
var cep 			= this.getChildById("cep").getValue();
var pais 			= this.getChildById("pais").getValue();
var estado 			= this.getChildById("estado").getValue();
var cidadeId 		= this.Parametros["cidade"]
var cidadeDescricao = this.getChildById("cidade").getValue();
var bairroId		= this.Parametros["bairro"]
var bairroDescricao = this.getChildById("bairro").getValue();
var tipoLogradouro 	= this.getChildById("tipoLogradouro").getValue();
var numero 			= this.getChildById("numero").getValue();
var complemento 	= this.getChildById("complemento").getValue();
var tipoEndereco 	= this.getChildById("tipoEndereco").getValue();
var logradouro 		= this.getChildById("logradouro").getValue();
var vm 				= "@VM";
cep = cep.replace(/-/g,"");
if (cep == "") cep = " ";
if(this.validarObrigatorios(logradouro, tipoEndereco, cep)){
var cepList 			= this.Cep.split(vm);
var tipoEnderecoList 	= this.TipoEndereco.split(vm);
var paisList 			= this.Pais.split(vm);
var estadoList 			= this.Estado.split(vm);
var cidadeIdList 		= this.CidadeId.split(vm);
var cidadeDescricaoList	= this.CidadeDescricao.split(vm);
var bairroIdList 		= this.BairroId.split(vm);
var bairroDescricaoList	= this.BairroDescricao.split(vm);
var tipoLogradouroList 	= this.TipoLogradouro.split(vm);
var logradouroList 		= this.Logradouro.split(vm);
var complementoList 	= this.Complemento.split(vm);
var numeroList 			= this.Numero.split(vm);
var posicao = this.PosicaoAtual - 1;
cepList.splice((posicao),1,cep);
tipoEnderecoList.splice((posicao),1,tipoEndereco);
paisList.splice((posicao),1,pais);
estadoList.splice((posicao),1,estado);
cidadeIdList.splice((posicao),1,cidadeId);
cidadeDescricaoList.splice((posicao),1,cidadeDescricao);
bairroIdList.splice((posicao),1,bairroId);
bairroDescricaoList.splice((posicao),1,bairroDescricao);
tipoLogradouroList.splice((posicao),1,tipoLogradouro);
logradouroList.splice((posicao),1,logradouro);
complementoList.splice((posicao),1,complemento);
numeroList.splice((posicao),1,numero);
this.TipoEndereco 	 = tipoEnderecoList.join(vm);
this.Cep 			 = cepList.join(vm);
this.Pais 			 = paisList.join(vm);
this.Estado 		 = estadoList.join(vm);
this.CidadeId 		 = cidadeIdList.join(vm);
this.CidadeDescricao = cidadeDescricaoList.join(vm);
this.BairroId 		 = bairroIdList.join(vm);
this.BairroDescricao = bairroDescricaoList.join(vm);
this.TipoLogradouro  = tipoLogradouroList.join(vm);
this.Logradouro 	 = logradouroList.join(vm);
this.Numero 		 = numeroList.join(vm);
this.Complemento 	 = complementoList.join(vm);
if(this.MultiplosEnderecos){
var retorno = this.limparCliente(1);
}
}
}catch (ex){
zenPage.alertaShift(ex.description);
}
return 1;
}

self.s00_componente_interface_scsCompositeEndereco3_buscarCepCliente = function(pCep) {
try{
if (pCep == ""){
zenPage.alertaShift(this.MensagemErro["preenchaCep"])
return 0;
}
var cep = pCep.replace(/-/g,"");
var proxyRetorno = new zenProxy();
var temEndereco = this.RetornarEndereco(cep,proxyRetorno);
if(temEndereco){
var cidade 		   = this.getChildById("cidade");
var estado 		   = this.getChildById("estado");
var tipoLogradouro = this.getChildById("tipoLogradouro");
var logradouro	   = this.getChildById("logradouro");
var pais 	   	   = this.getChildById("pais");
var bairro	   	   = this.getChildById("bairro");
var tipoEndereco   = this.getChildById("tipoEndereco");
cidade.setValue(proxyRetorno.CidadeDescricao);
this.Parametros["cidade"] = proxyRetorno.CidadeId;
estado.setValue(proxyRetorno.Estado);
if (pais){
pais.setProperty("value",proxyRetorno.Pais);
}
if(proxyRetorno.CepVariosLogradouros == "1"){
this.Parametros["logradouro"] = "";
logradouro.setValue("");
this.Parametros["bairro"] = "";
bairro.setValue("");
bairro.focus();
}else{
this.Parametros["bairro"] = proxyRetorno.BairroId
bairro.setValue(proxyRetorno.BairroDescricao);
this.Parametros["logradouro"] = proxyRetorno.LogradouroDescricao
if (this.UsaTipoLogradouro){
tipoLogradouro.setValue(proxyRetorno.TipoLogradouro);
logradouro.setValue(proxyRetorno.LogradouroDescricao);
}else{
logradouro.setValue(proxyRetorno.TipoLogradouro+" "+proxyRetorno.LogradouroDescricao)
}
if(tipoEndereco.getValue() == ""){
tipoEndereco.focus();
}
}
}else{
zenPage.alertaShift(this.MensagemErro["cepNaoEncontrado"]);
}
return 1;
}catch (ex){
return 0;
this.limparCliente(1);
zenPage.alertaShift(this.MensagemErro["erroBuscarCep"]+"\n"+ex.description);
}
}

self.s00_componente_interface_scsCompositeEndereco3_cadastrarBairro = function(multiplosEnderecos) {
var nomeJanela 	= "cadBairro";
var largura 	= 800;
var altura 		= 240;
if (multiplosEnderecos){
var estado = this.getChildById("estado").getValue();
var cidadeId = this.Parametros["cidade"];
}else{
var estado = zenPage.getComponentById("formularioCadastro.EnderecoEstado").getValue();
var cidadeId = zenPage.getComponentById("formularioCadastro.EnderecoCidade").getValue();
}
zenLaunchPopupWindow(
this.ListaLink["cadBairro"] + "&cidade=" +cidadeId+ "&estado=" + estado,
nomeJanela,
"status,scrollbars,resizable,width=" + largura + ",height=" + altura + "");
}

self.s00_componente_interface_scsCompositeEndereco3_cadastrarCidade = function() {
var nomeJanela 	= "cadLocalidade";
var largura 	= 800;
var altura 		= 240;
zenLaunchPopupWindow(
this.ListaLink["cadLocalidade"],
nomeJanela,
"status,scrollbars,resizable,width=" + largura + ",height=" + altura + "");
}

self.s00_componente_interface_scsCompositeEndereco3_cadastrarEstado = function() {
try{
var largura = 800;
var altura = 240;
zenLaunchPopupWindow(
this.ListaLink["cadEstado"],
"cadastroEstado",
"status,scrollbars,resizable,width=" + largura + ",height=" + altura + "");
}catch (ex){
zenPage.alertaShift(ex.description);
}
}

self.s00_componente_interface_scsCompositeEndereco3_cadastrarLogradouro = function() {
var nomeJanela 	= "cadLogradouro";
var largura  	= 800;
var altura 	 	= 340;
var bairro 	 	= this.Parametros["bairro"];
var cidadeId 	= this.Parametros["cidade"];
var estado 		= this.getChildById("estado").getValue();
var pais 		= this.getChildById("pais").getValue();
zenLaunchPopupWindow(
this.ListaLink["cadLogradouro"] + "&bairro=" +bairro+ "&cidade=" +cidadeId+ "&estado=" +estado+ "&pais=" +pais,
nomeJanela,
"status,scrollbars,resizable,width=" + largura + ",height=" + altura + "");
}

self.s00_componente_interface_scsCompositeEndereco3_consultarEndereco = function() {
var endereco = zenPage.getComponent(this.index);
var objCampoPersistenciaNacionalidade = zen(endereco.scsCampoPersistenciaNacionalidade);
if (objCampoPersistenciaNacionalidade){
endereco.getChildById("chkEstrangeiro").setValue(objCampoPersistenciaNacionalidade.getValue());
}else{
endereco.getChildById("chkEstrangeiro").setValue(false);
}
endereco.getChildById("chkEstrangeiro").onchangeHandler();
if (endereco.scsCamposPersistencia != ""){
var camposPersistencia = (endereco.scsCamposPersistencia).split(endereco.delimitador);
var cep = zenPage.getComponentById(camposPersistencia[0]).getValue();
var tipoEndereco = zenPage.getComponentById(camposPersistencia[1]).getValue();
if (zenPage.getComponentById(camposPersistencia[2]) != null){
var pais = zenPage.getComponentById(camposPersistencia[2]).getValue();
}else{
var pais = "";
}
var estado	 = zenPage.getComponentById(camposPersistencia[3]).getValue();
var cidadeId = zenPage.getComponentById(camposPersistencia[4]).getValue();
var bairro 	 = zenPage.getComponentById(camposPersistencia[5]).getValue();
if (zenPage.getComponentById(camposPersistencia[6])){
var tipoLogradouro = zenPage.getComponentById(camposPersistencia[6]).getValue();
}else{
var tipoLogradouro = "";
}
var logradouro 	= zenPage.getComponentById(camposPersistencia[7]).getValue();
var numero 		= zenPage.getComponentById(camposPersistencia[8]).getValue();
var complemento = zenPage.getComponentById(camposPersistencia[9]).getValue();
endereco.Cep 			 = cep;
endereco.TipoEndereco 	 = tipoEndereco;
endereco.Pais 			 = pais;
endereco.Estado 		 = estado
endereco.TotalPosicao 	 = cep!=""?cep.split("@VM").length:0
proxyDescricoes 		 = endereco.BuscarDescricaoCampos(cidadeId,bairro);
endereco.CidadeId 		 = cidadeId;
endereco.CidadeDescricao = proxyDescricoes.Cidades
endereco.BairroId 		 = bairro;
endereco.BairroDescricao = proxyDescricoes.Bairros;
endereco.TipoLogradouro  = tipoLogradouro;
endereco.Logradouro 	 = logradouro;
endereco.Numero 		 = numero;
endereco.Complemento 	 = complemento;
if(!endereco.MultiplosEnderecos){
endereco.proximoEnderecoCliente(1);
}
var retorno = endereco.atualizaGridHtmlCliente();
}
if (endereco.scsCamposPersistenciaEstrangeiro != ""){
var lCamposLocais = new Array();
lCamposLocais.push("txtCodigoPostalEstrangeiro");
lCamposLocais.push("txtCodigoPostal2Estrangeiro");
lCamposLocais.push("txtLogradouroEstrangeiro");
lCamposLocais.push("txtLogradouro2Estrangeiro");
lCamposLocais.push("txtCidadeEstrageiro");
lCamposLocais.push("txtEstadoEstrangeiro");
lCamposLocais.push("dtcPaisEstrangeiro");
lCamposLocais.push("txtNumeroEstrangeiro");
var lCamposPersistenciaEstrangeiro = endereco.scsCamposPersistenciaEstrangeiro.split(endereco.delimitador);
if (lCamposPersistenciaEstrangeiro.length == lCamposLocais.length){
for (var i=0, len=lCamposLocais.length; i < len; i++){
var objCampoLocal   = endereco.getChildById(lCamposLocais[i]);
var objPersistencia = zen(lCamposPersistenciaEstrangeiro[i]);
if ((objCampoLocal) && (objPersistencia)) { // Verifica se ambos os componentes foram encontrados
objCampoLocal.setValue(objPersistencia.getValue());
}
}
}
}
}

self.s00_componente_interface_scsCompositeEndereco3_desenhaGridHtmlCliente = function() {
var strGridHtml = "";
var vm = "@VM";
strGridHtml += "<table cellpadding='0' class='scsCompositeEndereco' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
if (this.Cep != ""){
var cepList 			= this.Cep.split(vm);
var tipoEnderecoList 	= this.TipoEndereco.split(vm);
var tipoLogradouroList 	= this.TipoLogradouro.split(vm);
var logradouroList		= this.Logradouro.split(vm);
var cidadeList 			= this.CidadeDescricao.split(vm);
var complementoList 	= this.Complemento.split(vm);
var numeroList 			= this.Numero.split(vm);
var qtd = cepList.length;
for (i=0;i<qtd;i++){
var tipoEndereco = parseInt(tipoEnderecoList[i]);
switch(tipoEndereco){
case 1:
tipoEndereco = "Residencial";
break;
case 2:
tipoEndereco = "Comercial";
break;
case 3:
tipoEndereco = "Cobrança";
break;
case 4:
tipoEndereco = "Fiscal";
break;
}
var cep = cepList[i];
if (cep != ""){
var tipoLogradouro = tipoLogradouroList[i];
var logradouro 	   = logradouroList[i];
var cidade 		   = cidadeList[i];
var complemento    = complementoList[i];
var numero 		   = numeroList[i];
if(this.UsaTipoLogradouro){
if ((tipoLogradouro != "") && (tipoLogradouro != undefined)){
logradouro = tipoLogradouro + " " + logradouro;
}
}
if((numero != "") && (complemento != "")){
logradouro = logradouro + ", " + numero + " - " + complemento;
}else if (numero != ""){
logradouro = logradouro + ", " + numero;
}else if (complemento != ""){
logradouro = logradouro + " - " + complemento;
}
if (cep == " ") cep = "&#160;";
if (cidade == "") cidade = "&#160;";
if (tipoLogradouro == "") tipoLogradouro = "&#160;";
if (logradouro == "") logradouro = "&#160;";
if (((i+1)%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
strGridHtml +=
"<tr bgcolor='" + zebra + "' id='linha_"+this.index+"_"+(i+1)+"' onclick='zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")' style='cursor:hand;'>"+
"<td width='115' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").proximoEnderecoCliente("+(i+1)+");'>"+tipoEndereco+"</td>"+
"<td width='110' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").proximoEnderecoCliente("+(i+1)+");'>"+cep+"</td>"+
"<td width='281' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").proximoEnderecoCliente("+(i+1)+");'>"+cidade+"</td>"+
"<td width='274' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").proximoEnderecoCliente("+(i+1)+");'>"+logradouro+"</td>";
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td align='center' style='vertical-align: middle;border-right:0px'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td align='center' style='vertical-align: middle;border-right:0px'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirEnderecoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"
"</tr>";
}
}
}
}
strGridHtml += "</table>";
return strGridHtml;
}

self.s00_componente_interface_scsCompositeEndereco3_excluirEnderecoCliente = function(pPosicao) {
var vm 					= "@VM";
var cepList 			= this.Cep.split(vm);
var tipoEnderecoList 	= this.TipoEndereco.split(vm);
var paisList 			= this.Pais.split(vm);
var estadoList 			= this.Estado.split(vm);
var cidadeIdList 		= this.CidadeId.split(vm);
var cidadeDescricaoList = this.CidadeDescricao.split(vm);
var bairroIdList		= this.BairroId.split(vm);
var bairroDescricaoList = this.BairroDescricao.split(vm);
var tipoLogradouroList 	= this.TipoLogradouro.split(vm);
var logradouroList 		= this.Logradouro.split(vm);
var complementoList 	= this.Complemento.split(vm);
var numeroList 			= this.Numero.split(vm);
cepList.splice((pPosicao-1),1);
tipoEnderecoList.splice((pPosicao-1),1);
paisList.splice((pPosicao-1),1);
estadoList.splice((pPosicao-1),1);
cidadeIdList.splice((pPosicao-1),1);
cidadeDescricaoList.splice((pPosicao-1),1);
bairroIdList.splice((pPosicao-1),1);
bairroDescricaoList.splice((pPosicao-1),1);
tipoLogradouroList.splice((pPosicao-1),1);
logradouroList.splice((pPosicao-1),1);
complementoList.splice((pPosicao-1),1);
numeroList.splice((pPosicao-1),1);
this.TipoEndereco 	 = tipoEnderecoList.join(vm);
this.Cep 			 = cepList.join(vm);
this.Pais 			 = paisList.join(vm);
this.Estado 		 = estadoList.join(vm);
this.CidadeId 		 = cidadeIdList.join(vm);
this.CidadeDescricao = cidadeDescricaoList.join(vm);
this.BairroId 		 = bairroIdList.join(vm);
this.BairroDescricao = bairroDescricaoList.join(vm);
this.TipoLogradouro  = tipoLogradouroList.join(vm);
this.Logradouro 	 = logradouroList.join(vm);
this.Complemento 	 = complementoList.join(vm);
this.Numero 		 = numeroList.join(vm);
this.TotalPosicao -= 1;
this.PosicaoAtual = 0;
this.Parametros["estado"]		= ""
this.Parametros["cidade"] 		= ""
this.Parametros["bairro"] 		= ""
this.Parametros["logradouro"] 	= ""
var retorno = this.limparCliente(1);
return 1;
}

self.s00_componente_interface_scsCompositeEndereco3_incluirAlteracoes = function() {
if(this.Atualizar){
var retorno = this.atualizarEnderecoCliente();
}else{
var retorno = this.incluirEnderecoCliente();
}
this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente_interface_scsCompositeEndereco3_incluirEnderecoCliente = function() {
var cep 		 	= this.getChildById("cep").getValue();
var pais 			= this.getChildById("pais").getValue();
var estado 			= this.getChildById("estado").getValue();
var cidadeId 		= this.Parametros["cidade"]
var cidadeDescricao = this.getChildById("cidade").getValue();
var bairroId		= this.Parametros["bairro"]
var bairroDescricao	= this.getChildById("bairro").getValue();
var tipoEndereco 	= this.getChildById("tipoEndereco").getValue();
var logradouro 	 	= this.getChildById("logradouro").getValue();
var tipoLogradouro 	= this.getChildById("tipoLogradouro").getValue();
var numero 			= this.getChildById("numero").getValue();
var complemento 	= this.getChildById("complemento").getValue();
var vm 				= "@VM";
cep = cep.replace(/-/g,"");
if (cep == "") cep = " ";
if(this.validarObrigatorios(logradouro, tipoEndereco, cep)){
if (this.Cep == ""){
this.Cep 			 = cep;
this.Pais 		 	 = pais;
this.Estado 		 = estado;
this.CidadeId 		 = cidadeId;
this.CidadeDescricao = cidadeDescricao;
this.BairroId 		 = bairroId;
this.BairroDescricao = bairroDescricao
this.TipoEndereco 	 = tipoEndereco;
this.TipoLogradouro  = tipoLogradouro;
this.Logradouro 	 = logradouro;
this.Numero 		 = numero;
this.Complemento 	 = complemento;
}else{
this.Cep 			 = this.Cep 		 	+ vm + cep;
this.Pais 			 = this.Pais 			+ vm + pais;
this.Estado 		 = this.Estado 			+ vm + estado;
this.CidadeId 		 = this.CidadeId 		+ vm + cidadeId;
this.CidadeDescricao = this.CidadeDescricao + vm + cidadeDescricao;
this.BairroId 		 = this.BairroId		+ vm + bairroId;
this.BairroDescricao = this.BairroDescricao + vm + bairroDescricao
this.TipoEndereco 	 = this.TipoEndereco 	+ vm + tipoEndereco;
this.TipoLogradouro  = this.TipoLogradouro 	+ vm + tipoLogradouro;
this.Logradouro 	 = this.Logradouro 		+ vm + logradouro;
this.Numero 		 = this.Numero			+ vm + numero;
this.Complemento 	 = this.Complemento 	+ vm + complemento;
}
this.TotalPosicao++;
var retorno = this.atualizaGridHtmlCliente();
if(this.MultiplosEnderecos){
var retorno = this.limparCliente(1);
}
}
return 1
}

self.s00_componente_interface_scsCompositeEndereco3_isEstrangeiro = function() {
return (this.getChildById("chkEstrangeiro").getValue());
}

self.s00_componente_interface_scsCompositeEndereco3_isNacional = function() {
return (!this.getChildById("chkEstrangeiro").getValue());
}

self.s00_componente_interface_scsCompositeEndereco3_limpaComponenteCliente = function() {
var retorno = this.resetarCliente();
return 1;
}

self.s00_componente_interface_scsCompositeEndereco3_limparCampos = function(pArrayCampos,pCampoFoco) {
if (pArrayCampos != ""){
for (i = 0; i < pArrayCampos.length; i++){
var campo = this.getChildById(pArrayCampos[i])
campo.setValue("");
}
this.getChildById(pCampoFoco).focus();
}
}

self.s00_componente_interface_scsCompositeEndereco3_limparCliente = function(pMultiplosEnderecos) {
if (pMultiplosEnderecos){
this.Parametros["estado"] = ""
this.Parametros["cidade"] = ""
this.Parametros["bairro"] = ""
this.Parametros["logradouro"] = ""
this.getChildById("tipoEndereco").setProperty("value","");
this.getChildById("cep").setProperty("value","");
this.getChildById("pais").setProperty("value","");
this.getChildById("estado").setProperty("value","");
this.getChildById("cidade").setProperty("value","");
this.getChildById("bairro").setProperty("value","");
this.getChildById("tipoLogradouro").setProperty("value","");
this.getChildById("logradouro").setProperty("value","");
this.getChildById("numero").setProperty("value","");
this.getChildById("complemento").setProperty("value","");
this.PosicaoAtual = 0;
this.getChildById("cidade").focus();
this.atualizaBotoesPadraoCliente(1);
}else{
var enderecoCep 			= zenPage.getComponentById("formularioCadastro.EnderecoCep");
var enderecoTipo 			= zenPage.getComponentById("formularioCadastro.EnderecoTipo");
var enderecoPais 			= zenPage.getComponentById("formularioCadastro.EnderecoPais");
var enderecoEstado 			= zenPage.getComponentById("formularioCadastro.EnderecoEstado");
var enderecoCidade 			= zenPage.getComponentById("formularioCadastro.EnderecoCidade");
var enderecoBairro 			= zenPage.getComponentById("formularioCadastro.EnderecoBairro");
var enderecoNumero 			= zenPage.getComponentById("formularioCadastro.EnderecoNumero");
var enderecoLogradouro 		= zenPage.getComponentById("formularioCadastro.EnderecoLogradouro");
var enderecoComplemento		= zenPage.getComponentById("formularioCadastro.EnderecoComplemento");
var enderecoTipoLogradouro 	= zenPage.getComponentById("formularioCadastro.EnderecoTipoLogradouro");
if (enderecoCep != undefined) enderecoCep.setProperty("value","");
if (enderecoTipo != undefined) enderecoTipo.setProperty("value","");
if (enderecoPais != undefined) enderecoPais.setProperty("value","");
if (enderecoEstado != undefined) enderecoEstado.setProperty("value","");
if (enderecoCidade != undefined) enderecoCidade.setProperty("value","");
if (enderecoBairro != undefined) enderecoBairro.setProperty("value","");
if (enderecoNumero != undefined) enderecoNumero.setProperty("value","");
if (enderecoLogradouro != undefined) enderecoLogradouro.setProperty("value","");
if (enderecoComplemento != undefined) enderecoComplemento.setProperty("value","");
if (enderecoTipoLogradouro != undefined) enderecoTipoLogradouro.setProperty("value","");
}
return 1;
}

self.s00_componente_interface_scsCompositeEndereco3_pesquisarBuscaCep = function(multiplosEnderecos) {
var vm = String.fromCharCode(253);
var nomeJanela = "buscaCEP"+ vm +"page"+ vm +"naoutilizado"+ vm +"formularioCadastro_EnderecoCep";
if ( multiplosEnderecos ){
var idComp = this.id;
idComp = idComp.replace(".","_");
nomeJanela = "buscaCEP"+ vm +"composite"+ vm +idComp+ vm +"cep";
}
zenLaunchPopupWindow(
's00.componente.interface.BuscaCep.cls',
nomeJanela,
'status,scrollbars,resizable,width=802,height=600');
}

self.s00_componente_interface_scsCompositeEndereco3_proximoEnderecoCliente = function(pPosicao) {
this.PosicaoAtual 		= pPosicao;
var cep 				= this.Cep.split("@VM");
var tipoEndereco 		= this.TipoEndereco.split("@VM");
var pais 				= this.Pais.split("@VM");
var estado 				= this.Estado.split("@VM");
var cidadeId 			= this.CidadeId.split("@VM");
var cidadeDescricao 	= this.CidadeDescricao.split("@VM");
var bairroId			= this.BairroId.split("@VM");
var bairroDescricao		= this.BairroDescricao.split("@VM");
var tipoLogradouro 		= this.TipoLogradouro.split("@VM");
var logradouro 			= this.Logradouro.split("@VM");
var numero 				= this.Numero.split("@VM");
var complemento 		= this.Complemento.split("@VM");
this.Parametros["estado"]		= estado[(pPosicao-1)]
this.Parametros["cidade"] 		= cidadeId[(pPosicao-1)]
this.Parametros["bairro"] 		= bairroId[(pPosicao-1)]
this.Parametros["logradouro"] 	= logradouro[(pPosicao-1)]
this.getChildById("tipoEndereco").setProperty("value", tipoEndereco[(pPosicao-1)]);
this.getChildById("cep").setProperty("value", cep[(pPosicao-1)]);
this.getChildById("pais").setProperty("value", pais[(pPosicao-1)]);
this.getChildById("estado").setProperty("value", estado[(pPosicao-1)]);
this.getChildById("cidade").setProperty("value", cidadeDescricao[(pPosicao-1)]);
this.getChildById("bairro").setProperty("value", bairroDescricao[(pPosicao-1)]);
if (!this.getChildById("tipoLogradouro").getHidden()){
this.getChildById("tipoLogradouro").setProperty("value", tipoLogradouro[(pPosicao-1)]);
}
this.getChildById("logradouro").setProperty("value", logradouro[(pPosicao-1)]);
this.getChildById("numero").setProperty("value", numero[(pPosicao-1)]);
this.getChildById("complemento").setProperty("value", complemento[(pPosicao-1)]);
var retorno = this.atualizaBotoesPadraoCliente(2);
return 1;
}

self.s00_componente_interface_scsCompositeEndereco3_resetarCliente = function() {
var retorno 				  = this.limparCliente(1);
this.TipoEndereco			  = "";
this.Cep 					  = "";
this.Pais 					  = "";
this.Estado 				  = "";
this.CidadeId 				  = "";
this.CidadeDescricao 		  = "";
this.BairroId 				  = "";
this.BairroDescricao		  = "";
this.TipoLogradouro 		  = "";
this.Logradouro 			  = "";
this.Numero 				  = "";
this.Complemento 			  = "";
this.Parametros["cidade"]	  = "";
this.Parametros["bairro"] 	  = "";
this.Parametros["logradouro"] = "";
this.TotalPosicao 			  = 0;
var lCamposLocais = new Array();
lCamposLocais.push("txtCodigoPostalEstrangeiro");
lCamposLocais.push("txtCodigoPostal2Estrangeiro");
lCamposLocais.push("txtLogradouroEstrangeiro");
lCamposLocais.push("txtLogradouro2Estrangeiro");
lCamposLocais.push("txtCidadeEstrageiro");
lCamposLocais.push("txtEstadoEstrangeiro");
lCamposLocais.push("dtcPaisEstrangeiro");
lCamposLocais.push("txtNumeroEstrangeiro");
this.selecionarEstrangeiro(false);
for (var i=0, len=lCamposLocais.length; i < len; i++){
var objCampoLocal = this.getChildById(lCamposLocais[i]);
objCampoLocal.setValue("");
objCampoLocal.onchangeHandler();
}
var retorno = this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente_interface_scsCompositeEndereco3_selecionarEstrangeiro = function(pIsEstrangeiro) {
var retorno = true;
try{
var objChkEstrangeiro = this.getChildById("chkEstrangeiro");
if (objChkEstrangeiro.getValue() != pIsEstrangeiro){
objChkEstrangeiro.setValue(pIsEstrangeiro);
objChkEstrangeiro.onchangeHandler();
throw 0;
}
this.getChildById("btAcao").setHidden(pIsEstrangeiro);
this.getChildById("grpCamposNacional").setHidden(pIsEstrangeiro);
this.getChildById("grpListaEnderecoNacional").setHidden(pIsEstrangeiro);
this.getChildById("grpCamposEstrangeiro").setHidden(!pIsEstrangeiro);
this.getChildById("grpListaEnderecoEstrangeiro").setHidden(!pIsEstrangeiro);
var lEnderecoLbl = this.getChildById("enderecoTitulo").getProperty("aux");
if (lEnderecoLbl != ""){
lEnderecoLbl = lEnderecoLbl.split("|");
this.getChildById("enderecoTitulo").setValue((pIsEstrangeiro) ? lEnderecoLbl[1] : lEnderecoLbl[0]);
}
}catch(ex){
if (ex && ex.description) zenPage.alertaShift(ex.description);
retorno = false;
}
return retorno;
}

self.s00_componente_interface_scsCompositeEndereco3_validarObrigatorios = function(pLogradouro,pTipoEndereco,pCep) {
if (this.isNacional()){
var erro = ""
if (pLogradouro == ""){
erro += " - Logradouro \n";
campoFoco = "logradouro"
}
if (pTipoEndereco == ""){
erro += " - Tipo de endereço \n";
campoFoco = "tipoEndereco"
}
if (this.CEPObrigatorio && pCep == ""){
erro += " - CEP \n";
campoFoco = "cep"
}
if (erro != ""){
zenPage.alertaShift(this.MensagemErro["camposObrigatorios"]+"\n"+erro);
this.getChildById(campoFoco).focus();
return 0;
}
}
return 1;
}

self.s00_componente_interface_scsCompositeEndereco3_verificarCampoCidade = function() {
var campoCidade = this.getChildById("cidade")
if (campoCidade.getValue() == ""){
zenPage.alertaShift(this.MensagemErro["selecioneCidade"]);
campoCidade.focus();
}
}

self.s00_componente_interface_scsCompositeEndereco3_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_AtualizarEndereco = function() {
	return zenInstanceMethod(this,'AtualizarEndereco','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_BuscarDescricaoCampos = function(pCidades,pBairros) {
	return zenClassMethod(this,'BuscarDescricaoCampos','L,L','HANDLE',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_DesenhaGridHtml = function() {
	return zenInstanceMethod(this,'DesenhaGridHtml','','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_ExcluirEndereco = function(posicao) {
	return zenInstanceMethod(this,'ExcluirEndereco','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_IncluirEndereco = function() {
	return zenInstanceMethod(this,'IncluirEndereco','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_Limpar = function(multiplosEnderecos) {
	return zenInstanceMethod(this,'Limpar','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_ProximoEndereco = function(posicao) {
	return zenInstanceMethod(this,'ProximoEndereco','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_Resetar = function() {
	return zenInstanceMethod(this,'Resetar','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_RetornarEndereco = function(pCep,pProxyRetorno) {
	return zenClassMethod(this,'RetornarEndereco','L,O','BOOLEAN',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_RetornarInformacoes = function(pCampo,pIdCampo) {
	return zenClassMethod(this,'RetornarInformacoes','L,L','ARRAYDT',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_TodosSomenteLeitura = function(acao) {
	return zenInstanceMethod(this,'TodosSomenteLeitura','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeEndereco3_refreshHTML = function() {
	return zenInstanceMethod(this,'refreshHTML','','STATUS',arguments);
}
self.s00_componente_interface_scsCompositeEndereco3__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeEndereco3.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeEndereco3.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeEndereco3;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeEndereco3';
	p._type = 'scsCompositeEndereco3';
	p.serialize = s00_componente_interface_scsCompositeEndereco3_serialize;
	p.getSettings = s00_componente_interface_scsCompositeEndereco3_getSettings;
	p.AtualizaBotoesPadrao = s00_componente_interface_scsCompositeEndereco3_AtualizaBotoesPadrao;
	p.AtualizaGridHtml = s00_componente_interface_scsCompositeEndereco3_AtualizaGridHtml;
	p.AtualizarEndereco = s00_componente_interface_scsCompositeEndereco3_AtualizarEndereco;
	p.BuscarCep = s00_componente_interface_scsCompositeEndereco3_BuscarCep;
	p.BuscarDescricaoCampos = s00_componente_interface_scsCompositeEndereco3_BuscarDescricaoCampos;
	p.DesenhaGridHtml = s00_componente_interface_scsCompositeEndereco3_DesenhaGridHtml;
	p.ExcluirEndereco = s00_componente_interface_scsCompositeEndereco3_ExcluirEndereco;
	p.IncluirEndereco = s00_componente_interface_scsCompositeEndereco3_IncluirEndereco;
	p.LimpaComponente = s00_componente_interface_scsCompositeEndereco3_LimpaComponente;
	p.Limpar = s00_componente_interface_scsCompositeEndereco3_Limpar;
	p.ProximoEndereco = s00_componente_interface_scsCompositeEndereco3_ProximoEndereco;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeEndereco3_ReallyRefreshContents;
	p.RecuperarEndereco = s00_componente_interface_scsCompositeEndereco3_RecuperarEndereco;
	p.Resetar = s00_componente_interface_scsCompositeEndereco3_Resetar;
	p.RetornarEndereco = s00_componente_interface_scsCompositeEndereco3_RetornarEndereco;
	p.RetornarInformacoes = s00_componente_interface_scsCompositeEndereco3_RetornarInformacoes;
	p.TodosSomenteLeitura = s00_componente_interface_scsCompositeEndereco3_TodosSomenteLeitura;
	p.alterarCampo = s00_componente_interface_scsCompositeEndereco3_alterarCampo;
	p.alterarCorLinha = s00_componente_interface_scsCompositeEndereco3_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente_interface_scsCompositeEndereco3_atualizaBotoesPadraoCliente;
	p.atualizaGridHtmlCliente = s00_componente_interface_scsCompositeEndereco3_atualizaGridHtmlCliente;
	p.atualizarComboBairro = s00_componente_interface_scsCompositeEndereco3_atualizarComboBairro;
	p.atualizarEnderecoCliente = s00_componente_interface_scsCompositeEndereco3_atualizarEnderecoCliente;
	p.buscarCepCliente = s00_componente_interface_scsCompositeEndereco3_buscarCepCliente;
	p.cadastrarBairro = s00_componente_interface_scsCompositeEndereco3_cadastrarBairro;
	p.cadastrarCidade = s00_componente_interface_scsCompositeEndereco3_cadastrarCidade;
	p.cadastrarEstado = s00_componente_interface_scsCompositeEndereco3_cadastrarEstado;
	p.cadastrarLogradouro = s00_componente_interface_scsCompositeEndereco3_cadastrarLogradouro;
	p.consultarEndereco = s00_componente_interface_scsCompositeEndereco3_consultarEndereco;
	p.desenhaGridHtmlCliente = s00_componente_interface_scsCompositeEndereco3_desenhaGridHtmlCliente;
	p.excluirEnderecoCliente = s00_componente_interface_scsCompositeEndereco3_excluirEnderecoCliente;
	p.incluirAlteracoes = s00_componente_interface_scsCompositeEndereco3_incluirAlteracoes;
	p.incluirEnderecoCliente = s00_componente_interface_scsCompositeEndereco3_incluirEnderecoCliente;
	p.isEstrangeiro = s00_componente_interface_scsCompositeEndereco3_isEstrangeiro;
	p.isNacional = s00_componente_interface_scsCompositeEndereco3_isNacional;
	p.limpaComponenteCliente = s00_componente_interface_scsCompositeEndereco3_limpaComponenteCliente;
	p.limparCampos = s00_componente_interface_scsCompositeEndereco3_limparCampos;
	p.limparCliente = s00_componente_interface_scsCompositeEndereco3_limparCliente;
	p.pesquisarBuscaCep = s00_componente_interface_scsCompositeEndereco3_pesquisarBuscaCep;
	p.proximoEnderecoCliente = s00_componente_interface_scsCompositeEndereco3_proximoEnderecoCliente;
	p.refreshHTML = s00_componente_interface_scsCompositeEndereco3_refreshHTML;
	p.resetarCliente = s00_componente_interface_scsCompositeEndereco3_resetarCliente;
	p.selecionarEstrangeiro = s00_componente_interface_scsCompositeEndereco3_selecionarEstrangeiro;
	p.validarObrigatorios = s00_componente_interface_scsCompositeEndereco3_validarObrigatorios;
	p.verificarCampoCidade = s00_componente_interface_scsCompositeEndereco3_verificarCampoCidade;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeGenerico'] = 's00_componente_interface_scsCompositeGenerico';
self.s00_componente_interface_scsCompositeGenerico = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeGenerico__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeGenerico__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.ctrlCampos = '0';
	o.ctrlDuplicado = '';
	o.ctrlEditaRegistro = false;
	o.ctrlStrCampoAux = '0';
	o.delimitador = '|';
	o.delimitadorMV = '';
	o.delimitadorSV = '';
	o.idDinamicoBarraDeTitulo = '';
	o.idDinamicoBotoesPadrao = '';
	o.idDinamicoBtAcao = '';
	o.idDinamicoBtNovo = '';
	o.idDinamicoGridCampos = '';
	o.idDinamicoGridConteudo = '';
	o.idDinamicoGrupoLabelTitulo = '';
	o.idDinamicoHtml = '';
	o.idDinamicoLabelTitulo = '';
	o.posicaoAtual = '0';
	o.scsAlignValorGrid = '';
	o.scsCampoLayout = '';
	o.scsCampoObrigatorio = '0';
	o.scsCamposControle = '';
	o.scsCamposPersistenecia = '';
	o.scsCaption = '';
	o.scsCasasDecimaisGrid = '';
	o.scsChoiceColumn = '';
	o.scsCols = '';
	o.scsComboType = '';
	o.scsContainerStyle = '';
	o.scsControlStyle = '';
	o.scsCustomLayout = false;
	o.scsDisabled = '';
	o.scsDisplayColumns = '';
	o.scsDisplayList = '';
	o.scsDropDownHeight = '';
	o.scsDropDownWidth = '';
	o.scsEditable = '';
	o.scsEnclosingClass = '';
	o.scsEnclosingStyle = '';
	o.scsFinalAdicionaGenerico = '';
	o.scsFinalAtualizaGenerico = '';
	o.scsFinalExcluiGenerico = '';
	o.scsFinalLimpaGenerico = '';
	o.scsHeightTabelaGrid = '90px';
	o.scsHidden = '';
	o.scsHintClass = '';
	o.scsHintStyle = '';
	o.scsId = '';
	o.scsIdGrid = '';
	o.scsIdGridInput = '';
	o.scsInicioAdicionaGenerico = '';
	o.scsInicioAtualizaGenerico = '';
	o.scsInicioExcluiGenerico = '';
	o.scsInicioLimpaGenerico = '';
	o.scsLabel = '';
	o.scsLabelClass = '';
	o.scsLabelGrid = '';
	o.scsLabelPosition = '';
	o.scsLabelStyle = '';
	o.scsLarguraColunasGrid = '';
	o.scsMargemGrupoCampos = '';
	o.scsMaxRows = '';
	o.scsMaxlength = '';
	o.scsMetodoEspecifico = '';
	o.scsMultiColumn = '';
	o.scsOcultaBarraTitulo = false;
	o.scsOcultaBotaoAdicionar = false;
	o.scsOcultaBotaoExcluir = false;
	o.scsOcultaBotoesPadrao = false;
	o.scsOcultaCamposEdicao = false;
	o.scsOnBlur = '';
	o.scsOnChange = '';
	o.scsOnClick = '';
	o.scsOnFocus = '';
	o.scsOnKeyDown = '';
	o.scsOnKeyPress = '';
	o.scsOnKeyUp = '';
	o.scsPermiteRepeticao = '0';
	o.scsQtdCaracteresColunaGrid = '';
	o.scsQtdLinhaColuna = '';
	o.scsQueryClass = '';
	o.scsQueryName = '';
	o.scsReadOnly = '';
	o.scsRepositorioObjetos = null;
	o.scsRetornoSubValue = '';
	o.scsRows = '';
	o.scsSearchKeyLen = '';
	o.scsSize = '';
	o.scsSomenteVisualizacao = false;
	o.scsSql = '';
	o.scsSqlConvCodigoPropriedade = '';
	o.scsSqlGrid = '';
	o.scsSqlLookUp = '';
	o.scsStrTemp = '';
	o.scsTabIndex = '';
	o.scsTextMoedaValorMaximo = '';
	o.scsTextMoedaValorMinimo = '';
	o.scsTipo = '';
	o.scsTipoLayout = '1';
	o.scsTituloComponente = '';
	o.scsTodosSomenteLeitura = false;
	o.scsUtilizaValidacao = false;
	o.scsValue = '';
	o.scsValueList = '';
	o.scsWidth = '';
	o.scsWidthComponente = '';
	o.scsWidthTabelaGrid = '';
	o.strCampo1 = '';
	o.strCampo10 = '';
	o.strCampo11 = '';
	o.strCampo12 = '';
	o.strCampo13 = '';
	o.strCampo14 = '';
	o.strCampo15 = '';
	o.strCampo16 = '';
	o.strCampo17 = '';
	o.strCampo18 = '';
	o.strCampo2 = '';
	o.strCampo3 = '';
	o.strCampo4 = '';
	o.strCampo5 = '';
	o.strCampo6 = '';
	o.strCampo7 = '';
	o.strCampo8 = '';
	o.strCampo9 = '';
	o.strCampoAux = '';
	o.totalPosicoes = '0';
}
function s00_componente_interface_scsCompositeGenerico_serialize(set,s)
{
	var o = this;s[0]='3042254717';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=(o.childrenCreated?1:0);s[14]=o.containerStyle;s[15]=o.ctrlCampos;s[16]=o.ctrlDuplicado;s[17]=(o.ctrlEditaRegistro?1:0);s[18]=o.ctrlStrCampoAux;s[19]=o.delimitador;s[20]=o.delimitadorMV;s[21]=o.delimitadorSV;s[22]=(o.disabled?1:0);s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.groupClass;s[30]=o.groupStyle;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=o.idDinamicoBarraDeTitulo;s[37]=o.idDinamicoBotoesPadrao;s[38]=o.idDinamicoBtAcao;s[39]=o.idDinamicoBtNovo;s[40]=o.idDinamicoGridCampos;s[41]=o.idDinamicoGridConteudo;s[42]=o.idDinamicoGrupoLabelTitulo;s[43]=o.idDinamicoHtml;s[44]=o.idDinamicoLabelTitulo;s[45]=o.label;s[46]=o.labelClass;s[47]=o.labelDisabledClass;s[48]=o.labelPosition;s[49]=o.labelStyle;s[50]=o.layout;s[51]=o.onafterdrag;s[52]=o.onbeforedrag;s[53]=o.onclick;s[54]=o.ondrag;s[55]=o.ondrop;s[56]=o.onhide;s[57]=o.onrefresh;s[58]=o.onshow;s[59]=o.onupdate;s[60]=o.overlayMode;s[61]=o.posicaoAtual;s[62]=o.renderFlag;s[63]=o.scsAlignValorGrid;s[64]=o.scsCampoLayout;s[65]=o.scsCampoObrigatorio;s[66]=o.scsCamposControle;s[67]=o.scsCamposPersistenecia;s[68]=o.scsCaption;s[69]=o.scsCasasDecimaisGrid;s[70]=o.scsChoiceColumn;s[71]=o.scsCols;s[72]=o.scsComboType;s[73]=o.scsContainerStyle;s[74]=o.scsControlStyle;s[75]=(o.scsCustomLayout?1:0);s[76]=o.scsDisabled;s[77]=o.scsDisplayColumns;s[78]=o.scsDisplayList;s[79]=o.scsDropDownHeight;s[80]=o.scsDropDownWidth;s[81]=o.scsEditable;s[82]=o.scsEnclosingClass;s[83]=o.scsEnclosingStyle;s[84]=o.scsFinalAdicionaGenerico;s[85]=o.scsFinalAtualizaGenerico;s[86]=o.scsFinalExcluiGenerico;s[87]=o.scsFinalLimpaGenerico;s[88]=o.scsHeightTabelaGrid;s[89]=o.scsHidden;s[90]=o.scsHintClass;s[91]=o.scsHintStyle;s[92]=o.scsId;s[93]=o.scsIdGrid;s[94]=o.scsIdGridInput;s[95]=o.scsInicioAdicionaGenerico;s[96]=o.scsInicioAtualizaGenerico;s[97]=o.scsInicioExcluiGenerico;s[98]=o.scsInicioLimpaGenerico;s[99]=o.scsLabel;s[100]=o.scsLabelClass;s[101]=o.scsLabelGrid;s[102]=o.scsLabelPosition;s[103]=o.scsLabelStyle;s[104]=o.scsLarguraColunasGrid;s[105]=o.scsMargemGrupoCampos;s[106]=o.scsMaxRows;s[107]=o.scsMaxlength;s[108]=o.scsMetodoEspecifico;s[109]=o.scsMultiColumn;s[110]=(o.scsOcultaBarraTitulo?1:0);s[111]=(o.scsOcultaBotaoAdicionar?1:0);s[112]=(o.scsOcultaBotaoExcluir?1:0);s[113]=(o.scsOcultaBotoesPadrao?1:0);s[114]=(o.scsOcultaCamposEdicao?1:0);s[115]=o.scsOnBlur;s[116]=o.scsOnChange;s[117]=o.scsOnClick;s[118]=o.scsOnFocus;s[119]=o.scsOnKeyDown;s[120]=o.scsOnKeyPress;s[121]=o.scsOnKeyUp;s[122]=o.scsPermiteRepeticao;s[123]=o.scsQtdCaracteresColunaGrid;s[124]=o.scsQtdLinhaColuna;s[125]=o.scsQueryClass;s[126]=o.scsQueryName;s[127]=o.scsReadOnly;s[128]=set.addObject(o.scsRepositorioObjetos,'scsRepositorioObjetos');s[129]=o.scsRetornoSubValue;s[130]=o.scsRows;s[131]=o.scsSearchKeyLen;s[132]=o.scsSize;s[133]=(o.scsSomenteVisualizacao?1:0);s[134]=o.scsSql;s[135]=o.scsSqlConvCodigoPropriedade;s[136]=o.scsSqlGrid;s[137]=o.scsSqlLookUp;s[138]=o.scsStrTemp;s[139]=o.scsTabIndex;s[140]=o.scsTextMoedaValorMaximo;s[141]=o.scsTextMoedaValorMinimo;s[142]=o.scsTipo;s[143]=o.scsTipoLayout;s[144]=o.scsTituloComponente;s[145]=(o.scsTodosSomenteLeitura?1:0);s[146]=(o.scsUtilizaValidacao?1:0);s[147]=o.scsValue;s[148]=o.scsValueList;s[149]=o.scsWidth;s[150]=o.scsWidthComponente;s[151]=o.scsWidthTabelaGrid;s[152]=(o.showLabel?1:0);s[153]=o.slice;s[154]=o.strCampo1;s[155]=o.strCampo10;s[156]=o.strCampo11;s[157]=o.strCampo12;s[158]=o.strCampo13;s[159]=o.strCampo14;s[160]=o.strCampo15;s[161]=o.strCampo16;s[162]=o.strCampo17;s[163]=o.strCampo18;s[164]=o.strCampo2;s[165]=o.strCampo3;s[166]=o.strCampo4;s[167]=o.strCampo5;s[168]=o.strCampo6;s[169]=o.strCampo7;s[170]=o.strCampo8;s[171]=o.strCampo9;s[172]=o.strCampoAux;s[173]=o.title;s[174]=o.totalPosicoes;s[175]=o.tuple;s[176]=o.valign;s[177]=(o.visible?1:0);s[178]=o.width;
}
function s00_componente_interface_scsCompositeGenerico_getSettings(s)
{
	s['name'] = 'string';
	s['ctrlCampos'] = 'string';
	s['ctrlDuplicado'] = 'string';
	s['ctrlEditaRegistro'] = 'string';
	s['ctrlStrCampoAux'] = 'string';
	s['delimitador'] = 'string';
	s['delimitadorMV'] = 'string';
	s['delimitadorSV'] = 'string';
	s['idDinamicoBarraDeTitulo'] = 'string';
	s['idDinamicoBotoesPadrao'] = 'string';
	s['idDinamicoBtAcao'] = 'string';
	s['idDinamicoBtNovo'] = 'string';
	s['idDinamicoGridCampos'] = 'string';
	s['idDinamicoGridConteudo'] = 'string';
	s['idDinamicoGrupoLabelTitulo'] = 'string';
	s['idDinamicoHtml'] = 'string';
	s['idDinamicoLabelTitulo'] = 'string';
	s['posicaoAtual'] = 'string';
	s['scsAlignValorGrid'] = 'string';
	s['scsCampoLayout'] = 'string';
	s['scsCampoObrigatorio'] = 'string';
	s['scsCamposControle'] = 'string';
	s['scsCamposPersistenecia'] = 'string';
	s['scsCaption'] = 'string';
	s['scsCasasDecimaisGrid'] = 'string';
	s['scsChoiceColumn'] = 'string';
	s['scsCols'] = 'string';
	s['scsComboType'] = 'string';
	s['scsContainerStyle'] = 'string';
	s['scsControlStyle'] = 'string';
	s['scsCustomLayout'] = 'boolean';
	s['scsDisabled'] = 'string';
	s['scsDisplayColumns'] = 'string';
	s['scsDisplayList'] = 'string';
	s['scsDropDownHeight'] = 'string';
	s['scsDropDownWidth'] = 'string';
	s['scsEditable'] = 'string';
	s['scsEnclosingClass'] = 'string';
	s['scsEnclosingStyle'] = 'string';
	s['scsFinalAdicionaGenerico'] = 'string';
	s['scsFinalAtualizaGenerico'] = 'string';
	s['scsFinalExcluiGenerico'] = 'string';
	s['scsFinalLimpaGenerico'] = 'string';
	s['scsHeightTabelaGrid'] = 'string';
	s['scsHidden'] = 'string';
	s['scsHintClass'] = 'string';
	s['scsHintStyle'] = 'string';
	s['scsId'] = 'string';
	s['scsIdGrid'] = 'string';
	s['scsIdGridInput'] = 'string';
	s['scsInicioAdicionaGenerico'] = 'string';
	s['scsInicioAtualizaGenerico'] = 'string';
	s['scsInicioExcluiGenerico'] = 'string';
	s['scsInicioLimpaGenerico'] = 'string';
	s['scsLabel'] = 'string';
	s['scsLabelClass'] = 'string';
	s['scsLabelGrid'] = 'string';
	s['scsLabelPosition'] = 'string';
	s['scsLabelStyle'] = 'string';
	s['scsLarguraColunasGrid'] = 'string';
	s['scsMargemGrupoCampos'] = 'string';
	s['scsMaxRows'] = 'string';
	s['scsMaxlength'] = 'string';
	s['scsMetodoEspecifico'] = 'string';
	s['scsMultiColumn'] = 'string';
	s['scsOcultaBarraTitulo'] = 'boolean';
	s['scsOcultaBotaoAdicionar'] = 'boolean';
	s['scsOcultaBotaoExcluir'] = 'boolean';
	s['scsOcultaBotoesPadrao'] = 'boolean';
	s['scsOcultaCamposEdicao'] = 'boolean';
	s['scsOnBlur'] = 'string';
	s['scsOnChange'] = 'string';
	s['scsOnClick'] = 'string';
	s['scsOnFocus'] = 'string';
	s['scsOnKeyDown'] = 'string';
	s['scsOnKeyPress'] = 'string';
	s['scsOnKeyUp'] = 'string';
	s['scsPermiteRepeticao'] = 'string';
	s['scsQtdCaracteresColunaGrid'] = 'string';
	s['scsQtdLinhaColuna'] = 'string';
	s['scsQueryClass'] = 'string';
	s['scsQueryName'] = 'string';
	s['scsReadOnly'] = 'string';
	s['scsRepositorioObjetos'] = 'string';
	s['scsRetornoSubValue'] = 'string';
	s['scsRows'] = 'string';
	s['scsSearchKeyLen'] = 'string';
	s['scsSize'] = 'string';
	s['scsSomenteVisualizacao'] = 'boolean';
	s['scsSql'] = 'string';
	s['scsSqlConvCodigoPropriedade'] = 'string';
	s['scsSqlGrid'] = 'string';
	s['scsSqlLookUp'] = 'string';
	s['scsStrTemp'] = 'string';
	s['scsTabIndex'] = 'string';
	s['scsTextMoedaValorMaximo'] = 'string';
	s['scsTextMoedaValorMinimo'] = 'string';
	s['scsTipo'] = 'string';
	s['scsTipoLayout'] = 'integer';
	s['scsTituloComponente'] = 'string';
	s['scsTodosSomenteLeitura'] = 'boolean';
	s['scsUtilizaValidacao'] = 'boolean';
	s['scsValue'] = 'string';
	s['scsValueList'] = 'string';
	s['scsWidth'] = 'string';
	s['scsWidthComponente'] = 'string';
	s['scsWidthTabelaGrid'] = 'string';
	s['strCampo1'] = 'string';
	s['strCampo10'] = 'string';
	s['strCampo11'] = 'string';
	s['strCampo12'] = 'string';
	s['strCampo13'] = 'string';
	s['strCampo14'] = 'string';
	s['strCampo15'] = 'string';
	s['strCampo16'] = 'string';
	s['strCampo17'] = 'string';
	s['strCampo18'] = 'string';
	s['strCampo2'] = 'string';
	s['strCampo3'] = 'string';
	s['strCampo4'] = 'string';
	s['strCampo5'] = 'string';
	s['strCampo6'] = 'string';
	s['strCampo7'] = 'string';
	s['strCampo8'] = 'string';
	s['strCampo9'] = 'string';
	s['strCampoAux'] = 'string';
	s['totalPosicoes'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_alterarCorLinha = function(posLinha) {
var componente = zenPage.getComponent(this.index)
var qtdLinha = componente.totalPosicoes
var linha = 1
var zebra = "#ffffff"
while(linha<=qtdLinha)
{
if ((linha%2) == 0){ zebra = "#e8f6e7" } else{ zebra = "#ffffff"}
var aux = componente.id + "linhagrid" + linha
var obj = document.getElementById(aux)
if (linha == posLinha)
{
obj.style.background = '#fbe091'
}
else
{
obj.style.background = zebra
}
linha = linha + 1
}
}

self.s00_componente_interface_scsCompositeGenerico_atualizaBotoesPadraoCliente = function() {
if ((this.scsSomenteVisualizacao) || (this.scsOcultaBotoesPadrao)) { return 1; }
this.getChildById(this.idDinamicoBtNovo).setProperty("hidden",true);
var btAcao = this.getChildById(this.idDinamicoBtAcao);
btAcao.setProperty("title","Adicionar");
btAcao.setProperty("onclick","zenPage.verificarAlteracaoCampo(); zenThis.composite.AdicionaGenerico(0);");
btAcao.setProperty("enclosingClass","botao_i_add");
if((this.scsOcultaBotaoAdicionar) && (btAcao.title = "Adicionar")){
btAcao.setProperty("hidden",true);
}else{
btAcao.setProperty("hidden",false);
}
if (this.scsTodosSomenteLeitura) {
this.getChildById("btNovo").setProperty("hidden",true);
this.getChildById("btAcao").setProperty("hidden",true);
}
return 1;
}

self.s00_componente_interface_scsCompositeGenerico_atualizaGridHtmlCliente = function() {
var conteudoTabelaHtml = ""
this.totalPosicoes = this.strCampo1.split(this.delimitadorMV).length;
if (this.scsTipoLayout == 1){
var larguraTabela = this.scsWidthComponente;
}else if (this.scsTipoLayout == 2){
var ajusteColunas = 32;
var larguraOriginalComponente = (parseInt(this.scsWidthComponente) - ajusteColunas);
var larguraTabela = (larguraOriginalComponente/2)+32;
}
conteudoTabelaHtml = "<table cellpadding='0' class='conteudoTabela' border='0' cellspacing='0'"+
"width='"+larguraTabela+"'>";
var scsIdGridList = this.scsIdGrid.split(this.delimitador);
var qtdColunasGrid = scsIdGridList.length;
var scsIdList = this.scsId.split(this.delimitador);
var qtdCampos = scsIdList.length;
var larguraList = this.scsLarguraColunasGrid.split(this.delimitador);
var labelList = this.scsLabelGrid.split(this.delimitador);
var strCabecalho = "";
for (numeroColuna=1;numeroColuna<=(qtdColunasGrid+1);numeroColuna++){
var campoColuna = scsIdGridList[(numeroColuna-1)];
for(numeroCampo=1;numeroCampo<=qtdCampos;numeroCampo++){
if (campoColuna == scsIdList[(numeroCampo-1)]){
var larguraColuna = larguraList[(numeroCampo-1)];
if (numeroColuna == 1){
var aux = "&#160;"
}else{
var aux = "";
}
strCabecalho += "<td align='left' width='"+larguraColuna+"'>"+ aux + labelList[(numeroCampo-1)] +"</td>";
}
}
}
var complemento = "16px";
if ((this.scsSomenteVisualizacao ) || (this.scsOcultaBotaoExcluir)) {
strCabecalho = strCabecalho + "<td style='border-OLADO: none; width:"+ complemento+ ";'>&#160;</td>";
}else{
strCabecalho = strCabecalho + "<td style='width:16px;'><img alt='Excluir Todos' src='img/icons/action_delete_all.png' onclick='javascript:zenPage.getComponent("+this.index+").LimpaComponente();' style='cursor:hand'/></td><td style='border-OLADO: none; width:"+ complemento+ ";'>&#160;</td>";
}
strCabecalho = "<tr class='linhaCabecalhoTabela' align='left'>" + strCabecalho + "</tr>" + "</table>";
conteudoTabelaHtml = conteudoTabelaHtml + strCabecalho;
larguraTabela = (larguraTabela - 17) //16px referente a barra de rolagem da tabela e 1px borda da tabela
larguraDiv = (larguraTabela + 16) //+16 referente a barra de rolagem da tabela
var tabelaDados = "<div style='height:"+this.scsHeightTabelaGrid+"; overflow-y: scroll; padding:0px; width:"+ larguraDiv +";'>"+
"<table cellpadding='0' class='conteudoTabela' cellspacing='0' border='0' width='"+larguraTabela+"'>";
var finalTabelaDados = "</table></div>";
conteudoTabelaHtml = conteudoTabelaHtml	+ tabelaDados + finalTabelaDados;
return conteudoTabelaHtml;
}

self.s00_componente_interface_scsCompositeGenerico_atualizaPropriedadeCliente = function(pPropriedade,pNaoUtilizado,valor,operacao) {
var retorno = "";
var componente = zenPage.getComponent(this.index)
if (operacao == "get"){
var retorno = componente.getProperty(pPropriedade);
var delimitador = componente.delimitadorMV;
var retorno = retorno.toString().replace(/delimitador/g,String.fromCharCode(253));
}else if(operacao == "set"){
componente.setProperty(pPropriedade,valor);
}
return retorno;
}

self.s00_componente_interface_scsCompositeGenerico_consultarGenerico = function() {
/* Método responsável por carregar itens na página ao realizar
* a execução do método consultar da classe padrão.
*/
var componente = zenPage.getComponent(this.index);
var prefixo = "formularioCadastro.";
var camposPersistencia = (componente.scsCamposPersistenecia).split(componente.delimitador);
var i = 0
var strTempAux = "strCampo"
for(i; i<= camposPersistencia.length-1; i++){
var campo = prefixo+camposPersistencia[i];
var propriedade = strTempAux+(i+1);
var valor = zenPage.getComponentById(campo).getValue()	;
var valorCampo = componente.atualizaPropriedadeCliente(propriedade, campo, valor, "set");
}
this.getChildById(componente.idDinamicoHtml).setProperty("content",this.AtualizaGridHtml());
return;
}

self.s00_componente_interface_scsCompositeGenerico_limpaCamposCliente = function() {
if((this.scsSomenteVisualizacao) || (this.scsOcultaCamposEdicao)) { return 1;}
var scsIdList = this.scsId.split(this.delimitador);
var qtdCampos = scsIdList.length;
for (i=0;i<qtdCampos;i++){
var campoInterface = scsIdList[i];
this.getChildById(campoInterface).setProperty("value","");
}
return 1;
}

self.s00_componente_interface_scsCompositeGenerico_limpaComponenteCliente = function() {
zenPage.verificarAlteracaoCampo();
var scsIdList = this.scsId.split(this.delimitador);
var qtdCampos = scsIdList.length;
var strTempAux = "strCampo";
this.ctrlDuplicado = "";
for(i=1;i<=qtdCampos;i++){
this.setProperty(strTempAux+i,"");
}
this.totalPosicoes = 0;
var retorno = this.atualizaBotoesPadraoCliente();
var retorno = this.limpaCamposCliente();
this.getChildById(this.idDinamicoHtml).setProperty("content",this.atualizaGridHtmlCliente());
return 1
}

self.s00_componente_interface_scsCompositeGenerico_recuperarGenerico = function() {
/* Método responsável por atribuir os valores das strings mv do componente aos
* respectivos campos do formulário. Este método deve ser executado através
* do método salvar sobrescrito na classe código do respectivo requisito.
*/
var componente = zenPage.getComponent(this.index);
var prefixo = "formularioCadastro.";
var camposPersistencia = (componente.scsCamposPersistenecia).split(componente.delimitador);
var alteraParaDelimitadorSV = (componente.scsRetornoSubValue).split(componente.delimitador);
var i = 0;
var strTempAux = "strCampo";
var sub = 0
for(i; i<= camposPersistencia.length-1; i++){
var campo = prefixo+camposPersistencia[i];
var str = strTempAux+(i+1);
var valorCampo = componente.atualizaPropriedadeCliente(str, campo, "", "get");
if(alteraParaDelimitadorSV[i] == 1){
var valorCampo = valorCampo.toString().replace(/componente.delimitadorMV/g, componente.delimitadorSV)
}
zenPage.getComponentById(campo).setValue(valorCampo);
zenPage.getComponentById(campo).onchangeHandler();
}
return
}

self.s00_componente_interface_scsCompositeGenerico_AdicionaGenerico = function(acao) {
	return zenInstanceMethod(this,'AdicionaGenerico','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_AtualizaConteudo = function() {
	return zenInstanceMethod(this,'AtualizaConteudo','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_AtualizaGenerico = function() {
	return zenInstanceMethod(this,'AtualizaGenerico','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_AtualizaGenericoTabela = function(pValor,pLinha,pColuna) {
	return zenInstanceMethod(this,'AtualizaGenericoTabela','L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_AtualizaPropriedade = function(pPropriedade,pNaoUtilizado,valor,operacao) {
	return zenInstanceMethod(this,'AtualizaPropriedade','L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_AtualizaPropriedadeInput = function(pNomeObjInput,pPropriedade,pValor) {
	return zenInstanceMethod(this,'AtualizaPropriedadeInput','L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_BuscaDadoTabela = function(pCodigo,pNumeroCampo) {
	return zenInstanceMethod(this,'BuscaDadoTabela','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_CamposReadOnly = function(pReadOnly) {
	return zenInstanceMethod(this,'CamposReadOnly','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_ConsultarGenericoServidor = function() {
	return zenInstanceMethod(this,'ConsultarGenericoServidor','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_DesenhaConteudo = function() {
	return zenInstanceMethod(this,'DesenhaConteudo','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_DesenhaEspecifico = function(comp,posicao,objGridCampos,tipo) {
	return zenInstanceMethod(this,'DesenhaEspecifico','L,L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_DesenhaGeral = function(comp,posicao,objGridCampos,tipo) {
	return zenInstanceMethod(this,'DesenhaGeral','L,L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_DesenhaLayoutEspecifico = function(objGridCampos) {
	return zenInstanceMethod(this,'DesenhaLayoutEspecifico','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_ExcluirGenerico = function(posicao) {
	zenInstanceMethod(this,'ExcluirGenerico','L','',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_LimpaCampos = function() {
	return zenInstanceMethod(this,'LimpaCampos','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_LocalizaPosicaoCampo = function(pCampo) {
	return zenInstanceMethod(this,'LocalizaPosicaoCampo','L','INTEGER',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_MetodoEspecifico = function(pParametrosMetodo) {
	return zenInstanceMethod(this,'MetodoEspecifico','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_MontaGrid = function(grid,linha,coluna) {
	return zenInstanceMethod(this,'MontaGrid','L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_PreencheCampos = function(linha) {
	zenInstanceMethod(this,'PreencheCampos','L','',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_PreparaValoresGrid = function(arrayD3,tipoCampo,numeroCampo,numeroColuna) {
	return zenInstanceMethod(this,'PreparaValoresGrid','L,L,L,L','HANDLE',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_RecuperaSomenteValor = function(pPropriedade) {
	return zenInstanceMethod(this,'RecuperaSomenteValor','L','INTEGER',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_VerificaCamposVazio = function() {
	return zenInstanceMethod(this,'VerificaCamposVazio','','BOOLEAN',arguments);
}

self.s00_componente_interface_scsCompositeGenerico_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeGenerico__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeGenerico.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeGenerico.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeGenerico;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeGenerico';
	p._type = 'scsCompositeGenerico';
	p.serialize = s00_componente_interface_scsCompositeGenerico_serialize;
	p.getSettings = s00_componente_interface_scsCompositeGenerico_getSettings;
	p.AdicionaGenerico = s00_componente_interface_scsCompositeGenerico_AdicionaGenerico;
	p.ApresentaExcecao = s00_componente_interface_scsCompositeGenerico_ApresentaExcecao;
	p.AtualizaBotoesPadrao = s00_componente_interface_scsCompositeGenerico_AtualizaBotoesPadrao;
	p.AtualizaConteudo = s00_componente_interface_scsCompositeGenerico_AtualizaConteudo;
	p.AtualizaGenerico = s00_componente_interface_scsCompositeGenerico_AtualizaGenerico;
	p.AtualizaGenericoTabela = s00_componente_interface_scsCompositeGenerico_AtualizaGenericoTabela;
	p.AtualizaGridHtml = s00_componente_interface_scsCompositeGenerico_AtualizaGridHtml;
	p.AtualizaPropriedade = s00_componente_interface_scsCompositeGenerico_AtualizaPropriedade;
	p.AtualizaPropriedadeInput = s00_componente_interface_scsCompositeGenerico_AtualizaPropriedadeInput;
	p.BuscaDadoTabela = s00_componente_interface_scsCompositeGenerico_BuscaDadoTabela;
	p.CamposReadOnly = s00_componente_interface_scsCompositeGenerico_CamposReadOnly;
	p.ConsultarGenericoServidor = s00_componente_interface_scsCompositeGenerico_ConsultarGenericoServidor;
	p.DesenhaConteudo = s00_componente_interface_scsCompositeGenerico_DesenhaConteudo;
	p.DesenhaEspecifico = s00_componente_interface_scsCompositeGenerico_DesenhaEspecifico;
	p.DesenhaGeral = s00_componente_interface_scsCompositeGenerico_DesenhaGeral;
	p.DesenhaLayoutEspecifico = s00_componente_interface_scsCompositeGenerico_DesenhaLayoutEspecifico;
	p.ExcluirGenerico = s00_componente_interface_scsCompositeGenerico_ExcluirGenerico;
	p.LimpaCampos = s00_componente_interface_scsCompositeGenerico_LimpaCampos;
	p.LimpaComponente = s00_componente_interface_scsCompositeGenerico_LimpaComponente;
	p.LocalizaPosicaoCampo = s00_componente_interface_scsCompositeGenerico_LocalizaPosicaoCampo;
	p.MetodoEspecifico = s00_componente_interface_scsCompositeGenerico_MetodoEspecifico;
	p.MontaGrid = s00_componente_interface_scsCompositeGenerico_MontaGrid;
	p.PreencheCampos = s00_componente_interface_scsCompositeGenerico_PreencheCampos;
	p.PreparaValoresGrid = s00_componente_interface_scsCompositeGenerico_PreparaValoresGrid;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeGenerico_ReallyRefreshContents;
	p.RecuperaSomenteValor = s00_componente_interface_scsCompositeGenerico_RecuperaSomenteValor;
	p.VerificaCamposVazio = s00_componente_interface_scsCompositeGenerico_VerificaCamposVazio;
	p.VerificaErro = s00_componente_interface_scsCompositeGenerico_VerificaErro;
	p.alterarCorLinha = s00_componente_interface_scsCompositeGenerico_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente_interface_scsCompositeGenerico_atualizaBotoesPadraoCliente;
	p.atualizaGridHtmlCliente = s00_componente_interface_scsCompositeGenerico_atualizaGridHtmlCliente;
	p.atualizaPropriedadeCliente = s00_componente_interface_scsCompositeGenerico_atualizaPropriedadeCliente;
	p.consultarGenerico = s00_componente_interface_scsCompositeGenerico_consultarGenerico;
	p.limpaCamposCliente = s00_componente_interface_scsCompositeGenerico_limpaCamposCliente;
	p.limpaComponenteCliente = s00_componente_interface_scsCompositeGenerico_limpaComponenteCliente;
	p.recuperarGenerico = s00_componente_interface_scsCompositeGenerico_recuperarGenerico;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeMV1'] = 's00_componente_interface_scsCompositeMV1';
self.s00_componente_interface_scsCompositeMV1 = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeMV1__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeMV1__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.Classe = '';
	o.Descricao = '';
	o.Locar = false;
	o.SomenteLeitura = false;
	o.ValorId = '';
}
function s00_componente_interface_scsCompositeMV1_serialize(set,s)
{
	var o = this;s[0]='3253688689';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.Classe;s[7]=o.Descricao;s[8]=(o.Locar?1:0);s[9]=(o.SomenteLeitura?1:0);s[10]=o.ValorId;s[11]=o.align;s[12]=o.aux;s[13]=o.cellAlign;s[14]=o.cellSize;s[15]=o.cellStyle;s[16]=o.cellVAlign;s[17]=set.serializeList(o,o.children,true,'children');s[18]=(o.childrenCreated?1:0);s[19]=o.containerStyle;s[20]=(o.disabled?1:0);s[21]=(o.dragEnabled?1:0);s[22]=(o.dropEnabled?1:0);s[23]=(o.dynamic?1:0);s[24]=o.enclosingClass;s[25]=o.enclosingStyle;s[26]=o.error;s[27]=o.groupClass;s[28]=o.groupStyle;s[29]=o.height;s[30]=(o.hidden?1:0);s[31]=o.hint;s[32]=o.hintClass;s[33]=o.hintStyle;s[34]=o.label;s[35]=o.labelClass;s[36]=o.labelDisabledClass;s[37]=o.labelPosition;s[38]=o.labelStyle;s[39]=o.layout;s[40]=o.onafterdrag;s[41]=o.onbeforedrag;s[42]=o.onclick;s[43]=o.ondrag;s[44]=o.ondrop;s[45]=o.onhide;s[46]=o.onrefresh;s[47]=o.onshow;s[48]=o.onupdate;s[49]=o.overlayMode;s[50]=o.renderFlag;s[51]=(o.showLabel?1:0);s[52]=o.slice;s[53]=o.title;s[54]=o.tuple;s[55]=o.valign;s[56]=(o.visible?1:0);s[57]=o.width;
}
function s00_componente_interface_scsCompositeMV1_getSettings(s)
{
	s['name'] = 'string';
	s['Classe'] = 'string';
	s['Descricao'] = 'string';
	s['Locar'] = 'string';
	s['SomenteLeitura'] = 'string';
	s['ValorId'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeMV1_removerComponente = function() {
if (this.Locar)
var retorno = this.LocarItem(this.Classe,"UNLOCK",this.ValorId);
zenPage.deleteComponent(this);
}

self.s00_componente_interface_scsCompositeMV1_Adicionar = function(Id,Container,ClasseItem,PropriedadeItem,MensagemErro,Locar,SomenteLeitura) {
	zenClassMethod(this,'Adicionar','L,L,L,L,L,L,B','',arguments);
}

self.s00_componente_interface_scsCompositeMV1_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV1_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMV1_Carregar = function(id,delimitador,container,classeItem,propriedadeItem,mensagemErro,locar,somenteLeitura) {
	return zenClassMethod(this,'Carregar','L,L,L,L,L,L,L,B','BOOLEAN',arguments);
}

self.s00_componente_interface_scsCompositeMV1_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV1_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV1_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV1_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV1_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV1_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV1_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV1_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV1_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV1_LocarItem = function(Classe,TipoLock,Id) {
	return zenClassMethod(this,'LocarItem','L,L,L','BOOLEAN',arguments);
}

self.s00_componente_interface_scsCompositeMV1_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeMV1_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV1_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMV1_SetarCampoId = function(container,delimitador) {
	return zenClassMethod(this,'SetarCampoId','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV1_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}

self.s00_componente_interface_scsCompositeMV1_VerificarSeExisteMV = function(Container,Id,MensagemErro) {
	return zenClassMethod(this,'VerificarSeExisteMV','L,L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeMV1__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeMV1.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeMV1.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeMV1;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeMV1';
	p._type = 'scsCompositeMV1';
	p.serialize = s00_componente_interface_scsCompositeMV1_serialize;
	p.getSettings = s00_componente_interface_scsCompositeMV1_getSettings;
	p.Adicionar = s00_componente_interface_scsCompositeMV1_Adicionar;
	p.AjustaTamanhoValor = s00_componente_interface_scsCompositeMV1_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente_interface_scsCompositeMV1_ApresentaExcecao;
	p.Carregar = s00_componente_interface_scsCompositeMV1_Carregar;
	p.GeraCheckBoxHtml = s00_componente_interface_scsCompositeMV1_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente_interface_scsCompositeMV1_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente_interface_scsCompositeMV1_GeraRadioHtml;
	p.GeraSV1Label = s00_componente_interface_scsCompositeMV1_GeraSV1Label;
	p.GeraSV1Text = s00_componente_interface_scsCompositeMV1_GeraSV1Text;
	p.GeraSelectHtml = s00_componente_interface_scsCompositeMV1_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente_interface_scsCompositeMV1_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente_interface_scsCompositeMV1_GeraTextHtml;
	p.GetValorPropriedade = s00_componente_interface_scsCompositeMV1_GetValorPropriedade;
	p.LocarItem = s00_componente_interface_scsCompositeMV1_LocarItem;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeMV1_ReallyRefreshContents;
	p.RetornaValorCampo = s00_componente_interface_scsCompositeMV1_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente_interface_scsCompositeMV1_SetValorPropriedade;
	p.SetarCampoId = s00_componente_interface_scsCompositeMV1_SetarCampoId;
	p.VerificaErro = s00_componente_interface_scsCompositeMV1_VerificaErro;
	p.VerificarSeExisteMV = s00_componente_interface_scsCompositeMV1_VerificarSeExisteMV;
	p.removerComponente = s00_componente_interface_scsCompositeMV1_removerComponente;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeMV2'] = 's00_componente_interface_scsCompositeMV2';
self.s00_componente_interface_scsCompositeMV2 = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeMV2__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeMV2__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.ClasseColuna1 = '';
	o.ClasseColuna2 = '';
	o.Coluna1 = '';
	o.Coluna2 = '';
	o.Locar = false;
	o.TamanhoColuna1 = '300';
	o.TamanhoColuna2 = '300';
	o.TamanhoValorId = '10';
	o.TipoColuna2 = '';
	o.ValorId = '';
	o.ValorIdColuna2 = '';
}
function s00_componente_interface_scsCompositeMV2_serialize(set,s)
{
	var o = this;s[0]='1981819942';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.ClasseColuna1;s[7]=o.ClasseColuna2;s[8]=o.Coluna1;s[9]=o.Coluna2;s[10]=(o.Locar?1:0);s[11]=o.TamanhoColuna1;s[12]=o.TamanhoColuna2;s[13]=o.TamanhoValorId;s[14]=o.TipoColuna2;s[15]=o.ValorId;s[16]=o.ValorIdColuna2;s[17]=o.align;s[18]=o.aux;s[19]=o.cellAlign;s[20]=o.cellSize;s[21]=o.cellStyle;s[22]=o.cellVAlign;s[23]=set.serializeList(o,o.children,true,'children');s[24]=(o.childrenCreated?1:0);s[25]=o.containerStyle;s[26]=(o.disabled?1:0);s[27]=(o.dragEnabled?1:0);s[28]=(o.dropEnabled?1:0);s[29]=(o.dynamic?1:0);s[30]=o.enclosingClass;s[31]=o.enclosingStyle;s[32]=o.error;s[33]=o.groupClass;s[34]=o.groupStyle;s[35]=o.height;s[36]=(o.hidden?1:0);s[37]=o.hint;s[38]=o.hintClass;s[39]=o.hintStyle;s[40]=o.label;s[41]=o.labelClass;s[42]=o.labelDisabledClass;s[43]=o.labelPosition;s[44]=o.labelStyle;s[45]=o.layout;s[46]=o.onafterdrag;s[47]=o.onbeforedrag;s[48]=o.onclick;s[49]=o.ondrag;s[50]=o.ondrop;s[51]=o.onhide;s[52]=o.onrefresh;s[53]=o.onshow;s[54]=o.onupdate;s[55]=o.overlayMode;s[56]=o.renderFlag;s[57]=(o.showLabel?1:0);s[58]=o.slice;s[59]=o.title;s[60]=o.tuple;s[61]=o.valign;s[62]=(o.visible?1:0);s[63]=o.width;
}
function s00_componente_interface_scsCompositeMV2_getSettings(s)
{
	s['name'] = 'string';
	s['ClasseColuna1'] = 'string';
	s['ClasseColuna2'] = 'string';
	s['Coluna1'] = 'string';
	s['Coluna2'] = 'string';
	s['Locar'] = 'string';
	s['TamanhoColuna1'] = 'string';
	s['TamanhoColuna2'] = 'string';
	s['TamanhoValorId'] = 'string';
	s['TipoColuna2'] = 'string';
	s['ValorId'] = 'string';
	s['ValorIdColuna2'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeMV2_removerComponente = function() {
if (this.Locar)
if (this.ClasseColuna1 != ""){
var retorno = this.LocaItem(this.ClasseColuna1,"UNLOCK",this.ValorId);
}
if (this.ClasseColuna2 != ""){
var retorno = this.LocaItem(this.ClasseColuna2,"UNLOCK",this.ValorIdColuna2);
}
zenPage.deleteComponent(this);
}

self.s00_componente_interface_scsCompositeMV2_Adicionar = function(Id,ValorColuna2,Container,ClasseItem,PropriedadeItem,MensagemErro,Locar,TipoColuna) {
	return zenClassMethod(this,'Adicionar','L,L,L,L,L,L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMV2_AtualizaValor = function(valor) {
	return zenInstanceMethod(this,'AtualizaValor','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMV2_Carregar = function(ValorCampo1,ValorCampo2,Delimitador,Container,ClasseItem,PropriedadeItem,MensagemErro,Locar,TipoColuna) {
	return zenClassMethod(this,'Carregar','L,L,L,L,L,L,L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMV2_LocaItem = function(classe,tipoLock,id) {
	return zenClassMethod(this,'LocaItem','L,L,L','BOOLEAN',arguments);
}

self.s00_componente_interface_scsCompositeMV2_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeMV2_RemoverTodos = function(Containers) {
	return zenClassMethod(this,'RemoverTodos','L','BOOLEAN',arguments);
}

self.s00_componente_interface_scsCompositeMV2_SetarCampoColuna2 = function(Container,Delimitador) {
	return zenClassMethod(this,'SetarCampoColuna2','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV2_SetarCampoId = function(Container,Delimitador) {
	return zenClassMethod(this,'SetarCampoId','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV2_VerificarSeExisteMV = function(Container,Id,MensagemErro) {
	return zenClassMethod(this,'VerificarSeExisteMV','L,L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeMV2__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeMV2.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeMV2.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeMV2;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeMV2';
	p._type = 'scsCompositeMV2';
	p.serialize = s00_componente_interface_scsCompositeMV2_serialize;
	p.getSettings = s00_componente_interface_scsCompositeMV2_getSettings;
	p.Adicionar = s00_componente_interface_scsCompositeMV2_Adicionar;
	p.AtualizaValor = s00_componente_interface_scsCompositeMV2_AtualizaValor;
	p.Carregar = s00_componente_interface_scsCompositeMV2_Carregar;
	p.LocaItem = s00_componente_interface_scsCompositeMV2_LocaItem;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeMV2_ReallyRefreshContents;
	p.RemoverTodos = s00_componente_interface_scsCompositeMV2_RemoverTodos;
	p.SetarCampoColuna2 = s00_componente_interface_scsCompositeMV2_SetarCampoColuna2;
	p.SetarCampoId = s00_componente_interface_scsCompositeMV2_SetarCampoId;
	p.VerificarSeExisteMV = s00_componente_interface_scsCompositeMV2_VerificarSeExisteMV;
	p.removerComponente = s00_componente_interface_scsCompositeMV2_removerComponente;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeMV3'] = 's00_componente_interface_scsCompositeMV3';
self.s00_componente_interface_scsCompositeMV3 = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeMV3__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeMV3__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.ClasseColuna1 = '';
	o.ClasseColuna2 = '';
	o.Coluna1 = '';
	o.Coluna2 = '';
	o.Coluna3 = '';
	o.Locar = false;
	o.TamanhoColuna1 = '200';
	o.TamanhoColuna2 = '200';
	o.TamanhoColuna3 = '200';
	o.TamanhoValorId = '10';
	o.TipoColuna2 = '';
	o.TipoColuna3 = '';
	o.ValorId = '';
	o.ValorIdColuna2 = '';
}
function s00_componente_interface_scsCompositeMV3_serialize(set,s)
{
	var o = this;s[0]='4144225168';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.ClasseColuna1;s[7]=o.ClasseColuna2;s[8]=o.Coluna1;s[9]=o.Coluna2;s[10]=o.Coluna3;s[11]=(o.Locar?1:0);s[12]=o.TamanhoColuna1;s[13]=o.TamanhoColuna2;s[14]=o.TamanhoColuna3;s[15]=o.TamanhoValorId;s[16]=o.TipoColuna2;s[17]=o.TipoColuna3;s[18]=o.ValorId;s[19]=o.ValorIdColuna2;s[20]=o.align;s[21]=o.aux;s[22]=o.cellAlign;s[23]=o.cellSize;s[24]=o.cellStyle;s[25]=o.cellVAlign;s[26]=set.serializeList(o,o.children,true,'children');s[27]=(o.childrenCreated?1:0);s[28]=o.containerStyle;s[29]=(o.disabled?1:0);s[30]=(o.dragEnabled?1:0);s[31]=(o.dropEnabled?1:0);s[32]=(o.dynamic?1:0);s[33]=o.enclosingClass;s[34]=o.enclosingStyle;s[35]=o.error;s[36]=o.groupClass;s[37]=o.groupStyle;s[38]=o.height;s[39]=(o.hidden?1:0);s[40]=o.hint;s[41]=o.hintClass;s[42]=o.hintStyle;s[43]=o.label;s[44]=o.labelClass;s[45]=o.labelDisabledClass;s[46]=o.labelPosition;s[47]=o.labelStyle;s[48]=o.layout;s[49]=o.onafterdrag;s[50]=o.onbeforedrag;s[51]=o.onclick;s[52]=o.ondrag;s[53]=o.ondrop;s[54]=o.onhide;s[55]=o.onrefresh;s[56]=o.onshow;s[57]=o.onupdate;s[58]=o.overlayMode;s[59]=o.renderFlag;s[60]=(o.showLabel?1:0);s[61]=o.slice;s[62]=o.title;s[63]=o.tuple;s[64]=o.valign;s[65]=(o.visible?1:0);s[66]=o.width;
}
function s00_componente_interface_scsCompositeMV3_getSettings(s)
{
	s['name'] = 'string';
	s['ClasseColuna1'] = 'string';
	s['ClasseColuna2'] = 'string';
	s['Coluna1'] = 'string';
	s['Coluna2'] = 'string';
	s['Coluna3'] = 'string';
	s['Locar'] = 'string';
	s['TamanhoColuna1'] = 'string';
	s['TamanhoColuna2'] = 'string';
	s['TamanhoColuna3'] = 'string';
	s['TamanhoValorId'] = 'string';
	s['TipoColuna2'] = 'string';
	s['TipoColuna3'] = 'string';
	s['ValorId'] = 'string';
	s['ValorIdColuna2'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeMV3_removerComponente = function() {
if (this.Locar)
if (this.ClasseColuna1 != ""){
var retorno = this.LocaItem(this.ClasseColuna1,"UNLOCK",this.ValorId);
}
if (this.ClasseColuna2 != ""){
var retorno = this.LocaItem(this.ClasseColuna2,"UNLOCK",this.ValorIdColuna2);
}
zenPage.deleteComponent(this);
}

self.s00_componente_interface_scsCompositeMV3_Adicionar = function(Id,ValorColuna2,ValorColuna3,Container,ClasseItem,PropriedadeItem,MensagemErro,Locar,TipoColuna2,TipoColuna3) {
	return zenClassMethod(this,'Adicionar','L,L,L,L,L,L,L,L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMV3_AtualizaValor = function(valor) {
	return zenInstanceMethod(this,'AtualizaValor','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMV3_AtualizaValor2 = function(valor) {
	return zenInstanceMethod(this,'AtualizaValor2','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMV3_Carregar = function(ValorCampo1,ValorCampo2,ValorCampo3,Delimitador,Container,ClasseItem,PropriedadeItem,MensagemErro,Locar,TipoColuna2,TipoColuna3) {
	return zenClassMethod(this,'Carregar','L,L,L,L,L,L,L,L,L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeMV3_LocaItem = function(classe,tipoLock,id) {
	return zenClassMethod(this,'LocaItem','L,L,L','BOOLEAN',arguments);
}

self.s00_componente_interface_scsCompositeMV3_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeMV3_RemoverTodos = function(Containers) {
	return zenClassMethod(this,'RemoverTodos','L','BOOLEAN',arguments);
}

self.s00_componente_interface_scsCompositeMV3_SetarCampoColuna2 = function(Container,Delimitador) {
	return zenClassMethod(this,'SetarCampoColuna2','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV3_SetarCampoId = function(Container,Delimitador) {
	return zenClassMethod(this,'SetarCampoId','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeMV3_VerificarSeExisteMV = function(Container,Id,MensagemErro) {
	return zenClassMethod(this,'VerificarSeExisteMV','L,L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeMV3__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeMV3.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeMV3.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeMV3;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeMV3';
	p._type = 'scsCompositeMV3';
	p.serialize = s00_componente_interface_scsCompositeMV3_serialize;
	p.getSettings = s00_componente_interface_scsCompositeMV3_getSettings;
	p.Adicionar = s00_componente_interface_scsCompositeMV3_Adicionar;
	p.AtualizaValor = s00_componente_interface_scsCompositeMV3_AtualizaValor;
	p.AtualizaValor2 = s00_componente_interface_scsCompositeMV3_AtualizaValor2;
	p.Carregar = s00_componente_interface_scsCompositeMV3_Carregar;
	p.LocaItem = s00_componente_interface_scsCompositeMV3_LocaItem;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeMV3_ReallyRefreshContents;
	p.RemoverTodos = s00_componente_interface_scsCompositeMV3_RemoverTodos;
	p.SetarCampoColuna2 = s00_componente_interface_scsCompositeMV3_SetarCampoColuna2;
	p.SetarCampoId = s00_componente_interface_scsCompositeMV3_SetarCampoId;
	p.VerificarSeExisteMV = s00_componente_interface_scsCompositeMV3_VerificarSeExisteMV;
	p.removerComponente = s00_componente_interface_scsCompositeMV3_removerComponente;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeNivelAcesso'] = 's00_componente_interface_scsCompositeNivelAcesso';
self.s00_componente_interface_scsCompositeNivelAcesso = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeNivelAcesso__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeNivelAcesso__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.CodigoMenu = '';
	o.CtrlArvoreMenus = '';
	o.CtrlMarcaFilhos = false;
	o.IdFilhoMarcaFilhosTemp = '';
	o.IdPaiMarcaFilhosTemp = '';
	o.Recurso = '';
	o.TipoMenu = '';
	o.scsIdMenuRaiz = '';
	o.scsIdMenuTemp = '';
	o.sistema = '';
}
function s00_componente_interface_scsCompositeNivelAcesso_serialize(set,s)
{
	var o = this;s[0]='3558963521';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.CodigoMenu;s[7]=o.CtrlArvoreMenus;s[8]=(o.CtrlMarcaFilhos?1:0);s[9]=o.IdFilhoMarcaFilhosTemp;s[10]=o.IdPaiMarcaFilhosTemp;s[11]=o.Recurso;s[12]=o.TipoMenu;s[13]=o.align;s[14]=o.aux;s[15]=o.cellAlign;s[16]=o.cellSize;s[17]=o.cellStyle;s[18]=o.cellVAlign;s[19]=set.serializeList(o,o.children,true,'children');s[20]=(o.childrenCreated?1:0);s[21]=o.containerStyle;s[22]=(o.disabled?1:0);s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.groupClass;s[30]=o.groupStyle;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=o.label;s[37]=o.labelClass;s[38]=o.labelDisabledClass;s[39]=o.labelPosition;s[40]=o.labelStyle;s[41]=o.layout;s[42]=o.onafterdrag;s[43]=o.onbeforedrag;s[44]=o.onclick;s[45]=o.ondrag;s[46]=o.ondrop;s[47]=o.onhide;s[48]=o.onrefresh;s[49]=o.onshow;s[50]=o.onupdate;s[51]=o.overlayMode;s[52]=o.renderFlag;s[53]=o.scsIdMenuRaiz;s[54]=o.scsIdMenuTemp;s[55]=(o.showLabel?1:0);s[56]=o.sistema;s[57]=o.slice;s[58]=o.title;s[59]=o.tuple;s[60]=o.valign;s[61]=(o.visible?1:0);s[62]=o.width;
}
function s00_componente_interface_scsCompositeNivelAcesso_getSettings(s)
{
	s['name'] = 'string';
	s['CodigoMenu'] = 'string';
	s['CtrlArvoreMenus'] = 'string';
	s['CtrlMarcaFilhos'] = 'string';
	s['IdFilhoMarcaFilhosTemp'] = 'string';
	s['IdPaiMarcaFilhosTemp'] = 'string';
	s['Recurso'] = 'string';
	s['TipoMenu'] = 'string';
	s['scsIdMenuRaiz'] = 'string';
	s['scsIdMenuTemp'] = 'string';
	s['sistema'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_ArmazenaArvoreMenus = function(pIdMenuAtual,pIdMenuAnterior,pTipoItem) {
	return zenInstanceMethod(this,'ArmazenaArvoreMenus','L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_ConsultarNivelAcesso = function() {
	return zenInstanceMethod(this,'ConsultarNivelAcesso','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_DefineAcesso = function(pCodigoMenu,pCodigoRecurso,pValor,pIdCheckPai,pIdCheckThis) {
	return zenInstanceMethod(this,'DefineAcesso','L,L,B,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_DesenhaConteudoMenu = function(pObjMenuItem,pObjItemExpando,pObjCheckAnterior) {
	return zenInstanceMethod(this,'DesenhaConteudoMenu','O,O,O','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_DesenhaOpcaoMenuUltimoNivel = function(pObjOpcaoItemMenu,pObjRaizExpando,pObjCheckAnterior) {
	return zenInstanceMethod(this,'DesenhaOpcaoMenuUltimoNivel','O,O,O','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_DesenhaOpcaoSubMenu = function(pObjOpcaoItemMenu,pObjRaizExpando,pObjCheckAnterior) {
	return zenInstanceMethod(this,'DesenhaOpcaoSubMenu','L,O,O','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_DesenhaRecursosOpcao = function(pObjOpcaoItemMenu,pObjItemMenuExpando,pObjCheckAnterior) {
	return zenInstanceMethod(this,'DesenhaRecursosOpcao','O,O,O','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_MarcaFilhos = function(pId,pValor) {
	return zenInstanceMethod(this,'MarcaFilhos','L,B','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_MarcaRaizPai = function(pId,pValor,pIdObjCheckAnterior) {
	return zenInstanceMethod(this,'MarcaRaizPai','L,B,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_MarcaTodosRecursos = function(pIdObjCheck,pValor) {
	return zenInstanceMethod(this,'MarcaTodosRecursos','L,B','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_PreparaConteudoMenu = function(pListaIdExpandoPai) {
	return zenInstanceMethod(this,'PreparaConteudoMenu','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_RetornaIdPai = function(pId) {
	return zenInstanceMethod(this,'RetornaIdPai','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_VerificaFilhosDefinidos = function(pIdCheck,pListaMenu) {
	return zenInstanceMethod(this,'VerificaFilhosDefinidos','L,L','BOOLEAN',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_VerificaSistema = function() {
	return zenInstanceMethod(this,'VerificaSistema','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_VerificaTipoMenu = function(pIdCampoInterface) {
	return zenInstanceMethod(this,'VerificaTipoMenu','L','INTEGER',arguments);
}

self.s00_componente_interface_scsCompositeNivelAcesso_VerificaVariosFilhos = function(pId) {
	return zenInstanceMethod(this,'VerificaVariosFilhos','L','STATUS',arguments);
}
self.s00_componente_interface_scsCompositeNivelAcesso__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeNivelAcesso.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeNivelAcesso.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeNivelAcesso;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeNivelAcesso';
	p._type = 'scsCompositeNivelAcesso';
	p.serialize = s00_componente_interface_scsCompositeNivelAcesso_serialize;
	p.getSettings = s00_componente_interface_scsCompositeNivelAcesso_getSettings;
	p.ArmazenaArvoreMenus = s00_componente_interface_scsCompositeNivelAcesso_ArmazenaArvoreMenus;
	p.ConsultarNivelAcesso = s00_componente_interface_scsCompositeNivelAcesso_ConsultarNivelAcesso;
	p.DefineAcesso = s00_componente_interface_scsCompositeNivelAcesso_DefineAcesso;
	p.DesenhaConteudoMenu = s00_componente_interface_scsCompositeNivelAcesso_DesenhaConteudoMenu;
	p.DesenhaOpcaoMenuUltimoNivel = s00_componente_interface_scsCompositeNivelAcesso_DesenhaOpcaoMenuUltimoNivel;
	p.DesenhaOpcaoSubMenu = s00_componente_interface_scsCompositeNivelAcesso_DesenhaOpcaoSubMenu;
	p.DesenhaRecursosOpcao = s00_componente_interface_scsCompositeNivelAcesso_DesenhaRecursosOpcao;
	p.LimpaComponente = s00_componente_interface_scsCompositeNivelAcesso_LimpaComponente;
	p.MarcaFilhos = s00_componente_interface_scsCompositeNivelAcesso_MarcaFilhos;
	p.MarcaRaizPai = s00_componente_interface_scsCompositeNivelAcesso_MarcaRaizPai;
	p.MarcaTodosRecursos = s00_componente_interface_scsCompositeNivelAcesso_MarcaTodosRecursos;
	p.PreparaConteudoMenu = s00_componente_interface_scsCompositeNivelAcesso_PreparaConteudoMenu;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeNivelAcesso_ReallyRefreshContents;
	p.RetornaIdPai = s00_componente_interface_scsCompositeNivelAcesso_RetornaIdPai;
	p.VerificaFilhosDefinidos = s00_componente_interface_scsCompositeNivelAcesso_VerificaFilhosDefinidos;
	p.VerificaSistema = s00_componente_interface_scsCompositeNivelAcesso_VerificaSistema;
	p.VerificaTipoMenu = s00_componente_interface_scsCompositeNivelAcesso_VerificaTipoMenu;
	p.VerificaVariosFilhos = s00_componente_interface_scsCompositeNivelAcesso_VerificaVariosFilhos;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeTelefone'] = 's00_componente_interface_scsCompositeTelefone';
self.s00_componente_interface_scsCompositeTelefone = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeTelefone__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeTelefone__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.Atualizar = false;
	o.MensagensErro = new Object();
	o.PosicaoAtual = '0';
	o.TipoComponente = '';
	o.TotalPosicao = '0';
	o.delimitador = '|';
	o.delimitadorMV = '@VM';
	o.scsApresentaLabel = true;
	o.scsCamposPersistencia = 'formularioCadastro.TelefoneTipo|formularioCadastro.TelefoneDdi|formularioCadastro.TelefoneDdd|formularioCadastro.TelefoneNumero|formularioCadastro.TelefoneObservacao';
	o.scsDddObrigatorio = false;
	o.scsDdiObrigatorio = false;
	o.scsObsObrigatorio = false;
	o.scsPropriedadesComponente = 'strTipo|strDdi|strDdd|strNumero|strObs';
	o.scsTodosSomenteLeitura = false;
	o.strDdd = '';
	o.strDdi = '';
	o.strNumero = '';
	o.strObs = '';
	o.strTipo = '';
}
function s00_componente_interface_scsCompositeTelefone_serialize(set,s)
{
	var o = this;s[0]='3555249683';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=(o.Atualizar?1:0);s[7]=set.serializeArray(o,o.MensagensErro,false,'MensagensErro');s[8]=o.PosicaoAtual;s[9]=o.TipoComponente;s[10]=o.TotalPosicao;s[11]=o.align;s[12]=o.aux;s[13]=o.cellAlign;s[14]=o.cellSize;s[15]=o.cellStyle;s[16]=o.cellVAlign;s[17]=set.serializeList(o,o.children,true,'children');s[18]=(o.childrenCreated?1:0);s[19]=o.containerStyle;s[20]=o.delimitador;s[21]=o.delimitadorMV;s[22]=(o.disabled?1:0);s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.groupClass;s[30]=o.groupStyle;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=o.label;s[37]=o.labelClass;s[38]=o.labelDisabledClass;s[39]=o.labelPosition;s[40]=o.labelStyle;s[41]=o.layout;s[42]=o.onafterdrag;s[43]=o.onbeforedrag;s[44]=o.onclick;s[45]=o.ondrag;s[46]=o.ondrop;s[47]=o.onhide;s[48]=o.onrefresh;s[49]=o.onshow;s[50]=o.onupdate;s[51]=o.overlayMode;s[52]=o.renderFlag;s[53]=(o.scsApresentaLabel?1:0);s[54]=o.scsCamposPersistencia;s[55]=(o.scsDddObrigatorio?1:0);s[56]=(o.scsDdiObrigatorio?1:0);s[57]=(o.scsObsObrigatorio?1:0);s[58]=o.scsPropriedadesComponente;s[59]=(o.scsTodosSomenteLeitura?1:0);s[60]=(o.showLabel?1:0);s[61]=o.slice;s[62]=o.strDdd;s[63]=o.strDdi;s[64]=o.strNumero;s[65]=o.strObs;s[66]=o.strTipo;s[67]=o.title;s[68]=o.tuple;s[69]=o.valign;s[70]=(o.visible?1:0);s[71]=o.width;
}
function s00_componente_interface_scsCompositeTelefone_getSettings(s)
{
	s['name'] = 'string';
	s['Atualizar'] = 'string';
	s['MensagensErro'] = 'string';
	s['PosicaoAtual'] = 'string';
	s['TipoComponente'] = 'string';
	s['TotalPosicao'] = 'string';
	s['delimitador'] = 'string';
	s['delimitadorMV'] = 'string';
	s['scsApresentaLabel'] = 'boolean';
	s['scsCamposPersistencia'] = 'string';
	s['scsDddObrigatorio'] = 'boolean';
	s['scsDdiObrigatorio'] = 'boolean';
	s['scsObsObrigatorio'] = 'boolean';
	s['scsPropriedadesComponente'] = 'string';
	s['scsTodosSomenteLeitura'] = 'boolean';
	s['strDdd'] = 'string';
	s['strDdi'] = 'string';
	s['strNumero'] = 'string';
	s['strObs'] = 'string';
	s['strTipo'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_RecuperarTelefone = function() {
var componente = zenPage.getComponent(this.index);
zenPage.getComponentById("formularioCadastro.TelefoneTipo").setValue(componente.strTipo)
zenPage.getComponentById("formularioCadastro.TelefoneTipo").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneDdi").setValue(componente.strDdi)
zenPage.getComponentById("formularioCadastro.TelefoneDdi").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneDdd").setValue(componente.strDdd)
zenPage.getComponentById("formularioCadastro.TelefoneDdd").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneNumero").setValue(componente.strNumero)
zenPage.getComponentById("formularioCadastro.TelefoneNumero").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneObservacao").setValue(componente.strObs)
zenPage.getComponentById("formularioCadastro.TelefoneObservacao").onchangeHandler()
/*
PARAR NÃO UTILIZAR O MÉTODO GetValorPropriedade O CONTEÚDO ABAIXO
FOI COMEMTADO. INCIDENTE 3624
*/
var camposPersistencia = (componente.scsCamposPersistencia).split(componente.delimitador);
var camposComponente = (componente.scsPropriedadesComponente).split(componente.delimitador);
var i = 0;
for(i; i<= camposPersistencia.length-1; i++){
var campoPersistencia = camposPersistencia[i];
var campoComponente = camposComponente[i];
var valorCampo = this.getProperty(campoComponente);
zenPage.getComponentById(campoPersistencia).setValue(valorCampo);
zenPage.getComponentById(campoPersistencia).onchangeHandler();
}
return;
}

self.s00_componente_interface_scsCompositeTelefone_adicionaTelefoneCliente = function() {
var tipo = this.getChildById("telefoneTipo").getProperty("value");
var ddi = this.getChildById("telefoneDdi").getProperty("value");
var ddd = this.getChildById("telefoneDdd").getProperty("value");
var numero = this.getChildById("telefoneNumero").getProperty("value");
var obs = this.getChildById("telefoneObs").getProperty("value");
var erro = "";
if(this.removerEspacos(tipo) == ""){
erro = erro + "- Tipo \n";
}
if((this.removerEspacos(ddi) == "") && (this.scsDdiObrigatorio == 1)){
erro = erro + "- DDI \n";
}
if((this.removerEspacos(ddd) == "") && (this.scsDddObrigatorio == 1)){
erro = erro + "- DDD \n";
}
if(this.removerEspacos(numero) == ""){
erro = erro + "- Número \n";
}
if((this.removerEspacos(obs) == "") && (this.scsObsObrigatorio == 1)){
erro = erro + "- Observação \n";
}
if (erro != ""){
zenPage.alertaShift(this.MensagensErro["camposObrigatorios"]+"\n"+erro);
return 1;
}
if (this.Atualizar){
this.atualizaTelefoneCliente();
return 1;
}
if (this.strNumero == ""){
this.strTipo = tipo;
this.strDdi = ddi;
this.strDdd = ddd;
this.strNumero = numero;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
this.TotalPosicao = this.strNumero.split(this.delimitadorMV).length;
this.limpaCamposCliente();
return 1;
}

self.s00_componente_interface_scsCompositeTelefone_alterarCorLinha = function(posLinha) {
var comp = zenPage.getComponent(this.index);
var qtdLinha = comp.TotalPosicao;
var linha = 1;
while(linha<=qtdLinha)
{
var aux = "linhaTelefone"+linha;
var obj = document.getElementById(aux);
if ((linha%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (linha == posLinha){
obj.style.background = "#fbe091";
}else{
obj.style.background = zebra;
}
linha = linha + 1;
}
}

self.s00_componente_interface_scsCompositeTelefone_atualizaBotoesPadraoCliente = function(pAcao) {
if (pAcao==1){
this.getChildById("btNovo").setProperty("hidden",true);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Adicionar telefone");
this.Atualizar = 0;
btAcao.setProperty("onclick","zenThis.composite.adicionaTelefoneCliente(); zenThis.composite.atualizaGridHtmlCliente();")
btAcao.setProperty("enclosingClass","botao_i_add");
}else if (pAcao == 2){
this.getChildById("btNovo").setProperty("hidden",false);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Atualizar telefone");
this.Atualizar = 1;
btAcao.setProperty("onclick","zenThis.composite.adicionaTelefoneCliente(); zenThis.composite.atualizaGridHtmlCliente();")
btAcao.setProperty("enclosingClass","botao_i_refresh_red");
}
if (this.scsTodosSomenteLeitura){
this.getChildById("btNovo").setHidden(true);
this.getChildById("btAcao").setHidden(true);
}
return 1;
}

self.s00_componente_interface_scsCompositeTelefone_atualizaGridHtmlCliente = function() {
var objHtml = this.getChildById("telefoneGrid");
objHtml.setProperty("content",this.desenhaGridHtmlCliente());
return 1;
}

self.s00_componente_interface_scsCompositeTelefone_atualizaTelefoneCliente = function() {
var retorno = true;
try{
var tipo = this.getChildById("telefoneTipo").getProperty("value");
var ddi = this.getChildById("telefoneDdi").getProperty("value");
var ddd = this.getChildById("telefoneDdd").getProperty("value");
var numero = this.getChildById("telefoneNumero").getProperty("value");
var obs = this.getChildById("telefoneObs").getProperty("value");
var tTipo = this.strTipo.split(this.delimitadorMV);
var tDdi = this.strDdi.split(this.delimitadorMV);
var tDdd = this.strDdd.split(this.delimitadorMV);
var tNumero = this.strNumero.split(this.delimitadorMV);
var tObs = this.strObs.split(this.delimitadorMV);
this.strTipo = "";
this.strDdi = "";
this.strDdd = "";
this.strNumero = "";
this.strObs = "";
for(i=0;i<this.TotalPosicao;i++){
if (this.PosicaoAtual == (i+1)){
if (this.strNumero==""){
this.strTipo = tipo;
this.strDdi = ddi;
this.strDdd = ddd;
this.strNumero = numero;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
}else{
if (this.strNumero == ""){
this.strTipo = tTipo[i];
this.strDdi = tDdi[i];
this.strDdd = tDdd[i];
this.strNumero = tNumero[i];
this.strObs = tObs[i];
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tTipo[i];
this.strDdi = this.strDdi + this.delimitadorMV + tDdi[i];
this.strDdd = this.strDdd + this.delimitadorMV + tDdd[i];
this.strNumero = this.strNumero + this.delimitadorMV + tNumero[i];
this.strObs = this.strObs + this.delimitadorMV + tObs[i];
}
}
}
this.atualizaBotoesPadraoCliente(1);
var retorno = this.limpaCamposCliente();
}catch(ex){
retorno = false;
zenPage.alertaShift("atualizaTelefoneCliente(): "+ex.description);
}
return 1
}

self.s00_componente_interface_scsCompositeTelefone_consultarTelefone = function() {
var componente = zenPage.getComponent(this.index);
componente.strTipo   = zenPage.getComponentById("formularioCadastro.TelefoneTipo").getValue()
componente.strDdi    = zenPage.getComponentById("formularioCadastro.TelefoneDdi").getValue()
componente.strDdd    = zenPage.getComponentById("formularioCadastro.TelefoneDdd").getValue()
componente.strNumero = zenPage.getComponentById("formularioCadastro.TelefoneNumero").getValue()
componente.strObs    = zenPage.getComponentById("formularioCadastro.TelefoneObservacao").getValue()
/*
PARAR NÃO UTILIZAR O MÉTODO GetValorPropriedade O CONTEÚDO ABAIXO
FOI COMEMTADO. INCIDENTE 3624
*/
var camposPersistencia = (componente.scsCamposPersistencia).split(componente.delimitador);
var propriedadesComponente = (componente.scsPropriedadesComponente).split(componente.delimitador);
var i = 0;
for(i; i<= camposPersistencia.length-1; i++){
var campoPersistencia = camposPersistencia[i];	//campo persistente para recuperar o valor
var propriedadeComponente = propriedadesComponente[i]; //propriedade do componente que deve receber o valor
var valorPersistente = zenPage.getComponentById(campoPersistencia).getValue();
this.setProperty(propriedadeComponente, valorPersistente);
}
var retorno = componente.atualizaGridHtmlCliente();
return;
}

self.s00_componente_interface_scsCompositeTelefone_desenhaGridHtmlCliente = function() {
var strGridHtml = "";
var strNumeroList = this.strNumero.split(this.delimitadorMV);
this.TotalPosicao = strNumeroList.length;
if (this.TipoComponente == "scsCompositeTelefone2"){
strGridHtml +=
"<div>"+
"<table cellpadding='0' class='scsCompositeTelefone2' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;' width='360'>";
}else if(this.TipoComponente == "scsCompositeTelefone3"){
strGridHtml +=
"<div>"+
"<table cellpadding='0' cellspacing='0' scsCompositeTelefone2='scsCompositeTelefone3'>";
}else if(this.TipoComponente == "scsCompositeTelefone4"){
strGridHtml +=
"<table cellpadding='0' class='scsCompositeTelefone4' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;' width='880'>"+
"<tr style='font-size:8pt; cursor:hand; background-color:#D2E1EE; height: 20px;'>"+
"<td width='200' style='padding-left: 12px'>Tipo</td>"+
"<td width='200' style='padding-left: 12px'>Telefone</td>"+
"<td width='450' style='padding-left: 12px'>Observações</td>"+
"<td width='60'></td>"+
"</tr>"+
"</table>"+
"<div  style='height: 76px;overflow-y: scroll;' >"+
"<table cellpadding='0' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;' width='850'>"
}
if (this.strNumero != ""){
var strNumeroList = this.strNumero.split(this.delimitadorMV);
var strDddList = this.strDdd.split(this.delimitadorMV);
var strObsList = this.strObs.split(this.delimitadorMV);
var strTipoList = this.strTipo.split(this.delimitadorMV);
var qtdMV = strNumeroList.length;
for (i=0;i<qtdMV;i++){
var tipoTelefone = strTipoList[i];
if((tipoTelefone != "") && (tipoTelefone != undefined)){
tipoTelefone = parseInt(tipoTelefone);
}
switch(tipoTelefone){
case 1:
tipoTelefone = "Residencial";
break;
case 2:
tipoTelefone = "Comercial";
break;
case 3:
tipoTelefone = "Celular";
break;
case 4:
tipoTelefone = "Fax";
break;
case 5:
tipoTelefone = "Outros";
break;
default:
tipoTelefone = "&#160;";
break;
}
var ddd = strDddList[i];
var numero = strNumeroList[i];
var observacoes = strObsList[i];
var telefone = "(" + ddd + ") " + numero;
if (((i+1)%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (this.TipoComponente == "scsCompositeTelefone2"){
strGridHtml +=
"<tr height='30' id='linhaTelefone"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='141' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoTelefone+"</td>"+
"<td width='160' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
}else if (this.TipoComponente == "scsCompositeTelefone3"){
strGridHtml +=
"<tr id='linhaTelefone"+(i+1)+"'>"+
"<td onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoTelefone+"</td>"+
"<td onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
}else if (this.TipoComponente == "scsCompositeTelefone4"){
strGridHtml +=
"<tr height='30' id='linhaTelefone"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='200' style='padding-left: 12px; zebra;' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoTelefone+"</td>"+
"<td width='200' style='padding-left: 12px; zebra;' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>"+
"<td width='450' style='padding-left: 12px; zebra;' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+observacoes+"</td>";
}
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='30' align='rigth' style='vertical-align: middle;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='30' align='rigth' style='vertical-align: middle;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirTelefoneCliente("+(i+1)+");'/></td>"+
"</tr>"
}
}
}
strGridHtml += "</table></div>";
return strGridHtml;
}

self.s00_componente_interface_scsCompositeTelefone_excluirTelefoneCliente = function(posicao) {
var strNumeroList = this.strNumero.split(this.delimitadorMV);
var strDddList = this.strDdd.split(this.delimitadorMV);
var strDdiList = this.strDdi.split(this.delimitadorMV);
var strObsList = this.strObs.split(this.delimitadorMV);
var strTipoList = this.strTipo.split(this.delimitadorMV);
strNumeroList.splice((posicao-1),1);
strDddList.splice((posicao-1),1);
strDdiList.splice((posicao-1),1);
strObsList.splice((posicao-1),1);
strTipoList.splice((posicao-1),1);
this.strNumero = strNumeroList.join(this.delimitadorMV);
this.strDdd = strDddList.join(this.delimitadorMV);
this.strDdi = strDdiList.join(this.delimitadorMV);
this.strTipo = strTipoList.join(this.delimitadorMV);
this.strObs = strObsList.join(this.delimitadorMV);
this.TotalPosicao = this.TotalPosicao - 1;
this.PosicaoAtual = 0;
this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1)
var retorno = this.atualizaGridHtmlCliente()
return 1;
}

self.s00_componente_interface_scsCompositeTelefone_limpaCamposCliente = function() {
this.getChildById("telefoneTipo").setProperty("value","");
this.getChildById("telefoneDdi").setProperty("value","");
this.getChildById("telefoneDdd").setProperty("value","");
this.getChildById("telefoneNumero").setProperty("value","");
this.getChildById("telefoneObs").setProperty("value","");
return 1;
}

self.s00_componente_interface_scsCompositeTelefone_limpaComponenteCliente = function() {
if (this.strNumero == "")
return 1;
var retorno = this.limpaCamposCliente();
this.strTipo = "";
this.strDdi = "";
this.strDdd = "";
this.strNumero = "";
this.strObs = "";
var retorno = this.atualizaBotoesPadraoCliente(1);
var retorno = this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente_interface_scsCompositeTelefone_preencheCamposCliente = function(pPosicao) {
this.PosicaoAtual = (pPosicao);
var posicao = (pPosicao-1);
var tipo = this.strTipo.split(this.delimitadorMV);
var ddd = this.strDdd.split(this.delimitadorMV);
var ddi = this.strDdi.split(this.delimitadorMV);
var numero = this.strNumero.split(this.delimitadorMV);
var obs = this.strObs.split(this.delimitadorMV);
this.getChildById("telefoneTipo").setProperty("value",tipo[posicao]);
this.getChildById("telefoneDdd").setProperty("value",ddd[posicao]);
this.getChildById("telefoneDdi").setProperty("value",ddi[posicao]);
this.getChildById("telefoneNumero").setProperty("value",numero[posicao]);
this.getChildById("telefoneObs").setProperty("value",obs[posicao]);
var retorno = this.atualizaBotoesPadraoCliente(2);
return 1;
}

self.s00_componente_interface_scsCompositeTelefone_refreshHTML = function() {
var retorno = zenPage.atualizaGridHtmlCliente();
}

self.s00_componente_interface_scsCompositeTelefone_removerEspacos = function(pString) {
return pString.replace(/\s/g,"");
}

self.s00_componente_interface_scsCompositeTelefone_AdicionaTelefone = function(atualiza) {
	return zenInstanceMethod(this,'AdicionaTelefone','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_AtualizaTelefone = function() {
	return zenInstanceMethod(this,'AtualizaTelefone','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_DesenhaGridHtml = function() {
	return zenInstanceMethod(this,'DesenhaGridHtml','','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_ExcluirTelefone = function(posicao) {
	return zenInstanceMethod(this,'ExcluirTelefone','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_LimpaCampos = function() {
	return zenInstanceMethod(this,'LimpaCampos','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_PreencheCampos = function(posicao) {
	return zenInstanceMethod(this,'PreencheCampos','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_TodosSomenteLeitura = function(acao) {
	return zenInstanceMethod(this,'TodosSomenteLeitura','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeTelefone__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeTelefone.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeTelefone.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeTelefone;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeTelefone';
	p._type = 'scsCompositeTelefone';
	p.serialize = s00_componente_interface_scsCompositeTelefone_serialize;
	p.getSettings = s00_componente_interface_scsCompositeTelefone_getSettings;
	p.AdicionaTelefone = s00_componente_interface_scsCompositeTelefone_AdicionaTelefone;
	p.AjustaTamanhoValor = s00_componente_interface_scsCompositeTelefone_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente_interface_scsCompositeTelefone_ApresentaExcecao;
	p.AtualizaBotoesPadrao = s00_componente_interface_scsCompositeTelefone_AtualizaBotoesPadrao;
	p.AtualizaGridHtml = s00_componente_interface_scsCompositeTelefone_AtualizaGridHtml;
	p.AtualizaTelefone = s00_componente_interface_scsCompositeTelefone_AtualizaTelefone;
	p.DesenhaGridHtml = s00_componente_interface_scsCompositeTelefone_DesenhaGridHtml;
	p.ExcluirTelefone = s00_componente_interface_scsCompositeTelefone_ExcluirTelefone;
	p.GeraCheckBoxHtml = s00_componente_interface_scsCompositeTelefone_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente_interface_scsCompositeTelefone_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente_interface_scsCompositeTelefone_GeraRadioHtml;
	p.GeraSV1Label = s00_componente_interface_scsCompositeTelefone_GeraSV1Label;
	p.GeraSV1Text = s00_componente_interface_scsCompositeTelefone_GeraSV1Text;
	p.GeraSelectHtml = s00_componente_interface_scsCompositeTelefone_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente_interface_scsCompositeTelefone_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente_interface_scsCompositeTelefone_GeraTextHtml;
	p.GetValorPropriedade = s00_componente_interface_scsCompositeTelefone_GetValorPropriedade;
	p.LimpaCampos = s00_componente_interface_scsCompositeTelefone_LimpaCampos;
	p.LimpaComponente = s00_componente_interface_scsCompositeTelefone_LimpaComponente;
	p.PreencheCampos = s00_componente_interface_scsCompositeTelefone_PreencheCampos;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeTelefone_ReallyRefreshContents;
	p.RecuperarTelefone = s00_componente_interface_scsCompositeTelefone_RecuperarTelefone;
	p.RetornaValorCampo = s00_componente_interface_scsCompositeTelefone_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente_interface_scsCompositeTelefone_SetValorPropriedade;
	p.TodosSomenteLeitura = s00_componente_interface_scsCompositeTelefone_TodosSomenteLeitura;
	p.VerificaErro = s00_componente_interface_scsCompositeTelefone_VerificaErro;
	p.adicionaTelefoneCliente = s00_componente_interface_scsCompositeTelefone_adicionaTelefoneCliente;
	p.alterarCorLinha = s00_componente_interface_scsCompositeTelefone_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente_interface_scsCompositeTelefone_atualizaBotoesPadraoCliente;
	p.atualizaGridHtmlCliente = s00_componente_interface_scsCompositeTelefone_atualizaGridHtmlCliente;
	p.atualizaTelefoneCliente = s00_componente_interface_scsCompositeTelefone_atualizaTelefoneCliente;
	p.consultarTelefone = s00_componente_interface_scsCompositeTelefone_consultarTelefone;
	p.desenhaGridHtmlCliente = s00_componente_interface_scsCompositeTelefone_desenhaGridHtmlCliente;
	p.excluirTelefoneCliente = s00_componente_interface_scsCompositeTelefone_excluirTelefoneCliente;
	p.limpaCamposCliente = s00_componente_interface_scsCompositeTelefone_limpaCamposCliente;
	p.limpaComponenteCliente = s00_componente_interface_scsCompositeTelefone_limpaComponenteCliente;
	p.preencheCamposCliente = s00_componente_interface_scsCompositeTelefone_preencheCamposCliente;
	p.refreshHTML = s00_componente_interface_scsCompositeTelefone_refreshHTML;
	p.removerEspacos = s00_componente_interface_scsCompositeTelefone_removerEspacos;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeTelefone2'] = 's00_componente_interface_scsCompositeTelefone2';
self.s00_componente_interface_scsCompositeTelefone2 = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeTelefone2__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeTelefone2__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.Atualizar = false;
	o.MensagensErro = new Object();
	o.PosicaoAtual = '0';
	o.TipoComponente = '';
	o.TotalPosicao = '0';
	o.delimitador = '|';
	o.delimitadorMV = '@VM';
	o.scsApresentaLabel = true;
	o.scsCamposPersistencia = 'formularioCadastro.TelefoneTipo|formularioCadastro.TelefoneDdi|formularioCadastro.TelefoneDdd|formularioCadastro.TelefoneNumero|formularioCadastro.TelefoneObservacao';
	o.scsDddObrigatorio = false;
	o.scsDdiObrigatorio = false;
	o.scsObsObrigatorio = false;
	o.scsPropriedadesComponente = 'strTipo|strDdi|strDdd|strNumero|strObs';
	o.scsTodosSomenteLeitura = false;
	o.strDdd = '';
	o.strDdi = '';
	o.strNumero = '';
	o.strObs = '';
	o.strTipo = '';
}
function s00_componente_interface_scsCompositeTelefone2_serialize(set,s)
{
	var o = this;s[0]='3555249683';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=(o.Atualizar?1:0);s[7]=set.serializeArray(o,o.MensagensErro,false,'MensagensErro');s[8]=o.PosicaoAtual;s[9]=o.TipoComponente;s[10]=o.TotalPosicao;s[11]=o.align;s[12]=o.aux;s[13]=o.cellAlign;s[14]=o.cellSize;s[15]=o.cellStyle;s[16]=o.cellVAlign;s[17]=set.serializeList(o,o.children,true,'children');s[18]=(o.childrenCreated?1:0);s[19]=o.containerStyle;s[20]=o.delimitador;s[21]=o.delimitadorMV;s[22]=(o.disabled?1:0);s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.groupClass;s[30]=o.groupStyle;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=o.label;s[37]=o.labelClass;s[38]=o.labelDisabledClass;s[39]=o.labelPosition;s[40]=o.labelStyle;s[41]=o.layout;s[42]=o.onafterdrag;s[43]=o.onbeforedrag;s[44]=o.onclick;s[45]=o.ondrag;s[46]=o.ondrop;s[47]=o.onhide;s[48]=o.onrefresh;s[49]=o.onshow;s[50]=o.onupdate;s[51]=o.overlayMode;s[52]=o.renderFlag;s[53]=(o.scsApresentaLabel?1:0);s[54]=o.scsCamposPersistencia;s[55]=(o.scsDddObrigatorio?1:0);s[56]=(o.scsDdiObrigatorio?1:0);s[57]=(o.scsObsObrigatorio?1:0);s[58]=o.scsPropriedadesComponente;s[59]=(o.scsTodosSomenteLeitura?1:0);s[60]=(o.showLabel?1:0);s[61]=o.slice;s[62]=o.strDdd;s[63]=o.strDdi;s[64]=o.strNumero;s[65]=o.strObs;s[66]=o.strTipo;s[67]=o.title;s[68]=o.tuple;s[69]=o.valign;s[70]=(o.visible?1:0);s[71]=o.width;
}
function s00_componente_interface_scsCompositeTelefone2_getSettings(s)
{
	s['name'] = 'string';
	s['Atualizar'] = 'string';
	s['MensagensErro'] = 'string';
	s['PosicaoAtual'] = 'string';
	s['TipoComponente'] = 'string';
	s['TotalPosicao'] = 'string';
	s['delimitador'] = 'string';
	s['delimitadorMV'] = 'string';
	s['scsApresentaLabel'] = 'boolean';
	s['scsCamposPersistencia'] = 'string';
	s['scsDddObrigatorio'] = 'boolean';
	s['scsDdiObrigatorio'] = 'boolean';
	s['scsObsObrigatorio'] = 'boolean';
	s['scsPropriedadesComponente'] = 'string';
	s['scsTodosSomenteLeitura'] = 'boolean';
	s['strDdd'] = 'string';
	s['strDdi'] = 'string';
	s['strNumero'] = 'string';
	s['strObs'] = 'string';
	s['strTipo'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_RecuperarTelefone = function() {
var componente = zenPage.getComponent(this.index);
zenPage.getComponentById("formularioCadastro.TelefoneTipo").setValue(componente.strTipo)
zenPage.getComponentById("formularioCadastro.TelefoneTipo").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneDdi").setValue(componente.strDdi)
zenPage.getComponentById("formularioCadastro.TelefoneDdi").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneDdd").setValue(componente.strDdd)
zenPage.getComponentById("formularioCadastro.TelefoneDdd").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneNumero").setValue(componente.strNumero)
zenPage.getComponentById("formularioCadastro.TelefoneNumero").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneObservacao").setValue(componente.strObs)
zenPage.getComponentById("formularioCadastro.TelefoneObservacao").onchangeHandler()
/*
PARAR NÃO UTILIZAR O MÉTODO GetValorPropriedade O CONTEÚDO ABAIXO
FOI COMEMTADO. INCIDENTE 3624
*/
var camposPersistencia = (componente.scsCamposPersistencia).split(componente.delimitador);
var camposComponente = (componente.scsPropriedadesComponente).split(componente.delimitador);
var i = 0;
for(i; i<= camposPersistencia.length-1; i++){
var campoPersistencia = camposPersistencia[i];
var campoComponente = camposComponente[i];
var valorCampo = this.getProperty(campoComponente);
zenPage.getComponentById(campoPersistencia).setValue(valorCampo);
zenPage.getComponentById(campoPersistencia).onchangeHandler();
}
return;
}

self.s00_componente_interface_scsCompositeTelefone2_adicionaTelefoneCliente = function() {
var tipo = this.getChildById("telefoneTipo").getProperty("value");
var ddi = this.getChildById("telefoneDdi").getProperty("value");
var ddd = this.getChildById("telefoneDdd").getProperty("value");
var numero = this.getChildById("telefoneNumero").getProperty("value");
var obs = this.getChildById("telefoneObs").getProperty("value");
var erro = "";
if(this.removerEspacos(tipo) == ""){
erro = erro + "- Tipo \n";
}
if((this.removerEspacos(ddi) == "") && (this.scsDdiObrigatorio == 1)){
erro = erro + "- DDI \n";
}
if((this.removerEspacos(ddd) == "") && (this.scsDddObrigatorio == 1)){
erro = erro + "- DDD \n";
}
if(this.removerEspacos(numero) == ""){
erro = erro + "- Número \n";
}
if((this.removerEspacos(obs) == "") && (this.scsObsObrigatorio == 1)){
erro = erro + "- Observação \n";
}
if (erro != ""){
zenPage.alertaShift(this.MensagensErro["camposObrigatorios"]+"\n"+erro);
return 1;
}
if (this.Atualizar){
this.atualizaTelefoneCliente();
return 1;
}
if (this.strNumero == ""){
this.strTipo = tipo;
this.strDdi = ddi;
this.strDdd = ddd;
this.strNumero = numero;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
this.TotalPosicao = this.strNumero.split(this.delimitadorMV).length;
this.limpaCamposCliente();
return 1;
}

self.s00_componente_interface_scsCompositeTelefone2_alterarCorLinha = function(posLinha) {
var comp = zenPage.getComponent(this.index);
var qtdLinha = comp.TotalPosicao;
var linha = 1;
while(linha<=qtdLinha)
{
var aux = "linhaTelefone"+linha;
var obj = document.getElementById(aux);
if ((linha%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (linha == posLinha){
obj.style.background = "#fbe091";
}else{
obj.style.background = zebra;
}
linha = linha + 1;
}
}

self.s00_componente_interface_scsCompositeTelefone2_atualizaBotoesPadraoCliente = function(pAcao) {
if (pAcao==1){
this.getChildById("btNovo").setProperty("hidden",true);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Adicionar telefone");
this.Atualizar = 0;
btAcao.setProperty("onclick","zenThis.composite.adicionaTelefoneCliente(); zenThis.composite.atualizaGridHtmlCliente();")
btAcao.setProperty("enclosingClass","botao_i_add");
}else if (pAcao == 2){
this.getChildById("btNovo").setProperty("hidden",false);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Atualizar telefone");
this.Atualizar = 1;
btAcao.setProperty("onclick","zenThis.composite.adicionaTelefoneCliente(); zenThis.composite.atualizaGridHtmlCliente();")
btAcao.setProperty("enclosingClass","botao_i_refresh_red");
}
if (this.scsTodosSomenteLeitura){
this.getChildById("btNovo").setHidden(true);
this.getChildById("btAcao").setHidden(true);
}
return 1;
}

self.s00_componente_interface_scsCompositeTelefone2_atualizaGridHtmlCliente = function() {
var objHtml = this.getChildById("telefoneGrid");
objHtml.setProperty("content",this.desenhaGridHtmlCliente());
return 1;
}

self.s00_componente_interface_scsCompositeTelefone2_atualizaTelefoneCliente = function() {
var retorno = true;
try{
var tipo = this.getChildById("telefoneTipo").getProperty("value");
var ddi = this.getChildById("telefoneDdi").getProperty("value");
var ddd = this.getChildById("telefoneDdd").getProperty("value");
var numero = this.getChildById("telefoneNumero").getProperty("value");
var obs = this.getChildById("telefoneObs").getProperty("value");
var tTipo = this.strTipo.split(this.delimitadorMV);
var tDdi = this.strDdi.split(this.delimitadorMV);
var tDdd = this.strDdd.split(this.delimitadorMV);
var tNumero = this.strNumero.split(this.delimitadorMV);
var tObs = this.strObs.split(this.delimitadorMV);
this.strTipo = "";
this.strDdi = "";
this.strDdd = "";
this.strNumero = "";
this.strObs = "";
for(i=0;i<this.TotalPosicao;i++){
if (this.PosicaoAtual == (i+1)){
if (this.strNumero==""){
this.strTipo = tipo;
this.strDdi = ddi;
this.strDdd = ddd;
this.strNumero = numero;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
}else{
if (this.strNumero == ""){
this.strTipo = tTipo[i];
this.strDdi = tDdi[i];
this.strDdd = tDdd[i];
this.strNumero = tNumero[i];
this.strObs = tObs[i];
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tTipo[i];
this.strDdi = this.strDdi + this.delimitadorMV + tDdi[i];
this.strDdd = this.strDdd + this.delimitadorMV + tDdd[i];
this.strNumero = this.strNumero + this.delimitadorMV + tNumero[i];
this.strObs = this.strObs + this.delimitadorMV + tObs[i];
}
}
}
this.atualizaBotoesPadraoCliente(1);
var retorno = this.limpaCamposCliente();
}catch(ex){
retorno = false;
zenPage.alertaShift("atualizaTelefoneCliente(): "+ex.description);
}
return 1
}

self.s00_componente_interface_scsCompositeTelefone2_consultarTelefone = function() {
var componente = zenPage.getComponent(this.index);
componente.strTipo   = zenPage.getComponentById("formularioCadastro.TelefoneTipo").getValue()
componente.strDdi    = zenPage.getComponentById("formularioCadastro.TelefoneDdi").getValue()
componente.strDdd    = zenPage.getComponentById("formularioCadastro.TelefoneDdd").getValue()
componente.strNumero = zenPage.getComponentById("formularioCadastro.TelefoneNumero").getValue()
componente.strObs    = zenPage.getComponentById("formularioCadastro.TelefoneObservacao").getValue()
/*
PARAR NÃO UTILIZAR O MÉTODO GetValorPropriedade O CONTEÚDO ABAIXO
FOI COMEMTADO. INCIDENTE 3624
*/
var camposPersistencia = (componente.scsCamposPersistencia).split(componente.delimitador);
var propriedadesComponente = (componente.scsPropriedadesComponente).split(componente.delimitador);
var i = 0;
for(i; i<= camposPersistencia.length-1; i++){
var campoPersistencia = camposPersistencia[i];	//campo persistente para recuperar o valor
var propriedadeComponente = propriedadesComponente[i]; //propriedade do componente que deve receber o valor
var valorPersistente = zenPage.getComponentById(campoPersistencia).getValue();
this.setProperty(propriedadeComponente, valorPersistente);
}
var retorno = componente.atualizaGridHtmlCliente();
return;
}

self.s00_componente_interface_scsCompositeTelefone2_desenhaGridHtmlCliente = function() {
var strGridHtml = "";
var strNumeroList = this.strNumero.split(this.delimitadorMV);
this.TotalPosicao = strNumeroList.length;
if (this.TipoComponente == "scsCompositeTelefone2"){
strGridHtml +=
"<div>"+
"<table cellpadding='0' class='scsCompositeTelefone2' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;' width='360'>";
}else if(this.TipoComponente == "scsCompositeTelefone3"){
strGridHtml +=
"<div>"+
"<table cellpadding='0' cellspacing='0' scsCompositeTelefone2='scsCompositeTelefone3'>";
}else if(this.TipoComponente == "scsCompositeTelefone4"){
strGridHtml +=
"<table cellpadding='0' class='scsCompositeTelefone4' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;' width='880'>"+
"<tr style='font-size:8pt; cursor:hand; background-color:#D2E1EE; height: 20px;'>"+
"<td width='200' style='padding-left: 12px'>Tipo</td>"+
"<td width='200' style='padding-left: 12px'>Telefone</td>"+
"<td width='450' style='padding-left: 12px'>Observações</td>"+
"<td width='60'></td>"+
"</tr>"+
"</table>"+
"<div  style='height: 76px;overflow-y: scroll;' >"+
"<table cellpadding='0' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;' width='850'>"
}
if (this.strNumero != ""){
var strNumeroList = this.strNumero.split(this.delimitadorMV);
var strDddList = this.strDdd.split(this.delimitadorMV);
var strObsList = this.strObs.split(this.delimitadorMV);
var strTipoList = this.strTipo.split(this.delimitadorMV);
var qtdMV = strNumeroList.length;
for (i=0;i<qtdMV;i++){
var tipoTelefone = strTipoList[i];
if((tipoTelefone != "") && (tipoTelefone != undefined)){
tipoTelefone = parseInt(tipoTelefone);
}
switch(tipoTelefone){
case 1:
tipoTelefone = "Residencial";
break;
case 2:
tipoTelefone = "Comercial";
break;
case 3:
tipoTelefone = "Celular";
break;
case 4:
tipoTelefone = "Fax";
break;
case 5:
tipoTelefone = "Outros";
break;
default:
tipoTelefone = "&#160;";
break;
}
var ddd = strDddList[i];
var numero = strNumeroList[i];
var observacoes = strObsList[i];
var telefone = "(" + ddd + ") " + numero;
if (((i+1)%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (this.TipoComponente == "scsCompositeTelefone2"){
strGridHtml +=
"<tr height='30' id='linhaTelefone"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='141' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoTelefone+"</td>"+
"<td width='160' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
}else if (this.TipoComponente == "scsCompositeTelefone3"){
strGridHtml +=
"<tr id='linhaTelefone"+(i+1)+"'>"+
"<td onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoTelefone+"</td>"+
"<td onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
}else if (this.TipoComponente == "scsCompositeTelefone4"){
strGridHtml +=
"<tr height='30' id='linhaTelefone"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='200' style='padding-left: 12px; zebra;' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoTelefone+"</td>"+
"<td width='200' style='padding-left: 12px; zebra;' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>"+
"<td width='450' style='padding-left: 12px; zebra;' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+observacoes+"</td>";
}
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='30' align='rigth' style='vertical-align: middle;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='30' align='rigth' style='vertical-align: middle;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirTelefoneCliente("+(i+1)+");'/></td>"+
"</tr>"
}
}
}
strGridHtml += "</table></div>";
return strGridHtml;
}

self.s00_componente_interface_scsCompositeTelefone2_excluirTelefoneCliente = function(posicao) {
var strNumeroList = this.strNumero.split(this.delimitadorMV);
var strDddList = this.strDdd.split(this.delimitadorMV);
var strDdiList = this.strDdi.split(this.delimitadorMV);
var strObsList = this.strObs.split(this.delimitadorMV);
var strTipoList = this.strTipo.split(this.delimitadorMV);
strNumeroList.splice((posicao-1),1);
strDddList.splice((posicao-1),1);
strDdiList.splice((posicao-1),1);
strObsList.splice((posicao-1),1);
strTipoList.splice((posicao-1),1);
this.strNumero = strNumeroList.join(this.delimitadorMV);
this.strDdd = strDddList.join(this.delimitadorMV);
this.strDdi = strDdiList.join(this.delimitadorMV);
this.strTipo = strTipoList.join(this.delimitadorMV);
this.strObs = strObsList.join(this.delimitadorMV);
this.TotalPosicao = this.TotalPosicao - 1;
this.PosicaoAtual = 0;
this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1)
var retorno = this.atualizaGridHtmlCliente()
return 1;
}

self.s00_componente_interface_scsCompositeTelefone2_limpaCamposCliente = function() {
this.getChildById("telefoneTipo").setProperty("value","");
this.getChildById("telefoneDdi").setProperty("value","");
this.getChildById("telefoneDdd").setProperty("value","");
this.getChildById("telefoneNumero").setProperty("value","");
this.getChildById("telefoneObs").setProperty("value","");
return 1;
}

self.s00_componente_interface_scsCompositeTelefone2_limpaComponenteCliente = function() {
if (this.strNumero == "")
return 1;
var retorno = this.limpaCamposCliente();
this.strTipo = "";
this.strDdi = "";
this.strDdd = "";
this.strNumero = "";
this.strObs = "";
var retorno = this.atualizaBotoesPadraoCliente(1);
var retorno = this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente_interface_scsCompositeTelefone2_preencheCamposCliente = function(pPosicao) {
this.PosicaoAtual = (pPosicao);
var posicao = (pPosicao-1);
var tipo = this.strTipo.split(this.delimitadorMV);
var ddd = this.strDdd.split(this.delimitadorMV);
var ddi = this.strDdi.split(this.delimitadorMV);
var numero = this.strNumero.split(this.delimitadorMV);
var obs = this.strObs.split(this.delimitadorMV);
this.getChildById("telefoneTipo").setProperty("value",tipo[posicao]);
this.getChildById("telefoneDdd").setProperty("value",ddd[posicao]);
this.getChildById("telefoneDdi").setProperty("value",ddi[posicao]);
this.getChildById("telefoneNumero").setProperty("value",numero[posicao]);
this.getChildById("telefoneObs").setProperty("value",obs[posicao]);
var retorno = this.atualizaBotoesPadraoCliente(2);
return 1;
}

self.s00_componente_interface_scsCompositeTelefone2_refreshHTML = function() {
var retorno = zenPage.atualizaGridHtmlCliente();
}

self.s00_componente_interface_scsCompositeTelefone2_removerEspacos = function(pString) {
return pString.replace(/\s/g,"");
}

self.s00_componente_interface_scsCompositeTelefone2_AdicionaTelefone = function(atualiza) {
	return zenInstanceMethod(this,'AdicionaTelefone','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_AtualizaTelefone = function() {
	return zenInstanceMethod(this,'AtualizaTelefone','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_DesenhaGridHtml = function() {
	return zenInstanceMethod(this,'DesenhaGridHtml','','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_ExcluirTelefone = function(posicao) {
	return zenInstanceMethod(this,'ExcluirTelefone','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_LimpaCampos = function() {
	return zenInstanceMethod(this,'LimpaCampos','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_PreencheCampos = function(posicao) {
	return zenInstanceMethod(this,'PreencheCampos','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_TodosSomenteLeitura = function(acao) {
	return zenInstanceMethod(this,'TodosSomenteLeitura','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone2_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeTelefone2__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeTelefone2.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeTelefone2.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeTelefone2;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeTelefone2';
	p._type = 'scsCompositeTelefone2';
	p.serialize = s00_componente_interface_scsCompositeTelefone2_serialize;
	p.getSettings = s00_componente_interface_scsCompositeTelefone2_getSettings;
	p.AdicionaTelefone = s00_componente_interface_scsCompositeTelefone2_AdicionaTelefone;
	p.AjustaTamanhoValor = s00_componente_interface_scsCompositeTelefone2_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente_interface_scsCompositeTelefone2_ApresentaExcecao;
	p.AtualizaBotoesPadrao = s00_componente_interface_scsCompositeTelefone2_AtualizaBotoesPadrao;
	p.AtualizaGridHtml = s00_componente_interface_scsCompositeTelefone2_AtualizaGridHtml;
	p.AtualizaTelefone = s00_componente_interface_scsCompositeTelefone2_AtualizaTelefone;
	p.DesenhaGridHtml = s00_componente_interface_scsCompositeTelefone2_DesenhaGridHtml;
	p.ExcluirTelefone = s00_componente_interface_scsCompositeTelefone2_ExcluirTelefone;
	p.GeraCheckBoxHtml = s00_componente_interface_scsCompositeTelefone2_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente_interface_scsCompositeTelefone2_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente_interface_scsCompositeTelefone2_GeraRadioHtml;
	p.GeraSV1Label = s00_componente_interface_scsCompositeTelefone2_GeraSV1Label;
	p.GeraSV1Text = s00_componente_interface_scsCompositeTelefone2_GeraSV1Text;
	p.GeraSelectHtml = s00_componente_interface_scsCompositeTelefone2_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente_interface_scsCompositeTelefone2_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente_interface_scsCompositeTelefone2_GeraTextHtml;
	p.GetValorPropriedade = s00_componente_interface_scsCompositeTelefone2_GetValorPropriedade;
	p.LimpaCampos = s00_componente_interface_scsCompositeTelefone2_LimpaCampos;
	p.LimpaComponente = s00_componente_interface_scsCompositeTelefone2_LimpaComponente;
	p.PreencheCampos = s00_componente_interface_scsCompositeTelefone2_PreencheCampos;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeTelefone2_ReallyRefreshContents;
	p.RecuperarTelefone = s00_componente_interface_scsCompositeTelefone2_RecuperarTelefone;
	p.RetornaValorCampo = s00_componente_interface_scsCompositeTelefone2_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente_interface_scsCompositeTelefone2_SetValorPropriedade;
	p.TodosSomenteLeitura = s00_componente_interface_scsCompositeTelefone2_TodosSomenteLeitura;
	p.VerificaErro = s00_componente_interface_scsCompositeTelefone2_VerificaErro;
	p.adicionaTelefoneCliente = s00_componente_interface_scsCompositeTelefone2_adicionaTelefoneCliente;
	p.alterarCorLinha = s00_componente_interface_scsCompositeTelefone2_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente_interface_scsCompositeTelefone2_atualizaBotoesPadraoCliente;
	p.atualizaGridHtmlCliente = s00_componente_interface_scsCompositeTelefone2_atualizaGridHtmlCliente;
	p.atualizaTelefoneCliente = s00_componente_interface_scsCompositeTelefone2_atualizaTelefoneCliente;
	p.consultarTelefone = s00_componente_interface_scsCompositeTelefone2_consultarTelefone;
	p.desenhaGridHtmlCliente = s00_componente_interface_scsCompositeTelefone2_desenhaGridHtmlCliente;
	p.excluirTelefoneCliente = s00_componente_interface_scsCompositeTelefone2_excluirTelefoneCliente;
	p.limpaCamposCliente = s00_componente_interface_scsCompositeTelefone2_limpaCamposCliente;
	p.limpaComponenteCliente = s00_componente_interface_scsCompositeTelefone2_limpaComponenteCliente;
	p.preencheCamposCliente = s00_componente_interface_scsCompositeTelefone2_preencheCamposCliente;
	p.refreshHTML = s00_componente_interface_scsCompositeTelefone2_refreshHTML;
	p.removerEspacos = s00_componente_interface_scsCompositeTelefone2_removerEspacos;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeTelefone3'] = 's00_componente_interface_scsCompositeTelefone3';
self.s00_componente_interface_scsCompositeTelefone3 = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeTelefone3__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeTelefone3__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.Atualizar = false;
	o.MensagensErro = new Object();
	o.PosicaoAtual = '0';
	o.TipoComponente = '';
	o.TotalPosicao = '0';
	o.delimitador = '|';
	o.delimitadorMV = '@VM';
	o.scsApresentaLabel = true;
	o.scsCamposPersistencia = 'formularioCadastro.TelefoneTipo|formularioCadastro.TelefoneDdi|formularioCadastro.TelefoneDdd|formularioCadastro.TelefoneNumero|formularioCadastro.TelefoneObservacao';
	o.scsDddObrigatorio = false;
	o.scsDdiObrigatorio = false;
	o.scsObsObrigatorio = false;
	o.scsPropriedadesComponente = 'strTipo|strDdi|strDdd|strNumero|strObs';
	o.scsTodosSomenteLeitura = false;
	o.strDdd = '';
	o.strDdi = '';
	o.strNumero = '';
	o.strObs = '';
	o.strTipo = '';
}
function s00_componente_interface_scsCompositeTelefone3_serialize(set,s)
{
	var o = this;s[0]='3555249683';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=(o.Atualizar?1:0);s[7]=set.serializeArray(o,o.MensagensErro,false,'MensagensErro');s[8]=o.PosicaoAtual;s[9]=o.TipoComponente;s[10]=o.TotalPosicao;s[11]=o.align;s[12]=o.aux;s[13]=o.cellAlign;s[14]=o.cellSize;s[15]=o.cellStyle;s[16]=o.cellVAlign;s[17]=set.serializeList(o,o.children,true,'children');s[18]=(o.childrenCreated?1:0);s[19]=o.containerStyle;s[20]=o.delimitador;s[21]=o.delimitadorMV;s[22]=(o.disabled?1:0);s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.groupClass;s[30]=o.groupStyle;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=o.label;s[37]=o.labelClass;s[38]=o.labelDisabledClass;s[39]=o.labelPosition;s[40]=o.labelStyle;s[41]=o.layout;s[42]=o.onafterdrag;s[43]=o.onbeforedrag;s[44]=o.onclick;s[45]=o.ondrag;s[46]=o.ondrop;s[47]=o.onhide;s[48]=o.onrefresh;s[49]=o.onshow;s[50]=o.onupdate;s[51]=o.overlayMode;s[52]=o.renderFlag;s[53]=(o.scsApresentaLabel?1:0);s[54]=o.scsCamposPersistencia;s[55]=(o.scsDddObrigatorio?1:0);s[56]=(o.scsDdiObrigatorio?1:0);s[57]=(o.scsObsObrigatorio?1:0);s[58]=o.scsPropriedadesComponente;s[59]=(o.scsTodosSomenteLeitura?1:0);s[60]=(o.showLabel?1:0);s[61]=o.slice;s[62]=o.strDdd;s[63]=o.strDdi;s[64]=o.strNumero;s[65]=o.strObs;s[66]=o.strTipo;s[67]=o.title;s[68]=o.tuple;s[69]=o.valign;s[70]=(o.visible?1:0);s[71]=o.width;
}
function s00_componente_interface_scsCompositeTelefone3_getSettings(s)
{
	s['name'] = 'string';
	s['Atualizar'] = 'string';
	s['MensagensErro'] = 'string';
	s['PosicaoAtual'] = 'string';
	s['TipoComponente'] = 'string';
	s['TotalPosicao'] = 'string';
	s['delimitador'] = 'string';
	s['delimitadorMV'] = 'string';
	s['scsApresentaLabel'] = 'boolean';
	s['scsCamposPersistencia'] = 'string';
	s['scsDddObrigatorio'] = 'boolean';
	s['scsDdiObrigatorio'] = 'boolean';
	s['scsObsObrigatorio'] = 'boolean';
	s['scsPropriedadesComponente'] = 'string';
	s['scsTodosSomenteLeitura'] = 'boolean';
	s['strDdd'] = 'string';
	s['strDdi'] = 'string';
	s['strNumero'] = 'string';
	s['strObs'] = 'string';
	s['strTipo'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_RecuperarTelefone = function() {
var componente = zenPage.getComponent(this.index);
zenPage.getComponentById("formularioCadastro.TelefoneTipo").setValue(componente.strTipo)
zenPage.getComponentById("formularioCadastro.TelefoneTipo").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneDdi").setValue(componente.strDdi)
zenPage.getComponentById("formularioCadastro.TelefoneDdi").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneDdd").setValue(componente.strDdd)
zenPage.getComponentById("formularioCadastro.TelefoneDdd").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneNumero").setValue(componente.strNumero)
zenPage.getComponentById("formularioCadastro.TelefoneNumero").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneObservacao").setValue(componente.strObs)
zenPage.getComponentById("formularioCadastro.TelefoneObservacao").onchangeHandler()
/*
PARAR NÃO UTILIZAR O MÉTODO GetValorPropriedade O CONTEÚDO ABAIXO
FOI COMEMTADO. INCIDENTE 3624
*/
var camposPersistencia = (componente.scsCamposPersistencia).split(componente.delimitador);
var camposComponente = (componente.scsPropriedadesComponente).split(componente.delimitador);
var i = 0;
for(i; i<= camposPersistencia.length-1; i++){
var campoPersistencia = camposPersistencia[i];
var campoComponente = camposComponente[i];
var valorCampo = this.getProperty(campoComponente);
zenPage.getComponentById(campoPersistencia).setValue(valorCampo);
zenPage.getComponentById(campoPersistencia).onchangeHandler();
}
return;
}

self.s00_componente_interface_scsCompositeTelefone3_adicionaTelefoneCliente = function() {
var tipo = this.getChildById("telefoneTipo").getProperty("value");
var ddi = this.getChildById("telefoneDdi").getProperty("value");
var ddd = this.getChildById("telefoneDdd").getProperty("value");
var numero = this.getChildById("telefoneNumero").getProperty("value");
var obs = this.getChildById("telefoneObs").getProperty("value");
var erro = "";
if(this.removerEspacos(tipo) == ""){
erro = erro + "- Tipo \n";
}
if((this.removerEspacos(ddi) == "") && (this.scsDdiObrigatorio == 1)){
erro = erro + "- DDI \n";
}
if((this.removerEspacos(ddd) == "") && (this.scsDddObrigatorio == 1)){
erro = erro + "- DDD \n";
}
if(this.removerEspacos(numero) == ""){
erro = erro + "- Número \n";
}
if((this.removerEspacos(obs) == "") && (this.scsObsObrigatorio == 1)){
erro = erro + "- Observação \n";
}
if (erro != ""){
zenPage.alertaShift(this.MensagensErro["camposObrigatorios"]+"\n"+erro);
return 1;
}
if (this.Atualizar){
this.atualizaTelefoneCliente();
return 1;
}
if (this.strNumero == ""){
this.strTipo = tipo;
this.strDdi = ddi;
this.strDdd = ddd;
this.strNumero = numero;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
this.TotalPosicao = this.strNumero.split(this.delimitadorMV).length;
this.limpaCamposCliente();
return 1;
}

self.s00_componente_interface_scsCompositeTelefone3_alterarCorLinha = function(posLinha) {
var comp = zenPage.getComponent(this.index);
var qtdLinha = comp.TotalPosicao;
var linha = 1;
while(linha<=qtdLinha)
{
var aux = "linhaTelefone"+linha;
var obj = document.getElementById(aux);
if ((linha%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (linha == posLinha){
obj.style.background = "#fbe091";
}else{
obj.style.background = zebra;
}
linha = linha + 1;
}
}

self.s00_componente_interface_scsCompositeTelefone3_atualizaBotoesPadraoCliente = function(pAcao) {
if (pAcao==1){
this.getChildById("btNovo").setProperty("hidden",true);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Adicionar telefone");
this.Atualizar = 0;
btAcao.setProperty("onclick","zenThis.composite.adicionaTelefoneCliente(); zenThis.composite.atualizaGridHtmlCliente();")
btAcao.setProperty("enclosingClass","botao_i_add");
}else if (pAcao == 2){
this.getChildById("btNovo").setProperty("hidden",false);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Atualizar telefone");
this.Atualizar = 1;
btAcao.setProperty("onclick","zenThis.composite.adicionaTelefoneCliente(); zenThis.composite.atualizaGridHtmlCliente();")
btAcao.setProperty("enclosingClass","botao_i_refresh_red");
}
if (this.scsTodosSomenteLeitura){
this.getChildById("btNovo").setHidden(true);
this.getChildById("btAcao").setHidden(true);
}
return 1;
}

self.s00_componente_interface_scsCompositeTelefone3_atualizaGridHtmlCliente = function() {
var objHtml = this.getChildById("telefoneGrid");
objHtml.setProperty("content",this.desenhaGridHtmlCliente());
return 1;
}

self.s00_componente_interface_scsCompositeTelefone3_atualizaTelefoneCliente = function() {
var retorno = true;
try{
var tipo = this.getChildById("telefoneTipo").getProperty("value");
var ddi = this.getChildById("telefoneDdi").getProperty("value");
var ddd = this.getChildById("telefoneDdd").getProperty("value");
var numero = this.getChildById("telefoneNumero").getProperty("value");
var obs = this.getChildById("telefoneObs").getProperty("value");
var tTipo = this.strTipo.split(this.delimitadorMV);
var tDdi = this.strDdi.split(this.delimitadorMV);
var tDdd = this.strDdd.split(this.delimitadorMV);
var tNumero = this.strNumero.split(this.delimitadorMV);
var tObs = this.strObs.split(this.delimitadorMV);
this.strTipo = "";
this.strDdi = "";
this.strDdd = "";
this.strNumero = "";
this.strObs = "";
for(i=0;i<this.TotalPosicao;i++){
if (this.PosicaoAtual == (i+1)){
if (this.strNumero==""){
this.strTipo = tipo;
this.strDdi = ddi;
this.strDdd = ddd;
this.strNumero = numero;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
}else{
if (this.strNumero == ""){
this.strTipo = tTipo[i];
this.strDdi = tDdi[i];
this.strDdd = tDdd[i];
this.strNumero = tNumero[i];
this.strObs = tObs[i];
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tTipo[i];
this.strDdi = this.strDdi + this.delimitadorMV + tDdi[i];
this.strDdd = this.strDdd + this.delimitadorMV + tDdd[i];
this.strNumero = this.strNumero + this.delimitadorMV + tNumero[i];
this.strObs = this.strObs + this.delimitadorMV + tObs[i];
}
}
}
this.atualizaBotoesPadraoCliente(1);
var retorno = this.limpaCamposCliente();
}catch(ex){
retorno = false;
zenPage.alertaShift("atualizaTelefoneCliente(): "+ex.description);
}
return 1
}

self.s00_componente_interface_scsCompositeTelefone3_consultarTelefone = function() {
var componente = zenPage.getComponent(this.index);
componente.strTipo   = zenPage.getComponentById("formularioCadastro.TelefoneTipo").getValue()
componente.strDdi    = zenPage.getComponentById("formularioCadastro.TelefoneDdi").getValue()
componente.strDdd    = zenPage.getComponentById("formularioCadastro.TelefoneDdd").getValue()
componente.strNumero = zenPage.getComponentById("formularioCadastro.TelefoneNumero").getValue()
componente.strObs    = zenPage.getComponentById("formularioCadastro.TelefoneObservacao").getValue()
/*
PARAR NÃO UTILIZAR O MÉTODO GetValorPropriedade O CONTEÚDO ABAIXO
FOI COMEMTADO. INCIDENTE 3624
*/
var camposPersistencia = (componente.scsCamposPersistencia).split(componente.delimitador);
var propriedadesComponente = (componente.scsPropriedadesComponente).split(componente.delimitador);
var i = 0;
for(i; i<= camposPersistencia.length-1; i++){
var campoPersistencia = camposPersistencia[i];	//campo persistente para recuperar o valor
var propriedadeComponente = propriedadesComponente[i]; //propriedade do componente que deve receber o valor
var valorPersistente = zenPage.getComponentById(campoPersistencia).getValue();
this.setProperty(propriedadeComponente, valorPersistente);
}
var retorno = componente.atualizaGridHtmlCliente();
return;
}

self.s00_componente_interface_scsCompositeTelefone3_desenhaGridHtmlCliente = function() {
var strGridHtml = "";
var strNumeroList = this.strNumero.split(this.delimitadorMV);
this.TotalPosicao = strNumeroList.length;
if (this.TipoComponente == "scsCompositeTelefone2"){
strGridHtml +=
"<div>"+
"<table cellpadding='0' class='scsCompositeTelefone2' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;' width='360'>";
}else if(this.TipoComponente == "scsCompositeTelefone3"){
strGridHtml +=
"<div>"+
"<table cellpadding='0' cellspacing='0' scsCompositeTelefone2='scsCompositeTelefone3'>";
}else if(this.TipoComponente == "scsCompositeTelefone4"){
strGridHtml +=
"<table cellpadding='0' class='scsCompositeTelefone4' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;' width='880'>"+
"<tr style='font-size:8pt; cursor:hand; background-color:#D2E1EE; height: 20px;'>"+
"<td width='200' style='padding-left: 12px'>Tipo</td>"+
"<td width='200' style='padding-left: 12px'>Telefone</td>"+
"<td width='450' style='padding-left: 12px'>Observações</td>"+
"<td width='60'></td>"+
"</tr>"+
"</table>"+
"<div  style='height: 76px;overflow-y: scroll;' >"+
"<table cellpadding='0' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;' width='850'>"
}
if (this.strNumero != ""){
var strNumeroList = this.strNumero.split(this.delimitadorMV);
var strDddList = this.strDdd.split(this.delimitadorMV);
var strObsList = this.strObs.split(this.delimitadorMV);
var strTipoList = this.strTipo.split(this.delimitadorMV);
var qtdMV = strNumeroList.length;
for (i=0;i<qtdMV;i++){
var tipoTelefone = strTipoList[i];
if((tipoTelefone != "") && (tipoTelefone != undefined)){
tipoTelefone = parseInt(tipoTelefone);
}
switch(tipoTelefone){
case 1:
tipoTelefone = "Residencial";
break;
case 2:
tipoTelefone = "Comercial";
break;
case 3:
tipoTelefone = "Celular";
break;
case 4:
tipoTelefone = "Fax";
break;
case 5:
tipoTelefone = "Outros";
break;
default:
tipoTelefone = "&#160;";
break;
}
var ddd = strDddList[i];
var numero = strNumeroList[i];
var observacoes = strObsList[i];
var telefone = "(" + ddd + ") " + numero;
if (((i+1)%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (this.TipoComponente == "scsCompositeTelefone2"){
strGridHtml +=
"<tr height='30' id='linhaTelefone"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='141' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoTelefone+"</td>"+
"<td width='160' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
}else if (this.TipoComponente == "scsCompositeTelefone3"){
strGridHtml +=
"<tr id='linhaTelefone"+(i+1)+"'>"+
"<td onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoTelefone+"</td>"+
"<td onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
}else if (this.TipoComponente == "scsCompositeTelefone4"){
strGridHtml +=
"<tr height='30' id='linhaTelefone"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='200' style='padding-left: 12px; zebra;' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoTelefone+"</td>"+
"<td width='200' style='padding-left: 12px; zebra;' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>"+
"<td width='450' style='padding-left: 12px; zebra;' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+observacoes+"</td>";
}
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='30' align='rigth' style='vertical-align: middle;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='30' align='rigth' style='vertical-align: middle;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirTelefoneCliente("+(i+1)+");'/></td>"+
"</tr>"
}
}
}
strGridHtml += "</table></div>";
return strGridHtml;
}

self.s00_componente_interface_scsCompositeTelefone3_excluirTelefoneCliente = function(posicao) {
var strNumeroList = this.strNumero.split(this.delimitadorMV);
var strDddList = this.strDdd.split(this.delimitadorMV);
var strDdiList = this.strDdi.split(this.delimitadorMV);
var strObsList = this.strObs.split(this.delimitadorMV);
var strTipoList = this.strTipo.split(this.delimitadorMV);
strNumeroList.splice((posicao-1),1);
strDddList.splice((posicao-1),1);
strDdiList.splice((posicao-1),1);
strObsList.splice((posicao-1),1);
strTipoList.splice((posicao-1),1);
this.strNumero = strNumeroList.join(this.delimitadorMV);
this.strDdd = strDddList.join(this.delimitadorMV);
this.strDdi = strDdiList.join(this.delimitadorMV);
this.strTipo = strTipoList.join(this.delimitadorMV);
this.strObs = strObsList.join(this.delimitadorMV);
this.TotalPosicao = this.TotalPosicao - 1;
this.PosicaoAtual = 0;
this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1)
var retorno = this.atualizaGridHtmlCliente()
return 1;
}

self.s00_componente_interface_scsCompositeTelefone3_limpaCamposCliente = function() {
this.getChildById("telefoneTipo").setProperty("value","");
this.getChildById("telefoneDdi").setProperty("value","");
this.getChildById("telefoneDdd").setProperty("value","");
this.getChildById("telefoneNumero").setProperty("value","");
this.getChildById("telefoneObs").setProperty("value","");
return 1;
}

self.s00_componente_interface_scsCompositeTelefone3_limpaComponenteCliente = function() {
if (this.strNumero == "")
return 1;
var retorno = this.limpaCamposCliente();
this.strTipo = "";
this.strDdi = "";
this.strDdd = "";
this.strNumero = "";
this.strObs = "";
var retorno = this.atualizaBotoesPadraoCliente(1);
var retorno = this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente_interface_scsCompositeTelefone3_preencheCamposCliente = function(pPosicao) {
this.PosicaoAtual = (pPosicao);
var posicao = (pPosicao-1);
var tipo = this.strTipo.split(this.delimitadorMV);
var ddd = this.strDdd.split(this.delimitadorMV);
var ddi = this.strDdi.split(this.delimitadorMV);
var numero = this.strNumero.split(this.delimitadorMV);
var obs = this.strObs.split(this.delimitadorMV);
this.getChildById("telefoneTipo").setProperty("value",tipo[posicao]);
this.getChildById("telefoneDdd").setProperty("value",ddd[posicao]);
this.getChildById("telefoneDdi").setProperty("value",ddi[posicao]);
this.getChildById("telefoneNumero").setProperty("value",numero[posicao]);
this.getChildById("telefoneObs").setProperty("value",obs[posicao]);
var retorno = this.atualizaBotoesPadraoCliente(2);
return 1;
}

self.s00_componente_interface_scsCompositeTelefone3_refreshHTML = function() {
var retorno = zenPage.atualizaGridHtmlCliente();
}

self.s00_componente_interface_scsCompositeTelefone3_removerEspacos = function(pString) {
return pString.replace(/\s/g,"");
}

self.s00_componente_interface_scsCompositeTelefone3_AdicionaTelefone = function(atualiza) {
	return zenInstanceMethod(this,'AdicionaTelefone','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_AtualizaTelefone = function() {
	return zenInstanceMethod(this,'AtualizaTelefone','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_DesenhaGridHtml = function() {
	return zenInstanceMethod(this,'DesenhaGridHtml','','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_ExcluirTelefone = function(posicao) {
	return zenInstanceMethod(this,'ExcluirTelefone','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_LimpaCampos = function() {
	return zenInstanceMethod(this,'LimpaCampos','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_PreencheCampos = function(posicao) {
	return zenInstanceMethod(this,'PreencheCampos','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_TodosSomenteLeitura = function(acao) {
	return zenInstanceMethod(this,'TodosSomenteLeitura','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone3_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeTelefone3__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeTelefone3.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeTelefone3.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeTelefone3;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeTelefone3';
	p._type = 'scsCompositeTelefone3';
	p.serialize = s00_componente_interface_scsCompositeTelefone3_serialize;
	p.getSettings = s00_componente_interface_scsCompositeTelefone3_getSettings;
	p.AdicionaTelefone = s00_componente_interface_scsCompositeTelefone3_AdicionaTelefone;
	p.AjustaTamanhoValor = s00_componente_interface_scsCompositeTelefone3_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente_interface_scsCompositeTelefone3_ApresentaExcecao;
	p.AtualizaBotoesPadrao = s00_componente_interface_scsCompositeTelefone3_AtualizaBotoesPadrao;
	p.AtualizaGridHtml = s00_componente_interface_scsCompositeTelefone3_AtualizaGridHtml;
	p.AtualizaTelefone = s00_componente_interface_scsCompositeTelefone3_AtualizaTelefone;
	p.DesenhaGridHtml = s00_componente_interface_scsCompositeTelefone3_DesenhaGridHtml;
	p.ExcluirTelefone = s00_componente_interface_scsCompositeTelefone3_ExcluirTelefone;
	p.GeraCheckBoxHtml = s00_componente_interface_scsCompositeTelefone3_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente_interface_scsCompositeTelefone3_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente_interface_scsCompositeTelefone3_GeraRadioHtml;
	p.GeraSV1Label = s00_componente_interface_scsCompositeTelefone3_GeraSV1Label;
	p.GeraSV1Text = s00_componente_interface_scsCompositeTelefone3_GeraSV1Text;
	p.GeraSelectHtml = s00_componente_interface_scsCompositeTelefone3_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente_interface_scsCompositeTelefone3_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente_interface_scsCompositeTelefone3_GeraTextHtml;
	p.GetValorPropriedade = s00_componente_interface_scsCompositeTelefone3_GetValorPropriedade;
	p.LimpaCampos = s00_componente_interface_scsCompositeTelefone3_LimpaCampos;
	p.LimpaComponente = s00_componente_interface_scsCompositeTelefone3_LimpaComponente;
	p.PreencheCampos = s00_componente_interface_scsCompositeTelefone3_PreencheCampos;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeTelefone3_ReallyRefreshContents;
	p.RecuperarTelefone = s00_componente_interface_scsCompositeTelefone3_RecuperarTelefone;
	p.RetornaValorCampo = s00_componente_interface_scsCompositeTelefone3_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente_interface_scsCompositeTelefone3_SetValorPropriedade;
	p.TodosSomenteLeitura = s00_componente_interface_scsCompositeTelefone3_TodosSomenteLeitura;
	p.VerificaErro = s00_componente_interface_scsCompositeTelefone3_VerificaErro;
	p.adicionaTelefoneCliente = s00_componente_interface_scsCompositeTelefone3_adicionaTelefoneCliente;
	p.alterarCorLinha = s00_componente_interface_scsCompositeTelefone3_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente_interface_scsCompositeTelefone3_atualizaBotoesPadraoCliente;
	p.atualizaGridHtmlCliente = s00_componente_interface_scsCompositeTelefone3_atualizaGridHtmlCliente;
	p.atualizaTelefoneCliente = s00_componente_interface_scsCompositeTelefone3_atualizaTelefoneCliente;
	p.consultarTelefone = s00_componente_interface_scsCompositeTelefone3_consultarTelefone;
	p.desenhaGridHtmlCliente = s00_componente_interface_scsCompositeTelefone3_desenhaGridHtmlCliente;
	p.excluirTelefoneCliente = s00_componente_interface_scsCompositeTelefone3_excluirTelefoneCliente;
	p.limpaCamposCliente = s00_componente_interface_scsCompositeTelefone3_limpaCamposCliente;
	p.limpaComponenteCliente = s00_componente_interface_scsCompositeTelefone3_limpaComponenteCliente;
	p.preencheCamposCliente = s00_componente_interface_scsCompositeTelefone3_preencheCamposCliente;
	p.refreshHTML = s00_componente_interface_scsCompositeTelefone3_refreshHTML;
	p.removerEspacos = s00_componente_interface_scsCompositeTelefone3_removerEspacos;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeTelefone4'] = 's00_componente_interface_scsCompositeTelefone4';
self.s00_componente_interface_scsCompositeTelefone4 = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeTelefone4__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeTelefone4__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.Atualizar = false;
	o.MensagensErro = new Object();
	o.PosicaoAtual = '0';
	o.TipoComponente = '';
	o.TotalPosicao = '0';
	o.delimitador = '|';
	o.delimitadorMV = '@VM';
	o.scsApresentaLabel = true;
	o.scsCamposPersistencia = 'formularioCadastro.TelefoneTipo|formularioCadastro.TelefoneDdi|formularioCadastro.TelefoneDdd|formularioCadastro.TelefoneNumero|formularioCadastro.TelefoneObservacao';
	o.scsDddObrigatorio = false;
	o.scsDdiObrigatorio = false;
	o.scsObsObrigatorio = false;
	o.scsPropriedadesComponente = 'strTipo|strDdi|strDdd|strNumero|strObs';
	o.scsTodosSomenteLeitura = false;
	o.strDdd = '';
	o.strDdi = '';
	o.strNumero = '';
	o.strObs = '';
	o.strTipo = '';
}
function s00_componente_interface_scsCompositeTelefone4_serialize(set,s)
{
	var o = this;s[0]='3555249683';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=(o.Atualizar?1:0);s[7]=set.serializeArray(o,o.MensagensErro,false,'MensagensErro');s[8]=o.PosicaoAtual;s[9]=o.TipoComponente;s[10]=o.TotalPosicao;s[11]=o.align;s[12]=o.aux;s[13]=o.cellAlign;s[14]=o.cellSize;s[15]=o.cellStyle;s[16]=o.cellVAlign;s[17]=set.serializeList(o,o.children,true,'children');s[18]=(o.childrenCreated?1:0);s[19]=o.containerStyle;s[20]=o.delimitador;s[21]=o.delimitadorMV;s[22]=(o.disabled?1:0);s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.groupClass;s[30]=o.groupStyle;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=o.label;s[37]=o.labelClass;s[38]=o.labelDisabledClass;s[39]=o.labelPosition;s[40]=o.labelStyle;s[41]=o.layout;s[42]=o.onafterdrag;s[43]=o.onbeforedrag;s[44]=o.onclick;s[45]=o.ondrag;s[46]=o.ondrop;s[47]=o.onhide;s[48]=o.onrefresh;s[49]=o.onshow;s[50]=o.onupdate;s[51]=o.overlayMode;s[52]=o.renderFlag;s[53]=(o.scsApresentaLabel?1:0);s[54]=o.scsCamposPersistencia;s[55]=(o.scsDddObrigatorio?1:0);s[56]=(o.scsDdiObrigatorio?1:0);s[57]=(o.scsObsObrigatorio?1:0);s[58]=o.scsPropriedadesComponente;s[59]=(o.scsTodosSomenteLeitura?1:0);s[60]=(o.showLabel?1:0);s[61]=o.slice;s[62]=o.strDdd;s[63]=o.strDdi;s[64]=o.strNumero;s[65]=o.strObs;s[66]=o.strTipo;s[67]=o.title;s[68]=o.tuple;s[69]=o.valign;s[70]=(o.visible?1:0);s[71]=o.width;
}
function s00_componente_interface_scsCompositeTelefone4_getSettings(s)
{
	s['name'] = 'string';
	s['Atualizar'] = 'string';
	s['MensagensErro'] = 'string';
	s['PosicaoAtual'] = 'string';
	s['TipoComponente'] = 'string';
	s['TotalPosicao'] = 'string';
	s['delimitador'] = 'string';
	s['delimitadorMV'] = 'string';
	s['scsApresentaLabel'] = 'boolean';
	s['scsCamposPersistencia'] = 'string';
	s['scsDddObrigatorio'] = 'boolean';
	s['scsDdiObrigatorio'] = 'boolean';
	s['scsObsObrigatorio'] = 'boolean';
	s['scsPropriedadesComponente'] = 'string';
	s['scsTodosSomenteLeitura'] = 'boolean';
	s['strDdd'] = 'string';
	s['strDdi'] = 'string';
	s['strNumero'] = 'string';
	s['strObs'] = 'string';
	s['strTipo'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_RecuperarTelefone = function() {
var componente = zenPage.getComponent(this.index);
zenPage.getComponentById("formularioCadastro.TelefoneTipo").setValue(componente.strTipo)
zenPage.getComponentById("formularioCadastro.TelefoneTipo").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneDdi").setValue(componente.strDdi)
zenPage.getComponentById("formularioCadastro.TelefoneDdi").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneDdd").setValue(componente.strDdd)
zenPage.getComponentById("formularioCadastro.TelefoneDdd").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneNumero").setValue(componente.strNumero)
zenPage.getComponentById("formularioCadastro.TelefoneNumero").onchangeHandler()
zenPage.getComponentById("formularioCadastro.TelefoneObservacao").setValue(componente.strObs)
zenPage.getComponentById("formularioCadastro.TelefoneObservacao").onchangeHandler()
/*
PARAR NÃO UTILIZAR O MÉTODO GetValorPropriedade O CONTEÚDO ABAIXO
FOI COMEMTADO. INCIDENTE 3624
*/
var camposPersistencia = (componente.scsCamposPersistencia).split(componente.delimitador);
var camposComponente = (componente.scsPropriedadesComponente).split(componente.delimitador);
var i = 0;
for(i; i<= camposPersistencia.length-1; i++){
var campoPersistencia = camposPersistencia[i];
var campoComponente = camposComponente[i];
var valorCampo = this.getProperty(campoComponente);
zenPage.getComponentById(campoPersistencia).setValue(valorCampo);
zenPage.getComponentById(campoPersistencia).onchangeHandler();
}
return;
}

self.s00_componente_interface_scsCompositeTelefone4_adicionaTelefoneCliente = function() {
var tipo = this.getChildById("telefoneTipo").getProperty("value");
var ddi = this.getChildById("telefoneDdi").getProperty("value");
var ddd = this.getChildById("telefoneDdd").getProperty("value");
var numero = this.getChildById("telefoneNumero").getProperty("value");
var obs = this.getChildById("telefoneObs").getProperty("value");
var erro = "";
if(this.removerEspacos(tipo) == ""){
erro = erro + "- Tipo \n";
}
if((this.removerEspacos(ddi) == "") && (this.scsDdiObrigatorio == 1)){
erro = erro + "- DDI \n";
}
if((this.removerEspacos(ddd) == "") && (this.scsDddObrigatorio == 1)){
erro = erro + "- DDD \n";
}
if(this.removerEspacos(numero) == ""){
erro = erro + "- Número \n";
}
if((this.removerEspacos(obs) == "") && (this.scsObsObrigatorio == 1)){
erro = erro + "- Observação \n";
}
if (erro != ""){
zenPage.alertaShift(this.MensagensErro["camposObrigatorios"]+"\n"+erro);
return 1;
}
if (this.Atualizar){
this.atualizaTelefoneCliente();
return 1;
}
if (this.strNumero == ""){
this.strTipo = tipo;
this.strDdi = ddi;
this.strDdd = ddd;
this.strNumero = numero;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
this.TotalPosicao = this.strNumero.split(this.delimitadorMV).length;
this.limpaCamposCliente();
return 1;
}

self.s00_componente_interface_scsCompositeTelefone4_alterarCorLinha = function(posLinha) {
var comp = zenPage.getComponent(this.index);
var qtdLinha = comp.TotalPosicao;
var linha = 1;
while(linha<=qtdLinha)
{
var aux = "linhaTelefone"+linha;
var obj = document.getElementById(aux);
if ((linha%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (linha == posLinha){
obj.style.background = "#fbe091";
}else{
obj.style.background = zebra;
}
linha = linha + 1;
}
}

self.s00_componente_interface_scsCompositeTelefone4_atualizaBotoesPadraoCliente = function(pAcao) {
if (pAcao==1){
this.getChildById("btNovo").setProperty("hidden",true);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Adicionar telefone");
this.Atualizar = 0;
btAcao.setProperty("onclick","zenThis.composite.adicionaTelefoneCliente(); zenThis.composite.atualizaGridHtmlCliente();")
btAcao.setProperty("enclosingClass","botao_i_add");
}else if (pAcao == 2){
this.getChildById("btNovo").setProperty("hidden",false);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Atualizar telefone");
this.Atualizar = 1;
btAcao.setProperty("onclick","zenThis.composite.adicionaTelefoneCliente(); zenThis.composite.atualizaGridHtmlCliente();")
btAcao.setProperty("enclosingClass","botao_i_refresh_red");
}
if (this.scsTodosSomenteLeitura){
this.getChildById("btNovo").setHidden(true);
this.getChildById("btAcao").setHidden(true);
}
return 1;
}

self.s00_componente_interface_scsCompositeTelefone4_atualizaGridHtmlCliente = function() {
var objHtml = this.getChildById("telefoneGrid");
objHtml.setProperty("content",this.desenhaGridHtmlCliente());
return 1;
}

self.s00_componente_interface_scsCompositeTelefone4_atualizaTelefoneCliente = function() {
var retorno = true;
try{
var tipo = this.getChildById("telefoneTipo").getProperty("value");
var ddi = this.getChildById("telefoneDdi").getProperty("value");
var ddd = this.getChildById("telefoneDdd").getProperty("value");
var numero = this.getChildById("telefoneNumero").getProperty("value");
var obs = this.getChildById("telefoneObs").getProperty("value");
var tTipo = this.strTipo.split(this.delimitadorMV);
var tDdi = this.strDdi.split(this.delimitadorMV);
var tDdd = this.strDdd.split(this.delimitadorMV);
var tNumero = this.strNumero.split(this.delimitadorMV);
var tObs = this.strObs.split(this.delimitadorMV);
this.strTipo = "";
this.strDdi = "";
this.strDdd = "";
this.strNumero = "";
this.strObs = "";
for(i=0;i<this.TotalPosicao;i++){
if (this.PosicaoAtual == (i+1)){
if (this.strNumero==""){
this.strTipo = tipo;
this.strDdi = ddi;
this.strDdd = ddd;
this.strNumero = numero;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
}else{
if (this.strNumero == ""){
this.strTipo = tTipo[i];
this.strDdi = tDdi[i];
this.strDdd = tDdd[i];
this.strNumero = tNumero[i];
this.strObs = tObs[i];
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tTipo[i];
this.strDdi = this.strDdi + this.delimitadorMV + tDdi[i];
this.strDdd = this.strDdd + this.delimitadorMV + tDdd[i];
this.strNumero = this.strNumero + this.delimitadorMV + tNumero[i];
this.strObs = this.strObs + this.delimitadorMV + tObs[i];
}
}
}
this.atualizaBotoesPadraoCliente(1);
var retorno = this.limpaCamposCliente();
}catch(ex){
retorno = false;
zenPage.alertaShift("atualizaTelefoneCliente(): "+ex.description);
}
return 1
}

self.s00_componente_interface_scsCompositeTelefone4_consultarTelefone = function() {
var componente = zenPage.getComponent(this.index);
componente.strTipo   = zenPage.getComponentById("formularioCadastro.TelefoneTipo").getValue()
componente.strDdi    = zenPage.getComponentById("formularioCadastro.TelefoneDdi").getValue()
componente.strDdd    = zenPage.getComponentById("formularioCadastro.TelefoneDdd").getValue()
componente.strNumero = zenPage.getComponentById("formularioCadastro.TelefoneNumero").getValue()
componente.strObs    = zenPage.getComponentById("formularioCadastro.TelefoneObservacao").getValue()
/*
PARAR NÃO UTILIZAR O MÉTODO GetValorPropriedade O CONTEÚDO ABAIXO
FOI COMEMTADO. INCIDENTE 3624
*/
var camposPersistencia = (componente.scsCamposPersistencia).split(componente.delimitador);
var propriedadesComponente = (componente.scsPropriedadesComponente).split(componente.delimitador);
var i = 0;
for(i; i<= camposPersistencia.length-1; i++){
var campoPersistencia = camposPersistencia[i];	//campo persistente para recuperar o valor
var propriedadeComponente = propriedadesComponente[i]; //propriedade do componente que deve receber o valor
var valorPersistente = zenPage.getComponentById(campoPersistencia).getValue();
this.setProperty(propriedadeComponente, valorPersistente);
}
var retorno = componente.atualizaGridHtmlCliente();
return;
}

self.s00_componente_interface_scsCompositeTelefone4_desenhaGridHtmlCliente = function() {
var strGridHtml = "";
var strNumeroList = this.strNumero.split(this.delimitadorMV);
this.TotalPosicao = strNumeroList.length;
if (this.TipoComponente == "scsCompositeTelefone2"){
strGridHtml +=
"<div>"+
"<table cellpadding='0' class='scsCompositeTelefone2' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;' width='360'>";
}else if(this.TipoComponente == "scsCompositeTelefone3"){
strGridHtml +=
"<div>"+
"<table cellpadding='0' cellspacing='0' scsCompositeTelefone2='scsCompositeTelefone3'>";
}else if(this.TipoComponente == "scsCompositeTelefone4"){
strGridHtml +=
"<table cellpadding='0' class='scsCompositeTelefone4' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;' width='880'>"+
"<tr style='font-size:8pt; cursor:hand; background-color:#D2E1EE; height: 20px;'>"+
"<td width='200' style='padding-left: 12px'>Tipo</td>"+
"<td width='200' style='padding-left: 12px'>Telefone</td>"+
"<td width='450' style='padding-left: 12px'>Observações</td>"+
"<td width='60'></td>"+
"</tr>"+
"</table>"+
"<div  style='height: 76px;overflow-y: scroll;' >"+
"<table cellpadding='0' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;' width='850'>"
}
if (this.strNumero != ""){
var strNumeroList = this.strNumero.split(this.delimitadorMV);
var strDddList = this.strDdd.split(this.delimitadorMV);
var strObsList = this.strObs.split(this.delimitadorMV);
var strTipoList = this.strTipo.split(this.delimitadorMV);
var qtdMV = strNumeroList.length;
for (i=0;i<qtdMV;i++){
var tipoTelefone = strTipoList[i];
if((tipoTelefone != "") && (tipoTelefone != undefined)){
tipoTelefone = parseInt(tipoTelefone);
}
switch(tipoTelefone){
case 1:
tipoTelefone = "Residencial";
break;
case 2:
tipoTelefone = "Comercial";
break;
case 3:
tipoTelefone = "Celular";
break;
case 4:
tipoTelefone = "Fax";
break;
case 5:
tipoTelefone = "Outros";
break;
default:
tipoTelefone = "&#160;";
break;
}
var ddd = strDddList[i];
var numero = strNumeroList[i];
var observacoes = strObsList[i];
var telefone = "(" + ddd + ") " + numero;
if (((i+1)%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (this.TipoComponente == "scsCompositeTelefone2"){
strGridHtml +=
"<tr height='30' id='linhaTelefone"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='141' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoTelefone+"</td>"+
"<td width='160' style='padding-left: 12px' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
}else if (this.TipoComponente == "scsCompositeTelefone3"){
strGridHtml +=
"<tr id='linhaTelefone"+(i+1)+"'>"+
"<td onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoTelefone+"</td>"+
"<td onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
}else if (this.TipoComponente == "scsCompositeTelefone4"){
strGridHtml +=
"<tr height='30' id='linhaTelefone"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='200' style='padding-left: 12px; zebra;' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoTelefone+"</td>"+
"<td width='200' style='padding-left: 12px; zebra;' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>"+
"<td width='450' style='padding-left: 12px; zebra;' onclick='zenPage.getComponent("+this.index+").preencheCamposCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+observacoes+"</td>";
}
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='30' align='rigth' style='vertical-align: middle;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='30' align='rigth' style='vertical-align: middle;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirTelefoneCliente("+(i+1)+");'/></td>"+
"</tr>"
}
}
}
strGridHtml += "</table></div>";
return strGridHtml;
}

self.s00_componente_interface_scsCompositeTelefone4_excluirTelefoneCliente = function(posicao) {
var strNumeroList = this.strNumero.split(this.delimitadorMV);
var strDddList = this.strDdd.split(this.delimitadorMV);
var strDdiList = this.strDdi.split(this.delimitadorMV);
var strObsList = this.strObs.split(this.delimitadorMV);
var strTipoList = this.strTipo.split(this.delimitadorMV);
strNumeroList.splice((posicao-1),1);
strDddList.splice((posicao-1),1);
strDdiList.splice((posicao-1),1);
strObsList.splice((posicao-1),1);
strTipoList.splice((posicao-1),1);
this.strNumero = strNumeroList.join(this.delimitadorMV);
this.strDdd = strDddList.join(this.delimitadorMV);
this.strDdi = strDdiList.join(this.delimitadorMV);
this.strTipo = strTipoList.join(this.delimitadorMV);
this.strObs = strObsList.join(this.delimitadorMV);
this.TotalPosicao = this.TotalPosicao - 1;
this.PosicaoAtual = 0;
this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1)
var retorno = this.atualizaGridHtmlCliente()
return 1;
}

self.s00_componente_interface_scsCompositeTelefone4_limpaCamposCliente = function() {
this.getChildById("telefoneTipo").setProperty("value","");
this.getChildById("telefoneDdi").setProperty("value","");
this.getChildById("telefoneDdd").setProperty("value","");
this.getChildById("telefoneNumero").setProperty("value","");
this.getChildById("telefoneObs").setProperty("value","");
return 1;
}

self.s00_componente_interface_scsCompositeTelefone4_limpaComponenteCliente = function() {
if (this.strNumero == "")
return 1;
var retorno = this.limpaCamposCliente();
this.strTipo = "";
this.strDdi = "";
this.strDdd = "";
this.strNumero = "";
this.strObs = "";
var retorno = this.atualizaBotoesPadraoCliente(1);
var retorno = this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente_interface_scsCompositeTelefone4_preencheCamposCliente = function(pPosicao) {
this.PosicaoAtual = (pPosicao);
var posicao = (pPosicao-1);
var tipo = this.strTipo.split(this.delimitadorMV);
var ddd = this.strDdd.split(this.delimitadorMV);
var ddi = this.strDdi.split(this.delimitadorMV);
var numero = this.strNumero.split(this.delimitadorMV);
var obs = this.strObs.split(this.delimitadorMV);
this.getChildById("telefoneTipo").setProperty("value",tipo[posicao]);
this.getChildById("telefoneDdd").setProperty("value",ddd[posicao]);
this.getChildById("telefoneDdi").setProperty("value",ddi[posicao]);
this.getChildById("telefoneNumero").setProperty("value",numero[posicao]);
this.getChildById("telefoneObs").setProperty("value",obs[posicao]);
var retorno = this.atualizaBotoesPadraoCliente(2);
return 1;
}

self.s00_componente_interface_scsCompositeTelefone4_refreshHTML = function() {
var retorno = zenPage.atualizaGridHtmlCliente();
}

self.s00_componente_interface_scsCompositeTelefone4_removerEspacos = function(pString) {
return pString.replace(/\s/g,"");
}

self.s00_componente_interface_scsCompositeTelefone4_AdicionaTelefone = function(atualiza) {
	return zenInstanceMethod(this,'AdicionaTelefone','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_AtualizaTelefone = function() {
	return zenInstanceMethod(this,'AtualizaTelefone','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_DesenhaGridHtml = function() {
	return zenInstanceMethod(this,'DesenhaGridHtml','','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_ExcluirTelefone = function(posicao) {
	return zenInstanceMethod(this,'ExcluirTelefone','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_LimpaCampos = function() {
	return zenInstanceMethod(this,'LimpaCampos','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_PreencheCampos = function(posicao) {
	return zenInstanceMethod(this,'PreencheCampos','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_TodosSomenteLeitura = function(acao) {
	return zenInstanceMethod(this,'TodosSomenteLeitura','L','STATUS',arguments);
}

self.s00_componente_interface_scsCompositeTelefone4_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsCompositeTelefone4__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeTelefone4.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeTelefone4.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeTelefone4;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeTelefone4';
	p._type = 'scsCompositeTelefone4';
	p.serialize = s00_componente_interface_scsCompositeTelefone4_serialize;
	p.getSettings = s00_componente_interface_scsCompositeTelefone4_getSettings;
	p.AdicionaTelefone = s00_componente_interface_scsCompositeTelefone4_AdicionaTelefone;
	p.AjustaTamanhoValor = s00_componente_interface_scsCompositeTelefone4_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente_interface_scsCompositeTelefone4_ApresentaExcecao;
	p.AtualizaBotoesPadrao = s00_componente_interface_scsCompositeTelefone4_AtualizaBotoesPadrao;
	p.AtualizaGridHtml = s00_componente_interface_scsCompositeTelefone4_AtualizaGridHtml;
	p.AtualizaTelefone = s00_componente_interface_scsCompositeTelefone4_AtualizaTelefone;
	p.DesenhaGridHtml = s00_componente_interface_scsCompositeTelefone4_DesenhaGridHtml;
	p.ExcluirTelefone = s00_componente_interface_scsCompositeTelefone4_ExcluirTelefone;
	p.GeraCheckBoxHtml = s00_componente_interface_scsCompositeTelefone4_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente_interface_scsCompositeTelefone4_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente_interface_scsCompositeTelefone4_GeraRadioHtml;
	p.GeraSV1Label = s00_componente_interface_scsCompositeTelefone4_GeraSV1Label;
	p.GeraSV1Text = s00_componente_interface_scsCompositeTelefone4_GeraSV1Text;
	p.GeraSelectHtml = s00_componente_interface_scsCompositeTelefone4_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente_interface_scsCompositeTelefone4_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente_interface_scsCompositeTelefone4_GeraTextHtml;
	p.GetValorPropriedade = s00_componente_interface_scsCompositeTelefone4_GetValorPropriedade;
	p.LimpaCampos = s00_componente_interface_scsCompositeTelefone4_LimpaCampos;
	p.LimpaComponente = s00_componente_interface_scsCompositeTelefone4_LimpaComponente;
	p.PreencheCampos = s00_componente_interface_scsCompositeTelefone4_PreencheCampos;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeTelefone4_ReallyRefreshContents;
	p.RecuperarTelefone = s00_componente_interface_scsCompositeTelefone4_RecuperarTelefone;
	p.RetornaValorCampo = s00_componente_interface_scsCompositeTelefone4_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente_interface_scsCompositeTelefone4_SetValorPropriedade;
	p.TodosSomenteLeitura = s00_componente_interface_scsCompositeTelefone4_TodosSomenteLeitura;
	p.VerificaErro = s00_componente_interface_scsCompositeTelefone4_VerificaErro;
	p.adicionaTelefoneCliente = s00_componente_interface_scsCompositeTelefone4_adicionaTelefoneCliente;
	p.alterarCorLinha = s00_componente_interface_scsCompositeTelefone4_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente_interface_scsCompositeTelefone4_atualizaBotoesPadraoCliente;
	p.atualizaGridHtmlCliente = s00_componente_interface_scsCompositeTelefone4_atualizaGridHtmlCliente;
	p.atualizaTelefoneCliente = s00_componente_interface_scsCompositeTelefone4_atualizaTelefoneCliente;
	p.consultarTelefone = s00_componente_interface_scsCompositeTelefone4_consultarTelefone;
	p.desenhaGridHtmlCliente = s00_componente_interface_scsCompositeTelefone4_desenhaGridHtmlCliente;
	p.excluirTelefoneCliente = s00_componente_interface_scsCompositeTelefone4_excluirTelefoneCliente;
	p.limpaCamposCliente = s00_componente_interface_scsCompositeTelefone4_limpaCamposCliente;
	p.limpaComponenteCliente = s00_componente_interface_scsCompositeTelefone4_limpaComponenteCliente;
	p.preencheCamposCliente = s00_componente_interface_scsCompositeTelefone4_preencheCamposCliente;
	p.refreshHTML = s00_componente_interface_scsCompositeTelefone4_refreshHTML;
	p.removerEspacos = s00_componente_interface_scsCompositeTelefone4_removerEspacos;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsCompositeUpload'] = 's00_componente_interface_scsCompositeUpload';
self.s00_componente_interface_scsCompositeUpload = function(index,id) {
	if (index>=0) {s00_componente_interface_scsCompositeUpload__init(this,index,id);}
}

self.s00_componente_interface_scsCompositeUpload__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.LinkPaginaUpload = '';
	o.scsBackgroundColor = '#FFFFFF';
	o.scsCodigoItem = '';
	o.scsDisabled = false;
	o.scsHeight = '100%';
	o.scsIniticialExecute = false;
	o.scsReadOnly = false;
	o.scsTipo = '';
}
function s00_componente_interface_scsCompositeUpload_serialize(set,s)
{
	var o = this;s[0]='123943894';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.LinkPaginaUpload;s[7]=o.align;s[8]=o.aux;s[9]=o.cellAlign;s[10]=o.cellSize;s[11]=o.cellStyle;s[12]=o.cellVAlign;s[13]=set.serializeList(o,o.children,true,'children');s[14]=(o.childrenCreated?1:0);s[15]=o.containerStyle;s[16]=(o.disabled?1:0);s[17]=(o.dragEnabled?1:0);s[18]=(o.dropEnabled?1:0);s[19]=(o.dynamic?1:0);s[20]=o.enclosingClass;s[21]=o.enclosingStyle;s[22]=o.error;s[23]=o.groupClass;s[24]=o.groupStyle;s[25]=o.height;s[26]=(o.hidden?1:0);s[27]=o.hint;s[28]=o.hintClass;s[29]=o.hintStyle;s[30]=o.label;s[31]=o.labelClass;s[32]=o.labelDisabledClass;s[33]=o.labelPosition;s[34]=o.labelStyle;s[35]=o.layout;s[36]=o.onafterdrag;s[37]=o.onbeforedrag;s[38]=o.onclick;s[39]=o.ondrag;s[40]=o.ondrop;s[41]=o.onhide;s[42]=o.onrefresh;s[43]=o.onshow;s[44]=o.onupdate;s[45]=o.overlayMode;s[46]=o.renderFlag;s[47]=o.scsBackgroundColor;s[48]=o.scsCodigoItem;s[49]=(o.scsDisabled?1:0);s[50]=o.scsHeight;s[51]=(o.scsIniticialExecute?1:0);s[52]=(o.scsReadOnly?1:0);s[53]=o.scsTipo;s[54]=(o.showLabel?1:0);s[55]=o.slice;s[56]=o.title;s[57]=o.tuple;s[58]=o.valign;s[59]=(o.visible?1:0);s[60]=o.width;
}
function s00_componente_interface_scsCompositeUpload_getSettings(s)
{
	s['name'] = 'string';
	s['LinkPaginaUpload'] = 'string';
	s['scsBackgroundColor'] = 'color';
	s['scsCodigoItem'] = 'string';
	s['scsDisabled'] = 'boolean';
	s['scsHeight'] = 'string';
	s['scsIniticialExecute'] = 'boolean';
	s['scsReadOnly'] = 'boolean';
	s['scsTipo'] = 'enum:1,2,3,4,5,101,102,103,104';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsCompositeUpload_atualizar = function() {
var objIframe = this.getChildById("ifrmUploadPagina");
var parametros =
"&scsTipo="+this.scsTipo+
"&scsCodigoItem="+this.scsCodigoItem+
"&scsDisabled="+(+this.scsDisabled)+
"&scsReadOnly="+(+this.scsReadOnly)+
"&scsBackgroundColor="+escape(this.scsBackgroundColor);
objIframe.setProperty("src",this.LinkPaginaUpload+parametros);
}

self.s00_componente_interface_scsCompositeUpload_onDisplayHandler = function() {
if (this.scsIniticialExecute){
var objIframe = this.getChildById("ifrmUploadPagina");
var src = objIframe.getProperty("src");
if (src == ""){
this.atualizar();
}
}
}

self.s00_componente_interface_scsCompositeUpload_onloadHandler = function() {
if (this.disabled && this.parent && !this.parent.disabled) {
this.setProperty('disabled',true);
}
this.getChildById("ifrmUploadPagina").setProperty("height",this.scsHeight);
}

self.s00_componente_interface_scsCompositeUpload_salvar = function(pFuncaoRetorno,pComponente) {
var retorno = true;
var zsm = zenSynchronousMode;
zenSynchronousMode = 1;
try{
var objIframe = this.getChildById("ifrmUploadPagina");
var paginaUpload = objIframe.getPage();
if((paginaUpload != null)){ //essa verificação é feita, porque existem casos em que a página não é carregada, devido a cuidados com performance
paginaUpload.setProperty("scsCodigoItem",this.getProperty("scsCodigoItem"));
retorno = paginaUpload.salvar();
this.verificaSalvou(pComponente);
}
}catch (ex){
retorno = false;
zenPage.alertaShift(ex.description);
if (typeof(pFuncaoRetorno) == "function") pFuncaoRetorno();
}
zenSynchronousMode = zsm;
return retorno;
}

self.s00_componente_interface_scsCompositeUpload_verificaSalvou = function(pComponente) {
var objIframe = this.getChildById("ifrmUploadPagina");
var iframeDoc = objIframe.getDocument();
if (iframeDoc.readyState  == 'complete'){
try{	pComponente.retornoSalvouArquivo(); }catch(ex){}
return;
}
var pthis = this;
setTimeout(function(){pthis.verificaSalvou(pComponente)}, 100);
}

self.s00_componente_interface_scsCompositeUpload_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsCompositeUpload__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsCompositeUpload.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsCompositeUpload.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsCompositeUpload;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsCompositeUpload';
	p._type = 'scsCompositeUpload';
	p.serialize = s00_componente_interface_scsCompositeUpload_serialize;
	p.getSettings = s00_componente_interface_scsCompositeUpload_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsCompositeUpload_ReallyRefreshContents;
	p.atualizar = s00_componente_interface_scsCompositeUpload_atualizar;
	p.onDisplayHandler = s00_componente_interface_scsCompositeUpload_onDisplayHandler;
	p.onloadHandler = s00_componente_interface_scsCompositeUpload_onloadHandler;
	p.salvar = s00_componente_interface_scsCompositeUpload_salvar;
	p.verificaSalvou = s00_componente_interface_scsCompositeUpload_verificaSalvou;
}

self._zenClassIdx['scsDataComboShift'] = 's00_componente_interface_scsDataComboShift';
self.s00_componente_interface_scsDataComboShift = function(index,id) {
	if (index>=0) {s00_componente_interface_scsDataComboShift__init(this,index,id);}
}

self.s00_componente_interface_scsDataComboShift__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_dataCombo__init) ?zenMaster._ZEN_Component_dataCombo__init(o,index,id):_ZEN_Component_dataCombo__init(o,index,id);
	o.OnCreateResultSet = ''; // encrypted
	o.OnExecuteResultSet = ''; // encrypted
	o.columnName = '';
	o.countRows = '0';
	o.groupByClause = '';
	o.maxRows = '100';
	o.orderByClause = '';
	o.placeholder = '';
	o.queryClass = ''; // encrypted
	o.queryName = '';
	o.sql = ''; // encrypted
	o.tableName = ''; // encrypted
	o.whereClause = '';
}
function s00_componente_interface_scsDataComboShift_serialize(set,s)
{
	var o = this;s[0]='3827919566';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.OnCreateResultSet;s[7]=o.OnExecuteResultSet;s[8]=o.align;s[9]=(o.autocomplete?1:0);s[10]=o.aux;s[11]=o.auxColumn;s[12]=o.buttonCaption;s[13]=o.buttonImage;s[14]=o.buttonImageDown;s[15]=o.buttonTitle;s[16]=(o.cached?1:0);s[17]=o.choiceColumn;s[18]=(o.clearOnLoad?1:0);s[19]=o.clientType;s[20]=o.columnHeaders;s[21]=o.columnName;s[22]=o.comboType;s[23]=set.serializeList(o,o.conditions,true,'conditions');s[24]=o.containerStyle;s[25]=o.contentType;s[26]=o.controlClass;s[27]=o.controlStyle;s[28]=o.countRows;s[29]=o.dataBinding;s[30]=(o.dataLoaded?1:0);s[31]=o.delay;s[32]=(o.disabled?1:0);s[33]=o.displayColumns;s[34]=(o.dragEnabled?1:0);s[35]=(o.dropEnabled?1:0);s[36]=o.dropdownHeight;s[37]=o.dropdownWidth;s[38]=(o.dynamic?1:0);s[39]=(o.editable?1:0);s[40]=o.emptyText;s[41]=o.enclosingClass;s[42]=o.enclosingStyle;s[43]=o.error;s[44]=o.groupByClause;s[45]=o.height;s[46]=(o.hidden?1:0);s[47]=o.hint;s[48]=o.hintClass;s[49]=o.hintStyle;s[50]=(o.hzScroll?1:0);s[51]=o.inputtype;s[52]=(o.invalid?1:0);s[53]=o.invalidMessage;s[54]=(o.isDropdownVisible?1:0);s[55]=o.itemCount;s[56]=o.label;s[57]=o.labelClass;s[58]=o.labelDisabledClass;s[59]=o.labelStyle;s[60]=o.loadingMessage;s[61]=o.maxRows;s[62]=o.maxlength;s[63]=o.modelClass;s[64]=(o.multiColumn?1:0);s[65]=o.onafterdrag;s[66]=o.onbeforedrag;s[67]=o.onblur;s[68]=o.onchange;s[69]=o.onclick;s[70]=o.ondblclick;s[71]=o.ondrag;s[72]=o.ondrop;s[73]=o.onfocus;s[74]=o.onhide;s[75]=o.onkeydown;s[76]=o.onkeypress;s[77]=o.onkeyup;s[78]=o.onmousedown;s[79]=o.onmouseout;s[80]=o.onmouseover;s[81]=o.onmouseup;s[82]=o.onrefresh;s[83]=o.onshow;s[84]=o.onshowDropdown;s[85]=o.onsubmit;s[86]=o.ontouchend;s[87]=o.ontouchmove;s[88]=o.ontouchstart;s[89]=o.onupdate;s[90]=o.onvalidate;s[91]=o.orderByClause;s[92]=o.originalValue;s[93]=o.overlayMode;s[94]=set.serializeList(o,o.parameters,true,'parameters');s[95]=o.placeholder;s[96]=o.queryClass;s[97]=o.queryName;s[98]=(o.readOnly?1:0);s[99]=o.renderFlag;s[100]=(o.required?1:0);s[101]=o.requiredMessage;s[102]=(o.scrollIntoView?1:0);s[103]=o.searchKeyLen;s[104]=o.selectedIndex;s[105]=(o.showEmpty?1:0);s[106]=(o.showLabel?1:0);s[107]=o.showQuery;s[108]=o.size;s[109]=o.slice;s[110]=(o.spellcheck?1:0);s[111]=o.sql;s[112]=o.sqlLookup;s[113]=o.tabIndex;s[114]=o.tableName;s[115]=o.text;s[116]=o.title;s[117]=o.tuple;s[118]=(o.unrestricted?1:0);s[119]=o.valign;s[120]=('boolean'==typeof o.value?(o.value?1:0):o.value);s[121]=o.valueColumn;s[122]=(o.visible?1:0);s[123]=o.whereClause;s[124]=o.width;
}
function s00_componente_interface_scsDataComboShift_getSettings(s)
{
	s['name'] = 'string';
	s['columnName'] = 'string';
	s['countRows'] = 'integer';
	s['groupByClause'] = 'string';
	s['maxRows'] = 'integer';
	s['orderByClause'] = 'string';
	s['placeholder'] = 'caption';
	s['queryClass'] = 'className';
	s['queryName'] = 'classMember:QUERY';
	s['sql'] = 'sql';
	s['tableName'] = 'string';
	s['whereClause'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsDataComboShift_adjustDropdownPosition = function() {
var div = this.getDropDownDiv();
zenASSERT(div,'Unable to find dropdown div',arguments);
var input = this.findElement('input');
zenASSERT(input,'Unable to find input element',arguments);
var iHgt = input.offsetHeight;
var wScrollTop = document.body.scrollTop;
var pN = document.body.parentNode;
if (pN && pN!=document.body) {
if (pN.scrollTop) wScrollTop+=pN.scrollTop;
}
var top,right;
var obj = zenGetPageOffsets(input);
if (div.nativeHeight) div.style.height=div.nativeHeight+"px";
var dHgt = div.offsetHeight;
var hgt = zenGetWindowHeight();
var uSpace = obj.top - wScrollTop;
var dSpace = hgt-uSpace-iHgt-2;
if (dHgt>dSpace) { // dropdown won't fit as is
if (dSpace>uSpace) { // beneath is best option but must shorten menu
if (!div.nativeHeight) div.nativeHeight = dHgt;
div.style.height = (dSpace - 2) + "px";
top = obj.top+iHgt;
}
else { // open dropdown upwards
if (dHgt>uSpace) {
if (!div.nativeHeight) div.nativeHeight = dHgt;
div.style.height=(uSpace-2)+"px";
}
top = obj.top-div.offsetHeight;
}
}
else {  // Dropdown is fine where it is but need to be in page coordinates
top = obj.top+iHgt;
}
div.style.top = top + "px";
var elInput = document.getElementById("input_"+this.index);
if((document.body) && (obj.left + div.offsetWidth > document.body.offsetWidth)) {
div.style.left = (obj.left - (div.offsetWidth - elInput.offsetWidth)) + "px";
} else {
div.style.left = obj.left + "px";
}
}

self.s00_componente_interface_scsDataComboShift_adjustDropdownPositionCache2015 = function() {
var div = this.getDropDownDiv();
zenASSERT(div,'Unable to find dropdown div',arguments);
var input = this.findElement('input');
zenASSERT(input,'Unable to find input element',arguments);
var iHgt = input.offsetHeight;
var wScrollTop = zenGetPageScrollTop();
var top,right;
var obj = zenGetPageOffsets(input);
if (div.nativeHeight) div.style.height=div.nativeHeight+"px";
var dHgt = div.offsetHeight;
var hgt = zenGetWindowHeight();
var uSpace = obj.top - wScrollTop;
var dSpace = hgt-uSpace-iHgt-2;
if (dHgt>dSpace) { // dropdown won't fit as is
if (dSpace>uSpace) { // beneath is best option but must shorten menu
if (!div.nativeHeight) div.nativeHeight = dHgt;
div.style.height = (dSpace - 2) + "px";
top = obj.top+iHgt;
}
else { // open dropdown upwards
if (dHgt>uSpace) {
if (!div.nativeHeight) div.nativeHeight = dHgt;
div.style.height=(uSpace-2)+"px";
}
top = obj.top-div.offsetHeight;
}
}
else {  // Dropdown is fine where it is but need to be in page coordinates
top = obj.top+iHgt;
}
div.style.top = top + "px";
var elInput = document.getElementById("input_"+this.index);
if((document.body) && (obj.left + div.offsetWidth > document.body.offsetWidth)) {
div.style.left = (obj.left - (div.offsetWidth - elInput.offsetWidth)) + "px";
} else {
div.style.left = obj.left + "px";
}
}

self.s00_componente_interface_scsDataComboShift_inputKeyHandler = function(evt) {
evt = evt ? evt : window.event;
var idx = parseInt(this.selectedIndex,10);
if (this.isDropdownVisible) {
switch(evt.keyCode) {
case zenHOME:
this.clearTimer();
this.keyMode = true;
if (evt.preventDefault) {
evt.preventDefault();
}
this.selectItem(0,true,false);
return false;
case zenEND:
this.clearTimer();
this.keyMode = true;
if (evt.preventDefault) {
evt.preventDefault();
}
this.selectItem(this.getOptionCount()-1,true,false);
return false;
case zenUP:
this.clearTimer();
this.keyMode = true;
if (evt.preventDefault) {
evt.preventDefault();
}
if (idx > 0) {
this.selectItem(idx - 1,true,false);
}
return false;
case zenDOWN:
this.clearTimer();
this.keyMode = true;
if (evt.preventDefault) {
evt.preventDefault();
}
if (idx < (this.getOptionCount()-1)) {
this.selectItem(idx + 1,true,false);
}
return false;
case zenPAGEUP:
this.clearTimer();
this.keyMode = true;
if (evt.preventDefault) {
evt.preventDefault();
}
if (idx > 0) {
this.selectItem((idx > 10) ? idx - 10 : 0,true,false);
}
return false;
case zenPAGEDN:
this.clearTimer();
this.keyMode = true;
if (evt.preventDefault) {
evt.preventDefault();
}
var count = this.getOptionCount();
if (idx < (count-1)) {
this.selectItem((idx < count - 10) ? idx + 10 : count - 1,true,false);
}
return false;
case zenESC:
if (evt.preventDefault) {
evt.preventDefault();
}
zenPage.endModal();
return false;
case zenENTER:
this.clearTimer();
if (this.keyMode) {
zenPage.endModal();
this.selectItem(idx,false,true);
}
else {
this.renderDropdown();
}
return false;
case 16:
case 17:
break;
default:
this.startTimer();
this.keyMode = null;
break;
}
}
else {
switch(evt.keyCode) {
case zenDOWN:
case zenENTER:
this.clearTimer();
this.keyMode = true;
this.showDropdown();
return false;
case 16:
case 17:
case 27:
break;
default:
this.startTimer();
break;
}
}
return zenInvokeCallbackMethod(this.onkeydown,this,'onkeydown');
}

self.s00_componente_interface_scsDataComboShift_selecionarPrimeiroItem = function() {
this.keyMode = true;
this.selectItem(0,true,false);
return false;
}

self.s00_componente_interface_scsDataComboShift_LoadDropDownContents = function(searchParm,cached) {
	zenInstanceMethod(this,'LoadDropDownContents','L,B','',arguments);
}

self.s00_componente_interface_scsDataComboShift_LookupDisplayValue = function(value) {
	return zenInstanceMethod(this,'LookupDisplayValue','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsDataComboShift_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsDataComboShift__Loader = function() {
	zenLoadClass('_ZEN_Component_dataCombo');
	s00_componente_interface_scsDataComboShift.prototype = zenCreate('_ZEN_Component_dataCombo',-1);
	var p = s00_componente_interface_scsDataComboShift.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsDataComboShift;
	p.superClass = ('undefined' == typeof _ZEN_Component_dataCombo) ? zenMaster._ZEN_Component_dataCombo.prototype:_ZEN_Component_dataCombo.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsDataComboShift';
	p._type = 'scsDataComboShift';
	p.serialize = s00_componente_interface_scsDataComboShift_serialize;
	p.getSettings = s00_componente_interface_scsDataComboShift_getSettings;
	p.LoadDropDownContents = s00_componente_interface_scsDataComboShift_LoadDropDownContents;
	p.LookupDisplayValue = s00_componente_interface_scsDataComboShift_LookupDisplayValue;
	p.ReallyRefreshContents = s00_componente_interface_scsDataComboShift_ReallyRefreshContents;
	p.adjustDropdownPosition = s00_componente_interface_scsDataComboShift_adjustDropdownPosition;
	p.adjustDropdownPositionCache2015 = s00_componente_interface_scsDataComboShift_adjustDropdownPositionCache2015;
	p.inputKeyHandler = s00_componente_interface_scsDataComboShift_inputKeyHandler;
	p.selecionarPrimeiroItem = s00_componente_interface_scsDataComboShift_selecionarPrimeiroItem;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsImportarArquivo'] = 's00_componente_interface_scsImportarArquivo';
self.s00_componente_interface_scsImportarArquivo = function(index,id) {
	if (index>=0) {s00_componente_interface_scsImportarArquivo__init(this,index,id);}
}

self.s00_componente_interface_scsImportarArquivo__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.MensagemErro = 'Erro na importação do arquivo:';
	o.MensagemOk = 'Arquivo importado com sucesso.';
	o.leftPosition = '310';
	o.scsManterNomeArquivo = false;
	o.scsMostrarMensagemOK = true;
	o.scsSemAlerta = false;
	o.scsZIndex = '';
	o.topPosition = '80';
}
function s00_componente_interface_scsImportarArquivo_serialize(set,s)
{
	var o = this;s[0]='2559516243';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.MensagemErro;s[7]=o.MensagemOk;s[8]=o.align;s[9]=o.aux;s[10]=o.cellAlign;s[11]=o.cellSize;s[12]=o.cellStyle;s[13]=o.cellVAlign;s[14]=set.serializeList(o,o.children,true,'children');s[15]=(o.childrenCreated?1:0);s[16]=o.containerStyle;s[17]=(o.disabled?1:0);s[18]=(o.dragEnabled?1:0);s[19]=(o.dropEnabled?1:0);s[20]=(o.dynamic?1:0);s[21]=o.enclosingClass;s[22]=o.enclosingStyle;s[23]=o.error;s[24]=o.groupClass;s[25]=o.groupStyle;s[26]=o.height;s[27]=(o.hidden?1:0);s[28]=o.hint;s[29]=o.hintClass;s[30]=o.hintStyle;s[31]=o.label;s[32]=o.labelClass;s[33]=o.labelDisabledClass;s[34]=o.labelPosition;s[35]=o.labelStyle;s[36]=o.layout;s[37]=o.leftPosition;s[38]=o.onafterdrag;s[39]=o.onbeforedrag;s[40]=o.onclick;s[41]=o.ondrag;s[42]=o.ondrop;s[43]=o.onhide;s[44]=o.onrefresh;s[45]=o.onshow;s[46]=o.onupdate;s[47]=o.overlayMode;s[48]=o.renderFlag;s[49]=(o.scsManterNomeArquivo?1:0);s[50]=(o.scsMostrarMensagemOK?1:0);s[51]=(o.scsSemAlerta?1:0);s[52]=o.scsZIndex;s[53]=(o.showLabel?1:0);s[54]=o.slice;s[55]=o.title;s[56]=o.topPosition;s[57]=o.tuple;s[58]=o.valign;s[59]=(o.visible?1:0);s[60]=o.width;
}
function s00_componente_interface_scsImportarArquivo_getSettings(s)
{
	s['name'] = 'string';
	s['MensagemErro'] = 'string';
	s['MensagemOk'] = 'string';
	s['leftPosition'] = 'string';
	s['scsManterNomeArquivo'] = 'boolean';
	s['scsMostrarMensagemOK'] = 'boolean';
	s['scsSemAlerta'] = 'boolean';
	s['scsZIndex'] = 'string';
	s['topPosition'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsImportarArquivo_fecharModalArquivo = function(pEnderecoArquivo) {
var idComposite = this.getProperty("id")
zenPage.getComponentById(idComposite).setProperty("hidden",1)
if (pEnderecoArquivo != ""){
if (this.scsSemAlerta){
zenPage.ImportarArquivo(pEnderecoArquivo);
}else{
var retorno = zenPage.ImportarArquivo(pEnderecoArquivo);
if (retorno != ""){
var mensagem = this.MensagemErro + "\n\n" + retorno
zenPage.alertaShift(mensagem)
} else if (this.scsMostrarMensagemOK){
zenPage.alertaShift(this.MensagemOk)
}
}
}
return 1
}

self.s00_componente_interface_scsImportarArquivo_setProperty = function(property,value,value2) {
switch(property) {
case 'hidden':
if (value){
var src = "s00.iu.interface.cadastro.UploadArquivo.cls?componenteId="+this.id+"&manterNomeArquivo="+(+this.scsManterNomeArquivo)+"&semAlerta="+(+this.scsSemAlerta);
this.getChildById("iframe").setProperty("src",src)
}
return this.invokeSuper('setProperty',arguments);
break;
default:
return this.invokeSuper('setProperty',arguments);
}
return true;
}

self.s00_componente_interface_scsImportarArquivo_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsImportarArquivo__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsImportarArquivo.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsImportarArquivo.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsImportarArquivo;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsImportarArquivo';
	p._type = 'scsImportarArquivo';
	p.serialize = s00_componente_interface_scsImportarArquivo_serialize;
	p.getSettings = s00_componente_interface_scsImportarArquivo_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsImportarArquivo_ReallyRefreshContents;
	p.fecharModalArquivo = s00_componente_interface_scsImportarArquivo_fecharModalArquivo;
	p.setProperty = s00_componente_interface_scsImportarArquivo_setProperty;
}

self._zenClassIdx['scsInformacoesCustomizadas'] = 's00_componente_interface_scsInformacoesCustomizadas';
self.s00_componente_interface_scsInformacoesCustomizadas = function(index,id) {
	if (index>=0) {s00_componente_interface_scsInformacoesCustomizadas__init(this,index,id);}
}

self.s00_componente_interface_scsInformacoesCustomizadas__init = function(o,index,id) {
	('undefined' == typeof s00_componente2_interface_Padrao__init) ?zenMaster.s00_componente2_interface_Padrao__init(o,index,id):s00_componente2_interface_Padrao__init(o,index,id);
}
function s00_componente_interface_scsInformacoesCustomizadas_serialize(set,s)
{
	var o = this;s[0]='4096323540';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=(o.childrenCreated?1:0);s[14]=o.containerStyle;s[15]=(o.disabled?1:0);s[16]=(o.dragEnabled?1:0);s[17]=(o.dropEnabled?1:0);s[18]=(o.dynamic?1:0);s[19]=o.enclosingClass;s[20]=o.enclosingStyle;s[21]=o.error;s[22]=o.groupClass;s[23]=o.groupStyle;s[24]=o.height;s[25]=(o.hidden?1:0);s[26]=o.hint;s[27]=o.hintClass;s[28]=o.hintStyle;s[29]=o.label;s[30]=o.labelClass;s[31]=o.labelDisabledClass;s[32]=o.labelPosition;s[33]=o.labelStyle;s[34]=o.layout;s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onclick;s[38]=o.ondrag;s[39]=o.ondrop;s[40]=o.onhide;s[41]=o.onrefresh;s[42]=o.onshow;s[43]=o.onupdate;s[44]=o.overlayMode;s[45]=o.renderFlag;s[46]=(o.showLabel?1:0);s[47]=o.slice;s[48]=o.title;s[49]=o.tuple;s[50]=o.valign;s[51]=(o.visible?1:0);s[52]=o.width;
}
function s00_componente_interface_scsInformacoesCustomizadas_getSettings(s)
{
	s['name'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsInformacoesCustomizadas_abrirInformacoesCustomizadas = function(pHtml) {
try{
var zsm = zenSynchronousMode;
zenSynchronousMode = true;
var proxyInformacoesJanela = this.RecuperarInformacoesJanela();
var tituloJanela = proxyInformacoesJanela.TituloJanela;
var alturaJanela = proxyInformacoesJanela.AlturaJanela;
var larguraJanela = proxyInformacoesJanela.LarguraJanela;
if((alturaJanela == null || alturaJanela == undefined || alturaJanela == "") ||
(larguraJanela == null || larguraJanela == undefined || larguraJanela == "")){
zenPage.alertaShift($$$Text("Tamanho da popup de informações customizadas não definida."));
return;
}
var janelaPopup = this.getChildById("popupInformacoesCustomizadas");
janelaPopup.setProperty("scsTitulo", tituloJanela);
var htmlJanela = document.getElementById("divInformacoesCustomizadas");
htmlJanela.style.height = alturaJanela+"px";
htmlJanela.style.width = larguraJanela+"px";
pHtml = pHtml.replace(new RegExp("<p/>", 'g'), "<p>&#160;</p>");
pHtml = pHtml.replace(new RegExp("<p></p>", 'g'), "<p>&#160;</p>");
pHtml = pHtml.replace(new RegExp("<div></div>", 'g'), "<div>&#160;</div>");
var htmlJanela = document.getElementById("divInformacoesCustomizadas");
htmlJanela.innerHTML = pHtml;
zenSynchronousMode = zsm;
janelaPopup.setHidden(0); //Exibe o componente
}catch(ex){
zenPage.alertaShift("abrirInformacoesCustomizadas(): "+ex.description);
}
}

self.s00_componente_interface_scsInformacoesCustomizadas_carregarTemplate = function(pIdTemplate) {
var html = this.RecuperarHtml(pIdTemplate);
var htmlJanela = document.getElementById("divInformacoesCustomizadas");
htmlJanela.innerHTML = html;
}

self.s00_componente_interface_scsInformacoesCustomizadas_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsInformacoesCustomizadas_RecuperarHtml = function(pIdTemplate) {
	return zenClassMethod(this,'RecuperarHtml','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsInformacoesCustomizadas_RecuperarInformacoesJanela = function() {
	return zenClassMethod(this,'RecuperarInformacoesJanela','','HANDLE',arguments);
}

self.s00_componente_interface_scsInformacoesCustomizadas_RecuperarPrimeiroTemplate = function() {
	return zenClassMethod(this,'RecuperarPrimeiroTemplate','','VARCHAR',arguments);
}
self.s00_componente_interface_scsInformacoesCustomizadas__Loader = function() {
	zenLoadClass('s00_componente2_interface_Padrao');
	s00_componente_interface_scsInformacoesCustomizadas.prototype = zenCreate('s00_componente2_interface_Padrao',-1);
	var p = s00_componente_interface_scsInformacoesCustomizadas.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsInformacoesCustomizadas;
	p.superClass = ('undefined' == typeof s00_componente2_interface_Padrao) ? zenMaster.s00_componente2_interface_Padrao.prototype:s00_componente2_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsInformacoesCustomizadas';
	p._type = 'scsInformacoesCustomizadas';
	p.serialize = s00_componente_interface_scsInformacoesCustomizadas_serialize;
	p.getSettings = s00_componente_interface_scsInformacoesCustomizadas_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_scsInformacoesCustomizadas_ReallyRefreshContents;
	p.RecuperarHtml = s00_componente_interface_scsInformacoesCustomizadas_RecuperarHtml;
	p.RecuperarInformacoesJanela = s00_componente_interface_scsInformacoesCustomizadas_RecuperarInformacoesJanela;
	p.RecuperarPrimeiroTemplate = s00_componente_interface_scsInformacoesCustomizadas_RecuperarPrimeiroTemplate;
	p.abrirInformacoesCustomizadas = s00_componente_interface_scsInformacoesCustomizadas_abrirInformacoesCustomizadas;
	p.carregarTemplate = s00_componente_interface_scsInformacoesCustomizadas_carregarTemplate;
}

self._zenClassIdx['scsLogOperacao'] = 's00_componente_interface_scsLogOperacao';
self.s00_componente_interface_scsLogOperacao = function(index,id) {
	if (index>=0) {s00_componente_interface_scsLogOperacao__init(this,index,id);}
}

self.s00_componente_interface_scsLogOperacao__init = function(o,index,id) {
	('undefined' == typeof s00_componente2_interface_Padrao__init) ?zenMaster.s00_componente2_interface_Padrao__init(o,index,id):s00_componente2_interface_Padrao__init(o,index,id);
	o.AtualizaFiltrosHistoricoOS = true;
	o.Categoria = '';
	o.FiltroData = new Object();
	o.FiltroOperacao = new Object();
	o.FiltroProcedimento = new Object();
	o.FiltroRecipiente = new Object();
	o.FiltroUsuario = new Object();
	o.InformacoesAdicionaisHistoricoOS = new Object();
	o.JSONLevels = '100';
	o.Mensagens = new Object();
	o.PacienteId = '';
	o.Segmento = '1';
	o.scsAnalitoId = '';
	o.scsFiltroHistoricoOS = new Object();
	o.scsIdOS = '';
	o.scsInfoLeft = '';
	o.scsInfoTop = '';
	o.scsOrigem = '0';
}
function s00_componente_interface_scsLogOperacao_serialize(set,s)
{
	var o = this;s[0]='923274747';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=(o.AtualizaFiltrosHistoricoOS?1:0);s[7]=o.Categoria;s[8]=set.serializeArray(o,o.FiltroData,false,'FiltroData');s[9]=set.serializeArray(o,o.FiltroOperacao,false,'FiltroOperacao');s[10]=set.serializeArray(o,o.FiltroProcedimento,false,'FiltroProcedimento');s[11]=set.serializeArray(o,o.FiltroRecipiente,false,'FiltroRecipiente');s[12]=set.serializeArray(o,o.FiltroUsuario,false,'FiltroUsuario');s[13]=set.serializeArray(o,o.InformacoesAdicionaisHistoricoOS,false,'InformacoesAdicionaisHistoricoOS');s[14]=o.JSONLevels;s[15]=set.serializeArray(o,o.Mensagens,false,'Mensagens');s[16]=o.PacienteId;s[17]=o.Segmento;s[18]=o.align;s[19]=o.aux;s[20]=o.cellAlign;s[21]=o.cellSize;s[22]=o.cellStyle;s[23]=o.cellVAlign;s[24]=set.serializeList(o,o.children,true,'children');s[25]=(o.childrenCreated?1:0);s[26]=o.containerStyle;s[27]=(o.disabled?1:0);s[28]=(o.dragEnabled?1:0);s[29]=(o.dropEnabled?1:0);s[30]=(o.dynamic?1:0);s[31]=o.enclosingClass;s[32]=o.enclosingStyle;s[33]=o.error;s[34]=o.groupClass;s[35]=o.groupStyle;s[36]=o.height;s[37]=(o.hidden?1:0);s[38]=o.hint;s[39]=o.hintClass;s[40]=o.hintStyle;s[41]=o.label;s[42]=o.labelClass;s[43]=o.labelDisabledClass;s[44]=o.labelPosition;s[45]=o.labelStyle;s[46]=o.layout;s[47]=o.onafterdrag;s[48]=o.onbeforedrag;s[49]=o.onclick;s[50]=o.ondrag;s[51]=o.ondrop;s[52]=o.onhide;s[53]=o.onrefresh;s[54]=o.onshow;s[55]=o.onupdate;s[56]=o.overlayMode;s[57]=o.renderFlag;s[58]=o.scsAnalitoId;s[59]=set.serializeArray(o,o.scsFiltroHistoricoOS,false,'scsFiltroHistoricoOS');s[60]=o.scsIdOS;s[61]=o.scsInfoLeft;s[62]=o.scsInfoTop;s[63]=o.scsOrigem;s[64]=(o.showLabel?1:0);s[65]=o.slice;s[66]=o.title;s[67]=o.tuple;s[68]=o.valign;s[69]=(o.visible?1:0);s[70]=o.width;
}
function s00_componente_interface_scsLogOperacao_getSettings(s)
{
	s['name'] = 'string';
	s['AtualizaFiltrosHistoricoOS'] = 'string';
	s['Categoria'] = 'string';
	s['FiltroData'] = 'string';
	s['FiltroOperacao'] = 'string';
	s['FiltroProcedimento'] = 'string';
	s['FiltroRecipiente'] = 'string';
	s['FiltroUsuario'] = 'string';
	s['InformacoesAdicionaisHistoricoOS'] = 'string';
	s['JSONLevels'] = 'string';
	s['Mensagens'] = 'string';
	s['PacienteId'] = 'string';
	s['Segmento'] = 'string';
	s['scsAnalitoId'] = 'string';
	s['scsFiltroHistoricoOS'] = 'string';
	s['scsIdOS'] = 'string';
	s['scsInfoLeft'] = 'integer';
	s['scsInfoTop'] = 'integer';
	s['scsOrigem'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsLogOperacao_atualizarHistorico = function() {
var zsm = zenSynchronousMode;
zenSynchronousMode = true;
try{
var objTp = this.getChildById("tpHistoricoOS");
if(!this.scsOrigem=="S02"){
var pFiltroOSchk			= this.scsFiltroHistoricoOS["chkTipoOS"];
var pFiltroRecipientechk	= this.scsFiltroHistoricoOS["chkTipoRecipiente"];
var pFiltroProcedimentochk	= this.scsFiltroHistoricoOS["chkTipoProcedimento"];
var colunaNome = " ";
if (!pFiltroOSchk){
if (pFiltroRecipientechk && !pFiltroProcedimentochk){
colunaNome = this.Mensagens["headerRecipiente"];
}else if(!pFiltroRecipientechk && pFiltroProcedimentochk){
if (this.Segmento == 1){
colunaNome = this.Mensagens["headerProcedimento"];
}else if(this.Segmento == 2){
colunaNome = this.Mensagens["headerVacina"];
}
}
}
objTp.columns[3].setProperty("header", colunaNome);
objTp.sortOrder = "";
objTp.currColumn = "";
}
objTp.executeQuery(true);
}catch(ex){
zenPage.alertaShift("Exception: atualizarHistorico(): "+ex.description);
}
zenSynchronousMode = zsm;
}

self.s00_componente_interface_scsLogOperacao_exibirInformacoesAdicionais = function(pMostrar,pMotivo,pTitulo,pIdPosicaoHTML,pMotivoLabel) {
var retorno = true;
try{
var objGrupoInfAdicional           = this.getChildById("grpInfAdicionalHistoricoOS");//PopUp
var objLblMotivo                   = this.getChildById("lblMotivo");
var objHtmlInfAdicionalHistoricoOS = this.getChildById("htmlInfAdicionalHistoricoOS");
var divHtmlInfAdicionalHistoricoOS = objHtmlInfAdicionalHistoricoOS.getEnclosingDiv();
var objLblTitulo                   = this.getChildById("tituloHistoricoOS");
var lblLblTitulo                   = objLblTitulo.getLabelElement();
objGrupoInfAdicional.setProperty("hidden", !pMostrar);
if (pMostrar){
if(pMotivo != undefined && pMotivo != ""){
objLblMotivo.setProperty("hidden", false);
objLblMotivo.setProperty("value", pMotivo);
if(pMotivoLabel != undefined && pMotivoLabel != ""){
objLblMotivo.setProperty("label",pMotivoLabel);
}
}else{
objLblMotivo.setProperty("value", " ");
objLblMotivo.setProperty("hidden", true);
}
if(pTitulo != undefined && pTitulo != ""){
lblLblTitulo.innerHTML = pTitulo;
divHtmlInfAdicionalHistoricoOS.style = "borderTop", "1px solid #ddd";
}else{
lblLblTitulo.innerHTML = " ";
divHtmlInfAdicionalHistoricoOS.style = "borderTop", "0px";
}
objHtmlInfAdicionalHistoricoOS.setProperty("content", this.InformacoesAdicionaisHistoricoOS[pIdPosicaoHTML]);
}else{ // reseta a interface
lblLblTitulo.innerHTML = "";
objHtmlInfAdicionalHistoricoOS.setProperty("content", " ");
objLblMotivo.setProperty("value", " ");
}
}catch(ex){
if(ex != 0) alert("exibirInformacoesAdicionais():"+ex.description);
retorno = false;
}
return retorno;
}

self.s00_componente_interface_scsLogOperacao_exibirInformacoesPadraoLog = function(pOperacao,pData,pHora,pUsuario,pDado,pTipo) {
var retorno = 1;
try{
this.getChildById("lblInfPadraoOp").setProperty("value",pOperacao);
this.getChildById("lblInfPadraoData").setProperty("value",pData);
this.getChildById("lblInfPadraoHora").setProperty("value",pHora);
this.getChildById("lblInfPadraoUsuario").setProperty("value",pUsuario);
if(pTipo=="3"){ //tipo recipiente
this.getChildById("lblInfPadraoTipo").setHidden(0);
this.getChildById("lblInfPadraoTipo").setProperty("enclosingStyle","display:normal;margin-top:3px;");
this.getChildById("lblInfPadraoTipo").setProperty("label",this.Mensagens["headerRecipiente"]+": ");
this.getChildById("lblInfPadraoTipo").setProperty("value",pDado);
}else if(pTipo=="4"){ //tipo procedimento
var label = "";
if (this.Segmento == 1){
label = this.Mensagens["headerProcedimento"];
}else if (this.Segmento == 2){
label = this.Mensagens["headerVacina"];
}
this.getChildById("lblInfPadraoTipo").setHidden(0);
this.getChildById("lblInfPadraoTipo").setProperty("enclosingStyle","display:normal;margin-top:3px;");
this.getChildById("lblInfPadraoTipo").setProperty("label",label+": ");
this.getChildById("lblInfPadraoTipo").setProperty("value",pDado);
if (pDado == ""){
this.getChildById("lblInfPadraoTipo").setHidden(1);
}
}else{
this.getChildById("lblInfPadraoTipo").setHidden(1);
this.getChildById("lblInfPadraoTipo").setProperty("enclosingStyle","display:none;margin-top:3px");
}
}catch(ex){
alert("exibirInformacoesPadraoLog():"+ex.description);
}
return retorno;
}

self.s00_componente_interface_scsLogOperacao_filtrosOrigem = function() {
try {
if(this.scsOrigem=="S02"){
this.getChildById("grpFiltroS02").setHidden(0);
this.getChildById("grpFiltro").setHidden(1);
}
}
catch (ex) {
alert("filtrosOrigem():"+ex.description);
}
}

self.s00_componente_interface_scsLogOperacao_onloadHandler = function() {
if (this.disabled && this.parent && !this.parent.disabled) {
this.setProperty('disabled',true);
}
this.filtrosOrigem();
}

self.s00_componente_interface_scsLogOperacao_parseJSON = function(pStringJson) {
try{
var tUsaEval = 1;
if(typeof(JSON) != "undefined"){
try {
pStringJson = JSON.parse(pStringJson);
tUsaEval = 0;
}catch (ex) {
tUsaEval = 1;
}
}
if (tUsaEval) {
if(pStringJson){
pStringJson = eval("("+pStringJson+")");
}else{
pStringJson = {};
}
}
}catch(ex){
if (ex) zenPage.alertaShift("parseJSON:" + zenPage.getMsgExcecao(ex));
}
return pStringJson;
}

self.s00_componente_interface_scsLogOperacao_selecionarFiltroHistoricoOS = function() {
if(this.scsOrigem=="S02"){
this.scsFiltroHistoricoOS["chkTipoAnalito"] = (this.getChildById("chkTipoAnalito").getValue())?1:0;
this.scsFiltroHistoricoOS["chkTipoAmostra"] = (this.getChildById("chkTipoAmostra").getValue())?1:0;
}else{
this.scsFiltroHistoricoOS["chkTipoOS"] = (this.getChildById("chkTipoOS").getValue())?1:0;
this.scsFiltroHistoricoOS["chkTipoRecipiente"] = (this.getChildById("chkTipoRecipiente").getValue())?1:0;
this.scsFiltroHistoricoOS["chkTipoProcedimento"] = (this.getChildById("chkTipoProcedimento").getValue())?1:0;
this.scsFiltroHistoricoOS["chkTipoPacienteDadosCadastrais"] = (this.getChildById("chkTipoPacienteDadosCadastrais").getValue())?1:0;
}
this.atualizarHistorico();
}

self.s00_componente_interface_scsLogOperacao_toJSON = function(obj,cycle,level) {
try {
cycle = ('undefined' == typeof cycle) ? Math.floor(Math.random()*1000000) : cycle;
level = ('undefined' == typeof level) ? 0 : level;
if (level > this.JSONLevels) {
alert('jsonProvider: too many levels in JSON object');
}
if ('object' == typeof obj && null != obj) {
if (null == obj.__cycle || cycle != obj.__cycle) {
obj.__cycle = cycle;
}
else if (cycle == obj.__cycle) {
return 'null';
}
}
var t = new Array();
switch (typeof obj) {
case 'boolean':
t[t.length] = obj ? 'true' : 'false';
break;
case 'string':
var text = obj.toString();
text = text.replace(/\\/g,'\\\\'); // escape any backslash
text = text.replace(/\'/g,"\\'"); // escape any single quotes
text = text.replace(/\"/g,'\\"');
t[t.length] = '\"' + text + '\"';
break;
case 'number':
t[t.length] = obj;
break;
case 'object':
if (null == obj) {
return 'null';
}
else if (obj.constructor == Function) {
return '';
}
else if (obj.constructor == Array) {
t[t.length] = '[';
for (var n = 0; n < obj.length; n++) {
var sub = this.toJSON(obj[n],cycle,level+1);
if (null == sub) return null;
t[t.length] = ((n>0)?',':'') + sub;
}
t[t.length] = ']';
}
else {
var pc = 0;
t[t.length] = '{';
for (var p in obj) {
if ('function' != typeof obj[p]) {
if ((p.indexOf('_')==-1)||(p=='_class')) {
var sub = this.toJSON(obj[p],cycle,level+1);
if (null == sub) return null;
t[t.length] = ((pc++>0)?',':'')+ '\"' + p + '\":' + sub + '';
}
}
}
t[t.length] = '}\n';
}
break;
case 'function':
break;
default:
break;
}
return t.join('').replace(":,", ":\"\",");
}
catch(ex) {
}
return null;
}

self.s00_componente_interface_scsLogOperacao_CreateRSHistorico = function(tSC,pInfo) {
	return zenInstanceMethod(this,'CreateRSHistorico','L,O','HANDLE',arguments);
}

self.s00_componente_interface_scsLogOperacao_DesenharInformacoesEspecificas = function(pTitulo,pStrEnclosingHTML,pLabelMotivo,pOrigem,pTipo,pLogId,pLogOperacaoId,pDado1,pDado2,pDadosEspecificos) {
	return zenClassMethod(this,'DesenharInformacoesEspecificas','L,L,L,L,L,L,L,L,L,L','STATUS',arguments);
}

self.s00_componente_interface_scsLogOperacao_GerarLIInformacoesEspecificas = function(pOrigem,pLabel,pTexto,pMostarMarcador,pEstiloExtraLI,pEstiloExtraLabel,pEstiloExtraTexto,pFloat) {
	return zenClassMethod(this,'GerarLIInformacoesEspecificas','L,L,L,B,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsLogOperacao_PreparaRSHistoricoAnalito = function(tSC,pInfo,pAnalitoId,pAmostraId,pAnalitock,pAmostrack) {
	return zenClassMethod(this,'PreparaRSHistoricoAnalito','L,O,L,L,L,L','HANDLE',arguments);
}

self.s00_componente_interface_scsLogOperacao_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsLogOperacao__Loader = function() {
	zenLoadClass('s00_componente2_interface_Padrao');
	s00_componente_interface_scsLogOperacao.prototype = zenCreate('s00_componente2_interface_Padrao',-1);
	var p = s00_componente_interface_scsLogOperacao.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsLogOperacao;
	p.superClass = ('undefined' == typeof s00_componente2_interface_Padrao) ? zenMaster.s00_componente2_interface_Padrao.prototype:s00_componente2_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsLogOperacao';
	p._type = 'scsLogOperacao';
	p.serialize = s00_componente_interface_scsLogOperacao_serialize;
	p.getSettings = s00_componente_interface_scsLogOperacao_getSettings;
	p.CreateRSHistorico = s00_componente_interface_scsLogOperacao_CreateRSHistorico;
	p.DesenharInformacoesEspecificas = s00_componente_interface_scsLogOperacao_DesenharInformacoesEspecificas;
	p.GerarLIInformacoesEspecificas = s00_componente_interface_scsLogOperacao_GerarLIInformacoesEspecificas;
	p.PreparaRSHistoricoAnalito = s00_componente_interface_scsLogOperacao_PreparaRSHistoricoAnalito;
	p.ReallyRefreshContents = s00_componente_interface_scsLogOperacao_ReallyRefreshContents;
	p.atualizarHistorico = s00_componente_interface_scsLogOperacao_atualizarHistorico;
	p.exibirInformacoesAdicionais = s00_componente_interface_scsLogOperacao_exibirInformacoesAdicionais;
	p.exibirInformacoesPadraoLog = s00_componente_interface_scsLogOperacao_exibirInformacoesPadraoLog;
	p.filtrosOrigem = s00_componente_interface_scsLogOperacao_filtrosOrigem;
	p.onloadHandler = s00_componente_interface_scsLogOperacao_onloadHandler;
	p.parseJSON = s00_componente_interface_scsLogOperacao_parseJSON;
	p.selecionarFiltroHistoricoOS = s00_componente_interface_scsLogOperacao_selecionarFiltroHistoricoOS;
	p.toJSON = s00_componente_interface_scsLogOperacao_toJSON;
}

self._zenClassIdx['http://www.e-lis.com.br/zen/scsMultiplaSelecao'] = 's00_componente_interface_scsMultiplaSelecao';
self.s00_componente_interface_scsMultiplaSelecao = function(index,id) {
	if (index>=0) {s00_componente_interface_scsMultiplaSelecao__init(this,index,id);}
}

self.s00_componente_interface_scsMultiplaSelecao__init = function(o,index,id) {
	('undefined' == typeof s00_componente_interface_Padrao__init) ?zenMaster.s00_componente_interface_Padrao__init(o,index,id):s00_componente_interface_Padrao__init(o,index,id);
	o.scsBTStyle = '';
	o.scsCampoDisplay = '';
	o.scsDCChoice = '';
	o.scsDCDisplay = '';
	o.scsDCDropDownHeight = '';
	o.scsDCDropDownLeft = '';
	o.scsDCDropDownWidth = '';
	o.scsDCEditable = '';
	o.scsDCExibir = false;
	o.scsDCHeader = '';
	o.scsDCsqlLookup = '';
	o.scsHzScroll = false;
	o.scsLabel = '';
	o.scsLabelStyle = '';
	o.scsOnIniciarSelecao = '';
	o.scsOnTerminarSelecao = '';
	o.scsPermiteNenhumSelecionados = false;
	o.scsRSDataCombo = ''; // encrypted
	o.scsRSTablePane = ''; // encrypted
	o.scsSelecaoUnica = false;
	o.scsSize = '';
	o.scsTPBodyHeight = '';
	o.scsTPColunaHidden = '';
	o.scsTPColunaId = '';
	o.scsTPColunaTamanho = '';
	o.scsTPColunaTitulo = '';
	o.scsTPFilter = '';
	o.scsTPFilterOp = '';
	o.scsTPLeft = '';
	o.scsTPOrderByClause = '';
	o.scsTPPageSize = '';
	o.scsTPTableName = '';
	o.scsTPTop = '';
	o.scsTextNenhumSelecionados = 'Nenhum item selecionado';
	o.scsTextTodos = 'Todos os itens selecionados';
	o.scsTextVarios = 'Vários itens selecionados';
	o.scsTodosSelecionados = '';
	o.scsWidth = '';
	o.selecionados = '';
	o.selecionadosAntes = '';
	o.todosAntes = '0';
	o.todosSelecionados = '0';
	o.total = '0';
}
function s00_componente_interface_scsMultiplaSelecao_serialize(set,s)
{
	var o = this;s[0]='1823934757';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=(o.childrenCreated?1:0);s[14]=o.containerStyle;s[15]=(o.disabled?1:0);s[16]=(o.dragEnabled?1:0);s[17]=(o.dropEnabled?1:0);s[18]=(o.dynamic?1:0);s[19]=o.enclosingClass;s[20]=o.enclosingStyle;s[21]=o.error;s[22]=o.groupClass;s[23]=o.groupStyle;s[24]=o.height;s[25]=(o.hidden?1:0);s[26]=o.hint;s[27]=o.hintClass;s[28]=o.hintStyle;s[29]=o.label;s[30]=o.labelClass;s[31]=o.labelDisabledClass;s[32]=o.labelPosition;s[33]=o.labelStyle;s[34]=o.layout;s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onclick;s[38]=o.ondrag;s[39]=o.ondrop;s[40]=o.onhide;s[41]=o.onrefresh;s[42]=o.onshow;s[43]=o.onupdate;s[44]=o.overlayMode;s[45]=o.renderFlag;s[46]=o.scsBTStyle;s[47]=o.scsCampoDisplay;s[48]=o.scsDCChoice;s[49]=o.scsDCDisplay;s[50]=o.scsDCDropDownHeight;s[51]=o.scsDCDropDownLeft;s[52]=o.scsDCDropDownWidth;s[53]=o.scsDCEditable;s[54]=(o.scsDCExibir?1:0);s[55]=o.scsDCHeader;s[56]=o.scsDCsqlLookup;s[57]=(o.scsHzScroll?1:0);s[58]=o.scsLabel;s[59]=o.scsLabelStyle;s[60]=o.scsOnIniciarSelecao;s[61]=o.scsOnTerminarSelecao;s[62]=(o.scsPermiteNenhumSelecionados?1:0);s[63]=o.scsRSDataCombo;s[64]=o.scsRSTablePane;s[65]=(o.scsSelecaoUnica?1:0);s[66]=o.scsSize;s[67]=o.scsTPBodyHeight;s[68]=o.scsTPColunaHidden;s[69]=o.scsTPColunaId;s[70]=o.scsTPColunaTamanho;s[71]=o.scsTPColunaTitulo;s[72]=o.scsTPFilter;s[73]=o.scsTPFilterOp;s[74]=o.scsTPLeft;s[75]=o.scsTPOrderByClause;s[76]=o.scsTPPageSize;s[77]=o.scsTPTableName;s[78]=o.scsTPTop;s[79]=o.scsTextNenhumSelecionados;s[80]=o.scsTextTodos;s[81]=o.scsTextVarios;s[82]=o.scsTodosSelecionados;s[83]=o.scsWidth;s[84]=o.selecionados;s[85]=o.selecionadosAntes;s[86]=(o.showLabel?1:0);s[87]=o.slice;s[88]=o.title;s[89]=o.todosAntes;s[90]=o.todosSelecionados;s[91]=o.total;s[92]=o.tuple;s[93]=o.valign;s[94]=(o.visible?1:0);s[95]=o.width;
}
function s00_componente_interface_scsMultiplaSelecao_getSettings(s)
{
	s['name'] = 'string';
	s['scsBTStyle'] = 'string';
	s['scsCampoDisplay'] = 'string';
	s['scsDCChoice'] = 'string';
	s['scsDCDisplay'] = 'string';
	s['scsDCDropDownHeight'] = 'string';
	s['scsDCDropDownLeft'] = 'string';
	s['scsDCDropDownWidth'] = 'string';
	s['scsDCEditable'] = 'string';
	s['scsDCExibir'] = 'boolean';
	s['scsDCHeader'] = 'string';
	s['scsDCsqlLookup'] = 'string';
	s['scsHzScroll'] = 'boolean';
	s['scsLabel'] = 'string';
	s['scsLabelStyle'] = 'string';
	s['scsOnIniciarSelecao'] = 'eventHandler';
	s['scsOnTerminarSelecao'] = 'eventHandler';
	s['scsPermiteNenhumSelecionados'] = 'boolean';
	s['scsSelecaoUnica'] = 'boolean';
	s['scsSize'] = 'integer';
	s['scsTPBodyHeight'] = 'string';
	s['scsTPColunaHidden'] = 'string';
	s['scsTPColunaId'] = 'string';
	s['scsTPColunaTamanho'] = 'string';
	s['scsTPColunaTitulo'] = 'string';
	s['scsTPFilter'] = 'string';
	s['scsTPFilterOp'] = 'string';
	s['scsTPLeft'] = 'integer';
	s['scsTPOrderByClause'] = 'string';
	s['scsTPPageSize'] = 'integer';
	s['scsTPTableName'] = 'string';
	s['scsTPTop'] = 'integer';
	s['scsTextNenhumSelecionados'] = 'string';
	s['scsTextTodos'] = 'string';
	s['scsTextVarios'] = 'string';
	s['scsTodosSelecionados'] = 'string';
	s['scsWidth'] = 'string';
	s['selecionados'] = 'string';
	s['selecionadosAntes'] = 'string';
	s['todosAntes'] = 'string';
	s['todosSelecionados'] = 'string';
	s['total'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_abrirPopup = function(pIdPopup,pTop,pLeft,pWidth,pHeight) {
componente = zenThis.composite;
var estilo = ""
if((pTop != undefined) && (pTop != "")){
var estilo = estilo + "top:"+pTop+";";
}
if((pLeft != undefined) && (pLeft != "")){
var estilo = estilo + "left:"+pLeft+";";
}
if((pWidth != undefined) && (pWidth != "")){
var estilo = estilo + "width:"+pWidth+";";
}
if((pHeight != undefined) && (pHeight != "")){
var estilo = estilo + "height:"+pHeight+";";
}
if(estilo != ""){
componente.getChildById(pIdPopup).setProperty("enclosingStyle",estilo);
}
componente.getChildById("fundoPopup").setProperty("hidden",0);
componente.getChildById(pIdPopup).setHidden(0);
}

self.s00_componente_interface_scsMultiplaSelecao_cancelarSelecao = function() {
componente = zenPage.getComponent(this.index);
componente.selecionados = componente.selecionadosAntes;
componente.todosSelecionados = componente.todosAntes;
componente.getChildById("fundoPopup").setProperty("hidden",1);
componente.getChildById("popupSelecao").setHidden(1);
return true;
}

self.s00_componente_interface_scsMultiplaSelecao_chamarOnIniciarSelecao = function() {
zenInvokeCallbackMethod(this.scsOnIniciarSelecao, this, "scsOnIniciarSelecao");
}

self.s00_componente_interface_scsMultiplaSelecao_chamarOnTerminarSelecao = function() {
zenInvokeCallbackMethod(this.scsOnTerminarSelecao, this, "scsOnTerminarSelecao");
}

self.s00_componente_interface_scsMultiplaSelecao_getSelecionados = function() {
var comp = zenPage.getComponent(this.index);
if(!comp.scsPermiteNenhumSelecionados && (comp.todosSelecionados == 1 || comp.selecionados == "")){
return comp.scsTodosSelecionados;
}else if(comp.scsPermiteNenhumSelecionados){
if(comp.todosSelecionados == 1){
return comp.scsTodosSelecionados;
}else if(comp.selecionados == ""){
return "";
}
}
return comp.selecionados;
}

self.s00_componente_interface_scsMultiplaSelecao_iniciarSelecao = function() {
var retorno = 1;
var zsm = zenSynchronousMode;
zenSynchronousMode = 1;
try{
componente = zenPage.getComponent(this.index);
componente.getChildById("tpSelecao").executeQuery();
componente.total = componente.getChildById("tpSelecao").getProperty("rowCount");
componente.selecionadosAntes = componente.selecionados;
componente.todosAntes = componente.todosSelecionados;
var top = 80;
var left = 120;
var width = 690;
if (componente.scsTPLeft != ""){ left = componente.scsTPLeft; }
if (componente.scsTPTop  != ""){ top  = componente.scsTPTop;  }
if (componente.scsWidth  != ""){ width = componente.scsWidth;  }
componente.abrirPopup("popupSelecao", top, left, width);
componente.chamarOnIniciarSelecao();
}catch(e){
retorno = 0;
zenPage.alertaShift(e.description);
}
zenSynchronousMode = zsm;
return retorno;
}

self.s00_componente_interface_scsMultiplaSelecao_limparComponente = function() {
var zsm = zenSynchronousMode;
zenSynchronousMode = true;
try{
var comp = zenPage.getComponent(this.index);
var tp = comp.getChildById("tpSelecao");
tp.resetColumnFilters();
tp.sortOrder = "";
tp.currColumn = "";
var msg = "";
if(!comp.scsPermiteNenhumSelecionados){
msg = comp.scsTextTodos;
comp.todosSelecionados = 1;
}else{
msg = comp.scsTextNenhumSelecionados;
comp.todosSelecionados = 0;
}
comp.selecionados = "";
comp.getChildById("dtcSelecao").getEnclosingDiv().getElementsByTagName("input")[1].value = msg;
comp.getChildById("cbPaginacao").setValue("500");
comp.chamarOnTerminarSelecao();
}catch(ex){
if (ex && ex.description) zenPage.alertaShift(ex.description);
}
zenSynchronousMode = zsm;
}

self.s00_componente_interface_scsMultiplaSelecao_listFind = function(pLista,pValor) {
var qtd = pLista.length
for(cvalor=0;cvalor < qtd;cvalor++) {
if (pLista[cvalor] == pValor) {
return cvalor
}
}
return -1
}

self.s00_componente_interface_scsMultiplaSelecao_selecionar = function(pIdCampoChave,pIdCampoDesc) {
var retorno = 1;
try{
var comp = zenPage.getComponent(this.index);
var pTablePaneId	= "tpSelecao";
var pIdCampoChave	= "Codigo";
var pIdCampoDesc	= comp.scsCampoDisplay == "" ? "Descricao" : comp.scsCampoDisplay;
var todosSel	= comp.todosSelecionados == 1;
var selecao		= comp.selecionados;
var txtFiltro	= comp.getChildById("dtcSelecao").getEnclosingDiv().getElementsByTagName("input")[1];
if(todosSel){
txtFiltro.value = comp.scsTextTodos;
}else if(selecao){
var selecao = selecao.split(",");
if((selecao.length == 1)&&(selecao[0] != "")){
if(this.scsDCsqlLookup != "") {
comp.getChildById("dtcSelecao").setValue(selecao[0]);
} else {
var encontrou = false;
var pagina = 1;
var tpProc = comp.getChildById(pTablePaneId);
var totalPaginas = tpProc.getPageCount();
while((!encontrou)&&(pagina <= totalPaginas)){
var i = 0;
var linha;
while(linha = tpProc.getRenderedRowData(i)){
if(linha[pIdCampoChave] == selecao[0]){
txtFiltro.value = linha[pIdCampoDesc];
encontrou = true;
break;
}
i++;
}
if(!encontrou){
pagina++;
tpProc.nextPage();
}
}
}
}else if((selecao.length == 0)||((selecao.length == 1)&&(selecao[0] == ""))){
if(!comp.scsPermiteNenhumSelecionados){
txtFiltro.value = comp.scsTextTodos;
}else{
txtFiltro.value = comp.scsTextNenhumSelecionados;
}
}else{
txtFiltro.value = comp.scsTextVarios;
}
}else{
if(!comp.scsPermiteNenhumSelecionados){
txtFiltro.value = comp.scsTextTodos;
}else{
txtFiltro.value = comp.scsTextNenhumSelecionados;
}
}
comp.getChildById("fundoPopup").setProperty("hidden",1);
comp.getChildById("popupSelecao").setHidden(1);
comp.chamarOnTerminarSelecao();
}catch(e){
retorno = 0;
zenPage.alertaShift(e.description);
}
return retorno;
}

self.s00_componente_interface_scsMultiplaSelecao_selecionarDataCombo = function(pIdDataCombo) {
var input = zenPage.getComponentById(pIdDataCombo).getEnclosingDiv().getElementsByTagName("input")[1];
input.select();
}

self.s00_componente_interface_scsMultiplaSelecao_selecionarLinha = function(pTablePaneId,pId,pComp,pAlteraTodos,pSelecionado) {
try{
var comp = zenPage.getComponent(this.index);
var selecionados  = comp.selecionados ? comp.selecionados.split(",") : new Array();
if (pComp.checked){
selecionados.push(pId)
}else{
var posicao = comp.listFind(selecionados,pId);
if (posicao > -1){
selecionados.splice(posicao,1);
}
}
if(pAlteraTodos){
var todosSel = pSelecionado
}else{
var todosSel = comp.verificarTodosSelecionados(pTablePaneId, 1);
}
if(!todosSel) {
var posicao = comp.listFind(selecionados, comp.scsTodosSelecionados);
if (posicao > -1){
selecionados.splice(posicao,1);
}
}
comp.selecionados = selecionados.join(",");
if(todosSel){
comp.todosSelecionados = 1;
}else{
comp.todosSelecionados = 0;
}
}catch (ex){
zenPage.alertaShift(ex.description);
}
return 1
}

self.s00_componente_interface_scsMultiplaSelecao_selecionarTodos = function(pTablePaneId,selecionado) {
var total = 0;
try{
var componente = zenPage.getComponent(this.index);
var elementos = document.getElementsByName("ckMult"+pTablePaneId);
total = elementos.length;
for (var i=0;i<total;i++){
var comp = elementos[i];
if (selecionado){
if (!comp.checked){
comp.checked = 1
componente.selecionarLinha(pTablePaneId,comp.value,comp,1,selecionado);
}
}else{
if (comp.checked){
comp.checked = 0
componente.selecionarLinha(pTablePaneId,comp.value,comp,1,selecionado);
}
}
}
}catch (ex){
zenPage.alertaShift(ex.description);
}finally{
if(total == 0) return;
var chkSelTodos = "ckTodos"+pTablePaneId;
document.getElementById(chkSelTodos).checked = selecionado ? "checked" : "";
if(selecionado && total == componente.total){
componente.todosSelecionados = 1;
}else{
componente.todosSelecionados = 0;
}
if(!selecionado) componente.selecionados = "";
}
return 1;
}

self.s00_componente_interface_scsMultiplaSelecao_setFocus = function() {
var input = this.getChildById("dtcSelecao").getEnclosingDiv().getElementsByTagName("input")[1];
input.select();
}

self.s00_componente_interface_scsMultiplaSelecao_setSelecaoDataCombo = function(pValor,pUsaLookup) {
var retorno = "";
try{
var comp = zenPage.getComponent(this.index);
comp.selecionados		= pValor;
comp.todosSelecionados	= 0;
if(pValor == ""){
var txtFiltro	= comp.getChildById("dtcSelecao").getEnclosingDiv().getElementsByTagName("input")[1];
if(!comp.scsPermiteNenhumSelecionados){
txtFiltro.value	= comp.scsTextTodos;
comp.todosSelecionados	= 1;
}else{
txtFiltro.value	= comp.scsTextNenhumSelecionados;
}
}else{
if(comp.scsDCsqlLookup != ""){
comp.getChildById("dtcSelecao").setValue(pValor);
}
if(pValor == comp.scsTodosSelecionados){
comp.todosSelecionados	= 1;
}
}
comp.chamarOnTerminarSelecao();
}catch(e){
retorno = "";
zenPage.alertaShift(e.description);
}
return retorno;
}

self.s00_componente_interface_scsMultiplaSelecao_setSelecaoUnica = function(pSelecaoUnica) {
var btSelecao = this.getChildById("btAbrirSelecao");
btSelecao.setHidden(pSelecaoUnica);
}

self.s00_componente_interface_scsMultiplaSelecao_setSelecionados = function(pValor,pRefresh) {
var zsm = zenSynchronousMode;
zenSynchronousMode = true;
var comp = zenPage.getComponent(this.index);
comp.setSelecaoDataCombo(pValor);
if(pRefresh != false) {
var ret = comp.getChildById("tpSelecao").executeQuery();
}
comp.selecionar();
zenSynchronousMode = zsm;
return 1;
}

self.s00_componente_interface_scsMultiplaSelecao_setarLarguraTablePane = function(pTablePaneId) {
try{
var comp = zenPage.getComponent(this.index);
var checked 	  = comp.todosSelecionados == 1 ? "checked" : "";
var chkSelTodos   = "ckTodos"+pTablePaneId;
var componente = "<input id='"+chkSelTodos+"' "+
"		 type='checkbox' "+
"		 value='0' "+
"		 onclick='zenPage.getComponent("+this.index+").selecionarTodos(\""+pTablePaneId+"\", this.checked)' "+
checked+
"/>";
var tpanediv = document.getElementById(pTablePaneId);
var tpanethFirst = $(tpanediv).find("thead").find("tr").find("th")[0]; // tpanediv.childNodes[0].childNodes[0].childNodes[0].childNodes[0];
if(tpanethFirst != undefined){
tpanethFirst.onclick = "";
tpanethFirst.style.cursor= "default";
tpanethFirst.innerHTML = "";
var compCheckbox = $(componente)[0]; // document.createElement(componente);
tpanethFirst.appendChild(compCheckbox);
}
}catch (ex){
zenPage.alertaShift(ex.description);
}
return 1;
}

self.s00_componente_interface_scsMultiplaSelecao_verificarTodosSelecionados = function(pTablePaneId,pSelecionar) {
try{
var componente = zenPage.getComponent(this.index);
var elementos = document.getElementsByName("ckMult"+pTablePaneId);
var total = elementos.length;
var chkSelTodos = document.getElementById("ckTodos"+pTablePaneId);
for (i=0;i<total;i++){
comp = elementos[i];
if (!comp.checked){
if(pSelecionar){
chkSelTodos.checked = false;
}
return false;
}
}
if(componente.total != total){
chkSelTodos.checked = false;
return false;
}
}catch (ex){
zenPage.alertaShift(ex.description);
}
if(pSelecionar){
chkSelTodos.checked = true;
}
return true;
}

self.s00_componente_interface_scsMultiplaSelecao_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente_interface_scsMultiplaSelecao__Loader = function() {
	zenLoadClass('s00_componente_interface_Padrao');
	s00_componente_interface_scsMultiplaSelecao.prototype = zenCreate('s00_componente_interface_Padrao',-1);
	var p = s00_componente_interface_scsMultiplaSelecao.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsMultiplaSelecao;
	p.superClass = ('undefined' == typeof s00_componente_interface_Padrao) ? zenMaster.s00_componente_interface_Padrao.prototype:s00_componente_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsMultiplaSelecao';
	p._type = 'scsMultiplaSelecao';
	p.serialize = s00_componente_interface_scsMultiplaSelecao_serialize;
	p.getSettings = s00_componente_interface_scsMultiplaSelecao_getSettings;
	p.AjustaTamanhoValor = s00_componente_interface_scsMultiplaSelecao_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente_interface_scsMultiplaSelecao_ApresentaExcecao;
	p.GeraCheckBoxHtml = s00_componente_interface_scsMultiplaSelecao_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente_interface_scsMultiplaSelecao_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente_interface_scsMultiplaSelecao_GeraRadioHtml;
	p.GeraSV1Label = s00_componente_interface_scsMultiplaSelecao_GeraSV1Label;
	p.GeraSV1Text = s00_componente_interface_scsMultiplaSelecao_GeraSV1Text;
	p.GeraSelectHtml = s00_componente_interface_scsMultiplaSelecao_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente_interface_scsMultiplaSelecao_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente_interface_scsMultiplaSelecao_GeraTextHtml;
	p.GetValorPropriedade = s00_componente_interface_scsMultiplaSelecao_GetValorPropriedade;
	p.ReallyRefreshContents = s00_componente_interface_scsMultiplaSelecao_ReallyRefreshContents;
	p.RetornaValorCampo = s00_componente_interface_scsMultiplaSelecao_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente_interface_scsMultiplaSelecao_SetValorPropriedade;
	p.VerificaErro = s00_componente_interface_scsMultiplaSelecao_VerificaErro;
	p.abrirPopup = s00_componente_interface_scsMultiplaSelecao_abrirPopup;
	p.cancelarSelecao = s00_componente_interface_scsMultiplaSelecao_cancelarSelecao;
	p.chamarOnIniciarSelecao = s00_componente_interface_scsMultiplaSelecao_chamarOnIniciarSelecao;
	p.chamarOnTerminarSelecao = s00_componente_interface_scsMultiplaSelecao_chamarOnTerminarSelecao;
	p.getSelecionados = s00_componente_interface_scsMultiplaSelecao_getSelecionados;
	p.iniciarSelecao = s00_componente_interface_scsMultiplaSelecao_iniciarSelecao;
	p.limparComponente = s00_componente_interface_scsMultiplaSelecao_limparComponente;
	p.listFind = s00_componente_interface_scsMultiplaSelecao_listFind;
	p.selecionar = s00_componente_interface_scsMultiplaSelecao_selecionar;
	p.selecionarDataCombo = s00_componente_interface_scsMultiplaSelecao_selecionarDataCombo;
	p.selecionarLinha = s00_componente_interface_scsMultiplaSelecao_selecionarLinha;
	p.selecionarTodos = s00_componente_interface_scsMultiplaSelecao_selecionarTodos;
	p.setFocus = s00_componente_interface_scsMultiplaSelecao_setFocus;
	p.setSelecaoDataCombo = s00_componente_interface_scsMultiplaSelecao_setSelecaoDataCombo;
	p.setSelecaoUnica = s00_componente_interface_scsMultiplaSelecao_setSelecaoUnica;
	p.setSelecionados = s00_componente_interface_scsMultiplaSelecao_setSelecionados;
	p.setarLarguraTablePane = s00_componente_interface_scsMultiplaSelecao_setarLarguraTablePane;
	p.verificarTodosSelecionados = s00_componente_interface_scsMultiplaSelecao_verificarTodosSelecionados;
}

self._zenClassIdx['scsMultiplaSelecao2'] = 's00_componente_interface_scsMultiplaSelecao2';
self.s00_componente_interface_scsMultiplaSelecao2 = function(index,id) {
	if (index>=0) {s00_componente_interface_scsMultiplaSelecao2__init(this,index,id);}
}

self.s00_componente_interface_scsMultiplaSelecao2__init = function(o,index,id) {
	('undefined' == typeof s00_componente2_interface_Padrao__init) ?zenMaster.s00_componente2_interface_Padrao__init(o,index,id):s00_componente2_interface_Padrao__init(o,index,id);
	o.JsonLinhas = '';
	o.ListaIdsSelecionados = '';
	o.NaoSelecionados = '';
	o.NaoSelecionadosAntes = '';
	o.Selecionados = '';
	o.SelecionadosAntes = '';
	o.jaCarregado = null;
	o.manterSelecao = null;
	o.operacaoPendente = null;
	o.scsBodyHeightTabelaExibicao = '';
	o.scsChoiceColumnDC = '';
	o.scsColumnHeadersDC = '';
	o.scsColunasTabela = '';
	o.scsColunasTabelaPrincipalDisplay = '';
	o.scsColunasTabelaSelecaoDisplay = '';
	o.scsColunasTabelaTamanho = '';
	o.scsColunasTabelaTitulo = '';
	o.scsComponenteOcupaLarguraTodaDaTela = false;
	o.scsCustomTrapPopUpSelecao = false;
	o.scsDataComboLabelStyle = '';
	o.scsDisplayColumnsDC = '';
	o.scsDropDownHeightDC = '';
	o.scsDropDownWidthDC = '';
	o.scsExibirBotaoPesquisa = true;
	o.scsExibirDataCombo = false;
	o.scsExibirFiltroTabelaPrincipal = false;
	o.scsExibirTabela = false;
	o.scsFilterTypeColunas = '';
	o.scsLabel = '';
	o.scsLazyLoading = false;
	o.scsMiniRowTabelaExibicao = false;
	o.scsNavigatorTabelaExibicao = '';
	o.scsOnBeforeDeleteRowTabelaPrincipal = '';
	o.scsOnChange = '';
	o.scsOnCreateRs = '';
	o.scsOnCreateRsClassName = '';
	o.scsOnDeleteAllRowTabelaPrincipal = '';
	o.scsOnDeleteRowTabelaPrincipal = '';
	o.scsParametrosCliente = '';
	o.scsPermiteNenhumSelecionados = false;
	o.scsRSDataCombo = ''; // encrypted
	o.scsSizeDC = '';
	o.scsSqlLookupDC = '';
	o.scsSqlTabela = '';
	o.scsStringTodosSelecionados = false;
	o.scsTextoNenhumSelecionado = 'Nenhum item selecionado';
	o.scsTextoTodosSelecionados = 'Todos os itens selecionados';
	o.scsTextoVariosSelecionados = 'Vários itens selecionados';
	o.scsTitulo = '';
	o.scsWidthTabelaExibicao = '';
	o.showLabel = false;
	o.size = '';
}
function s00_componente_interface_scsMultiplaSelecao2_serialize(set,s)
{
	var o = this;s[0]='1666846705';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.JsonLinhas;s[7]=o.ListaIdsSelecionados;s[8]=o.NaoSelecionados;s[9]=o.NaoSelecionadosAntes;s[10]=o.Selecionados;s[11]=o.SelecionadosAntes;s[12]=o.align;s[13]=o.aux;s[14]=o.cellAlign;s[15]=o.cellSize;s[16]=o.cellStyle;s[17]=o.cellVAlign;s[18]=set.serializeList(o,o.children,true,'children');s[19]=(o.childrenCreated?1:0);s[20]=o.containerStyle;s[21]=(o.disabled?1:0);s[22]=(o.dragEnabled?1:0);s[23]=(o.dropEnabled?1:0);s[24]=(o.dynamic?1:0);s[25]=o.enclosingClass;s[26]=o.enclosingStyle;s[27]=o.error;s[28]=o.groupClass;s[29]=o.groupStyle;s[30]=o.height;s[31]=(o.hidden?1:0);s[32]=o.hint;s[33]=o.hintClass;s[34]=o.hintStyle;s[35]=o.label;s[36]=o.labelClass;s[37]=o.labelDisabledClass;s[38]=o.labelPosition;s[39]=o.labelStyle;s[40]=o.layout;s[41]=o.onafterdrag;s[42]=o.onbeforedrag;s[43]=o.onclick;s[44]=o.ondrag;s[45]=o.ondrop;s[46]=o.onhide;s[47]=o.onrefresh;s[48]=o.onshow;s[49]=o.onupdate;s[50]=o.overlayMode;s[51]=o.renderFlag;s[52]=o.scsBodyHeightTabelaExibicao;s[53]=o.scsChoiceColumnDC;s[54]=o.scsColumnHeadersDC;s[55]=o.scsColunasTabela;s[56]=o.scsColunasTabelaPrincipalDisplay;s[57]=o.scsColunasTabelaSelecaoDisplay;s[58]=o.scsColunasTabelaTamanho;s[59]=o.scsColunasTabelaTitulo;s[60]=(o.scsComponenteOcupaLarguraTodaDaTela?1:0);s[61]=(o.scsCustomTrapPopUpSelecao?1:0);s[62]=o.scsDataComboLabelStyle;s[63]=o.scsDisplayColumnsDC;s[64]=o.scsDropDownHeightDC;s[65]=o.scsDropDownWidthDC;s[66]=(o.scsExibirBotaoPesquisa?1:0);s[67]=(o.scsExibirDataCombo?1:0);s[68]=(o.scsExibirFiltroTabelaPrincipal?1:0);s[69]=(o.scsExibirTabela?1:0);s[70]=o.scsFilterTypeColunas;s[71]=o.scsLabel;s[72]=(o.scsLazyLoading?1:0);s[73]=(o.scsMiniRowTabelaExibicao?1:0);s[74]=o.scsNavigatorTabelaExibicao;s[75]=o.scsOnBeforeDeleteRowTabelaPrincipal;s[76]=o.scsOnChange;s[77]=o.scsOnCreateRs;s[78]=o.scsOnCreateRsClassName;s[79]=o.scsOnDeleteAllRowTabelaPrincipal;s[80]=o.scsOnDeleteRowTabelaPrincipal;s[81]=o.scsParametrosCliente;s[82]=(o.scsPermiteNenhumSelecionados?1:0);s[83]=o.scsRSDataCombo;s[84]=o.scsSizeDC;s[85]=o.scsSqlLookupDC;s[86]=o.scsSqlTabela;s[87]=(o.scsStringTodosSelecionados?1:0);s[88]=o.scsTextoNenhumSelecionado;s[89]=o.scsTextoTodosSelecionados;s[90]=o.scsTextoVariosSelecionados;s[91]=o.scsTitulo;s[92]=o.scsWidthTabelaExibicao;s[93]=(o.showLabel?1:0);s[94]=o.size;s[95]=o.slice;s[96]=o.title;s[97]=o.tuple;s[98]=o.valign;s[99]=(o.visible?1:0);s[100]=o.width;
}
function s00_componente_interface_scsMultiplaSelecao2_getSettings(s)
{
	s['name'] = 'string';
	s['JsonLinhas'] = 'string';
	s['ListaIdsSelecionados'] = 'string';
	s['NaoSelecionados'] = 'string';
	s['NaoSelecionadosAntes'] = 'string';
	s['Selecionados'] = 'string';
	s['SelecionadosAntes'] = 'string';
	s['scsBodyHeightTabelaExibicao'] = 'string';
	s['scsChoiceColumnDC'] = 'string';
	s['scsColumnHeadersDC'] = 'caption';
	s['scsColunasTabela'] = 'string';
	s['scsColunasTabelaPrincipalDisplay'] = 'string';
	s['scsColunasTabelaSelecaoDisplay'] = 'string';
	s['scsColunasTabelaTamanho'] = 'string';
	s['scsColunasTabelaTitulo'] = 'caption';
	s['scsComponenteOcupaLarguraTodaDaTela'] = 'boolean';
	s['scsCustomTrapPopUpSelecao'] = 'boolean';
	s['scsDataComboLabelStyle'] = 'string';
	s['scsDisplayColumnsDC'] = 'string';
	s['scsDropDownHeightDC'] = 'string';
	s['scsDropDownWidthDC'] = 'string';
	s['scsExibirBotaoPesquisa'] = 'boolean';
	s['scsExibirDataCombo'] = 'boolean';
	s['scsExibirFiltroTabelaPrincipal'] = 'boolean';
	s['scsExibirTabela'] = 'boolean';
	s['scsFilterTypeColunas'] = 'string';
	s['scsLabel'] = 'caption';
	s['scsLazyLoading'] = 'boolean';
	s['scsMiniRowTabelaExibicao'] = 'boolean';
	s['scsNavigatorTabelaExibicao'] = 'string';
	s['scsOnBeforeDeleteRowTabelaPrincipal'] = 'string';
	s['scsOnChange'] = 'eventHandler';
	s['scsOnCreateRs'] = 'string';
	s['scsOnCreateRsClassName'] = 'string';
	s['scsOnDeleteAllRowTabelaPrincipal'] = 'eventHandler';
	s['scsOnDeleteRowTabelaPrincipal'] = 'eventHandler';
	s['scsParametrosCliente'] = 'string';
	s['scsPermiteNenhumSelecionados'] = 'boolean';
	s['scsSizeDC'] = 'string';
	s['scsSqlLookupDC'] = 'string';
	s['scsSqlTabela'] = 'string';
	s['scsStringTodosSelecionados'] = 'boolean';
	s['scsTextoNenhumSelecionado'] = 'caption';
	s['scsTextoTodosSelecionados'] = 'caption';
	s['scsTextoVariosSelecionados'] = 'caption';
	s['scsTitulo'] = 'caption';
	s['scsWidthTabelaExibicao'] = 'string';
	s['showLabel'] = 'boolean';
	s['size'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao2_abrirPopupMultiplaSelecao = function() {
try{
if(!this.jaCarregado){
this.carregarDados();
}else{
this.operacaoPendente = "";
}
var componente = zenPage.getComponent(this.index);
this.SelecionadosAntes = this.Selecionados;
this.NaoSelecionadosAntes = this.NaoSelecionados;
var tabelaNaoSelecionados = componente.getChildById("tableNaoSelecionadosPopup");
var tabelaSelecionados = componente.getChildById("tableSelecionadosPopup");
tabelaNaoSelecionados.clear();
tabelaNaoSelecionados.addRows(this.NaoSelecionados);
tabelaSelecionados.clear();
tabelaSelecionados.addRows(this.Selecionados);
componente.getChildById("popupSelecao").setProperty("hidden", false);
componente.verificarSelecionarTodos();
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_atualizarListaIds = function(pControlarExibicaoDataCombo) {
try{
var colunas = this.scsColunasTabela.split(",");
this.ListaIdsSelecionados = _.pluck(this.Selecionados, colunas[0]);
this.ListaIdsSelecionados = this.ListaIdsSelecionados.join(",");
if(pControlarExibicaoDataCombo != 0){
this.controlarExibicaoDataCombo();
}
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_beforeDeleteRowTabelaPrincipal = function(pData) {
try {
if(this.scsOnBeforeDeleteRowTabelaPrincipal != "") {
var callback = new Function('data', 'return '+this.scsOnBeforeDeleteRowTabelaPrincipal);
return callback(pData);
}
} catch(ex) {
zenPage.exibirExcecao(ex);
return false;
}
return true;
}

self.s00_componente_interface_scsMultiplaSelecao2_cancelarPopupMultiplaSelecao = function() {
try{
var componente = zenPage.getComponent(this.index);
this.Selecionados = this.SelecionadosAntes;
this.NaoSelecionados = this.NaoSelecionadosAntes;
this.atualizarListaIds();
if(this.scsExibirTabela){
var tabelaPrincipal = componente.getChildById("tableSelecionadosPrincipal");
tabelaPrincipal.clear();
tabelaPrincipal.addRows(this.Selecionados);
}
componente.getChildById("popupSelecao").setProperty("hidden", true);
this.atualizarListaIds();
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_carregarDados = function() {
if(!this.jaCarregado){
var zsm = zenSynchronousMode;
try{
zenSynchronousMode = true;
var json = JSON.parse(this.GetJsonObjeto(
this.scsColunasTabela,
this.scsSqlTabela,
this.scsOnCreateRs,
this.scsOnCreateRsClassName,
this.getParametros()
));
this.JsonLinhas = json.Linhas;
this.controlarManterSelecionado()
this.jaCarregado = true;
}catch(e){
throw e;
}finally{
zenSynchronousMode = zsm;
}
}
}

self.s00_componente_interface_scsMultiplaSelecao2_chamarOnChange = function() {
zenInvokeCallbackMethod(this.scsOnChange, this, "scsOnChange");
}

self.s00_componente_interface_scsMultiplaSelecao2_confirmarSelecao = function() {
try{
var componente = zenPage.getComponent(this.index);
var tabelaPrincipal = componente.getChildById("tableSelecionadosPrincipal");
var tabelaNaoSelecionados = componente.getChildById("tableNaoSelecionadosPopup");
var tabelaSelecionados = componente.getChildById("tableSelecionadosPopup");
this.Selecionados = tabelaSelecionados.jsonContent;
this.NaoSelecionados = tabelaNaoSelecionados.jsonContent;
this.atualizarListaIds();
tabelaPrincipal.clear();
tabelaPrincipal.addRows(this.Selecionados);
componente.getChildById("popupSelecao").setProperty("hidden", true);
this.chamarOnChange();
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_controlarExibicaoDataCombo = function() {
try{
if(!this.scsLazyLoading){
this.controlarExibicaoDataComboNormal();
}else{
this.controlarExibicaoDataComboLazyLoading();
}
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_controlarExibicaoDataComboLazyLoading = function() {
var componente = zenPage.getComponent(this.index);
var selecionados = this.Selecionados;
var qtdSelecionados = 0;
if (selecionados != undefined){
qtdSelecionados = selecionados.length;
}
var naoSelecionados = this.NaoSelecionados;
var qtdNaoSelecionados = 0;
if (naoSelecionados != undefined){
qtdNaoSelecionados = naoSelecionados.length;
}
var qtdTotal = this.getJsonLinhas().length;
var dataCombo = componente.getChildById("dtcSelecao");
var txtFiltro = dataCombo.getEnclosingDiv().getElementsByTagName("input")[1];
if((qtdSelecionados == 0 && qtdNaoSelecionados == 0) && (!this.scsPermiteNenhumSelecionados || (qtdNaoSelecionados == 0 && qtdSelecionados != 0))){
txtFiltro.value	= this.scsTextoTodosSelecionados;
}else if(qtdSelecionados > 0){
if (qtdSelecionados == 1){
dataCombo.setValue(this.ListaIdsSelecionados);
}else if(qtdSelecionados == qtdTotal){
txtFiltro.value	= this.scsTextoTodosSelecionados;
}else{
txtFiltro.value	= this.scsTextoVariosSelecionados;
}
}else{
txtFiltro.value	= this.scsTextoNenhumSelecionado;
}
}

self.s00_componente_interface_scsMultiplaSelecao2_controlarExibicaoDataComboNormal = function() {
var componente = zenPage.getComponent(this.index);
var selecionados = this.Selecionados;
var qtdSelecionados = 0;
if (selecionados != undefined){
qtdSelecionados = selecionados.length;
}
var naoSelecionados = this.NaoSelecionados;
var qtdNaoSelecionados = 0;
if (naoSelecionados != undefined){
qtdNaoSelecionados = naoSelecionados.length;
}
var dataCombo = componente.getChildById("dtcSelecao");
var txtFiltro = dataCombo.getEnclosingDiv().getElementsByTagName("input")[1];
if ((qtdNaoSelecionados == 0) && (!this.scsPermiteNenhumSelecionados || qtdSelecionados != 0)){
txtFiltro.value	= this.scsTextoTodosSelecionados;
}else if(qtdSelecionados > 0){
if (qtdSelecionados == 1){
dataCombo.setValue(this.ListaIdsSelecionados);
}else{
txtFiltro.value	= this.scsTextoVariosSelecionados;
}
}else{
txtFiltro.value	= this.scsTextoNenhumSelecionado;
}
}

self.s00_componente_interface_scsMultiplaSelecao2_controlarManterSelecionado = function() {
try{
if(this.manterSelecao){
var lIdLinhas 				= _.pluck(this.JsonLinhas,"Id");
var lIdLinhasSelecionadas 	= _.pluck(this.Selecionados,"Id");
lIdLinhasSelecionadas		= _.reject(lIdLinhasSelecionadas,function(idSelecionado){return !_.contains(lIdLinhas,idSelecionado)});
lIdLinhasNaoSelecionados	= _.difference(lIdLinhas,lIdLinhasSelecionadas);
var jsonNaoSelecionados		= _.filter(this.JsonLinhas,function(obj){return _.contains(lIdLinhasNaoSelecionados,obj.Id) });
var jsonSelecionados		= _.filter(this.JsonLinhas,function(obj){return _.contains(lIdLinhasSelecionadas,obj.Id) });
this.NaoSelecionados = jsonNaoSelecionados;
this.Selecionados = jsonSelecionados;
this.manterSelecao = false;
}else{
this.NaoSelecionados = this.JsonLinhas;
this.Selecionados = [];
}
}catch(ex){
zenPage.exibirExcecao("metodo() " + ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_definirIntefaceInicial = function() {
try{
var componente = zenPage.getComponent(this.index);
if(componente.scsExibirDataCombo){
componente.getChildById("grpPrincipal").setProperty("hidden",false);
componente.getChildById("cabecalhoSemCombo").setProperty("hidden",true);
}else{
componente.getChildById("grpPrincipal").setProperty("hidden",true);
componente.getChildById("cabecalhoSemCombo").setProperty("hidden",false);
componente.getChildById("jsonPrincipal").setProperty("enclosingStyle","margin-left:0px");
componente.getChildById("cabecalhoSemCombo").setProperty("enclosingStyle","margin-left:0px");
}
if(componente.scsExibirTabela){
componente.getChildById("jsonPrincipal").setProperty("enclosingStyle","margin-left:0px");
componente.getChildById("cabecalhoSemCombo").setProperty("enclosingStyle","margin-left:0px");
componente.getChildById("jsonPrincipal").setProperty("hidden",false);
}else{
componente.getChildById("jsonPrincipal").setProperty("hidden",true);
componente.getChildById("cabecalhoSemCombo").setProperty("hidden",true);
}
if(componente.isDataComboComTabela()){
componente.getChildById("btAbrirSelecao").setProperty("hidden",false);
componente.getChildById("cabecalhoSemCombo").setProperty("hidden",true);
}
this.desenharColunasJsonTables();
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_desenharColunasJsonTables = function() {
try{
var zsm = zenSynchronousMode;
zenSynchronousMode = true;
var componente = zenPage.getComponent(this.index);
var colunas = this.scsColunasTabela.split(",");
var colunasTitulo = this.scsColunasTabelaTitulo.split(",");
var colunasTamanho = this.scsColunasTabelaTamanho.split(",");
var tiposFiltrosColuna = this.scsFilterTypeColunas.split(",");
var colunasDisplay = this.scsColunasTabelaPrincipalDisplay ? this.scsColunasTabelaPrincipalDisplay.split(",") : colunas;
var colunasSelecaoDisplay = this.scsColunasTabelaSelecaoDisplay ? this.scsColunasTabelaSelecaoDisplay.split(",") : colunas;
var tabelaPrincipal = componente.getChildById("tableSelecionadosPrincipal");
var tabelaNaoSelecionados = componente.getChildById("tableNaoSelecionadosPopup");
var tabelaSelecionados = componente.getChildById("tableSelecionadosPopup");
for(var x = 0; x < colunas.length; x++){
tipoFiltroColuna = tiposFiltrosColuna[x];
var jsonColumn 			= zenPage.createComponentNS("http://www.intersystems.com/zen","scsJsonColumn");
jsonColumn.colName 		= colunas[x];
jsonColumn.header 		= colunasTitulo[x];
jsonColumn.width 		= colunasTamanho[x]+"%";
jsonColumn.ellipsis 	= true;
jsonColumn.sortColumn 	= true;
jsonColumn.hidden 		= !(_.contains(colunasDisplay,colunas[x]));
if(this.scsExibirFiltroTabelaPrincipal){
jsonColumn.filter = "TEXTO";
if(tipoFiltroColuna) {
jsonColumn.filterType = tipoFiltroColuna;
}else {
jsonColumn.filterType = "LIKE";
}
}
tabelaPrincipal.columns.push(jsonColumn);
var jsonColumn 			= zenPage.createComponentNS("http://www.intersystems.com/zen","scsJsonColumn");
jsonColumn.colName 		= colunas[x];
jsonColumn.header 		= colunasTitulo[x];
jsonColumn.width 		= colunasTamanho[x]+"%";
jsonColumn.ellipsis 	= true;
jsonColumn.hidden 		= !(_.contains(colunasSelecaoDisplay,colunas[x]));
jsonColumn.sortColumn 	= true;
jsonColumn.filter 		= "TEXTO";
if(tipoFiltroColuna) {
jsonColumn.filterType = tipoFiltroColuna;
}else {
jsonColumn.filterType = "LIKE";
}
tabelaNaoSelecionados.columns.push(jsonColumn);
tabelaSelecionados.columns.push(jsonColumn);
}
var jsonColumn 			= zenPage.createComponentNS("http://www.intersystems.com/zen","scsJsonColumn");
jsonColumn.colName 		= "Adicionar";
jsonColumn.headerTitle	= $$$Text("Adicionar todas as linhas");
jsonColumn.header 		= "";
jsonColumn.width 		= "12%";
jsonColumn.ellipsis 	= true;
jsonColumn.onDrawCell 	= "drawColunaAdicionar";
jsonColumn.onDrawHeader = "drawHeaderColunaAdicionar";
tabelaNaoSelecionados.columns.push(jsonColumn);
tabelaPrincipal.refreshContents();
tabelaNaoSelecionados.refreshContents();
tabelaSelecionados.refreshContents();
tabelaNaoSelecionados.addRows(this.NaoSelecionados);
zenSynchronousMode = false;
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_drawColunaAdicionar = function(pDados) {
try{
var stringJsonObjeto = this.escapeHtml(zenPage.toJSON(pDados));
var index = this.index;
var html = "<div class='icone_add icone'><input type='button' title='"+$$$Text("Adicionar")+"' onclick='zenPage.getComponent("+index+").selecionarItem("+stringJsonObjeto+");'/></div>";
return html;
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_drawHeaderColunaAdicionar = function() {
try{
var index = this.index;
var html = "<div class='icone_add icone'><input type='button' onclick='zenPage.getComponent("+index+").selecionarTodos();'/></div>";
return html;
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_escapeHtml = function(pString) {
return pString
.replace(/&/g, "&amp;")
.replace(/</g, "&lt;")
.replace(/>/g, "&gt;")
.replace(/"/g, "&quot;")
.replace(/'/g, "&#039;");
}

self.s00_componente_interface_scsMultiplaSelecao2_focus = function() {
this.getChildById("dtcSelecao").focus();
}

self.s00_componente_interface_scsMultiplaSelecao2_getArraySelecionados = function() {
var arraySelecionados = [];
try{
arraySelecionados = JSON.parse(JSON.stringify(this.Selecionados));
}catch(ex){
zenPage.exibirExcecao(ex);
}
return arraySelecionados;
}

self.s00_componente_interface_scsMultiplaSelecao2_getJsonLinhas = function() {
if(this.JsonLinhas == "" || this.JsonLinhas == undefined){
this.JsonLinhas = [];
}else{
if(typeof this.JsonLinhas == "string"){
this.JsonLinhas = zenPage.parseJSON(this.JsonLinhas)
}
if(this.JsonLinhas && this.JsonLinhas.Linhas){
this.JsonLinhas = this.JsonLinhas.Linhas
}
}
return this.JsonLinhas;
}

self.s00_componente_interface_scsMultiplaSelecao2_getJsonSelecionados = function() {
var retorno = "";
try{
retorno = zenPage.toJSON(this.Selecionados);
}catch(ex){
zenPage.exibirExcecao(ex);
}
return retorno;
}

self.s00_componente_interface_scsMultiplaSelecao2_getListaNaoSelecionados = function() {
try{
var listaIdSelecionados = this.ListaIdsSelecionados;
var listaNaoSelecionados = this.getJsonLinhas();
listaIdSelecionados = listaIdSelecionados.split(',');
var propriedade = this.getPropriedadeChave();
var listaRetorno = _.filter(listaNaoSelecionados, function(obj){
var id = obj[propriedade] ? obj[propriedade].toString() : '';
if(listaIdSelecionados){
return !_.contains(listaIdSelecionados, id)
}else{
return true;
}
});
return listaRetorno
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_getListaSelecionados = function() {
try{
var listaIdSelecionados = this.ListaIdsSelecionados;
if(!listaIdSelecionados || listaIdSelecionados.length <= 0){
return "";
}
var listaNaoSelecionados = this.getJsonLinhas();
listaIdSelecionados = listaIdSelecionados.split(',');
var propriedade = this.getPropriedadeChave();
var listaRetorno = _.filter(listaNaoSelecionados, function(obj){
var id = obj[propriedade] ? obj[propriedade].toString() : '';
return _.contains(listaIdSelecionados, id)
});
return listaRetorno
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_getParametros = function() {
var scsParametrosCliente = zenPage[this.scsParametrosCliente];
if (typeof(scsParametrosCliente) == "function"){
return JSON.stringify(scsParametrosCliente());
}else{
return JSON.stringify([scsParametrosCliente]);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_getPropriedadeChave = function() {
return this.scsColunasTabela.split(',')[0];
}

self.s00_componente_interface_scsMultiplaSelecao2_getSelecionados = function() {
var retorno = ""
try{
if(this.scsStringTodosSelecionados){
if(this.ListaIdsSelecionados){
var selecao = this.ListaIdsSelecionados.split(",");
var qtdSelecionados = selecao.length;
var qtdTotal = this.getJsonLinhas().length;
if(qtdSelecionados == 1){
retorno = selecao[0];
}else if(qtdSelecionados == qtdTotal){
retorno = "*";
}else{
retorno = this.ListaIdsSelecionados;
}
}else if(this.NaoSelecionados && this.NaoSelecionados.length == 0){
retorno = "*";
}
}else{
retorno = this.ListaIdsSelecionados;
}
}catch(ex){
zenPage.exibirExcecao(ex);
}
return retorno;
}

self.s00_componente_interface_scsMultiplaSelecao2_isDataComboComTabela = function() {
try{
var retorno = false;
var componente = zenPage.getComponent(this.index);
if(componente.scsExibirDataCombo && componente.scsExibirTabela){
retorno = true;
}
}catch(ex){
retorno = false;
zenPage.exibirExcecao(ex);
}
return retorno
}

self.s00_componente_interface_scsMultiplaSelecao2_limparComponente = function() {
try{
this.ListaIdsSelecionados = "";
this.NaoSelecionados = "";
this.SelecionadosAntes = "";
this.NaoSelecionadosAntes = "";
this.Selecionados = "";
this.setSelecionados(this.Selecionados);
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_ondisabledHandler = function() {
if (this.disabled){
this.getEnclosingDiv().style.opacity = '0.5';
}else{
this.getEnclosingDiv().style.opacity = '';
}
return;
}

self.s00_componente_interface_scsMultiplaSelecao2_onloadHandler = function() {
try{
if(this.NaoSelecionados != ""){
var naoSelecionados = zenPage.parseJSON(this.NaoSelecionados);
this.NaoSelecionados = naoSelecionados.Linhas;
}
this.definirIntefaceInicial();
this.atualizarListaIds();
if(this.scsLazyLoading){
this.jaCarregado = false;
}else{
this.jaCarregado = true;
}
this.manterSelecao = false;
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_removerItem = function(pDado,pIdTabelaSelecionada,pTabelaPrincipal) {
try{
var componente 				= zenPage.getComponent(this.index);
var idTabelaSelecionada 	= pIdTabelaSelecionada.split(".");
idTabelaSelecionada 		= idTabelaSelecionada[(idTabelaSelecionada.length - 1)];
var tabelaSelecionada 		= componente.getChildById(idTabelaSelecionada);
var tabelaNaoSelecionados 	= componente.getChildById("tableNaoSelecionadosPopup");
this.Selecionados 			= tabelaSelecionada.jsonContent;
if(pDado){
var lista	 			= this.NaoSelecionados;
var page 				= tabelaNaoSelecionados.currentPage;
lista.push(pDado);
lista 					= _.sortBy(lista, 'idxAuxiliar');
tabelaNaoSelecionados.clear(1);
tabelaNaoSelecionados.addRows(lista);
tabelaNaoSelecionados.showPage(page);
this.NaoSelecionados 	= tabelaNaoSelecionados.jsonContent;
}
this.atualizarListaIds();
if(pTabelaPrincipal == 1){
if(this.scsOnDeleteRowTabelaPrincipal != ""){
zenInvokeCallbackMethod(this.scsOnDeleteRowTabelaPrincipal, this, "scsOnDeleteRowTabelaPrincipal","data",pDado);
}
}
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_removerTodos = function() {
try{
var componente 						= zenPage.getComponent(this.index);
var tabelaSelecionados 				= componente.getChildById("tableSelecionadosPopup");
var tabelaNaoSelecionados 			= componente.getChildById("tableNaoSelecionadosPopup");
var pageNaoSelecionados 			= tabelaNaoSelecionados.currentPage;
var listaSelecionados 				= tabelaSelecionados.jsonContent;
var listaSelecionadosFiltrados 		= tabelaSelecionados.jsonContentInternal;
listaSelecionados 					= _.difference(listaSelecionados,listaSelecionadosFiltrados);
var listaNaoSelecionados 			= tabelaNaoSelecionados.jsonContent;
var listaTodos 						= _.union(listaSelecionadosFiltrados, listaNaoSelecionados);
listaTodos 							= _.sortBy(listaTodos, 'idxAuxiliar');
tabelaSelecionados.clear();
tabelaSelecionados.addRows(listaSelecionados);
tabelaNaoSelecionados.clear();
tabelaNaoSelecionados.addRows(listaTodos);
tabelaNaoSelecionados.showPage(pageNaoSelecionados);
if(tabelaSelecionados.jsonContent.length > 0){
this.Selecionados 		= tabelaSelecionados.jsonContent;
}else{
this.Selecionados 		= "";
}
this.NaoSelecionados 	= tabelaNaoSelecionados.jsonContent;
this.atualizarListaIds();
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_removerTodosPrincipal = function() {
try{
var componente = zenPage.getComponent(this.index);
var tabelaSelecionados = componente.getChildById("tableSelecionadosPrincipal");
var tabelaNaoSelecionados = componente.getChildById("tableNaoSelecionadosPopup");
var listaSelecionados = tabelaSelecionados.jsonContent;
var listaNaoSelecionados = tabelaNaoSelecionados.jsonContent;
var listaTodos = _.union(listaSelecionados, listaNaoSelecionados);
listaTodos = _.sortBy(listaTodos, 'idxAuxiliar');
tabelaSelecionados.clear();
tabelaNaoSelecionados.clear();
tabelaNaoSelecionados.addRows(listaTodos);
this.Selecionados = '';
this.NaoSelecionados = tabelaNaoSelecionados.jsonContent;
this.atualizarListaIds();
this.chamarOnChange();
if(this.scsOnDeleteAllRowTabelaPrincipal != ""){
zenInvokeCallbackMethod(this.scsOnDeleteAllRowTabelaPrincipal, this, "scsOnDeleteAllRowTabelaPrincipal");
}
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_selecionarDataCombo = function(pIdDataCombo) {
try{
var input = zenPage.getComponentById(pIdDataCombo).getEnclosingDiv().getElementsByTagName("input")[1];
input.select();
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_selecionarItem = function(pDado) {
try{
var componente 				= zenPage.getComponent(this.index);
var tabelaSelecionados 		= componente.getChildById("tableSelecionadosPopup");
tabelaSelecionados.addRow(pDado);
var tabelaNaoSelecionados 	= componente.getChildById("tableNaoSelecionadosPopup");
var naoSelecionados 		= tabelaNaoSelecionados.jsonContent;
naoSelecionados 			= _.reject(naoSelecionados, {idxAuxiliar: pDado.idxAuxiliar});
var pagina 					= tabelaNaoSelecionados.currentPage
tabelaNaoSelecionados.clear(true);
tabelaNaoSelecionados.addRows(naoSelecionados);
tabelaNaoSelecionados.showPage(pagina);
this.NaoSelecionados 		= naoSelecionados;
this.atualizarListaIds();
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_selecionarTodos = function() {
try{
var componente = zenPage.getComponent(this.index);
var tabelaNaoSelecionados 		= componente.getChildById("tableNaoSelecionadosPopup");
var tabelaSelecionados 			= componente.getChildById("tableSelecionadosPopup");
var naoSelecionados 			= tabelaNaoSelecionados.jsonContent;
var naoSelecionadosFiltrados 	= tabelaNaoSelecionados.jsonContentInternal;
naoSelecionados 				= _.difference(naoSelecionados,naoSelecionadosFiltrados);
tabelaSelecionados.addRows(naoSelecionadosFiltrados);
this.Selecionados = naoSelecionadosFiltrados;
tabelaNaoSelecionados.clear();
tabelaNaoSelecionados.addRows(naoSelecionados);
this.NaoSelecionados 		= naoSelecionados;
this.atualizarListaIds();
this.operacaoPendente = this.scsLazyLoading ? "selecionarTodos" : "";
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_setBodyHeightTabelaPrincipal = function(pBodyHeight) {
try{
this.scsBodyHeightTabelaExibicao = pBodyHeight;
this.getChildById('tableSelecionadosPrincipal').setProperty('bodyHeight', this.scsBodyHeightTabelaExibicao);
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_setJaCarregado = function(pFlag,pManterSelecao) {
this.jaCarregado 	= pFlag;
this.manterSelecao 	= pManterSelecao;
}

self.s00_componente_interface_scsMultiplaSelecao2_setSelecaoDataCombo = function() {
try{
var componente = zenPage.getComponent(this.index);
var dataCombo = componente.getChildById("dtcSelecao");
var valorSelecionado = dataCombo.getValue();
if(this.scsLazyLoading && !this.jaCarregado){
var chave = this.getPropriedadeChave();
var registro = {};
registro[chave] = valorSelecionado;
var linha = [registro];
this.JsonLinhas = linha;
this.NaoSelecionados = [];
this.Selecionados = linha;
this.atualizarListaIds(0);
this.operacaoPendente = this.scsLazyLoading ? "selecionarUnico" : "";
}
this.setSelecionados(valorSelecionado);
if(componente.isDataComboComTabela()){
dataCombo.setValue("");
dataCombo.focus();
}
this.chamarOnChange();
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_setSelecionados = function(pSelecionados) {
try{
var zsm = zenSynchronousMode;
zenSynchronousMode = true;
var componente = zenPage.getComponent(this.index);
this.ListaIdsSelecionados = pSelecionados;
if(this.ListaIdsSelecionados){
if(this.Selecionados != "" && this.Selecionados.length > 0 && componente.isDataComboComTabela()){
var objRepetido = _.findWhere(this.Selecionados, {"Id":parseInt(pSelecionados)});
if(objRepetido == undefined){
objRepetido = _.findWhere(this.Selecionados, {"Id":pSelecionados});
}
if(objRepetido != undefined){
var dataCombo = componente.getChildById("dtcSelecao");
var valorPrimeiraPropriedadeObjeto = objRepetido[Object.keys(objRepetido)[0]];
zenPage.alertaShift($$$FormatText("Item '%1' já está selecionado!",valorPrimeiraPropriedadeObjeto),dataCombo.id,2);
this.atualizarListaIds();
return 0;
}
var objSelecionado = this.getListaSelecionados();
this.Selecionados.push(objSelecionado[0]);
}else if(this.ListaIdsSelecionados == "*"){
this.selecionarTodos();
}else{
this.Selecionados = this.getListaSelecionados();
}
} else {
this.Selecionados = "";
}
this.atualizarListaIds(0);
this.NaoSelecionados = this.getListaNaoSelecionados();
var tabelaPrincipal = componente.getChildById("tableSelecionadosPrincipal");
var tabelaNaoSelecionados = componente.getChildById("tableNaoSelecionadosPopup");
var tabelaSelecionados = componente.getChildById("tableSelecionadosPopup");
tabelaPrincipal.clear();
tabelaNaoSelecionados.clear();
tabelaSelecionados.clear();
tabelaNaoSelecionados.addRows(this.NaoSelecionados);
tabelaSelecionados.addRows(this.Selecionados);
tabelaPrincipal.addRows(this.Selecionados);
this.atualizarListaIds();
zenSynchronousMode = false;
}catch(ex){
zenPage.exibirExcecao(ex);
}
}

self.s00_componente_interface_scsMultiplaSelecao2_setSelecionadosS01Filtro = function(pSelecionados) {
var zsm = zenSynchronousMode;
zenSynchronousMode = true;
if((this.scsLazyLoading)&&(!this.jaCarregado)){
this.carregarDados();
}
zenSynchronousMode = zsm;
this.setSelecionados(pSelecionados);
if (pSelecionados == "*"){
this.selecionarTodos();
}
}

self.s00_componente_interface_scsMultiplaSelecao2_verificarSelecionarTodos = function() {
if(this.scsLazyLoading && this.operacaoPendente != ""){
if(this.operacaoPendente == "selecionarTodos"){
this.selecionarTodos();
}else if(this.operacaoPendente = "selecionarUnico"){
var valorSelecionados = this.getChildById("dtcSelecao").getValue();
this.setSelecionados(valorSelecionados);
}
this.SelecionadosAntes = this.Selecionados;
this.NaoSelecionadosAntes = this.NaoSelecionados;
this.operacaoPendente = "";
}
}

self.s00_componente_interface_scsMultiplaSelecao2_GetJsonObjeto = function(pColunas,pSql,pOnCreateRs,pOnCreateRsClassName,pJSONParametrs) {
	return zenClassMethod(this,'GetJsonObjeto','L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente_interface_scsMultiplaSelecao2_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_scsMultiplaSelecao2__Loader = function() {
	zenLoadClass('s00_componente2_interface_Padrao');
	s00_componente_interface_scsMultiplaSelecao2.prototype = zenCreate('s00_componente2_interface_Padrao',-1);
	var p = s00_componente_interface_scsMultiplaSelecao2.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_scsMultiplaSelecao2;
	p.superClass = ('undefined' == typeof s00_componente2_interface_Padrao) ? zenMaster.s00_componente2_interface_Padrao.prototype:s00_componente2_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.scsMultiplaSelecao2';
	p._type = 'scsMultiplaSelecao2';
	p.serialize = s00_componente_interface_scsMultiplaSelecao2_serialize;
	p.getSettings = s00_componente_interface_scsMultiplaSelecao2_getSettings;
	p.GetJsonObjeto = s00_componente_interface_scsMultiplaSelecao2_GetJsonObjeto;
	p.ReallyRefreshContents = s00_componente_interface_scsMultiplaSelecao2_ReallyRefreshContents;
	p.abrirPopupMultiplaSelecao = s00_componente_interface_scsMultiplaSelecao2_abrirPopupMultiplaSelecao;
	p.atualizarListaIds = s00_componente_interface_scsMultiplaSelecao2_atualizarListaIds;
	p.beforeDeleteRowTabelaPrincipal = s00_componente_interface_scsMultiplaSelecao2_beforeDeleteRowTabelaPrincipal;
	p.cancelarPopupMultiplaSelecao = s00_componente_interface_scsMultiplaSelecao2_cancelarPopupMultiplaSelecao;
	p.carregarDados = s00_componente_interface_scsMultiplaSelecao2_carregarDados;
	p.chamarOnChange = s00_componente_interface_scsMultiplaSelecao2_chamarOnChange;
	p.confirmarSelecao = s00_componente_interface_scsMultiplaSelecao2_confirmarSelecao;
	p.controlarExibicaoDataCombo = s00_componente_interface_scsMultiplaSelecao2_controlarExibicaoDataCombo;
	p.controlarExibicaoDataComboLazyLoading = s00_componente_interface_scsMultiplaSelecao2_controlarExibicaoDataComboLazyLoading;
	p.controlarExibicaoDataComboNormal = s00_componente_interface_scsMultiplaSelecao2_controlarExibicaoDataComboNormal;
	p.controlarManterSelecionado = s00_componente_interface_scsMultiplaSelecao2_controlarManterSelecionado;
	p.definirIntefaceInicial = s00_componente_interface_scsMultiplaSelecao2_definirIntefaceInicial;
	p.desenharColunasJsonTables = s00_componente_interface_scsMultiplaSelecao2_desenharColunasJsonTables;
	p.drawColunaAdicionar = s00_componente_interface_scsMultiplaSelecao2_drawColunaAdicionar;
	p.drawHeaderColunaAdicionar = s00_componente_interface_scsMultiplaSelecao2_drawHeaderColunaAdicionar;
	p.escapeHtml = s00_componente_interface_scsMultiplaSelecao2_escapeHtml;
	p.focus = s00_componente_interface_scsMultiplaSelecao2_focus;
	p.getArraySelecionados = s00_componente_interface_scsMultiplaSelecao2_getArraySelecionados;
	p.getJsonLinhas = s00_componente_interface_scsMultiplaSelecao2_getJsonLinhas;
	p.getJsonSelecionados = s00_componente_interface_scsMultiplaSelecao2_getJsonSelecionados;
	p.getListaNaoSelecionados = s00_componente_interface_scsMultiplaSelecao2_getListaNaoSelecionados;
	p.getListaSelecionados = s00_componente_interface_scsMultiplaSelecao2_getListaSelecionados;
	p.getParametros = s00_componente_interface_scsMultiplaSelecao2_getParametros;
	p.getPropriedadeChave = s00_componente_interface_scsMultiplaSelecao2_getPropriedadeChave;
	p.getSelecionados = s00_componente_interface_scsMultiplaSelecao2_getSelecionados;
	p.isDataComboComTabela = s00_componente_interface_scsMultiplaSelecao2_isDataComboComTabela;
	p.limparComponente = s00_componente_interface_scsMultiplaSelecao2_limparComponente;
	p.ondisabledHandler = s00_componente_interface_scsMultiplaSelecao2_ondisabledHandler;
	p.onloadHandler = s00_componente_interface_scsMultiplaSelecao2_onloadHandler;
	p.removerItem = s00_componente_interface_scsMultiplaSelecao2_removerItem;
	p.removerTodos = s00_componente_interface_scsMultiplaSelecao2_removerTodos;
	p.removerTodosPrincipal = s00_componente_interface_scsMultiplaSelecao2_removerTodosPrincipal;
	p.selecionarDataCombo = s00_componente_interface_scsMultiplaSelecao2_selecionarDataCombo;
	p.selecionarItem = s00_componente_interface_scsMultiplaSelecao2_selecionarItem;
	p.selecionarTodos = s00_componente_interface_scsMultiplaSelecao2_selecionarTodos;
	p.setBodyHeightTabelaPrincipal = s00_componente_interface_scsMultiplaSelecao2_setBodyHeightTabelaPrincipal;
	p.setJaCarregado = s00_componente_interface_scsMultiplaSelecao2_setJaCarregado;
	p.setSelecaoDataCombo = s00_componente_interface_scsMultiplaSelecao2_setSelecaoDataCombo;
	p.setSelecionados = s00_componente_interface_scsMultiplaSelecao2_setSelecionados;
	p.setSelecionadosS01Filtro = s00_componente_interface_scsMultiplaSelecao2_setSelecionadosS01Filtro;
	p.verificarSelecionarTodos = s00_componente_interface_scsMultiplaSelecao2_verificarSelecionarTodos;
}
/* EOF */