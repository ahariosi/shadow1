/**
*  Script: Horizontal Scroller by Ademir Gabardo.
*  Vers�o: 1.0.
*  Este script foi desenvolvido como uma alternativa a JQuery e a JCarrousel
*  Por ser uma funcionalidade bastante simples acredito que n�o vale a pena obrigar o
*  navegar a carregar todas as bibliotecas com centenas de linhas de JS s� para rolar uma DIV.
*  Montei ent�o o script abaixo que realiza esta tarefa.
*  A univa variavel que deve ser alterada para o bom funcionamento do 
*  scroller � 'larguracontainer' que dever� corresponder a largura em pixels da div externa.
*  Segue o codigo comentado.
* 
*/
// x deve ser global para que possa ser acessado por outras fun�oes e seja possivel parar o slider...
var x;
// voltar deve ser global para que possa ser instanciado pelas duas funcoes rolar para esquerda e direita
var mover = 0;
var larguracontainer = 306;
var totalCorrer      = 612;

// Iniciando a funcao que rola o slider para esquerda...
function moveLeft(){
    //recuperando a largura da div interna para impedir o estouro na rolagem...
    larguraScroll = document.getElementById('scrolabbleslider').style.width;
    //removendo os caracteres 'px' do style e subtraindo o tamanho do container para saber quanto pode rolar... 
    totalLargura = (larguraScroll.substring(0,(larguraScroll.length-2))-larguracontainer);
    var teste = 0;
    x = window.setInterval(function goLeft(){
            teste = parseInt(teste) + 20;
            mover = parseInt(mover) + 20;
            //Corrigindo a velocidade para o IE6
            if(/MSIE (\d+\.\d+);/.test(navigator.userAgent)){
                 var ieversion=new Number(RegExp.$1);
                  if (ieversion>=6 && ieversion <7){
					  teste = parseInt(teste) + 1;
                      mover = parseInt(mover) + 1;   
                  }
            }            
            if (mover <= totalLargura) {
				document.getElementById('scrolabbleslider').style.marginLeft = -(mover) +'px'; 
			}
            
            //Se j� tiver movido o total de espa�o disponivel, para o intervalo...
			var auxTeste = teste + 20;
			//alert("mover: "+mover+"\ntotalLargura: "+totalLargura+"\nauxTeste: "+auxTeste+"\ntotalCorrer: "+totalCorrer);
            if((mover > totalLargura) || (auxTeste >= totalCorrer)){
				if (mover <= totalLargura){
					mover = mover + 15;
				} else {
					mover = totalLargura;
				}
				document.getElementById('scrolabbleslider').style.marginLeft = -(mover) +'px'; 
                window.clearInterval(x);
            } else {
				document.getElementById('scrolabbleslider').style.marginLeft = -(mover) +'px'; 
			}
    },5);
}

// Iniciando a funcao que rola o slider para a direita...
function moveRight(){	
	var teste = 0;
    x = window.setInterval(function goRight(){
			teste = teste + 20;
            mover = mover - 20;
            //Corrigindo a velocidade para o IE6
            if(/MSIE (\d+\.\d+);/.test(navigator.userAgent)){
                 var ieversion=new Number(RegExp.$1);
                  if (ieversion>=6 && ieversion <7){
                      mover = mover - 1;
					  teste = teste + 1;
                  }
            }
			var auxTeste = teste + 20;
            if((mover < 1) || (auxTeste >= totalCorrer)){
				if (mover >= 1){
					mover = mover - 15;
				} else {
					mover = 0;
				}
				document.getElementById('scrolabbleslider').style.marginLeft = -(mover) +'px'; 
                window.clearInterval(x);
            } else {
				document.getElementById('scrolabbleslider').style.marginLeft = -(mover) +'px'; 
			}
            /*document.getElementById('scrolabbleslider').style.marginLeft = -(mover) +'px';
            if ((mover < 1) || (teste >= 950)){
                   window.clearInterval(x);
                   //document.getElementById('scrolabbleslider').style.marginLeft = '0px';
            }*/   
    },5);
}

// Iniciando a funcao que para a rolagem...
function stopMove(){
    //window.clearInterval(x);
}
