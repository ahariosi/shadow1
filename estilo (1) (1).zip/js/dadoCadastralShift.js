var DadoCadastralShift = {
	//Propriedades
    "contexto":null,
    "modeloDadosCadastrais":null,
    "divPrincipal":null,
    "callbackOnChange": null,
    "mensagemEdicaoGestaoContratoDesabilitado": null,
    "desabilitarEdicaoGestaoContrato": null,
    
    //M�todos "set" e "get"
    "setContexto":
    	function(contexto){
	    	this.contexto = contexto;
	    },
    "getContexto":
    	function(){
	    	return this.contexto;
	    },
    
    "setModeloDadosCadastrais":
    	function(modelo){
	    	this.modeloDadosCadastrais = modelo;
	    },
	    
	"getModeloDadosCadastrais":
		function(){
			return this.modeloDadosCadastrais;
		},
		
	"setDivPrincipal":
    	function(div){
	    	this.divPrincipal = div;
	    },
	    
	"getDivPrincipal":
		function(){
			return this.divPrincipal;
		},
		
	"setCallbackOnChange":
		function(callbackOnChange){
			this.callbackOnChange = callbackOnChange;
		},
	
	"getCallbackOnChange":
		function(){
			return this.callbackOnChange;	
		},
		
	"setMensagemEdicaoGestaoContratoDesabilitado":
		function(mensagemEdicaoGestaoContratoDesabilitado){
			this.mensagemEdicaoGestaoContratoDesabilitado = mensagemEdicaoGestaoContratoDesabilitado;	
		},
	
	"getMensagemEdicaoGestaoContratoDesabilitado":
		function(){
			return this.mensagemEdicaoGestaoContratoDesabilitado;
		},
	
	"setDesabilitarEdicaoGestaoContrato":
		function(desabilitarEdicaoGestaoContrato){
			this.desabilitarEdicaoGestaoContrato = desabilitarEdicaoGestaoContrato;	
		},
	
	"getDesabilitarEdicaoGestaoContrato":
		function(){
			return this.desabilitarEdicaoGestaoContrato;
		},
	
	"desenhar":
		function(){
			var arrayDadosCadastrais = this.modeloDadosCadastrais.DadoCadastralItens;
			var divDadosCadastrais = zen(this.divPrincipal);
			while(divDadosCadastrais.getEnclosingDiv().firstChild){
    			divDadosCadastrais.getEnclosingDiv().removeChild(divDadosCadastrais.getEnclosingDiv().firstChild);
			}			
					
			for (var x=0; x < arrayDadosCadastrais.length; x++){			
				var obj = arrayDadosCadastrais[x];
				var retorno = ""
				
				if (obj.DadoTipo == 1){
					retorno = this.desenharDadoCadastralNumerico(obj,x);
				}else if (obj.DadoTipo == 2){
					retorno = this.desenharDadoCadastralAlfanumero(obj,x);
				}else if (obj.DadoTipo == 3){
					if((obj.DadoCadastro == 4) || (obj.DadoCadastro == 6)){
						continue; //N�o desenha os campos que podem ser selecionadas mais de uma data (m�todo para esse tipo de dado ainda n�o foi escrito)
					}
					retorno = this.desenharDadoCadastralData(obj,x);
				}else if (obj.DadoTipo == 4){
					retorno = this.desenharDadoCadastralCruzado(obj,x);
				}
				
				if((retorno != "") && (retorno != undefined)){
					divDadosCadastrais.getEnclosingDiv().appendChild(retorno);
				}
			}
		},
		
	"desenharDadoCadastralNumerico":
		function(pObjDadoCadastral, pIndice){
			var divText = document.createElement("div");
			if((this.Css.classNameDivLinhaDadoCadastral != "")&&(this.Css.classNameDivLinhaDadoCadastral != undefined)){
				divText.className = this.Css.classNameDivLinhaDadoCadastral;
			}
			
			var textInteiro = this.getContexto().createComponentNS("http://www.e-lis.com.br/zen","scsTextInteiro");
			textInteiro.value = pObjDadoCadastral.Valor;
			textInteiro.label = pObjDadoCadastral.Descricao;
			textInteiro.id = pObjDadoCadastral.IdComponente;
			textInteiro.maxlength = pObjDadoCadastral.DadoTamanho;
			textInteiro.size = this.Css.sizeNumerico;
			textInteiro = textInteiro.renderContents();
			textInteiro.addEventListener("change",function(){
					DadoCadastralShift.alterarDadoCadastral(pObjDadoCadastral,this.value);
				});
				
			if((this.getCallbackOnChange() != "")&&(this.getCallbackOnChange() != undefined)){				
				textInteiro.addEventListener("change",this.getCallbackOnChange());
			}
			
			pObjDadoCadastral.IdComponente = textInteiro.id;
						
			var span = document.createElement("span");
			span.className = "zenLabel";
			span.innerHTML = pObjDadoCadastral.Descricao;
			
			divText.appendChild(span);
			divText.appendChild(textInteiro);
			
			return divText;
		},
		
	"desenharDadoCadastralAlfanumero":
		function(pObjDadoCadastral, pIndice){
			var divText = document.createElement("div");
			if((this.Css.classNameDivLinhaDadoCadastral != "")&&(this.Css.classNameDivLinhaDadoCadastral != undefined)){
				divText.className = this.Css.classNameDivLinhaDadoCadastral;
			}
			
			var text = document.createElement("input");
			text.size = this.Css.sizeAlfanumerico;
			text.id = pObjDadoCadastral.IdComponente;
			text.value = pObjDadoCadastral.Valor;
			text.maxLength = pObjDadoCadastral.DadoTamanho;
			text.className = "text";
			text.type = "text";
			text.addEventListener("change",function(){
					DadoCadastralShift.alterarDadoCadastral(pObjDadoCadastral,this.value);
				});
			
			if((this.getCallbackOnChange() != "")&&(this.getCallbackOnChange() != undefined)){				
				text.addEventListener("change",this.getCallbackOnChange());
			}
					
			var span = document.createElement("span");
			span.className = "zenLabel";
			span.innerHTML = pObjDadoCadastral.Descricao;
			
			divText.appendChild(span);
			divText.appendChild(text);
			
			return divText;
		},
		
	"desenharDadoCadastralData":
		function(pObjDadoCadastral, pIndice){
			var divText = document.createElement("div");
			if((this.Css.classNameDivLinhaDadoCadastral != "")&&(this.Css.classNameDivLinhaDadoCadastral != undefined)){
				divText.className = this.Css.classNameDivLinhaDadoCadastral + " clearfix";
			}else{
				divText.className = "clearfix";
			}			
			
			var textData = this.getContexto().createComponentNS("http://www.e-lis.com.br/zen","scsCalendarData");
			
			pObjDadoCadastral.IdComponente = "control_"+textData.index;

			textData.size = this.Css.sizeData;
			textData.value = pObjDadoCadastral.Valor;
			textData.label = pObjDadoCadastral.Descricao;
			textData.scsAcima = 1;			
			textData.onchange = "DadoCadastralShift.alterarDadoCadastralComponenteZen("+pObjDadoCadastral.IdComponente+");";
			
			if((this.getCallbackOnChange() != "")&&(this.getCallbackOnChange() != undefined)){
				textData.onchange += "DadoCadastralShift.callbackOnChange();";
			}
			
			textData = textData.renderContents();
						
			divText.appendChild(textData);
			
			return divText;
		},
		
	"desenharDadoCadastralCruzado":
		function(pObjDadoCadastral, pIndice){
			var divText = document.createElement("div");
			if((this.Css.classNameDivLinhaDadoCadastral != "")&&(this.Css.classNameDivLinhaDadoCadastral != undefined)){
				divText.className = this.Css.classNameDivLinhaDadoCadastral;
			}
			
			var select = document.createElement("select");
			select.id = pObjDadoCadastral.IdComponente;
			select.value = pObjDadoCadastral.Valor;
			select.className = "select";
			select.style.width = this.Css.sizeCruzado;
			select.addEventListener("change",function(){
					DadoCadastralShift.alterarDadoCadastral(pObjDadoCadastral,this.value);
				});
			
			if((this.getCallbackOnChange() != "")&&(this.getCallbackOnChange() != undefined)){				
				select.addEventListener("change",this.getCallbackOnChange());
			}
			
			var option = document.createElement("option");
			option.value = "";
			option.text = "";
			select.appendChild(option);
			
			var options = pObjDadoCadastral.CruzadoItens;
			for(var y=0;y<options.length;y++){
				var objOpcao = options[y];
				var option = document.createElement("option");
				option.value = objOpcao.Id;
				option.text = objOpcao.ItemCodigo + "-" + objOpcao.Descricao;
				if(pObjDadoCadastral.Valor == option.value) option.selected = true;
				select.appendChild(option);
			}
			
			var span = document.createElement("span");
			span.className = "zenLabel";
			span.innerHTML = pObjDadoCadastral.Descricao;
			
			divText.appendChild(span);
			divText.appendChild(select);
			
			if((pObjDadoCadastral.CruzadoGestaoContrato) && (this.getDesabilitarEdicaoGestaoContrato())){
				var img = document.createElement("img");
				img.src = "img/icons/icone_informacoes.png";
				img.title = this.getMensagemEdicaoGestaoContratoDesabilitado();
				img.style.marginLeft = "5px";
				divText.appendChild(img);
			}

			return divText;
		},
	
	"alterarDadoCadastral":
		function(pObjDadoCadastral,pValor){
			pObjDadoCadastral.Valor = pValor;
			pObjDadoCadastral.CampoAlterado = 1;
		},
		
	"alterarDadoCadastralComponenteZen":
		function(pIdComponente){
			var pObjDadoCadastral = _.where(DadoCadastralShift.modeloDadosCadastrais.DadoCadastralItens, {IdComponente:pIdComponente.id});
			if((pObjDadoCadastral != "") && (pObjDadoCadastral != undefined)){
				pObjDadoCadastral[0].Valor = pIdComponente.value;
				pObjDadoCadastral[0].CampoAlterado = 1;
			}
		}
}

DadoCadastralShift.Css = {
	"classNameDivLinhaDadoCadastral":null,
	"sizeNumerico":50,
	"sizeAlfanumerico":50,
	"sizeData":47,
	"sizeCruzado":"328px"
}