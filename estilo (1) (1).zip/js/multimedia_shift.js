var MultimediaShift = {
    "contexto":null,
    "dragAndDrop":{containerOrigem:null,containerDestino:null},
    "setContexto":function(contexto){MultimediaShift.contexto = contexto},
    
    "getContexto":function(){return MultimediaShift.contexto},
    
    "criarDropdown":
        function(elementoOrigem){
            var dropdown = document.createElement("div");
            dropdown.id = "multimediaShift_dropdown"
            dropdown.className = "drop-procedimento";
            dropdown.elementoOrigem = elementoOrigem;
            return dropdown;
        },
    
    "exibirDropdown":
        function(objDropdown){
            MultimediaShift.exibirOverlay(objDropdown);
            document.body.appendChild(objDropdown);
            objDropdown.elementoOrigem.style.backgroundColor = "rgba(0,0,0,.4)";
            objDropdown.style.cssText = MultimediaShift.getPosicaoDropdownImagem(objDropdown.elementoOrigem,objDropdown);
        },
    
    "getDropdownAtivo":
        function(){
            return $("#multimediaShift_dropdown")[0];
        },
    
    "exibirOverlay":
        function(objDropdown){
            var overlay = document.createElement("div");
            overlay.id = "multimediaShift_overlay";
            overlay.style.cssText = "background: rgba(0,0,0,0); position: fixed; top: 0; right: 0; width: 100%; height: 100%; z-index: 29";
            overlay.onclick = function() {MultimediaShift.esconderDropdown()}
            document.body.appendChild(overlay);
        },
    
    "removerOverlay":
        function(){
            $("#multimediaShift_overlay").remove();
        },
    
    "esconderDropdown":
        function(){
            MultimediaShift.removerOverlay();
            var dropDown = MultimediaShift.getDropdownAtivo();
            if(dropDown){
	            var elementoOrigem = dropDown.elementoOrigem;
	            elementoOrigem.style.backgroundColor = "";
	            $("#multimediaShift_dropdown").remove();
            }

        },
    
    "getPosicaoDropdownImagem":
        function(botao,dropdown){
            var xPos = 0;
            var yPos = 0;
            while (botao) {
                if (botao.tagName == "BODY") {
                    // deal with browser quirks with body/window/document and page scroll
                    var xScroll = botao.scrollLeft || document.documentElement.scrollLeft;
                    var yScroll = botao.scrollTop || document.documentElement.scrollTop;
                    xPos += (botao.offsetLeft - xScroll + botao.clientLeft);
                    yPos += (botao.offsetTop - yScroll + botao.clientTop);
                    break;
                } else {
                    // for all other non-BODY elements
                    xPos += (botao.offsetLeft - botao.scrollLeft + botao.clientLeft);
                    yPos += (botao.offsetTop - botao.scrollTop + botao.clientTop);
                }
                botao = botao.parentNode;
            }
            
            var styleLeft = ""
            var styleTop = ""
            
			if(document.body.offsetWidth > xPos + dropdown.offsetWidth) {
                styleLeft = "left: " + (xPos+20) + "px;";
            } else {
                styleLeft = "left: " + (xPos-dropdown.offsetWidth) + "px;";
            }
            
            if(yPos - dropdown.offsetHeight > 10) {
                styleTop = "top:" +(yPos - dropdown.offsetHeight - 1) + "px;"
            } else {
                styleTop = "top:" +(yPos - 32) + "px;"   
            }
            return styleLeft + styleTop;
        },
    
    "duplicarImagem":
    	function(objContainer, objetoImagem){
	    	var contexto = MultimediaShift.getContexto();
	    		    	
	    	var objImagemDuplicada = new MultimediaShift.Imagem();
	    	
	    	if((objetoImagem.imagemBase64 == "")||(objetoImagem.imagemBase64 == null)){
		    	objImagemDuplicada.imagemBase64 = MultimediaShift.converterUrlParaBase64(objetoImagem.caminhoInterno);
		    }else{
			    objImagemDuplicada.imagemBase64 = objetoImagem.imagemBase64;
			}            
            
            if(objContainer){
	            if(objContainer.tipo == "Procedimento"){
		        	if((objContainer.getTotalParametros() > objContainer.getTotalImagensSelecionadas()) && (contexto.IncluirLaudoAutomaticamente)){
						objImagemDuplicada.selecionada = true;
		       		}
		        }
                objContainer.inserirImagem(objImagemDuplicada);
            }
	    	
	    	MultimediaShift.esconderDropdown();
	    },
	    
	"converterUrlParaBase64":
		function(pUrl){
			var contexto = MultimediaShift.getContexto();
	    	var options = contexto.CameraApp._options;
			var can = document.createElement("canvas");
   			var img = document.createElement("img");
   			
   			img.src = pUrl;   			
   			img.width = img.naturalWidth;
            img.height = img.naturalHeight;
            
            var ctx = can.getContext("2d");   			
   			ctx.canvas.width = img.width;
            ctx.canvas.height = img.height;
            
   			ctx.drawImage(img, 0, 0);
   			   			
   			var encodedBase = can.toDataURL(options.imageType, options.imageQuality);
   			encodedBase = contexto.getImagemBase64DaUrl(encodedBase);
   			
   			return encodedBase;
		},
    
    "moverImagemDeContainer":
        function(objContainerOrigem,objContainerDestino,objetoImagem){
	        if(!objContainerOrigem || !objContainerDestino || !objetoImagem){
		        return;
	        }
	        	        
        	var contexto = MultimediaShift.getContexto();
        
            var procedimentoId = "";
            var parametroId = "";
            if (objContainerDestino.tipo == "Procedimento"){
                procedimentoId = objContainerDestino.getIdentificador();
                
                if ((objContainerDestino.getTotalParametros() > objContainerDestino.getTotalImagensSelecionadas()) && (contexto.IncluirLaudoAutomaticamente != "false")){
	            	objetoImagem.selecionada = true;
				}else{
					if(objContainerOrigem != objContainerDestino){
						objetoImagem.selecionada = false;
					}
				}
				
				var indice = contexto.AuxiliarIndiceDrop;
	            var auxContainer = $.extend(true, {}, objContainerDestino);
	            var auxImagensContainer = auxContainer.imagens;
	            auxImagensContainer.splice(indice,0,objetoImagem);
	            
		        if(indice !== ""){            
			    	if(indice == 0){//primeira posi��o
				    	if(auxImagensContainer.length > 1){
				    		objetoImagem.campoOrdenacao = auxImagensContainer[indice+1].campoOrdenacao - 1;
				    	}else{
					    	objetoImagem.campoOrdenacao = indice;
					    }
				    }else if(indice+1 == auxImagensContainer.length){//�ltima posi��o
					    if(auxImagensContainer.length > 1){
						 	objetoImagem.campoOrdenacao = auxImagensContainer[indice-1].campoOrdenacao + 1;   
						}else{
							objetoImagem.campoOrdenacao = indice;
						}
					}else{//no meio do array
						objetoImagem.campoOrdenacao = ((auxImagensContainer[indice-1].campoOrdenacao + auxImagensContainer[indice+1].campoOrdenacao) / 2);
					}
				}else{
					if(auxImagensContainer.length > 1){
						objetoImagem.campoOrdenacao = auxImagensContainer[indice+1].campoOrdenacao + 1;
					}else{
						objetoImagem.campoOrdenacao = indice;
					}				
				}
            }            
            
            var objetoAlteracaoImagem = 
            {
                "id":objetoImagem.id,
                "procedimentoId":procedimentoId,
                "parametroId":parametroId,
                "selecionada":objetoImagem.selecionada,
                "campoOrdenacao":objetoImagem.campoOrdenacao
            };
            
            contexto.escreverDebugConsole("AlterarDadosImagem",objetoAlteracaoImagem);            
            retorno = MultimediaShift.executarAcaoServidorSincrona("AlterarDadosImagem",objetoAlteracaoImagem);            
            contexto.escreverDebugConsole("retorno",retorno);
            
            if(retorno.status == "1"){
	            contexto.FlagHouveAlteracaoUsuario = 1;
	            
	            if((objContainerOrigem.verificarPossuiResultado()) || objContainerDestino.verificarPossuiResultado() ){
		            contexto.FlagHouveAlteracaoUsuarioEmResultado = 1;
		        }
	            
                objContainerOrigem.removerImagem(objetoImagem);
                objContainerDestino.inserirImagem(objetoImagem);
                                
                objContainerDestino.exibirBordaDragAndDrop(false);                
                MultimediaShift.esconderDropdown();
            }
        },
    
    "definirReferenciasImagens":
        function(objeto,propriedadeReferencia,propriedadeAlterar){
	        var contexto = MultimediaShift.getContexto();
            var listaImagens = contexto.getTodasAsImagens();
            var idsReferencias = objeto[propriedadeReferencia];
            
            if(_.isArray(idsReferencias)){
                objeto[propriedadeAlterar] = new Array();
                _.each(idsReferencias,
                    function(referenciaId,indice,idsReferencias){
                        objeto[propriedadeAlterar].push(MultimediaShift.encontrarReferenciaImagem(listaImagens,referenciaId));
                    }
                )
            }else{
                objeto[propriedadeAlterar] = MultimediaShift.encontrarReferenciaImagem(listaImagens,idsReferencias);
            }
            delete objeto[propriedadeReferencia];
        },
    "encontrarReferenciaImagem":
        function(listaImagens,referenciaId){
            return _.findWhere(listaImagens,{"id":referenciaId});
        },
        
    "executarAcaoServidorSincrona":
        function(metodo,parametro){
	        var contexto = MultimediaShift.getContexto();	        
	        var parametroString = contexto.getConteudoEmString(parametro)
	        
            var retorno = contexto.ExecutarAcao(metodo,parametroString)
            retorno = contexto.parseJSON(retorno);            
            if (retorno.mensagem != ""){
                contexto.alertaShift(retorno.mensagem,"",2);
            }
            if (retorno.erro == "1"){
                return;
            }
            
            return retorno.retornoFuncao
        },
    "executarAcaoServidorAssincrona":
        function(metodo,parametro,callbackRetorno){
	        var contexto = MultimediaShift.getContexto();
	        
            var controleComandos = contexto.ControleComandos;
            var comandoArmazenar = new controleComandos.Comando(metodo,parametro,callbackRetorno);
            
            controleComandos.inserirComando(comandoArmazenar);
        }
}

MultimediaShift.Objeto = function(objeto){
    if(objeto){
        $.extend(this,objeto);
    }
}

MultimediaShift.ElementoRenderizado = function(){
    this.renderizado = false;
    this.classeCSS = "";
    this.textoCSS = "";
    this.elementoNaInterface = null;
    this.getClasseCSS = function(){return this.classeCSS}
    this.setClasseCSS = function(classe){this.classeCSS = classe}
    this.getTextoCSS = function(){return this.textoCSS}
    this.setTextoCSS = function(texto){
	    this.textoCSS = texto
	    if (this.renderizado){
		    this.elementoPrincipal.style.cssText = texto;
	    }
	}
    
    this.desenhar = function(elementoPai){
        this.elementoNaInterface = this.getElementoADesenhar();
        elementoPai.appendChild(this.elementoNaInterface);
        this.renderizado = true;
    }
    
    this.removerDaInterface = function(){
        $(this.elementoNaInterface).remove();
    }
    this.getElementoADesenhar = function(){} // Deve ser sobrescrito na classe herdada
}

MultimediaShift.Procedimento = function(objeto){
    this.id = null;
    this.descricao = null;
    this.mnemonico = null;
    this.parametros = [];
    this.imagens = [];
    this.solicitantes = [];
    
    MultimediaShift.Objeto.call(this,objeto);
    MultimediaShift.definirReferenciasImagens(this,"imagensId","imagens");
    
    this.getImagens = function(){return this.imagens};
    this.getTextoSolicitante = function(){
	    if (this.solicitantes.length == 0){
		    return "";
	    }else if (this.solicitantes.length == 1){
		    return this.solicitantes[0].nome;
	    }else{
		    return $$$Text("V�rios solicitantes");
	    }
    }
}

MultimediaShift.Parametro = function(objeto){
    this.id = null;
    this.descricao = null;
    this.apelido = null;
    this.imagem = null;
        
    MultimediaShift.Objeto.call(this,objeto);
    MultimediaShift.definirReferenciasImagens(this,"imagemId","imagem");
    
    this.getImagem = function(){return this.imagem};
}

MultimediaShift.OrdemServico = function(objeto){
    this.codigoOs = null;
    this.procedimentos = [];
    this.imagens = [];
    
    MultimediaShift.Objeto.call(this,objeto);
}


MultimediaShift.ImagemLocalStorage = function(objeto){
	this.id = (new Date().getTime()) // timestamp
	this.osId = null;
	this.procedimentoId = null;
	MultimediaShift.Objeto.call(this,objeto);
}

MultimediaShift.Imagem = function(objeto){  
    var _this = this;
    this.id = null;
    this.idLocalStorage = null;
    this.selecionada = false;
    this.imagemBase64 = null;
    this.armazenada = false;
    this.permiteEdicao = null;
    this.data = null;
    this.hora = null;
    this.tipoContainerPai = null;
    this.caminhoInterno = null;
    
    /***************************/
    /* inicio dos objetos HTML */
    this.elementoPrincipal = null;
    this.botaoDropdown = null;
    this.imgMiniatura = null;
    this.checkboxSelecionar = null;
    this.elementoCarregando = null;
    this.elementoFazerUpload = null;
    
    /* fim dos objetos HTML */
    /**************************/
    
    MultimediaShift.Objeto.call(this,objeto);
    MultimediaShift.ElementoRenderizado.call(this);
    
    // -------- getters e setters ---------- //
    this.setId = function(id){this.id = id}
    this.getId = function(){return this.id}
    
    this.setArmazenada = function(armazenada){
	    this.armazenada = armazenada;	    
	    this.setArmazenando(false); // a partir do momento que ela assume um status, significa que ela n�o est� sendo armazenada
	}
    this.getArmazenada = function(){return this.armazenada}
    
    this.setArmazenando = function(armazenando){
	    this.armazenando = armazenando;
	    this.atualizarAcoesInterface();
	}

    this.getArmazenando = function(){return this.armazenando}
    
    this.setPermiteEdicao = function(permiteEdicao){
		this.permiteEdicao = permiteEdicao;
	}
	
	this.getPermiteEdicao = function(){
		return this.permiteEdicao;	
	}
	
	this.setData = function(data){
		this.data = data;
	}
	this.getData = function(){
		return this.data;
	}
	
	this.setHora = function(hora){
		this.hora = hora;
	}
	this.getHora = function(){
		return this.hora;
	}
	
	this.setCaminhoInterno = function(caminhoInterno){
		this.caminhoInterno = caminhoInterno;	
	}
	this.getCaminhoInterno = function(){
		return this.caminhoInterno;	
	}
    // -------- fim dos getters e setters ------ //
    
    
    this.getElementoADesenhar = function(){
        this.criarElementoPrincipal();
        this.criarImgMiniatura();
        this.criarBotaoDropdown();
        this.criarElementoCarregando();
        this.criarElementoFazerUpload();
        
        this.elementoPrincipal.appendChild(this.imgMiniatura);
        this.elementoPrincipal.appendChild(this.botaoDropdown);
        this.elementoPrincipal.appendChild(this.elementoCarregando);
        this.elementoPrincipal.appendChild(this.elementoFazerUpload);
        
        if(this.tipoContainerPai == "Procedimento"){
	    	this.criarCheckboxSelecionar();
	    	this.elementoPrincipal.appendChild(this.checkboxSelecionar);
	    }
		
		this.atualizarAcoesInterface();
		
        return this.elementoPrincipal;
    }
    
    /* M�TODO QUE CRIA O CONTEUDO PRINCIPAL DA IMAGEM */
    this.getElementoPrincipal = function(){return this.elementoPrincipal}
    this.criarElementoPrincipal = function(){
	    this.elementoPrincipal = document.createElement("div");
        //this.elementoPrincipal.id = "miniatura" + this.id;
        this.elementoPrincipal.className = "imagem-miniatura";
        this.elementoPrincipal.funcaoInicioDrag = function(){
	        _this.iniciarDrag();
	    }
        this.elementoPrincipal.funcaoFinalizarDrag = function(){
			_this.finalizarDrag();
	        MultimediaShift.getContexto().focarBotaoSnapshot();
	    }
        this.elementoPrincipal.draggable="true";
        /*
        this.elementoPrincipal.ondragstart = function(){
	        console.log("dragstart");
	        _this.iniciarDrag();
		};
		
		this.elementoPrincipal.ondragend = function(){
	        console.log("dragend");
	        _this.finalizarDrag();
	        MultimediaShift.getContexto().focarBotaoSnapshot();
		};
		*/
	}
	
	/* M�TODO QUE CRIA O IMG COM A FOTO */    
    this.getImgMiniatura = function(){return this.imgMiniatura}
    this.criarImgMiniatura = function(){
	    var contexto = MultimediaShift.getContexto();
        this.imgMiniatura = document.createElement("img");
        this.imgMiniatura.className = "imagem-miniatura__foto";
        if(this.caminhoInterno){
	        this.imgMiniatura.src = this.caminhoInterno;
        }else if(this.imagemBase64){
            this.imgMiniatura.src = contexto.getImagemBase64ParaSrc(this.imagemBase64);
        }
        this.imgMiniatura.onclick = function(){_this.click()};
    }
    
    /* M�TODO QUE CRIA O CHECKBOX DE SELE��O PARA O LAUDO PRINCIPAL DA IMAGEM */
    this.getCheckboxSelecionar = function(){return this.checkboxSelecionar}
    this.criarCheckboxSelecionar = function(){
        this.checkboxSelecionar = document.createElement("input");
        this.checkboxSelecionar.type = "checkbox";
        this.checkboxSelecionar.className = "imagem-miniatura__checkbox";
        this.checkboxSelecionar.value = this.id;
        this.checkboxSelecionar.id = "ckb"+this.id;
        this.checkboxSelecionar.disabled = !this.permiteEdicao;
        this.checkboxSelecionar.checked = this.selecionada;
        this.checkboxSelecionar.onclick = function(){_this.selecionarParaLaudo()}
    }
    
    /* M�TODO QUE CRIA O BOT�O DE DROPDOWN (UTILIZADO PARA SELECIONAR QUAL PROCEDIMENTO A IMAGEM IR�) PRINCIPAL DA IMAGEM */
    this.getBotaoDropdown = function(){return this.botaoDropdown}
    this.criarBotaoDropdown = function(){
        this.botaoDropdown =  document.createElement("button");
        this.botaoDropdown.className = "imagem-miniatura__button";
        this.botaoDropdown.onclick = function(){_this.exibirDropdown()};
    }
    
    /* M�TODO QUE CRIA O "LOADING" DA IMAGEM QUANDO ELA EST� SENDO ARMAZENADA*/
    this.getElementoCarregando = function(){return this.elementoCarregando}
    this.criarElementoCarregando = function(){
        this.elementoCarregando = document.createElement("div");
        this.elementoCarregando.className = "imagem-miniatura__carregando";
        this.elementoCarregando.title = $$$Text("Armazenando a imagem no servidor...");
    }
    
    /* M�TODO QUE CRIA O "UPLOAD" DA IMAGEM QUANDO ELA EST� N�O EST� ARMAZENADA E NEM SENDO ARMAZENADA*/
    this.getElementoFazerUpload = function(){return this.elementoFazerUpload}
    this.criarElementoFazerUpload = function(){
        this.elementoFazerUpload = document.createElement("button");
        this.elementoFazerUpload.className = "imagem-miniatura__fazer-upload";
        this.elementoFazerUpload.onclick = function(){_this.fazerUpload()};
        this.setMensagemPadraoUpload();
    }
    this.setMensagemPadraoUpload = function(){
	    this.elementoFazerUpload.title = $$$Text("Fazer upload");
    }
    this.setMensagemErroUpload = function(mensagem){
	    this.elementoFazerUpload.title = mensagem + $$$Text("\nClique para tentar gravar novamente");
    }
    
    
    this.onExibirDropdown = function(){}
    this.exibirDropdown = function(){
        this.onExibirDropdown(_this);
    }
    
    this.onExcluir = function(){}
    this.excluir = function(){
        this.onExcluir(_this);
    }
    
    this.onFazerUpload = function(){}
    this.fazerUpload = function(){
        this.onFazerUpload(_this);
    }
    
    this.onSelecionar = function(){}
    this.selecionar = function(){
        this.onSelecionar(_this);
    }
    
    this.onSelecionarParaLaudo = function(){}
    this.selecionarParaLaudo = function(){
        this.onSelecionarParaLaudo(_this);
    }
    
    this.onIniciarDrag = function(){}
    this.iniciarDrag = function(){
        this.onIniciarDrag(_this);
    }
    
    this.onFinalizarDrag = function(){}
    this.finalizarDrag = function(){
        this.onFinalizarDrag(_this);
    }
    
    this.onClick = function(){}
    this.click = function(){
        this.onClick(_this);
    }
    
    this.atualizarAcoesInterface = function(){
		if(this.armazenando){
			this.exibirCarregando(true);
			this.exibirFazerUpload(false);
		}else{
			if(this.armazenada){
				this.exibirCarregando(false);
				this.exibirFazerUpload(false);
			}else{
				this.exibirCarregando(false);
				this.exibirFazerUpload(true);
			}
		}
	}
	
    this.exibirCarregando = function(exibir){
		if(exibir){
			$(this.elementoCarregando).show();
		}else{
			$(this.elementoCarregando).hide();
		}
	}
	
	this.exibirFazerUpload = function(exibir){
		if(exibir){
			$(this.elementoFazerUpload).show();
		}else{
			$(this.elementoFazerUpload).hide();
		}
	}
}

MultimediaShift.Container = function(objeto){   
    if (this.constructor === MultimediaShift.Container) {
        throw "N�o � poss�el instanciar a classe";
    }
    var _this = this;
    this.imagens = [];
    
    this.elementoPrincipal = null;
    this.elementoCabecalho = null;
    this.elementoCorpo = null;
    this.identificador = null;
    this.tipo = null;
    this.minimizado = false;
    this.contadorDragAndDrop = 0;
    
    MultimediaShift.Objeto.call(this,objeto);
    MultimediaShift.ElementoRenderizado.call(this);

    this.permiteEdicao = function(){
		var permiteEdicao = true;
		if (this.tipo == "Procedimento"){
		   	permiteEdicao = this.procedimento.permiteEdicao;
		}else{
		    permiteEdicao = MultimediaShift.getContexto().PermiteEdicao;
		}

		return permiteEdicao;
	}
    
    this.getElementoADesenhar = function(){
        this.elementoPrincipal = document.createElement("div");
        this.elementoPrincipal.className = this.getClasseCSS();
        this.elementoPrincipal.onclick = function(){MultimediaShift.getContexto().focarBotaoSnapshot();}
        this.elementoPrincipal.style.cssText = this.getTextoCSS();
        
        if(this.permiteEdicao()){
	     	this.elementoPrincipal.funcaoOndrop=function(){
		        MultimediaShift.moverImagemDeContainer(MultimediaShift.dragAndDrop.containerOrigem,_this,MultimediaShift.dragAndDrop.imagem);
			};
	        //this.elementoPrincipal.ondragover=function(event){
		     //   event.preventDefault();
			//};
			this.elementoPrincipal.ondragenter=function(event){
				console.log("ondragenter");
		        _this.contadorDragAndDrop++;
		        if(MultimediaShift.dragAndDrop.containerOrigem && _this != MultimediaShift.dragAndDrop.containerOrigem){
			        _this.exibirBordaDragAndDrop(true);
		        }
			};
			this.elementoPrincipal.ondragleave=function(event){
				_this.contadorDragAndDrop--;
				if(_this.contadorDragAndDrop === 0){
					_this.exibirBordaDragAndDrop(false);
				}
			};
	    }
        
        this.criarElementoCabecalho();
        this.criarElementoCorpo();
        
        this.elementoPrincipal.appendChild(this.elementoCabecalho);
        this.elementoPrincipal.appendChild(this.elementoCorpo);
        
        this.desenharTodasAsImagens();
        return this.elementoPrincipal;
    }
	    
    this.getIdentificador = function(){return this.identificador} // deve ser implementado na classe herdada;
    this.setIdentificador = function(identificador){this.identificador = identificador.toString();}
    
    this.getElementoCabecalho = function(){return this.elementoCabecalho}
    this.criarElementoCabecalho = function(){} // deve ser implementado na classe herdada;
    
    this.getDescricao = function(){} // deve ser implementado na classe herdada;
    this.getElementoCorpo = function(){return this.elementoCorpo;}
    this.criarElementoCorpo = function(){
        this.elementoCorpo = document.createElement("div");
        if(this.permiteEdicao()){
			this.elementoCorpo.className = "proc__conteudo";
	    }else{
		    this.elementoCorpo.className = "proc__conteudo__desabilitado";
		}
        this.elementoCorpo.id = "grp"+this.getIdentificador();
    }
    
    this.limparCorpo = function(){
        $(this.elementoCorpo).empty();
    }
    
    this.desenharTodasAsImagens = function(){
        this.limparCorpo();
        var todosParametrosSelecionados = false;
		if(this.tipo == "Procedimento"){
			if(this.getTotalParametros() <= this.getTotalImagensSelecionadas()){
				todosParametrosSelecionados = true;
			}
		}
		for(var i in this.imagens) {
			this.desenharImagem(this.imagens[i],todosParametrosSelecionados);
        }       
    }
    
    this.desenharImagem = function(objetoImagem,todosParametrosSelecionados){
	    if((todosParametrosSelecionados) && (!objetoImagem.selecionada)){
		    objetoImagem.permiteEdicao = false;
		}else{
		    if(this.permiteEdicao()) objetoImagem.permiteEdicao = true;
		}
        objetoImagem.desenhar(this.elementoCorpo);
    }
    
    this.inicioInserirImagem = function(){
	    return true
	};    
    this.finalInserirImagem = function(){
	    MultimediaShift.getContexto().focarBotaoSnapshot();
	};    
    this.inserirImagem = function(objetoImagem){
        if (!this.inicioInserirImagem()) return;
        var contexto = MultimediaShift.getContexto();
       	var indiceDrop = contexto.AuxiliarIndiceDrop;
       	
       	if(indiceDrop !== ""){
	     	this.imagens.splice(indiceDrop, 0, objetoImagem);  	
	    }else{
			this.imagens.push(objetoImagem);    
		}
        
        objetoImagem.onClick = function(objetoImagem){_this.clickImagem(objetoImagem)};
        objetoImagem.tipoContainerPai = this.tipo;
        
        var permiteEdicao = this.permiteEdicao();
        objetoImagem.setPermiteEdicao(permiteEdicao);
        
        if(permiteEdicao){
	     	objetoImagem.onExibirDropdown = function(objetoImagem){_this.exibirDropdownImagem(objetoImagem)};
	        objetoImagem.onExcluir = function(objetoImagem){_this.removerImagem(objetoImagem)};
	        objetoImagem.onFazerUpload = function(objetoImagem){_this.armazenarImagem(objetoImagem)};
	        objetoImagem.onIniciarDrag = function(objetoImagem){_this.iniciarDragImagem(objetoImagem)};
	        objetoImagem.onSelecionarParaLaudo = function(objetoImagem){_this.inicioSelecionarParaLaudo(objetoImagem)};
	        
	        objetoImagem.onFinalizarDrag = function(){
		        var contexto = MultimediaShift.getContexto();
		        
		        if(contexto.AuxiliarTipoAcao != "DIV"){
			     	var dragAndDrop = MultimediaShift.dragAndDrop;
			        var indiceDrag = contexto.AuxiliarIndiceInicioDrag;
			        var indiceDrop = contexto.AuxiliarIndiceDrop;
			        
			        if((dragAndDrop.containerDestino == null) && (indiceDrag != indiceDrop) && (indiceDrop >= 0)){
				        dragAndDrop.containerOrigem.imagens.splice(indiceDrag,1);
				        
				        //ordena��o
				        var objetoImagem = dragAndDrop.imagem;
				        var indice = indiceDrop;
			            var auxContainer = $.extend(true, {}, dragAndDrop.containerOrigem);
			            var auxImagensContainer = auxContainer.imagens;
			            auxImagensContainer.splice(indice,0,objetoImagem);
				        
			        	if(indice == 0){//primeira posi��o
					    	if(auxImagensContainer.length > 1){
					    		objetoImagem.campoOrdenacao = auxImagensContainer[indice+1].campoOrdenacao - 1;
					    	}else{
						    	objetoImagem.campoOrdenacao = indice;
						    }
					    }else if(indice+1 == auxImagensContainer.length){//�ltima posi��o
						    if(auxImagensContainer.length > 1){
							 	objetoImagem.campoOrdenacao = auxImagensContainer[indice-1].campoOrdenacao + 1;   
							}else{
								objetoImagem.campoOrdenacao = indice;
							}
						}else{//no meio do array
							objetoImagem.campoOrdenacao = ((auxImagensContainer[indice-1].campoOrdenacao + auxImagensContainer[indice+1].campoOrdenacao) / 2);
						}
						
						var procedimentoId = ""
						if(dragAndDrop.containerOrigem.tipo == "Procedimento"){
							procedimentoId = dragAndDrop.containerOrigem.procedimento.id
						}
						var objetoAlteracaoImagem = 
			            {
				            "osId":contexto.OsId,
			                "id":objetoImagem.id,
			                "procedimentoId":procedimentoId,
			                "parametroId":"",
			                "selecionada":objetoImagem.selecionada,
			                "campoOrdenacao":objetoImagem.campoOrdenacao
			            };
			            
			       	 	contexto.escreverDebugConsole("AlterarDadosImagem",objetoAlteracaoImagem);
			            retorno = MultimediaShift.executarAcaoServidorSincrona("AlterarDadosImagem",objetoAlteracaoImagem);
			            contexto.escreverDebugConsole("retorno",retorno);
									        
				        dragAndDrop.containerOrigem.imagens.splice(indiceDrop,0,objetoImagem);
				        dragAndDrop.containerOrigem.desenharTodasAsImagens();
					}   
			    }		        
		        
		        //MultimediaShift.dragAndDrop.imagem = null;
		        var contexto = MultimediaShift.getContexto();
			    listaTodosContainers = contexto.getTodosContainers();
		        _.each(listaTodosContainers,
		            function(objetoContainer){
		                objetoContainer.exibirIndicacaoPermiteDrop(false);
		            }
		        )
	        }
	    }
        
        if(this.renderizado){
            this.desenharTodasAsImagens();
        }
        
        if (!objetoImagem.armazenada){
            this.armazenarImagem(objetoImagem);
        }
        
        this.finalInserirImagem();
    }
    
    this.armazenarImagem = function(objetoImagem){
	    var contexto = MultimediaShift.getContexto();
        var procedimentoId = "";
        var procedimentoId = (this.tipo == "Procedimento")?this.getIdentificador():"";
        var parametroId = "";
                
        var objetoImagemArmazenar = 
        {
	        "osId":contexto.OsId,
            "procedimentoId":procedimentoId,
            "parametroId":parametroId,
            "imagemBase64":objetoImagem.imagemBase64,
            "selecionada":objetoImagem.selecionada
        };
        
        // procura no localStorage pra verificar se a imagem j� est� armazenada
        var objetoImagemLocalStorage = contexto.ControleLocalStorage.encontrarImagem(objetoImagem);
        if(!objetoImagemLocalStorage){
	        objetoImagemLocalStorage = this.armazenarNoLocalStorage(objetoImagem);
	        objetoImagem.idLocalStorage = objetoImagemLocalStorage.id;
        }
        
        var callbackQuandoArmazenada = 
            function(objRetornoServidor){
	            try{
		            if(objRetornoServidor.status == "1"){
			            // Assim que a imagem for armazenada, ela � removida do localStorage
			            _this.removerDoLocalStorage(objetoImagemLocalStorage);
			            objetoImagem.setArmazenada(true);
	                	objetoImagem.setId(objRetornoServidor.id);
	                	objetoImagem.setData(objRetornoServidor.data);
	                	objetoImagem.setHora(objRetornoServidor.hora);
	                	objetoImagem.setCaminhoInterno(objRetornoServidor.caminhoInterno);
		            }else{
			            objetoImagem.setArmazenando(false);
			            objetoImagem.setMensagemErroUpload(objRetornoServidor.mensagem);
		            }
	            }catch(ex){
		            console.log(ex);
		            // TO DO
	            }
            }
		objetoImagem.setArmazenando(true);		
        MultimediaShift.executarAcaoServidorAssincrona("ArmazenarImagem",objetoImagemArmazenar,callbackQuandoArmazenada);
    }
    
    this.armazenarNoLocalStorage = function(objetoImagem){
	    var contexto = MultimediaShift.getContexto();
	    var procedimentoId = (this.tipo == "Procedimento")?this.getIdentificador():"";
	    
	    var objetoImagemLocalStorage = new MultimediaShift.ImagemLocalStorage();
	    objetoImagemLocalStorage.procedimentoId = procedimentoId;
	    objetoImagemLocalStorage.imagemBase64 = objetoImagem.imagemBase64;
	    
	    contexto.ControleLocalStorage.inserirImagem(objetoImagemLocalStorage);
	    contexto.escreverDebugConsole("Imagem armazenada no localStorage - id (timestamp): " + objetoImagemLocalStorage.id);
	    
	    return objetoImagemLocalStorage;
    }
    
    this.removerDoLocalStorage = function(objetoImagemLocalStorage){
	    var contexto = MultimediaShift.getContexto();
		contexto.ControleLocalStorage.removerImagem(objetoImagemLocalStorage);
		contexto.escreverDebugConsole("Imagem removida do localStorage - id (timestamp): " + objetoImagemLocalStorage.id);
    }
    
    this.inserirListaImagens = function(listaImagens){
        _.each(listaImagens,
            function(objetoImagem){
                this.inserirImagem(objetoImagem);
            },
            this
        )
    }
    
    this.ordenarImagens = function(){
        this.imagens = _.sortBy(this.imagens,
            function(objetoImagem){
                return parseFloat(objetoImagem.campoOrdenacao)
            }
        );
    }
    
    this.inicioRemoverImagem = function(){return true};
    this.finalRemoverImagem = function(){};
    this.removerImagem = function(objetoImagem){
        if (!this.inicioRemoverImagem()) return;
        
        this.imagens = _.without(this.imagens,objetoImagem);
        this.desenharTodasAsImagens();
        
        this.finalRemoverImagem();
    }
    
    this.clickImagem = function(objetoImagem){
	    MultimediaShift.getContexto().exibirImagemAmpliada(_this,objetoImagem);
    }
    
    this.exibirDropdownImagem = function(objetoImagem){
    	var contexto = MultimediaShift.getContexto();
    	
    	var listaContainersParaMover = this.getOutrosContainers();
    	
        /*var listaContainers = contexto.getTodosContainers();
        var listaContainersParaMover = _.without(listaContainers,_this)*/
        
        // desenha todos os outros containers com exce��o do atual
        var botaoDropdown = objetoImagem.getBotaoDropdown();
        var dropdown = MultimediaShift.criarDropdown(botaoDropdown); // Cria um dropdown para o bot�o do procedimento
        _.each(listaContainersParaMover,
            function(objetoContainer){
                dropdown.appendChild(_this.criarItemParaMoverDeContainer(objetoContainer,objetoImagem));
            }
        )
        dropdown.appendChild(_this.criarItemParaDuplicarImagem(_this,objetoImagem));
        
        MultimediaShift.exibirDropdown(dropdown);
    }
    
    this.iniciarDragImagem = function(objetoImagem){
    	MultimediaShift.dragAndDrop.containerOrigem = _this;
    	MultimediaShift.dragAndDrop.imagem = objetoImagem;
    	
        var outrosContainers = this.getOutrosContainers();
        _.each(outrosContainers,
            function(objetoContainer){
                objetoContainer.exibirIndicacaoPermiteDrop(true);
            }
        )
    }
    
    this.inicioSelecionarParaLaudo = function(objetoImagem){
		var contexto = MultimediaShift.getContexto();
		objetoImagem.selecionada = !objetoImagem.selecionada;
		
		var objetoAlteracaoImagem = 
            {
	            "osId":contexto.OsId,
                "id":objetoImagem.id,
                "procedimentoId":this.procedimento.id,
                "parametroId":"",
                "selecionada":objetoImagem.selecionada,
                "campoOrdenacao":objetoImagem.campoOrdenacao
            };
            
        contexto.escreverDebugConsole("AlterarDadosImagem",objetoAlteracaoImagem);            
        retorno = MultimediaShift.executarAcaoServidorSincrona("AlterarDadosImagem",objetoAlteracaoImagem);            
       	contexto.escreverDebugConsole("retorno",retorno);
       	
       	contexto.FlagHouveAlteracaoUsuario = 1;
       	
       	if(this.verificarPossuiResultado()){
			contexto.FlagHouveAlteracaoUsuarioEmResultado = 1;
		}
		
		this.desenharTodasAsImagens();
	}
    
    this.getOutrosContainers = function(){
	    var contexto = MultimediaShift.getContexto();
	    var listaContainers = contexto.getContainersHabilitados();
        return _.without(listaContainers,_this);
    }
    
    this.criarItemParaMoverDeContainer = function(objContainerDestino,objetoImagem){
        var item = document.createElement("a");
        item.href= "javascript:;";
        item.className = "drop-procedimento__item";
        item.innerHTML = objContainerDestino.getDescricao();
        item.onclick = function(){MultimediaShift.moverImagemDeContainer(_this,objContainerDestino,objetoImagem)};
        return item;
    }
    
    this.criarItemParaDuplicarImagem = function(objContainerDestino,objetoImagem){
	    var item = document.createElement("a");
        item.href= "javascript:;";
        item.className = "drop-procedimento__item";
        item.innerHTML = "Duplicar imagem";
        item.onclick = function(){MultimediaShift.duplicarImagem(_this,objetoImagem)};
        return item;
	}
    
    this.exibirBordaDragAndDrop = function(exibir){
	    if(exibir){
		    $(_this.elementoPrincipal).addClass("container-borda-drag-and-drop");
	    }else{
		    $(_this.elementoPrincipal).removeClass("container-borda-drag-and-drop");
		    _this.contadorDragAndDrop = 0;
	    }
    }
    
    this.exibirIndicacaoPermiteDrop = function(exibir){
	    if(exibir){
		    $(_this.elementoPrincipal).addClass("container-permite-drop");
	    }else{
		    $(_this.elementoPrincipal).removeClass("container-permite-drop");
	    }
    }
    
    this.onMinimizar = function(){};
    this.minimizar = function(){
	    this.minimizado = true;
	    $(_this.elementoPrincipal).addClass("minimizado");
	    
	    this.onMinimizar(_this);
	    //setTimeout(function(){_this.maximizar()},2000);
    }
    
    this.onMaximizar = function(){};
    this.maximizar = function(){
	    this.minimizado = false;
	    $(_this.elementoPrincipal).removeClass("minimizado");
	    
	    this.onMaximizar(_this);
	    //alert();
    }
    
    this.getTotalImagensSelecionadas = function(){
		var selecionadas = _.where(this.imagens,{selecionada:true});
		return selecionadas.length;
	}
	
	this.verificarPossuiResultado = function(){
		if(this.tipo == "NaoAtribuidas") return false;
		
		var parametrosComResultado = _.where(this.procedimento.parametros, {possuiResultado:true})
		if (parametrosComResultado.length > 0){
			return true;	
		}else{
			return false;	
		}
	}
}

MultimediaShift.ContainerNaoAtribuida = function(objeto){
    MultimediaShift.Container.call(this,objeto);
    
    this.tipo = "NaoAtribuidas";
    this.setClasseCSS("proc proc--os");
    this.setIdentificador("NaoAtribuidas");
    this.criarElementoCabecalho = function(){
	    var descricao = this.getDescricao();
	    
	    var desabilitar = "";
	    if(!MultimediaShift.getContexto().PermiteEdicao){
			desabilitar = "disabled='true'";
		}
		
        this.elementoCabecalho = document.createElement("div");
        this.elementoCabecalho.className = "proc__cabecalho";
        this.elementoCabecalho.innerHTML = "<label class='opt-item'><input type='radio' name='containers' "+desabilitar+" value='"+this.getIdentificador()+"'><span class='opt-item__caption'>"+descricao+"</span></label>";
        this.elementoCabecalho.title = descricao;
    }
    
    this.getDescricao = function(){
        return $$$Text("N�o atribuidas");
    }
}

MultimediaShift.ContainerProcedimento = function(objeto){   
	var _this = this;
    this.procedimento = null;
    this.osProcedimentoId = null;
    MultimediaShift.Container.call(this,objeto);
    
    this.tipo = "Procedimento";
    this.setClasseCSS("proc");    
    
    this.criarElementoCabecalho = function(){	    
	    var botaoMinimizar = document.createElement("button");
	    botaoMinimizar.className = "botao-minimizar-procedimento";
	    botaoMinimizar.title=$$$Text("Minimizar")
	    botaoMinimizar.innerHTML = "__";
	    botaoMinimizar.onclick = function(){
		    _this.minimizar();
	    }
	    
	    var botaoObsProcedimento = document.createElement("button");
	    botaoObsProcedimento.className = "botao-obs-procedimento";
	    botaoObsProcedimento.innerHTML = $$$Text("Observa��es");
	    botaoObsProcedimento.onclick = function(){
		    MultimediaShift.getContexto().exibirObservacaoProcedimento(_this);
	    }
	    
	    var desabilitar = "";
	    if(!_this.permiteEdicao()){
			desabilitar = "disabled='true'";
		}
		
		var descricao = this.getDescricao();
	    var labelContainer = document.createElement("label");
	   	labelContainer.className = "opt-item";
	    labelContainer.innerHTML = "<input type='radio' name='containers' "+desabilitar+" value='"+this.getIdentificador()+"'>"+
                					"<span class='opt-item__caption'>" + descricao + "</span>"
        labelContainer.title = descricao;
        
        this.elementoCabecalho = document.createElement("div");
        this.elementoCabecalho.appendChild(botaoMinimizar);
        this.elementoCabecalho.appendChild(botaoObsProcedimento);
        this.elementoCabecalho.appendChild(labelContainer);
        
        this.elementoCabecalho.className = "proc__cabecalho";
        return this.elementoCabecalho;
    }
    
    this.setProcedimento = function(procedimento){
        this.procedimento = procedimento;
        this.setIdentificador(procedimento.id);
    }
    
    this.getProcedimento = function(){
        return this.procedimento;
    }
    
    this.getDescricao = function(){
        return this.procedimento.mnemonico + " - " + this.procedimento.descricao;
    }
    
    this.getTotalParametros = function(){
		return this.procedimento.parametros.length;
	};
}

MultimediaShift.ImagemComMarcaDagua = function(objeto){
	var _this = this;
	
	this.imagemOriginal = null;
	this.imagemGerada = null;
	this.agrupamentos = [];
	this.configuracoes = {};
	
	this.onGerarImagem = function(imagemGerada){}
	
	MultimediaShift.Objeto.call(this,objeto);
	
	/* variaveis privadas */
	this._tempCanvas;
	this._tempContext;
	this._agrupamentoAtual;
	/* ------------------ */
	
	this.gerar = function(){
		this.imagemGerada = new Image()
		//this.imagemGerada.src = "img/icons/carregando.gif";
		
		var imgTemp = new Image();
		imgTemp.onload = function(){
			//setTimeout(function(){
			_this._tempCanvas = document.createElement("canvas");
			_this._tempCanvas.width = imgTemp.width
			_this._tempCanvas.height= imgTemp.height
			_this._tempContext = _this._tempCanvas.getContext('2d');
			_this._tempContext.drawImage(imgTemp,0,0); // Gera a imagem original em canvas
			
			_this.desenharAgrupamentos();
			
			_this.imagemGerada.src = _this._tempCanvas.toDataURL();
			
			_this.onGerarImagem(_this.imagemGerada);
			//},1000)
		}
		imgTemp.src = this.imagemOriginal.src;
		
		return this.imagemGerada;
	}
	
	this.desenharAgrupamentos = function(){		
		_.each(this.agrupamentos,this.desenharAgrupamento)
	}
	
	this.desenharAgrupamento = function(objAgrupamento){
		_this._agrupamentoAtual = objAgrupamento;
		var objConfiguracoes = _this.configuracoes;
		
		if(objAgrupamento.alinhamentoVertical == "superior"){
			objAgrupamento._yInicial = objConfiguracoes.fontePadraoTamanho + objConfiguracoes.margemPadrao - 3; // A subtra��o do 3 � devido a posi��o 0 ter um pequeno espa�o entre a borda superior e a escrita
		}else{
			objAgrupamento._yInicial = _this._tempCanvas.height - (objConfiguracoes.fontePadraoTamanho * (objAgrupamento.linhas.length - 1)) - objConfiguracoes.margemPadrao;
		}
		
		_.each(objAgrupamento.linhas,_this.desenharLinhaAgrupamento);
	}
	
	this.desenharLinhaAgrupamento = function(objLinha,linha){
		var objAgrupamentoAtual = _this._agrupamentoAtual;
		var tempContext = _this._tempContext;
		var objConfiguracoes = _this.configuracoes;
		var texto = objLinha.texto;
		
		// Isso deve ser definido antes pois � isso que vai influenciar no measureText
		tempContext.font= objConfiguracoes.fontePadraoTamanho + "px " + objConfiguracoes.fontePadrao;
		var tamanhoTexto = tempContext.measureText(texto).width;
		
		var yAtual = objAgrupamentoAtual._yInicial + (objConfiguracoes.fontePadraoTamanho * linha);
		var xAtual;
		if (objAgrupamentoAtual.alinhamentoHorizontal == "esquerda"){
			xAtual = 0 + objConfiguracoes.margemPadrao;
		}else{
			xAtual = _this._tempCanvas.width - tamanhoTexto - objConfiguracoes.margemPadrao;
		}		
		
		objLinha._xInicial = xAtual;
		objLinha._yInicial = yAtual;
		
		tempContext.lineWidth = 1.5;
		tempContext.strokeStyle = objConfiguracoes.fonteBordaCor;
		tempContext.strokeText(texto,xAtual,yAtual);
		
		tempContext.lineWidth = 1;
		tempContext.fillStyle = objConfiguracoes.fontePadraoCor;
		tempContext.fillText(texto,xAtual,yAtual);
	}
}

MultimediaShift.AgrupamentoMarcaDagua = function(objeto){
	this.posicionamento = null;
	this.linhas = [];
	this._xInicial;
	this._yInicial;
	MultimediaShift.Objeto.call(this,objeto);
}

MultimediaShift.LinhaMarcaDagua = function(objeto){
	this.texto = null;
	this._xInicial;
	this._yInicial;
	MultimediaShift.Objeto.call(this,objeto);
}