/*** Zen Module: s00_componente_interface_mobile ***/

self._zenClassIdx['scsPopupGroupMobile'] = 's00_componente_interface_mobile_scsPopupGroupMobile';
self.s00_componente_interface_mobile_scsPopupGroupMobile = function(index,id) {
	if (index>=0) {s00_componente_interface_mobile_scsPopupGroupMobile__init(this,index,id);}
}

self.s00_componente_interface_mobile_scsPopupGroupMobile__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_group__init) ?zenMaster._ZEN_Component_group__init(o,index,id):_ZEN_Component_group__init(o,index,id);
	o.enclosingClass = 'scsPopupGroupMobileBack';
	o.hidden = true;
	o.hintClass = 'scsPopupGroupMobileClose';
	o.labelClass = 'scsPopupGroupMobileTitle';
	o.layout = 'none';
	o.onclose = '';
	o.scsBotaoFechar = false;
	o.scsTituloPopup = '';
}
function s00_componente_interface_mobile_scsPopupGroupMobile_serialize(set,s)
{
	var o = this;s[0]='622093234';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=o.containerStyle;s[14]=(o.disabled?1:0);s[15]=(o.dragEnabled?1:0);s[16]=(o.dropEnabled?1:0);s[17]=(o.dynamic?1:0);s[18]=o.enclosingClass;s[19]=o.enclosingStyle;s[20]=o.error;s[21]=o.groupClass;s[22]=o.groupStyle;s[23]=o.height;s[24]=(o.hidden?1:0);s[25]=o.hint;s[26]=o.hintClass;s[27]=o.hintStyle;s[28]=o.label;s[29]=o.labelClass;s[30]=o.labelDisabledClass;s[31]=o.labelPosition;s[32]=o.labelStyle;s[33]=o.layout;s[34]=o.onafterdrag;s[35]=o.onbeforedrag;s[36]=o.onclick;s[37]=o.onclose;s[38]=o.ondrag;s[39]=o.ondrop;s[40]=o.onhide;s[41]=o.onrefresh;s[42]=o.onshow;s[43]=o.onupdate;s[44]=o.overlayMode;s[45]=o.renderFlag;s[46]=(o.scsBotaoFechar?1:0);s[47]=o.scsTituloPopup;s[48]=(o.showLabel?1:0);s[49]=o.slice;s[50]=o.title;s[51]=o.tuple;s[52]=o.valign;s[53]=(o.visible?1:0);s[54]=o.width;
}
function s00_componente_interface_mobile_scsPopupGroupMobile_getSettings(s)
{
	s['name'] = 'string';
	s['hidden'] = 'boolean';
	s['layout'] = 'string';
	s['onclose'] = 'string';
	s['scsBotaoFechar'] = 'boolean';
	s['scsTituloPopup'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente_interface_mobile_scsPopupGroupMobile_setProperty = function(property,value,value2) {
switch(property) {
case "scsTituloPopup":
document.getElementById(this.id+".popupTitulo").innerHTML = value;
break;
default:
return this.invokeSuper('setProperty',arguments);
}
return true;
}

self.s00_componente_interface_mobile_scsPopupGroupMobile_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente_interface_mobile_scsPopupGroupMobile__Loader = function() {
	zenLoadClass('_ZEN_Component_group');
	s00_componente_interface_mobile_scsPopupGroupMobile.prototype = zenCreate('_ZEN_Component_group',-1);
	var p = s00_componente_interface_mobile_scsPopupGroupMobile.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente_interface_mobile_scsPopupGroupMobile;
	p.superClass = ('undefined' == typeof _ZEN_Component_group) ? zenMaster._ZEN_Component_group.prototype:_ZEN_Component_group.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente.interface.mobile.scsPopupGroupMobile';
	p._type = 'scsPopupGroupMobile';
	p.serialize = s00_componente_interface_mobile_scsPopupGroupMobile_serialize;
	p.getSettings = s00_componente_interface_mobile_scsPopupGroupMobile_getSettings;
	p.ReallyRefreshContents = s00_componente_interface_mobile_scsPopupGroupMobile_ReallyRefreshContents;
	p.setProperty = s00_componente_interface_mobile_scsPopupGroupMobile_setProperty;
}
/* EOF */