/*** Zen Module: s00_componente2_interface ***/

self._zenClassIdx['Padrao'] = 's00_componente2_interface_Padrao';
self.s00_componente2_interface_Padrao = function(index,id) {
	if (index>=0) {s00_componente2_interface_Padrao__init(this,index,id);}
}

self.s00_componente2_interface_Padrao__init = function(o,index,id) {
	('undefined' == typeof _ZEN_Component_composite__init) ?zenMaster._ZEN_Component_composite__init(o,index,id):_ZEN_Component_composite__init(o,index,id);
}
function s00_componente2_interface_Padrao_serialize(set,s)
{
	var o = this;s[0]='4096323540';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=(o.childrenCreated?1:0);s[14]=o.containerStyle;s[15]=(o.disabled?1:0);s[16]=(o.dragEnabled?1:0);s[17]=(o.dropEnabled?1:0);s[18]=(o.dynamic?1:0);s[19]=o.enclosingClass;s[20]=o.enclosingStyle;s[21]=o.error;s[22]=o.groupClass;s[23]=o.groupStyle;s[24]=o.height;s[25]=(o.hidden?1:0);s[26]=o.hint;s[27]=o.hintClass;s[28]=o.hintStyle;s[29]=o.label;s[30]=o.labelClass;s[31]=o.labelDisabledClass;s[32]=o.labelPosition;s[33]=o.labelStyle;s[34]=o.layout;s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onclick;s[38]=o.ondrag;s[39]=o.ondrop;s[40]=o.onhide;s[41]=o.onrefresh;s[42]=o.onshow;s[43]=o.onupdate;s[44]=o.overlayMode;s[45]=o.renderFlag;s[46]=(o.showLabel?1:0);s[47]=o.slice;s[48]=o.title;s[49]=o.tuple;s[50]=o.valign;s[51]=(o.visible?1:0);s[52]=o.width;
}
function s00_componente2_interface_Padrao_getSettings(s)
{
	s['name'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente2_interface_Padrao_getCampo = function(campo,propriedade) {
var componente = this.getChildById(campo);
return componente.getProperty(propriedade);
}

self.s00_componente2_interface_Padrao_removeComp = function() {
zenThis.composite.setProperty('hidden', true);
}

self.s00_componente2_interface_Padrao_setCampo = function(campo,valor,propriedade) {
var componente = this.getChildById(campo);
componente.setProperty(propriedade, valor);
}

self.s00_componente2_interface_Padrao_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente2_interface_Padrao__Loader = function() {
	zenLoadClass('_ZEN_Component_composite');
	s00_componente2_interface_Padrao.prototype = zenCreate('_ZEN_Component_composite',-1);
	var p = s00_componente2_interface_Padrao.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente2_interface_Padrao;
	p.superClass = ('undefined' == typeof _ZEN_Component_composite) ? zenMaster._ZEN_Component_composite.prototype:_ZEN_Component_composite.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente2.interface.Padrao';
	p._type = 'Padrao';
	p.serialize = s00_componente2_interface_Padrao_serialize;
	p.getSettings = s00_componente2_interface_Padrao_getSettings;
	p.ReallyRefreshContents = s00_componente2_interface_Padrao_ReallyRefreshContents;
	p.getCampo = s00_componente2_interface_Padrao_getCampo;
	p.removeComp = s00_componente2_interface_Padrao_removeComp;
	p.setCampo = s00_componente2_interface_Padrao_setCampo;
}

self._zenClassIdx['scsCompositeContato'] = 's00_componente2_interface_scsCompositeContato';
self.s00_componente2_interface_scsCompositeContato = function(index,id) {
	if (index>=0) {s00_componente2_interface_scsCompositeContato__init(this,index,id);}
}

self.s00_componente2_interface_scsCompositeContato__init = function(o,index,id) {
	('undefined' == typeof s00_componente2_interface_Padrao__init) ?zenMaster.s00_componente2_interface_Padrao__init(o,index,id):s00_componente2_interface_Padrao__init(o,index,id);
	o.Atualizar = false;
	o.CamposTraducao = new Object();
	o.MensagensErro = new Object();
	o.PosicaoAtual = '0';
	o.TipoComponente = 'scsCompositeContato4';
	o.TotalPosicao = '0';
	o.delimitadorMV = '@VM';
	o.scsApresentaLabel = true;
	o.scsDddObrigatorio = false;
	o.scsDdiObrigatorio = false;
	o.scsDepartamentoObrigatorio = false;
	o.scsEmailObrigatorio = false;
	o.scsNomeObrigatorio = false;
	o.scsObsObrigatorio = false;
	o.scsRamalObrigatorio = false;
	o.scsTodosSomenteLeitura = false;
	o.strDdd = '';
	o.strDdi = '';
	o.strDepartamento = '';
	o.strEmail = '';
	o.strNome = '';
	o.strNumero = '';
	o.strObs = '';
	o.strRamal = '';
	o.strTipo = '';
}
function s00_componente2_interface_scsCompositeContato_serialize(set,s)
{
	var o = this;s[0]='3698044372';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=(o.Atualizar?1:0);s[7]=set.serializeArray(o,o.CamposTraducao,false,'CamposTraducao');s[8]=set.serializeArray(o,o.MensagensErro,false,'MensagensErro');s[9]=o.PosicaoAtual;s[10]=o.TipoComponente;s[11]=o.TotalPosicao;s[12]=o.align;s[13]=o.aux;s[14]=o.cellAlign;s[15]=o.cellSize;s[16]=o.cellStyle;s[17]=o.cellVAlign;s[18]=set.serializeList(o,o.children,true,'children');s[19]=(o.childrenCreated?1:0);s[20]=o.containerStyle;s[21]=o.delimitadorMV;s[22]=(o.disabled?1:0);s[23]=(o.dragEnabled?1:0);s[24]=(o.dropEnabled?1:0);s[25]=(o.dynamic?1:0);s[26]=o.enclosingClass;s[27]=o.enclosingStyle;s[28]=o.error;s[29]=o.groupClass;s[30]=o.groupStyle;s[31]=o.height;s[32]=(o.hidden?1:0);s[33]=o.hint;s[34]=o.hintClass;s[35]=o.hintStyle;s[36]=o.label;s[37]=o.labelClass;s[38]=o.labelDisabledClass;s[39]=o.labelPosition;s[40]=o.labelStyle;s[41]=o.layout;s[42]=o.onafterdrag;s[43]=o.onbeforedrag;s[44]=o.onclick;s[45]=o.ondrag;s[46]=o.ondrop;s[47]=o.onhide;s[48]=o.onrefresh;s[49]=o.onshow;s[50]=o.onupdate;s[51]=o.overlayMode;s[52]=o.renderFlag;s[53]=(o.scsApresentaLabel?1:0);s[54]=(o.scsDddObrigatorio?1:0);s[55]=(o.scsDdiObrigatorio?1:0);s[56]=(o.scsDepartamentoObrigatorio?1:0);s[57]=(o.scsEmailObrigatorio?1:0);s[58]=(o.scsNomeObrigatorio?1:0);s[59]=(o.scsObsObrigatorio?1:0);s[60]=(o.scsRamalObrigatorio?1:0);s[61]=(o.scsTodosSomenteLeitura?1:0);s[62]=(o.showLabel?1:0);s[63]=o.slice;s[64]=o.strDdd;s[65]=o.strDdi;s[66]=o.strDepartamento;s[67]=o.strEmail;s[68]=o.strNome;s[69]=o.strNumero;s[70]=o.strObs;s[71]=o.strRamal;s[72]=o.strTipo;s[73]=o.title;s[74]=o.tuple;s[75]=o.valign;s[76]=(o.visible?1:0);s[77]=o.width;
}
function s00_componente2_interface_scsCompositeContato_getSettings(s)
{
	s['name'] = 'string';
	s['Atualizar'] = 'string';
	s['CamposTraducao'] = 'string';
	s['MensagensErro'] = 'string';
	s['PosicaoAtual'] = 'string';
	s['TipoComponente'] = 'string';
	s['TotalPosicao'] = 'string';
	s['delimitadorMV'] = 'string';
	s['scsApresentaLabel'] = 'boolean';
	s['scsDddObrigatorio'] = 'boolean';
	s['scsDdiObrigatorio'] = 'boolean';
	s['scsDepartamentoObrigatorio'] = 'boolean';
	s['scsEmailObrigatorio'] = 'boolean';
	s['scsNomeObrigatorio'] = 'boolean';
	s['scsObsObrigatorio'] = 'boolean';
	s['scsRamalObrigatorio'] = 'boolean';
	s['scsTodosSomenteLeitura'] = 'boolean';
	s['strDdd'] = 'string';
	s['strDdi'] = 'string';
	s['strDepartamento'] = 'string';
	s['strEmail'] = 'string';
	s['strNome'] = 'string';
	s['strNumero'] = 'string';
	s['strObs'] = 'string';
	s['strRamal'] = 'string';
	s['strTipo'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente2_interface_scsCompositeContato_RecuperarContato = function() {
var componente = zenPage.getComponent(this.index)
zenPage.getComponentById("formularioCadastro.ContatoTipo").setValue(componente.strTipo)
zenPage.getComponentById("formularioCadastro.ContatoTipo").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDdi").setValue(componente.strDdi)
zenPage.getComponentById("formularioCadastro.ContatoDdi").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDdd").setValue(componente.strDdd)
zenPage.getComponentById("formularioCadastro.ContatoDdd").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoNome").setValue(componente.strNome)
zenPage.getComponentById("formularioCadastro.ContatoNome").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoNumero").setValue(componente.strNumero)
zenPage.getComponentById("formularioCadastro.ContatoNumero").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoRamal").setValue(componente.strRamal)
zenPage.getComponentById("formularioCadastro.ContatoRamal").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoDepartamento").setValue(componente.strDepartamento)
zenPage.getComponentById("formularioCadastro.ContatoDepartamento").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoEmail").setValue(componente.strEmail)
zenPage.getComponentById("formularioCadastro.ContatoEmail").onchangeHandler()
zenPage.getComponentById("formularioCadastro.ContatoObservacao").setValue(componente.strObs)
zenPage.getComponentById("formularioCadastro.ContatoObservacao").onchangeHandler()
}

self.s00_componente2_interface_scsCompositeContato_adicionaContatoCliente = function() {
var tipo = this.getChildById("contatoTipo").getProperty("value");
var ddi = this.getChildById("contatoDdi").getProperty("value");
var ddd = this.getChildById("contatoDdd").getProperty("value");
var nome = this.getChildById("contatoNome").getProperty("value");
var numero = this.getChildById("contatoNumero").getProperty("value");
var ramal = this.getChildById("contatoRamal").getProperty("value");
var departamento = this.getChildById("contatoDepartamento").getProperty("value");
var email = this.getChildById("contatoEmail").getProperty("value");
var obs = this.getChildById("contatoObs").getProperty("value");
var erro = "";
if (this.removerEspacos(tipo) == ""){
erro += "- "+this.CamposTraducao["tipo"]+" \n";
}
if ((this.removerEspacos(ddi) == "") && (this.scsDdiObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ddi"]+" \n";
}
if ((this.removerEspacos(ddd) == "") && (this.scsDddObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ddd"]+" \n";
}
if ((this.removerEspacos(nome) == "") && (this.scsNomeObrigatorio) == 1){
erro += "- "+this.CamposTraducao["nome"]+" \n";
}
if (this.removerEspacos(numero) == ""){
erro += "- "+this.CamposTraducao["numero"]+" \n";
}
if ((this.removerEspacos(ramal) == "") && (this.scsRamalObrigatorio) == 1){
erro += "- "+this.CamposTraducao["ramal"]+" \n";
}
if ((this.removerEspacos(departamento) == "") && (this.scsDepartamentoObrigatorio) == 1){
erro += "- "+this.CamposTraducao["departamento"]+" \n";
}
if ((this.removerEspacos(email) == "") && (this.scsEmailObrigatorio) == 1){
erro += "- "+this.CamposTraducao["email"]+" \n";
}
if ((this.removerEspacos(obs) == "") && (this.scsObsObrigatorio) == 1){
erro += "- "+this.CamposTraducao["observacoes"]+" \n";
}
if (erro != ""){
zenPage.alertaShift(this.MensagensErro["camposObrigatorios"]+"\n"+erro);
return 1;
}
if (this.Atualizar){
this.atualizaContatoCliente();
return 1;
}
if (this.strNumero == ""){
this.strTipo = tipo;
this.strDdd = ddd;
this.strDdi = ddi;
this.strNome = nome;
this.strNumero = numero;
this.strRamal = ramal;
this.strDepartamento = departamento;
this.strEmail = email;
this.strObs = obs;
}else{
this.strTipo = this.strTipo + this.delimitadorMV + tipo;
this.strDdd = this.strDdd + this.delimitadorMV + ddd;
this.strDdi = this.strDdi + this.delimitadorMV + ddi;
this.strNome = this.strNome + this.delimitadorMV + nome;
this.strNumero = this.strNumero + this.delimitadorMV + numero;
this.strRamal = this.strRamal + this.delimitadorMV + ramal;
this.strDepartamento = this.strDepartamento + this.delimitadorMV + departamento;
this.strEmail = this.strEmail + this.delimitadorMV + email;
this.strObs = this.strObs + this.delimitadorMV + obs;
}
this.TotalPosicao = this.strNumero.split(this.delimitadorMV).length;
this.limpaCamposCliente();
return 1;
}

self.s00_componente2_interface_scsCompositeContato_alterarCorLinha = function(posLinha) {
var componente = zenPage.getComponent(this.index)
var qtdLinha = componente.TotalPosicao
var linha = 1
while(linha<=qtdLinha){
var aux = "linhaContato"+linha
var obj = document.getElementById(aux)
if ((linha%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (linha == posLinha){
obj.style.background = "#fbe091";
}else{
obj.style.background = zebra;
}
linha = linha + 1
}
}

self.s00_componente2_interface_scsCompositeContato_atualizaBotoesPadraoCliente = function(pAcao) {
if (pAcao==1){
this.getChildById("btNovo").setHidden(true);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Adicionar contato");
this.Atualizar = 0;
btAcao.setProperty("onclick","zenThis.composite.adicionaContatoCliente(); zenThis.composite.atualizaGridHtmlCliente()");
btAcao.setProperty("enclosingClass","botao_i_add");
}else if (pAcao==2){
this.getChildById("btNovo").setHidden(false);
var btAcao = this.getChildById("btAcao");
btAcao.setProperty("title","Atualizar contato");
this.Atualizar = 1;
btAcao.setProperty("onclick","zenThis.composite.adicionaContatoCliente(); zenThis.composite.atualizaGridHtmlCliente()");
btAcao.setProperty("enclosingClass","botao_i_refresh_red");
}
if (this.scsTodosSomenteLeitura){
this.getChildById("btNovo").setHidden(true);
this.getChildById("btAcao").setHidden(true);
}
return 1;
}

self.s00_componente2_interface_scsCompositeContato_atualizaContatoCliente = function() {
var tipo = this.getChildById("contatoTipo").getProperty("value");
var ddi = this.getChildById("contatoDdi").getProperty("value");
var ddd = this.getChildById("contatoDdd").getProperty("value");
var nome = this.getChildById("contatoNome").getProperty("value");
var numero = this.getChildById("contatoNumero").getProperty("value");
var ramal = this.getChildById("contatoRamal").getProperty("value");
var departamento = this.getChildById("contatoDepartamento").getProperty("value");
var email = this.getChildById("contatoEmail").getProperty("value");
var obs = this.getChildById("contatoObs").getProperty("value");
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
var posicao = this.PosicaoAtual - 1;
tipoList.splice(posicao,1,tipo);
ddiList.splice(posicao,1,ddi);
dddList.splice(posicao,1,ddd);
nomeList.splice(posicao,1,nome);
numeroList.splice(posicao,1,numero);
ramalList.splice(posicao,1,ramal);
departamentoList.splice(posicao,1,departamento);
emailList.splice(posicao,1,email);
obsList.splice(posicao,1,obs);
this.strTipo = tipoList.join(this.delimitadorMV);
this.strDdi = ddiList.join(this.delimitadorMV);
this.strDdd = dddList.join(this.delimitadorMV);
this.strNome = nomeList.join(this.delimitadorMV);
this.strNumero = numeroList.join(this.delimitadorMV);
this.strRamal = ramalList.join(this.delimitadorMV);
this.strDepartamento = departamentoList.join(this.delimitadorMV);
this.strEmail = emailList.join(this.delimitadorMV);
this.strObs = obsList.join(this.delimitadorMV);
this.atualizaBotoesPadraoCliente(1);
this.limpaCamposCliente();
return 1;
}

self.s00_componente2_interface_scsCompositeContato_atualizaGridHtmlCliente = function() {
var objGrid = this.getChildById("contatoGrid");
objGrid.setProperty("content",this.desenhaGridHtmlCliente());
return 1;
}

self.s00_componente2_interface_scsCompositeContato_consultaContatoCliente = function(pPosicao) {
this.PosicaoAtual = pPosicao;
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
this.getChildById("contatoTipo").setProperty("value",tipoList[(pPosicao-1)]);
this.getChildById("contatoDdi").setProperty("value",ddiList[(pPosicao-1)]);
this.getChildById("contatoDdd").setProperty("value",dddList[(pPosicao-1)]);
this.getChildById("contatoNome").setProperty("value",nomeList[(pPosicao-1)]);
this.getChildById("contatoNumero").setProperty("value",numeroList[(pPosicao-1)]);
this.getChildById("contatoRamal").setProperty("value",ramalList[(pPosicao-1)]);
this.getChildById("contatoDepartamento").setProperty("value",departamentoList[(pPosicao-1)]);
this.getChildById("contatoEmail").setProperty("value",emailList[(pPosicao-1)]);
this.getChildById("contatoObs").setProperty("value",obsList[(pPosicao-1)]);
var retorno = this.atualizaBotoesPadraoCliente(2);
return 1;
}

self.s00_componente2_interface_scsCompositeContato_consultarContato = function() {
var tipo = zenPage.getComponentById("formularioCadastro.ContatoTipo").getValue();
var ddi = zenPage.getComponentById("formularioCadastro.ContatoDdi").getValue();
var ddd = zenPage.getComponentById("formularioCadastro.ContatoDdd").getValue();
var nome = zenPage.getComponentById("formularioCadastro.ContatoNome").getValue();
var numero = zenPage.getComponentById("formularioCadastro.ContatoNumero").getValue();
var ramal = zenPage.getComponentById("formularioCadastro.ContatoRamal").getValue();
var departamento = zenPage.getComponentById("formularioCadastro.ContatoDepartamento").getValue();
var email = zenPage.getComponentById("formularioCadastro.ContatoEmail").getValue();
var obs = zenPage.getComponentById("formularioCadastro.ContatoObservacao").getValue();
var componente = zenPage.getComponent(this.index);
componente.strTipo = tipo;
componente.strDdi = ddd;
componente.strDdd = ddd;
componente.strNome = nome;
componente.strNumero = numero;
componente.strRamal = ramal;
componente.strDepartamento = departamento;
componente.strEmail = email;
componente.strObs = obs;
componente.atualizaGridHtmlCliente();
}

self.s00_componente2_interface_scsCompositeContato_desenhaGridHtmlCliente = function() {
var strGridHtml = "";
var numeroList = this.strNumero.split(this.delimitadorMV);
this.TotalPosicao = numeroList.length;
if (this.TipoComponente == "scsCompositeContato2"){
strGridHtml += "<table cellpadding='0' class='scsCompositeContato2' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}else if (this.TipoComponente == "scsCompositeContato3"){
strGridHtml += "<table cellpadding='0' class='scsCompositeContato3' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;'>";
}else if (this.TipoComponente == "scsCompositeContato4"){
strGridHtml += "<table cellpadding='0' class='scsCompositeContato4' cellspacing='0' border='0' style='font-size:12px;color: #333;font-family: Tahoma;width:100%;'>";
}
if (this.strNumero != ""){
var tipoList = this.strTipo.split("@VM");
var dddList = this.strDdd.split("@VM");
var nomeList = this.strNome.split("@VM");
var ramalList = this.strRamal.split("@VM");
var departamentoList = this.strDepartamento.split("@VM");
var emailList = this.strEmail.split("@VM");
var qtdMV = this.TotalPosicao;
for (i=0;i<qtdMV;i++){
var tipoContato = parseInt(tipoList[i]);
switch (tipoContato){
case 1:
tipoContato = "Residencial";
break;
case 2:
tipoContato = "Comercial";
break;
case 3:
tipoContato = "Celular";
break;
case 4:
tipoContato = "Fax";
break;
case 5:
tipoContato = "Outros";
break;
}
var ddd = dddList[i];
var nome = nomeList[i];
var numero = numeroList[i];
var ramal = ramalList[i];
var departamento = departamentoList[i];
var email = emailList[i];
var telefone = "("+ddd+") "+numero;
if (nome == "") nome = "&#160;";
if (ramal == "") ramal = "&#160;";
if (departamento == "") departamento = "&#160;";
if (email == "") email = "&#160;";
if (((i+1)%2) == 0){
var zebra = "#e8f6e7";
}else{
var zebra = "#ffffff";
}
if (this.TipoComponente == "scsCompositeContato2"){
strGridHtml +=
"<tr style='cursor:pointer;' id='linhaContato"+(i+1)+"' bgcolor='"+zebra+"'>"+
"<td width='83px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+tipoContato+"</td>"+
"<td width='212px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='111px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>"+
"<td width='73px' align='left' style='padding: 5px 0px 5px 12px;' noWrap='nowrap' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+ramal+"</td>"+
"<td width='88px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+departamento+"</td>"+
"<td width='188px' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+email+"</td>"
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='30' align='rigth' style='border-right:0;vertical-align: middle;' noWrap='nowrap'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='30' align='center' style='border-right:0;vertical-align: middle;' noWrap='nowrap'><img alt='Excluir' style='cursor:pointer;' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}else if (this.TipoComponente == "scsCompositeContato3"){
strGridHtml +=
"<tr id='linhaContato"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='179' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='121' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='26' align='rigth' style='vertical-align: middle;border-right:0;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='26' align='center' style='vertical-align: middle;border-right:0;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}else if (this.TipoComponente == "scsCompositeContato4"){
strGridHtml +=
"<tr id='linhaContato"+(i+1)+"' style='cursor:hand;' bgcolor='"+zebra+"'>"+
"<td width='179' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+nome+"</td>"+
"<td width='121' align='left' style='padding: 5px 0px 5px 12px; word-break: break-all;' onclick='zenPage.getComponent("+this.index+").consultaContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").alterarCorLinha("+(i+1)+")'>"+telefone+"</td>";
if (this.scsTodosSomenteLeitura){
strGridHtml +=
"<td width='26' align='rigth' style='vertical-align: middle;border-right:0;'>&#160;</td>"+
"</tr>";
}else{
strGridHtml +=
"<td width='26' align='center' style='vertical-align: middle;border-right:0;'><img alt='Excluir' src='img/icons/action_delete.png' onclick='zenPage.getComponent("+this.index+").excluirContatoCliente("+(i+1)+");zenPage.getComponent("+this.index+").atualizaGridHtmlCliente()'/></td>"+
"</tr>";
}
}
}
}
strGridHtml += "</table>";
return strGridHtml;
}

self.s00_componente2_interface_scsCompositeContato_excluirContatoCliente = function(pPosicao) {
var tipoList = this.strTipo.split(this.delimitadorMV);
var ddiList = this.strDdi.split(this.delimitadorMV);
var dddList = this.strDdd.split(this.delimitadorMV);
var nomeList = this.strNome.split(this.delimitadorMV);
var numeroList = this.strNumero.split(this.delimitadorMV);
var ramalList = this.strRamal.split(this.delimitadorMV);
var departamentoList = this.strDepartamento.split(this.delimitadorMV);
var emailList = this.strEmail.split(this.delimitadorMV);
var obsList = this.strObs.split(this.delimitadorMV);
tipoList.splice((pPosicao-1),1);
ddiList.splice((pPosicao-1),1);
dddList.splice((pPosicao-1),1);
nomeList.splice((pPosicao-1),1);
numeroList.splice((pPosicao-1),1);
ramalList.splice((pPosicao-1),1);
departamentoList.splice((pPosicao-1),1);
emailList.splice((pPosicao-1),1);
obsList.splice((pPosicao-1),1);
this.strTipo = tipoList.join(this.delimitadorMV);
this.strDdi = ddiList.join(this.delimitadorMV);
this.strDdd = dddList.join(this.delimitadorMV);
this.strNome = nomeList.join(this.delimitadorMV);
this.strNumero = numeroList.join(this.delimitadorMV);
this.strRamal = ramalList.join(this.delimitadorMV);
this.strDepartamento = departamentoList.join(this.delimitadorMV);
this.strEmail = emailList.join(this.delimitadorMV);
this.strObs = obsList.join(this.delimitadorMV);
this.TotalPosicao = this.TotalPosicao - 1;
this.PosicaoAtual = 0;
var retorno = this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1)
return 1;
}

self.s00_componente2_interface_scsCompositeContato_limpaCamposCliente = function() {
this.getChildById("contatoTipo").setProperty("value","");
this.getChildById("contatoDdi").setProperty("value","");
this.getChildById("contatoDdd").setProperty("value","");
this.getChildById("contatoNome").setProperty("value","");
this.getChildById("contatoNumero").setProperty("value","");
this.getChildById("contatoRamal").setProperty("value","");
this.getChildById("contatoDepartamento").setProperty("value","");
this.getChildById("contatoEmail").setProperty("value","");
this.getChildById("contatoObs").setProperty("value","");
return 1;
}

self.s00_componente2_interface_scsCompositeContato_limpaComponenteCliente = function() {
this.limpaCamposCliente();
if (this.strNumero == "")
return 1
this.strTipo = "";
this.strDdd = "";
this.strDdi = "";
this.strNome = "";
this.strNumero = "";
this.strRamal = "";
this.strDepartamento = "";
this.strEmail = "";
this.strObs = "";
var retorno = this.atualizaBotoesPadraoCliente(1);
var retorno = this.atualizaGridHtmlCliente();
return 1;
}

self.s00_componente2_interface_scsCompositeContato_novo = function() {
this.limpaCamposCliente();
this.atualizaBotoesPadraoCliente(1);
this.alterarCorLinha(0);
return 1;
}

self.s00_componente2_interface_scsCompositeContato_refreshHTML = function() {
var retorno = zenPage.atualizaGridHtmlCliente();
}

self.s00_componente2_interface_scsCompositeContato_removerEspacos = function(pString) {
return pString.replace(/\s/g,"");
}

self.s00_componente2_interface_scsCompositeContato_AdicionaContato = function(atualiza) {
	return zenInstanceMethod(this,'AdicionaContato','L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeContato_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeContato_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeContato_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeContato_AtualizaContato = function() {
	return zenInstanceMethod(this,'AtualizaContato','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeContato_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeContato_ConsultaContato = function(posicao) {
	return zenInstanceMethod(this,'ConsultaContato','L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeContato_DesenhaGridHtml = function() {
	return zenInstanceMethod(this,'DesenhaGridHtml','','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeContato_ExcluirContato = function(posicao) {
	return zenInstanceMethod(this,'ExcluirContato','L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeContato_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeContato_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeContato_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeContato_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeContato_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeContato_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeContato_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeContato_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeContato_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeContato_LimpaCampos = function() {
	return zenInstanceMethod(this,'LimpaCampos','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeContato_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeContato_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente2_interface_scsCompositeContato_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeContato_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeContato_TodosSomenteLeitura = function(acao) {
	return zenInstanceMethod(this,'TodosSomenteLeitura','L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeContato_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente2_interface_scsCompositeContato__Loader = function() {
	zenLoadClass('s00_componente2_interface_Padrao');
	s00_componente2_interface_scsCompositeContato.prototype = zenCreate('s00_componente2_interface_Padrao',-1);
	var p = s00_componente2_interface_scsCompositeContato.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente2_interface_scsCompositeContato;
	p.superClass = ('undefined' == typeof s00_componente2_interface_Padrao) ? zenMaster.s00_componente2_interface_Padrao.prototype:s00_componente2_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente2.interface.scsCompositeContato';
	p._type = 'scsCompositeContato';
	p.serialize = s00_componente2_interface_scsCompositeContato_serialize;
	p.getSettings = s00_componente2_interface_scsCompositeContato_getSettings;
	p.AdicionaContato = s00_componente2_interface_scsCompositeContato_AdicionaContato;
	p.AjustaTamanhoValor = s00_componente2_interface_scsCompositeContato_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente2_interface_scsCompositeContato_ApresentaExcecao;
	p.AtualizaBotoesPadrao = s00_componente2_interface_scsCompositeContato_AtualizaBotoesPadrao;
	p.AtualizaContato = s00_componente2_interface_scsCompositeContato_AtualizaContato;
	p.AtualizaGridHtml = s00_componente2_interface_scsCompositeContato_AtualizaGridHtml;
	p.ConsultaContato = s00_componente2_interface_scsCompositeContato_ConsultaContato;
	p.DesenhaGridHtml = s00_componente2_interface_scsCompositeContato_DesenhaGridHtml;
	p.ExcluirContato = s00_componente2_interface_scsCompositeContato_ExcluirContato;
	p.GeraCheckBoxHtml = s00_componente2_interface_scsCompositeContato_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente2_interface_scsCompositeContato_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente2_interface_scsCompositeContato_GeraRadioHtml;
	p.GeraSV1Label = s00_componente2_interface_scsCompositeContato_GeraSV1Label;
	p.GeraSV1Text = s00_componente2_interface_scsCompositeContato_GeraSV1Text;
	p.GeraSelectHtml = s00_componente2_interface_scsCompositeContato_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente2_interface_scsCompositeContato_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente2_interface_scsCompositeContato_GeraTextHtml;
	p.GetValorPropriedade = s00_componente2_interface_scsCompositeContato_GetValorPropriedade;
	p.LimpaCampos = s00_componente2_interface_scsCompositeContato_LimpaCampos;
	p.LimpaComponente = s00_componente2_interface_scsCompositeContato_LimpaComponente;
	p.ReallyRefreshContents = s00_componente2_interface_scsCompositeContato_ReallyRefreshContents;
	p.RecuperarContato = s00_componente2_interface_scsCompositeContato_RecuperarContato;
	p.RetornaValorCampo = s00_componente2_interface_scsCompositeContato_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente2_interface_scsCompositeContato_SetValorPropriedade;
	p.TodosSomenteLeitura = s00_componente2_interface_scsCompositeContato_TodosSomenteLeitura;
	p.VerificaErro = s00_componente2_interface_scsCompositeContato_VerificaErro;
	p.adicionaContatoCliente = s00_componente2_interface_scsCompositeContato_adicionaContatoCliente;
	p.alterarCorLinha = s00_componente2_interface_scsCompositeContato_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente2_interface_scsCompositeContato_atualizaBotoesPadraoCliente;
	p.atualizaContatoCliente = s00_componente2_interface_scsCompositeContato_atualizaContatoCliente;
	p.atualizaGridHtmlCliente = s00_componente2_interface_scsCompositeContato_atualizaGridHtmlCliente;
	p.consultaContatoCliente = s00_componente2_interface_scsCompositeContato_consultaContatoCliente;
	p.consultarContato = s00_componente2_interface_scsCompositeContato_consultarContato;
	p.desenhaGridHtmlCliente = s00_componente2_interface_scsCompositeContato_desenhaGridHtmlCliente;
	p.excluirContatoCliente = s00_componente2_interface_scsCompositeContato_excluirContatoCliente;
	p.limpaCamposCliente = s00_componente2_interface_scsCompositeContato_limpaCamposCliente;
	p.limpaComponenteCliente = s00_componente2_interface_scsCompositeContato_limpaComponenteCliente;
	p.novo = s00_componente2_interface_scsCompositeContato_novo;
	p.refreshHTML = s00_componente2_interface_scsCompositeContato_refreshHTML;
	p.removerEspacos = s00_componente2_interface_scsCompositeContato_removerEspacos;
}

self._zenClassIdx['scsCompositeGenerico'] = 's00_componente2_interface_scsCompositeGenerico';
self.s00_componente2_interface_scsCompositeGenerico = function(index,id) {
	if (index>=0) {s00_componente2_interface_scsCompositeGenerico__init(this,index,id);}
}

self.s00_componente2_interface_scsCompositeGenerico__init = function(o,index,id) {
	('undefined' == typeof s00_componente2_interface_Padrao__init) ?zenMaster.s00_componente2_interface_Padrao__init(o,index,id):s00_componente2_interface_Padrao__init(o,index,id);
	o.alturaCabecalho = '';
	o.ctrlCampos = '0';
	o.ctrlDuplicado = '';
	o.ctrlEditaRegistro = false;
	o.ctrlStrCampoAux = '0';
	o.delimitador = '|';
	o.delimitadorMV = '';
	o.delimitadorSV = '';
	o.idDinamicoBarraDeTitulo = '';
	o.idDinamicoBotoesPadrao = '';
	o.idDinamicoBtAcao = '';
	o.idDinamicoBtNovo = '';
	o.idDinamicoGridCampos = '';
	o.idDinamicoGridConteudo = '';
	o.idDinamicoGrupoLabelTitulo = '';
	o.idDinamicoHtml = '';
	o.idDinamicoLabelTitulo = '';
	o.larguraRolagem = '';
	o.offsetWidth = '';
	o.posicaoAtual = '0';
	o.scsAlignValorGrid = '';
	o.scsCampoLayout = '';
	o.scsCampoObrigatorio = '0';
	o.scsCamposControle = '';
	o.scsCamposPersistenecia = '';
	o.scsCaption = '';
	o.scsCasasDecimaisGrid = '';
	o.scsChoiceColumn = '';
	o.scsCols = '';
	o.scsComboType = '';
	o.scsContainerStyle = '';
	o.scsControlStyle = '';
	o.scsCustomLayout = false;
	o.scsDisabled = '';
	o.scsDisplayColumns = '';
	o.scsDisplayList = '';
	o.scsDropDownHeight = '';
	o.scsDropDownWidth = '';
	o.scsEditable = '';
	o.scsEnclosingClass = '';
	o.scsEnclosingStyle = '';
	o.scsFinalAdicionaGenerico = '';
	o.scsFinalAtualizaGenerico = '';
	o.scsFinalExcluiGenerico = '';
	o.scsFinalLimpaGenerico = '';
	o.scsHeightTabelaGrid = '90px';
	o.scsHidden = '';
	o.scsHintClass = '';
	o.scsHintStyle = '';
	o.scsId = '';
	o.scsIdGrid = '';
	o.scsIdGridInput = '';
	o.scsInicioAdicionaGenerico = '';
	o.scsInicioAtualizaGenerico = '';
	o.scsInicioExcluiGenerico = '';
	o.scsInicioLimpaGenerico = '';
	o.scsLabel = '';
	o.scsLabelClass = '';
	o.scsLabelGrid = '';
	o.scsLabelPosition = '';
	o.scsLabelStyle = '';
	o.scsLarguraColunasGrid = '';
	o.scsMargemGrupoCampos = '';
	o.scsMaxRows = '';
	o.scsMaxlength = '';
	o.scsMetodoEspecifico = '';
	o.scsMultiColumn = '';
	o.scsOcultaBarraTitulo = false;
	o.scsOcultaBotaoAdicionar = false;
	o.scsOcultaBotaoExcluir = false;
	o.scsOcultaBotoesPadrao = false;
	o.scsOcultaCamposEdicao = false;
	o.scsOnBlur = '';
	o.scsOnChange = '';
	o.scsOnClick = '';
	o.scsOnFocus = '';
	o.scsOnKeyDown = '';
	o.scsOnKeyPress = '';
	o.scsOnKeyUp = '';
	o.scsPermiteRepeticao = '0';
	o.scsQtdCaracteresColunaGrid = '';
	o.scsQtdLinhaColuna = '';
	o.scsQueryClass = '';
	o.scsQueryName = '';
	o.scsReadOnly = '';
	o.scsRepositorioObjetos = null;
	o.scsRetornoSubValue = '';
	o.scsRows = '';
	o.scsSearchKeyLen = '';
	o.scsSize = '';
	o.scsSomenteVisualizacao = false;
	o.scsSql = '';
	o.scsSqlConvCodigoPropriedade = '';
	o.scsSqlGrid = '';
	o.scsSqlLookUp = '';
	o.scsStrTemp = '';
	o.scsTabIndex = '';
	o.scsTextMoedaValorMaximo = '';
	o.scsTextMoedaValorMinimo = '';
	o.scsTipo = '';
	o.scsTipoLayout = '1';
	o.scsTituloComponente = '';
	o.scsTodosSomenteLeitura = false;
	o.scsUtilizaValidacao = false;
	o.scsValue = '';
	o.scsValueList = '';
	o.scsWidth = '';
	o.scsWidthComponente = '';
	o.scsWidthTabelaGrid = '';
	o.strCampo1 = '';
	o.strCampo10 = '';
	o.strCampo11 = '';
	o.strCampo12 = '';
	o.strCampo13 = '';
	o.strCampo14 = '';
	o.strCampo15 = '';
	o.strCampo16 = '';
	o.strCampo17 = '';
	o.strCampo18 = '';
	o.strCampo2 = '';
	o.strCampo3 = '';
	o.strCampo4 = '';
	o.strCampo5 = '';
	o.strCampo6 = '';
	o.strCampo7 = '';
	o.strCampo8 = '';
	o.strCampo9 = '';
	o.strCampoAux = '';
	o.totalPosicoes = '0';
}
function s00_componente2_interface_scsCompositeGenerico_serialize(set,s)
{
	var o = this;s[0]='150038563';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.alturaCabecalho;s[8]=o.aux;s[9]=o.cellAlign;s[10]=o.cellSize;s[11]=o.cellStyle;s[12]=o.cellVAlign;s[13]=set.serializeList(o,o.children,true,'children');s[14]=(o.childrenCreated?1:0);s[15]=o.containerStyle;s[16]=o.ctrlCampos;s[17]=o.ctrlDuplicado;s[18]=(o.ctrlEditaRegistro?1:0);s[19]=o.ctrlStrCampoAux;s[20]=o.delimitador;s[21]=o.delimitadorMV;s[22]=o.delimitadorSV;s[23]=(o.disabled?1:0);s[24]=(o.dragEnabled?1:0);s[25]=(o.dropEnabled?1:0);s[26]=(o.dynamic?1:0);s[27]=o.enclosingClass;s[28]=o.enclosingStyle;s[29]=o.error;s[30]=o.groupClass;s[31]=o.groupStyle;s[32]=o.height;s[33]=(o.hidden?1:0);s[34]=o.hint;s[35]=o.hintClass;s[36]=o.hintStyle;s[37]=o.idDinamicoBarraDeTitulo;s[38]=o.idDinamicoBotoesPadrao;s[39]=o.idDinamicoBtAcao;s[40]=o.idDinamicoBtNovo;s[41]=o.idDinamicoGridCampos;s[42]=o.idDinamicoGridConteudo;s[43]=o.idDinamicoGrupoLabelTitulo;s[44]=o.idDinamicoHtml;s[45]=o.idDinamicoLabelTitulo;s[46]=o.label;s[47]=o.labelClass;s[48]=o.labelDisabledClass;s[49]=o.labelPosition;s[50]=o.labelStyle;s[51]=o.larguraRolagem;s[52]=o.layout;s[53]=o.offsetWidth;s[54]=o.onafterdrag;s[55]=o.onbeforedrag;s[56]=o.onclick;s[57]=o.ondrag;s[58]=o.ondrop;s[59]=o.onhide;s[60]=o.onrefresh;s[61]=o.onshow;s[62]=o.onupdate;s[63]=o.overlayMode;s[64]=o.posicaoAtual;s[65]=o.renderFlag;s[66]=o.scsAlignValorGrid;s[67]=o.scsCampoLayout;s[68]=o.scsCampoObrigatorio;s[69]=o.scsCamposControle;s[70]=o.scsCamposPersistenecia;s[71]=o.scsCaption;s[72]=o.scsCasasDecimaisGrid;s[73]=o.scsChoiceColumn;s[74]=o.scsCols;s[75]=o.scsComboType;s[76]=o.scsContainerStyle;s[77]=o.scsControlStyle;s[78]=(o.scsCustomLayout?1:0);s[79]=o.scsDisabled;s[80]=o.scsDisplayColumns;s[81]=o.scsDisplayList;s[82]=o.scsDropDownHeight;s[83]=o.scsDropDownWidth;s[84]=o.scsEditable;s[85]=o.scsEnclosingClass;s[86]=o.scsEnclosingStyle;s[87]=o.scsFinalAdicionaGenerico;s[88]=o.scsFinalAtualizaGenerico;s[89]=o.scsFinalExcluiGenerico;s[90]=o.scsFinalLimpaGenerico;s[91]=o.scsHeightTabelaGrid;s[92]=o.scsHidden;s[93]=o.scsHintClass;s[94]=o.scsHintStyle;s[95]=o.scsId;s[96]=o.scsIdGrid;s[97]=o.scsIdGridInput;s[98]=o.scsInicioAdicionaGenerico;s[99]=o.scsInicioAtualizaGenerico;s[100]=o.scsInicioExcluiGenerico;s[101]=o.scsInicioLimpaGenerico;s[102]=o.scsLabel;s[103]=o.scsLabelClass;s[104]=o.scsLabelGrid;s[105]=o.scsLabelPosition;s[106]=o.scsLabelStyle;s[107]=o.scsLarguraColunasGrid;s[108]=o.scsMargemGrupoCampos;s[109]=o.scsMaxRows;s[110]=o.scsMaxlength;s[111]=o.scsMetodoEspecifico;s[112]=o.scsMultiColumn;s[113]=(o.scsOcultaBarraTitulo?1:0);s[114]=(o.scsOcultaBotaoAdicionar?1:0);s[115]=(o.scsOcultaBotaoExcluir?1:0);s[116]=(o.scsOcultaBotoesPadrao?1:0);s[117]=(o.scsOcultaCamposEdicao?1:0);s[118]=o.scsOnBlur;s[119]=o.scsOnChange;s[120]=o.scsOnClick;s[121]=o.scsOnFocus;s[122]=o.scsOnKeyDown;s[123]=o.scsOnKeyPress;s[124]=o.scsOnKeyUp;s[125]=o.scsPermiteRepeticao;s[126]=o.scsQtdCaracteresColunaGrid;s[127]=o.scsQtdLinhaColuna;s[128]=o.scsQueryClass;s[129]=o.scsQueryName;s[130]=o.scsReadOnly;s[131]=set.addObject(o.scsRepositorioObjetos,'scsRepositorioObjetos');s[132]=o.scsRetornoSubValue;s[133]=o.scsRows;s[134]=o.scsSearchKeyLen;s[135]=o.scsSize;s[136]=(o.scsSomenteVisualizacao?1:0);s[137]=o.scsSql;s[138]=o.scsSqlConvCodigoPropriedade;s[139]=o.scsSqlGrid;s[140]=o.scsSqlLookUp;s[141]=o.scsStrTemp;s[142]=o.scsTabIndex;s[143]=o.scsTextMoedaValorMaximo;s[144]=o.scsTextMoedaValorMinimo;s[145]=o.scsTipo;s[146]=o.scsTipoLayout;s[147]=o.scsTituloComponente;s[148]=(o.scsTodosSomenteLeitura?1:0);s[149]=(o.scsUtilizaValidacao?1:0);s[150]=o.scsValue;s[151]=o.scsValueList;s[152]=o.scsWidth;s[153]=o.scsWidthComponente;s[154]=o.scsWidthTabelaGrid;s[155]=(o.showLabel?1:0);s[156]=o.slice;s[157]=o.strCampo1;s[158]=o.strCampo10;s[159]=o.strCampo11;s[160]=o.strCampo12;s[161]=o.strCampo13;s[162]=o.strCampo14;s[163]=o.strCampo15;s[164]=o.strCampo16;s[165]=o.strCampo17;s[166]=o.strCampo18;s[167]=o.strCampo2;s[168]=o.strCampo3;s[169]=o.strCampo4;s[170]=o.strCampo5;s[171]=o.strCampo6;s[172]=o.strCampo7;s[173]=o.strCampo8;s[174]=o.strCampo9;s[175]=o.strCampoAux;s[176]=o.title;s[177]=o.totalPosicoes;s[178]=o.tuple;s[179]=o.valign;s[180]=(o.visible?1:0);s[181]=o.width;
}
function s00_componente2_interface_scsCompositeGenerico_getSettings(s)
{
	s['name'] = 'string';
	s['alturaCabecalho'] = 'string';
	s['ctrlCampos'] = 'string';
	s['ctrlDuplicado'] = 'string';
	s['ctrlEditaRegistro'] = 'string';
	s['ctrlStrCampoAux'] = 'string';
	s['delimitador'] = 'string';
	s['delimitadorMV'] = 'string';
	s['delimitadorSV'] = 'string';
	s['idDinamicoBarraDeTitulo'] = 'string';
	s['idDinamicoBotoesPadrao'] = 'string';
	s['idDinamicoBtAcao'] = 'string';
	s['idDinamicoBtNovo'] = 'string';
	s['idDinamicoGridCampos'] = 'string';
	s['idDinamicoGridConteudo'] = 'string';
	s['idDinamicoGrupoLabelTitulo'] = 'string';
	s['idDinamicoHtml'] = 'string';
	s['idDinamicoLabelTitulo'] = 'string';
	s['larguraRolagem'] = 'string';
	s['offsetWidth'] = 'string';
	s['posicaoAtual'] = 'string';
	s['scsAlignValorGrid'] = 'string';
	s['scsCampoLayout'] = 'string';
	s['scsCampoObrigatorio'] = 'string';
	s['scsCamposControle'] = 'string';
	s['scsCamposPersistenecia'] = 'string';
	s['scsCaption'] = 'string';
	s['scsCasasDecimaisGrid'] = 'string';
	s['scsChoiceColumn'] = 'string';
	s['scsCols'] = 'string';
	s['scsComboType'] = 'string';
	s['scsContainerStyle'] = 'string';
	s['scsControlStyle'] = 'string';
	s['scsCustomLayout'] = 'boolean';
	s['scsDisabled'] = 'string';
	s['scsDisplayColumns'] = 'string';
	s['scsDisplayList'] = 'string';
	s['scsDropDownHeight'] = 'string';
	s['scsDropDownWidth'] = 'string';
	s['scsEditable'] = 'string';
	s['scsEnclosingClass'] = 'string';
	s['scsEnclosingStyle'] = 'string';
	s['scsFinalAdicionaGenerico'] = 'string';
	s['scsFinalAtualizaGenerico'] = 'string';
	s['scsFinalExcluiGenerico'] = 'string';
	s['scsFinalLimpaGenerico'] = 'string';
	s['scsHeightTabelaGrid'] = 'string';
	s['scsHidden'] = 'string';
	s['scsHintClass'] = 'string';
	s['scsHintStyle'] = 'string';
	s['scsId'] = 'string';
	s['scsIdGrid'] = 'string';
	s['scsIdGridInput'] = 'string';
	s['scsInicioAdicionaGenerico'] = 'string';
	s['scsInicioAtualizaGenerico'] = 'string';
	s['scsInicioExcluiGenerico'] = 'string';
	s['scsInicioLimpaGenerico'] = 'string';
	s['scsLabel'] = 'string';
	s['scsLabelClass'] = 'string';
	s['scsLabelGrid'] = 'string';
	s['scsLabelPosition'] = 'string';
	s['scsLabelStyle'] = 'string';
	s['scsLarguraColunasGrid'] = 'string';
	s['scsMargemGrupoCampos'] = 'string';
	s['scsMaxRows'] = 'string';
	s['scsMaxlength'] = 'string';
	s['scsMetodoEspecifico'] = 'string';
	s['scsMultiColumn'] = 'string';
	s['scsOcultaBarraTitulo'] = 'boolean';
	s['scsOcultaBotaoAdicionar'] = 'boolean';
	s['scsOcultaBotaoExcluir'] = 'boolean';
	s['scsOcultaBotoesPadrao'] = 'boolean';
	s['scsOcultaCamposEdicao'] = 'boolean';
	s['scsOnBlur'] = 'string';
	s['scsOnChange'] = 'string';
	s['scsOnClick'] = 'string';
	s['scsOnFocus'] = 'string';
	s['scsOnKeyDown'] = 'string';
	s['scsOnKeyPress'] = 'string';
	s['scsOnKeyUp'] = 'string';
	s['scsPermiteRepeticao'] = 'string';
	s['scsQtdCaracteresColunaGrid'] = 'string';
	s['scsQtdLinhaColuna'] = 'string';
	s['scsQueryClass'] = 'string';
	s['scsQueryName'] = 'string';
	s['scsReadOnly'] = 'string';
	s['scsRepositorioObjetos'] = 'string';
	s['scsRetornoSubValue'] = 'string';
	s['scsRows'] = 'string';
	s['scsSearchKeyLen'] = 'string';
	s['scsSize'] = 'string';
	s['scsSomenteVisualizacao'] = 'boolean';
	s['scsSql'] = 'string';
	s['scsSqlConvCodigoPropriedade'] = 'string';
	s['scsSqlGrid'] = 'string';
	s['scsSqlLookUp'] = 'string';
	s['scsStrTemp'] = 'string';
	s['scsTabIndex'] = 'string';
	s['scsTextMoedaValorMaximo'] = 'string';
	s['scsTextMoedaValorMinimo'] = 'string';
	s['scsTipo'] = 'string';
	s['scsTipoLayout'] = 'integer';
	s['scsTituloComponente'] = 'string';
	s['scsTodosSomenteLeitura'] = 'boolean';
	s['scsUtilizaValidacao'] = 'boolean';
	s['scsValue'] = 'string';
	s['scsValueList'] = 'string';
	s['scsWidth'] = 'string';
	s['scsWidthComponente'] = 'string';
	s['scsWidthTabelaGrid'] = 'string';
	s['strCampo1'] = 'string';
	s['strCampo10'] = 'string';
	s['strCampo11'] = 'string';
	s['strCampo12'] = 'string';
	s['strCampo13'] = 'string';
	s['strCampo14'] = 'string';
	s['strCampo15'] = 'string';
	s['strCampo16'] = 'string';
	s['strCampo17'] = 'string';
	s['strCampo18'] = 'string';
	s['strCampo2'] = 'string';
	s['strCampo3'] = 'string';
	s['strCampo4'] = 'string';
	s['strCampo5'] = 'string';
	s['strCampo6'] = 'string';
	s['strCampo7'] = 'string';
	s['strCampo8'] = 'string';
	s['strCampo9'] = 'string';
	s['strCampoAux'] = 'string';
	s['totalPosicoes'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_alterarCorLinha = function(posLinha) {
var componente = zenPage.getComponent(this.index)
var qtdLinha = componente.totalPosicoes
var linha = 1
var zebra = "#ffffff"
while(linha<=qtdLinha)
{
if ((linha%2) == 0){ zebra = "#e8f6e7" } else{ zebra = "#ffffff"}
var aux = componente.id + "linhagrid" + linha
var obj = document.getElementById(aux)
if (linha == posLinha)
{
obj.style.background = '#fbe091'
}
else
{
obj.style.background = zebra
}
linha = linha + 1
}
}

self.s00_componente2_interface_scsCompositeGenerico_atualizaBotoesPadraoCliente = function() {
if ((this.scsSomenteVisualizacao) || (this.scsOcultaBotoesPadrao)) { return 1; }
this.getChildById(this.idDinamicoBtNovo).setProperty("hidden",true);
var btAcao = this.getChildById(this.idDinamicoBtAcao);
btAcao.setProperty("title","Adicionar");
btAcao.setProperty("onclick","zenPage.verificarAlteracaoCampo(); zenThis.composite.AdicionaGenerico(0);");
btAcao.setProperty("enclosingClass","botao_i_add");
if((this.scsOcultaBotaoAdicionar) && (btAcao.title = "Adicionar")){
btAcao.setProperty("hidden",true);
}else{
btAcao.setProperty("hidden",false);
}
if (this.scsTodosSomenteLeitura) {
this.getChildById("btNovo").setProperty("hidden",true);
this.getChildById("btAcao").setProperty("hidden",true);
}
return 1;
}

self.s00_componente2_interface_scsCompositeGenerico_atualizaGridHtmlCliente = function() {
var conteudoTabelaHtml = ""
this.totalPosicoes = this.strCampo1.split(this.delimitadorMV).length;
if (this.scsTipoLayout == 1){
}else if (this.scsTipoLayout == 2){
}
conteudoTabelaHtml = "<table class='tpTable' cellpadding='0' border='0' cellspacing='0'><thead class='tpHead'>";
var scsIdGridList = this.scsIdGrid.split(this.delimitador);
var qtdColunasGrid = scsIdGridList.length;
var scsIdList = this.scsId.split(this.delimitador);
var qtdCampos = scsIdList.length;
var larguraList = this.scsLarguraColunasGrid.split(this.delimitador);
var labelList = this.scsLabelGrid.split(this.delimitador);
var strCabecalho = "";
for (numeroColuna=1;numeroColuna<=(qtdColunasGrid+1);numeroColuna++){
var campoColuna = scsIdGridList[(numeroColuna-1)];
for(numeroCampo=1;numeroCampo<=qtdCampos;numeroCampo++){
if (campoColuna == scsIdList[(numeroCampo-1)]){
var larguraColuna = larguraList[(numeroCampo-1)];
if (numeroColuna == 1){
var aux = "&#160;"
}else{
var aux = "";
}
strCabecalho += "<th width='"+larguraColuna+"'>"+ aux + labelList[(numeroCampo-1)] +"</th>";
}
}
}
if ((this.scsSomenteVisualizacao ) || (this.scsOcultaBotaoExcluir)) {
}else{
strCabecalho = strCabecalho + "<th style='width:30px;'><img title='Excluir Todos' src='img/icons/action_delete_all.png' onclick='javascript:zenPage.getComponent("+this.index+").LimpaComponente();' style='cursor:pointer'/></th>" //<th style='width:"+ complemento+ ";'>&#160;</th>";
}
strCabecalho = "<tr>" + strCabecalho + "</tr>" + "</thead></table>";
conteudoTabelaHtml = conteudoTabelaHtml + strCabecalho;
var tabelaDados = "<div class='tpBodyFixed' style='height:"+this.scsHeightTabelaGrid+"; overflow-y: scroll;'>"+
"<div><table class='tpTable' cellpadding='0' cellspacing='0' border='0'>";
var finalTabelaDados = "</table></div></div><div class='tpAuxColumn'> </div>";
conteudoTabelaHtml = conteudoTabelaHtml	+ tabelaDados + finalTabelaDados;
this.onDisplayHandler();
return conteudoTabelaHtml;
}

self.s00_componente2_interface_scsCompositeGenerico_atualizaPropriedadeCliente = function(pPropriedade,pNaoUtilizado,valor,operacao) {
var retorno = "";
var componente = zenPage.getComponent(this.index)
if (operacao == "get"){
var retorno = componente.getProperty(pPropriedade);
var delimitador = componente.delimitadorMV;
var retorno = retorno.toString().replace(/delimitador/g,String.fromCharCode(253));
}else if(operacao == "set"){
componente.setProperty(pPropriedade,valor);
}
return retorno;
}

self.s00_componente2_interface_scsCompositeGenerico_consultarGenerico = function() {
/* Método responsável por carregar itens na página ao realizar
* a execução do método consultar da classe padrão.
*/
var componente = zenPage.getComponent(this.index);
var prefixo = "formularioCadastro.";
var camposPersistencia = (componente.scsCamposPersistenecia).split(componente.delimitador);
var i = 0
var strTempAux = "strCampo"
for(i; i<= camposPersistencia.length-1; i++){
var campo = prefixo+camposPersistencia[i];
var propriedade = strTempAux+(i+1);
var valor = zenPage.getComponentById(campo).getValue()	;
var valorCampo = componente.atualizaPropriedadeCliente(propriedade, campo, valor, "set");
}
this.getChildById(componente.idDinamicoHtml).setProperty("content",this.AtualizaGridHtml());
return;
}

self.s00_componente2_interface_scsCompositeGenerico_limpaCamposCliente = function() {
if((this.scsSomenteVisualizacao) || (this.scsOcultaCamposEdicao)) { return 1;}
var scsIdList = this.scsId.split(this.delimitador);
var qtdCampos = scsIdList.length;
for (i=0;i<qtdCampos;i++){
var campoInterface = scsIdList[i];
this.getChildById(campoInterface).setProperty("value","");
}
return 1;
}

self.s00_componente2_interface_scsCompositeGenerico_limpaComponenteCliente = function() {
zenPage.verificarAlteracaoCampo();
var scsIdList = this.scsId.split(this.delimitador);
var qtdCampos = scsIdList.length;
var strTempAux = "strCampo";
this.ctrlDuplicado = "";
for(i=1;i<=qtdCampos;i++){
this.setProperty(strTempAux+i,"");
}
this.totalPosicoes = 0;
var retorno = this.atualizaBotoesPadraoCliente();
var retorno = this.limpaCamposCliente();
this.getChildById(this.idDinamicoHtml).setProperty("content",this.atualizaGridHtmlCliente());
this.onDisplayHandler();
return 1
}

self.s00_componente2_interface_scsCompositeGenerico_onDisplayHandler = function() {
var enc = $(this.getEnclosingDiv()).find('.tablePaneAzulShift')[0];
enc.style.width = '';
if(enc.style.width != '') return 1
var tpHead = $(enc).find('.tpTable')[0];
var tpBody = $(enc).find('.tpBodyFixed')[0];
var tpAux = $(enc).find('.tpAuxColumn')[0]
var clientW = tpBody.clientWidth;
var larguraRolagem = tpBody.offsetWidth - clientW;
var alturaCabecalho = $(enc).find('thead')[0].offsetHeight;
if(larguraRolagem > 0) {
tpBody.style.marginRight = larguraRolagem*(-1) + 'px';
enc.style.marginRight = larguraRolagem + 'px';
tpAux.style.right = larguraRolagem*(-1) + 'px';
tpAux.style.width = larguraRolagem + 'px';
if(alturaCabecalho > 0) {
tpAux.style.height = alturaCabecalho + 'px';
}
}
if(clientW > 0) {
tpHead.style.width = enc.offsetWidth + 'px';
tpBody.children[0].style.width = enc.offsetWidth + 'px';
}
this.larguraRolagem  = larguraRolagem;
this.alturaCabecalho = alturaCabecalho;
this.offsetWidth = enc.offsetWidth;
return 1;
}

self.s00_componente2_interface_scsCompositeGenerico_recuperarGenerico = function() {
/* Método responsável por atribuir os valores das strings mv do componente aos
* respectivos campos do formulário. Este método deve ser executado através
* do método salvar sobrescrito na classe código do respectivo requisito.
*/
var componente = zenPage.getComponent(this.index);
var prefixo = "formularioCadastro.";
var camposPersistencia = (componente.scsCamposPersistenecia).split(componente.delimitador);
var alteraParaDelimitadorSV = (componente.scsRetornoSubValue).split(componente.delimitador);
var i = 0;
var strTempAux = "strCampo";
var sub = 0
for(i; i<= camposPersistencia.length-1; i++){
var campo = prefixo+camposPersistencia[i];
var str = strTempAux+(i+1);
var valorCampo = componente.atualizaPropriedadeCliente(str, campo, "", "get");
if(alteraParaDelimitadorSV[i] == 1){
var valorCampo = valorCampo.toString().replace(/componente.delimitadorMV/g, componente.delimitadorSV)
}
zenPage.getComponentById(campo).setValue(valorCampo);
zenPage.getComponentById(campo).onchangeHandler();
}
return
}

self.s00_componente2_interface_scsCompositeGenerico_AdicionaGenerico = function(acao) {
	return zenInstanceMethod(this,'AdicionaGenerico','L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_AtualizaBotoesPadrao = function(acao) {
	return zenInstanceMethod(this,'AtualizaBotoesPadrao','L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_AtualizaConteudo = function() {
	return zenInstanceMethod(this,'AtualizaConteudo','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_AtualizaGenerico = function() {
	return zenInstanceMethod(this,'AtualizaGenerico','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_AtualizaGenericoTabela = function(pValor,pLinha,pColuna) {
	return zenInstanceMethod(this,'AtualizaGenericoTabela','L,L,L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_AtualizaGridHtml = function() {
	return zenInstanceMethod(this,'AtualizaGridHtml','','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_AtualizaPropriedade = function(pPropriedade,pNaoUtilizado,valor,operacao) {
	return zenInstanceMethod(this,'AtualizaPropriedade','L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_AtualizaPropriedadeInput = function(pNomeObjInput,pPropriedade,pValor) {
	return zenInstanceMethod(this,'AtualizaPropriedadeInput','L,L,L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_BuscaDadoTabela = function(pCodigo,pNumeroCampo) {
	return zenInstanceMethod(this,'BuscaDadoTabela','L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_CamposReadOnly = function(pReadOnly) {
	return zenInstanceMethod(this,'CamposReadOnly','L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_ConsultarGenericoServidor = function() {
	return zenInstanceMethod(this,'ConsultarGenericoServidor','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_DesenhaConteudo = function() {
	return zenInstanceMethod(this,'DesenhaConteudo','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_DesenhaEspecifico = function(comp,posicao,objGridCampos,tipo) {
	return zenInstanceMethod(this,'DesenhaEspecifico','L,L,L,L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_DesenhaGeral = function(comp,posicao,objGridCampos,tipo) {
	return zenInstanceMethod(this,'DesenhaGeral','L,L,L,L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_DesenhaLayoutEspecifico = function(objGridCampos) {
	return zenInstanceMethod(this,'DesenhaLayoutEspecifico','L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_ExcluirGenerico = function(posicao) {
	zenInstanceMethod(this,'ExcluirGenerico','L','',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_LimpaCampos = function() {
	return zenInstanceMethod(this,'LimpaCampos','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_LocalizaPosicaoCampo = function(pCampo) {
	return zenInstanceMethod(this,'LocalizaPosicaoCampo','L','INTEGER',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_MetodoEspecifico = function(pParametrosMetodo) {
	return zenInstanceMethod(this,'MetodoEspecifico','L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_MontaGrid = function(grid,linha,coluna) {
	return zenInstanceMethod(this,'MontaGrid','L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_PreencheCampos = function(linha) {
	zenInstanceMethod(this,'PreencheCampos','L','',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_PreparaValoresGrid = function(arrayD3,tipoCampo,numeroCampo,numeroColuna) {
	return zenInstanceMethod(this,'PreparaValoresGrid','L,L,L,L','HANDLE',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_RecuperaSomenteValor = function(pPropriedade) {
	return zenInstanceMethod(this,'RecuperaSomenteValor','L','INTEGER',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_VerificaCamposVazio = function() {
	return zenInstanceMethod(this,'VerificaCamposVazio','','BOOLEAN',arguments);
}

self.s00_componente2_interface_scsCompositeGenerico_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente2_interface_scsCompositeGenerico__Loader = function() {
	zenLoadClass('s00_componente2_interface_Padrao');
	s00_componente2_interface_scsCompositeGenerico.prototype = zenCreate('s00_componente2_interface_Padrao',-1);
	var p = s00_componente2_interface_scsCompositeGenerico.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente2_interface_scsCompositeGenerico;
	p.superClass = ('undefined' == typeof s00_componente2_interface_Padrao) ? zenMaster.s00_componente2_interface_Padrao.prototype:s00_componente2_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente2.interface.scsCompositeGenerico';
	p._type = 'scsCompositeGenerico';
	p.serialize = s00_componente2_interface_scsCompositeGenerico_serialize;
	p.getSettings = s00_componente2_interface_scsCompositeGenerico_getSettings;
	p.AdicionaGenerico = s00_componente2_interface_scsCompositeGenerico_AdicionaGenerico;
	p.ApresentaExcecao = s00_componente2_interface_scsCompositeGenerico_ApresentaExcecao;
	p.AtualizaBotoesPadrao = s00_componente2_interface_scsCompositeGenerico_AtualizaBotoesPadrao;
	p.AtualizaConteudo = s00_componente2_interface_scsCompositeGenerico_AtualizaConteudo;
	p.AtualizaGenerico = s00_componente2_interface_scsCompositeGenerico_AtualizaGenerico;
	p.AtualizaGenericoTabela = s00_componente2_interface_scsCompositeGenerico_AtualizaGenericoTabela;
	p.AtualizaGridHtml = s00_componente2_interface_scsCompositeGenerico_AtualizaGridHtml;
	p.AtualizaPropriedade = s00_componente2_interface_scsCompositeGenerico_AtualizaPropriedade;
	p.AtualizaPropriedadeInput = s00_componente2_interface_scsCompositeGenerico_AtualizaPropriedadeInput;
	p.BuscaDadoTabela = s00_componente2_interface_scsCompositeGenerico_BuscaDadoTabela;
	p.CamposReadOnly = s00_componente2_interface_scsCompositeGenerico_CamposReadOnly;
	p.ConsultarGenericoServidor = s00_componente2_interface_scsCompositeGenerico_ConsultarGenericoServidor;
	p.DesenhaConteudo = s00_componente2_interface_scsCompositeGenerico_DesenhaConteudo;
	p.DesenhaEspecifico = s00_componente2_interface_scsCompositeGenerico_DesenhaEspecifico;
	p.DesenhaGeral = s00_componente2_interface_scsCompositeGenerico_DesenhaGeral;
	p.DesenhaLayoutEspecifico = s00_componente2_interface_scsCompositeGenerico_DesenhaLayoutEspecifico;
	p.ExcluirGenerico = s00_componente2_interface_scsCompositeGenerico_ExcluirGenerico;
	p.LimpaCampos = s00_componente2_interface_scsCompositeGenerico_LimpaCampos;
	p.LimpaComponente = s00_componente2_interface_scsCompositeGenerico_LimpaComponente;
	p.LocalizaPosicaoCampo = s00_componente2_interface_scsCompositeGenerico_LocalizaPosicaoCampo;
	p.MetodoEspecifico = s00_componente2_interface_scsCompositeGenerico_MetodoEspecifico;
	p.MontaGrid = s00_componente2_interface_scsCompositeGenerico_MontaGrid;
	p.PreencheCampos = s00_componente2_interface_scsCompositeGenerico_PreencheCampos;
	p.PreparaValoresGrid = s00_componente2_interface_scsCompositeGenerico_PreparaValoresGrid;
	p.ReallyRefreshContents = s00_componente2_interface_scsCompositeGenerico_ReallyRefreshContents;
	p.RecuperaSomenteValor = s00_componente2_interface_scsCompositeGenerico_RecuperaSomenteValor;
	p.VerificaCamposVazio = s00_componente2_interface_scsCompositeGenerico_VerificaCamposVazio;
	p.VerificaErro = s00_componente2_interface_scsCompositeGenerico_VerificaErro;
	p.alterarCorLinha = s00_componente2_interface_scsCompositeGenerico_alterarCorLinha;
	p.atualizaBotoesPadraoCliente = s00_componente2_interface_scsCompositeGenerico_atualizaBotoesPadraoCliente;
	p.atualizaGridHtmlCliente = s00_componente2_interface_scsCompositeGenerico_atualizaGridHtmlCliente;
	p.atualizaPropriedadeCliente = s00_componente2_interface_scsCompositeGenerico_atualizaPropriedadeCliente;
	p.consultarGenerico = s00_componente2_interface_scsCompositeGenerico_consultarGenerico;
	p.limpaCamposCliente = s00_componente2_interface_scsCompositeGenerico_limpaCamposCliente;
	p.limpaComponenteCliente = s00_componente2_interface_scsCompositeGenerico_limpaComponenteCliente;
	p.onDisplayHandler = s00_componente2_interface_scsCompositeGenerico_onDisplayHandler;
	p.recuperarGenerico = s00_componente2_interface_scsCompositeGenerico_recuperarGenerico;
}

self._zenClassIdx['scsCompositeMVMultiplaSelecao'] = 's00_componente2_interface_scsCompositeMVMultiplaSelecao';
self.s00_componente2_interface_scsCompositeMVMultiplaSelecao = function(index,id) {
	if (index>=0) {s00_componente2_interface_scsCompositeMVMultiplaSelecao__init(this,index,id);}
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao__init = function(o,index,id) {
	('undefined' == typeof s00_componente2_interface_Padrao__init) ?zenMaster.s00_componente2_interface_Padrao__init(o,index,id):s00_componente2_interface_Padrao__init(o,index,id);
	o.delimitador = '|';
	o.delimitadorMV = '';
	o.scsAjusteTabelaConteudo = '';
	o.scsAlturaGrid = '100px';
	o.scsApresentaCabecalhoGrid = true;
	o.scsCampoConsulta = 'Descricao';
	o.scsCamposPersistencia = '';
	o.scsClassePesquisa = '';
	o.scsItemId = 'Id';
	o.scsLabelGrid = 'Código|Descrição';
	o.scsLarguraColunasGrid = '15%|auto';
	o.scsLarguraComponente = '350';
	o.scsLinhaSelecionada = '0';
	o.scsMaximoItensConsulta = '100';
	o.scsMostraCampoTabelaConsulta = 'Id|Descricao';
	o.scsSelecionarTodos = true;
	o.scsStrComponente = '';
	o.scsTabelaConsulta = '';
	o.scsTituloComponente = 'Título Padrão';
	o.scsTituloJanelaConsulta = 'Título Busca Padrão';
	o.scsTotalPosicoes = '0';
	o.scsWhereClause = '';
}
function s00_componente2_interface_scsCompositeMVMultiplaSelecao_serialize(set,s)
{
	var o = this;s[0]='448677039';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=(o.childrenCreated?1:0);s[14]=o.containerStyle;s[15]=o.delimitador;s[16]=o.delimitadorMV;s[17]=(o.disabled?1:0);s[18]=(o.dragEnabled?1:0);s[19]=(o.dropEnabled?1:0);s[20]=(o.dynamic?1:0);s[21]=o.enclosingClass;s[22]=o.enclosingStyle;s[23]=o.error;s[24]=o.groupClass;s[25]=o.groupStyle;s[26]=o.height;s[27]=(o.hidden?1:0);s[28]=o.hint;s[29]=o.hintClass;s[30]=o.hintStyle;s[31]=o.label;s[32]=o.labelClass;s[33]=o.labelDisabledClass;s[34]=o.labelPosition;s[35]=o.labelStyle;s[36]=o.layout;s[37]=o.onafterdrag;s[38]=o.onbeforedrag;s[39]=o.onclick;s[40]=o.ondrag;s[41]=o.ondrop;s[42]=o.onhide;s[43]=o.onrefresh;s[44]=o.onshow;s[45]=o.onupdate;s[46]=o.overlayMode;s[47]=o.renderFlag;s[48]=o.scsAjusteTabelaConteudo;s[49]=o.scsAlturaGrid;s[50]=(o.scsApresentaCabecalhoGrid?1:0);s[51]=o.scsCampoConsulta;s[52]=o.scsCamposPersistencia;s[53]=o.scsClassePesquisa;s[54]=o.scsItemId;s[55]=o.scsLabelGrid;s[56]=o.scsLarguraColunasGrid;s[57]=o.scsLarguraComponente;s[58]=o.scsLinhaSelecionada;s[59]=o.scsMaximoItensConsulta;s[60]=o.scsMostraCampoTabelaConsulta;s[61]=(o.scsSelecionarTodos?1:0);s[62]=o.scsStrComponente;s[63]=o.scsTabelaConsulta;s[64]=o.scsTituloComponente;s[65]=o.scsTituloJanelaConsulta;s[66]=o.scsTotalPosicoes;s[67]=o.scsWhereClause;s[68]=(o.showLabel?1:0);s[69]=o.slice;s[70]=o.title;s[71]=o.tuple;s[72]=o.valign;s[73]=(o.visible?1:0);s[74]=o.width;
}
function s00_componente2_interface_scsCompositeMVMultiplaSelecao_getSettings(s)
{
	s['name'] = 'string';
	s['delimitador'] = 'string';
	s['delimitadorMV'] = 'string';
	s['scsAjusteTabelaConteudo'] = 'string';
	s['scsAlturaGrid'] = 'string';
	s['scsApresentaCabecalhoGrid'] = 'boolean';
	s['scsCampoConsulta'] = 'string';
	s['scsCamposPersistencia'] = 'string';
	s['scsClassePesquisa'] = 'string';
	s['scsItemId'] = 'string';
	s['scsLabelGrid'] = 'string';
	s['scsLarguraColunasGrid'] = 'string';
	s['scsLarguraComponente'] = 'integer';
	s['scsLinhaSelecionada'] = 'string';
	s['scsMaximoItensConsulta'] = 'integer';
	s['scsMostraCampoTabelaConsulta'] = 'string';
	s['scsSelecionarTodos'] = 'boolean';
	s['scsStrComponente'] = 'string';
	s['scsTabelaConsulta'] = 'string';
	s['scsTituloComponente'] = 'string';
	s['scsTituloJanelaConsulta'] = 'string';
	s['scsTotalPosicoes'] = 'string';
	s['scsWhereClause'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_RecuperarMVMultiplaSelecao = function() {
var componente = zenPage.getComponent(this.index);
zenPage.getComponentById(componente.scsCamposPersistencia).setValue(componente.scsStrComponente);
zenPage.getComponentById(componente.scsCamposPersistencia).onchangeHandler();
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_alterarCorLinha = function(posLinha) {
this.scsLinhaSelecionada = posLinha;
var totalPosicoes = this.scsStrComponente.split(this.delimitadorMV).length;
this.scsTotalPosicoes = totalPosicoes;
var qtdLinha = this.scsTotalPosicoes;
var linha = 1;
var zebra = "#ffffff";
while(linha<=qtdLinha){
if ((linha%2) == 0){ zebra = "#e8f6e7" } else{ zebra = "#ffffff"}
var idLinha = this.index+"_linha"+linha;
var obj = document.getElementById(idLinha);
if (linha == posLinha){
obj.style.background = '#fbe091';
}
else{
obj.style.background = zebra;
}
linha++;
}
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_atualizarGridHtmlCliente = function() {
var strComponente = this.scsStrComponente.split(this.delimitadorMV);
this.scsTotalPosicoes = strComponente.length;
var conteudoHtml = this.criarHtmlCliente();
this.getChildById("gridMV").setProperty("content",conteudoHtml+'<div class="tpAuxColumn"> </div>');
this.resizeHeaders();
return true;
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_consultarMVMultiplaSelecao = function() {
var componente = zenPage.getComponent(this.index);
var dadoMv = zenPage.getComponentById(componente.scsCamposPersistencia).getValue();
componente.scsStrComponente = dadoMv;
componente.atualizarGridHtmlCliente();
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_criarHtmlCliente = function() {
var strGridHtml = "";
var mostraCampoTabelaConsulta = this.scsMostraCampoTabelaConsulta.split(this.delimitador);
var qtdColunas = mostraCampoTabelaConsulta.length;
var labelGrid = this.scsLabelGrid.split(this.delimitador);
var larguraColunasGrid = this.scsLarguraColunasGrid.split(this.delimitador);
var labelColuna = "";
var larguraColuna = "";
var strCabecalho = "";
var larguraTabela = this.width;
/*if (this.scsUtilizaOrdenacao){
larguraTabela = larguraTabela - 16;
}*/
if (this.scsApresentaCabecalhoGrid){
var strColunaExcluirTodos =
"<th style='width:30px;text-align:center;'>"+
"<img style='cursor:pointer;' onclick='zenPage.verificarAlteracaoCampo(); zenPage.getComponent("+this.index+").excluirTodosCliente();' alt='Excluir todos' src='img/icons/action_delete.png'/>"+
"</th>";
for (i=0;i<qtdColunas;i++){
labelColuna = labelGrid[i];
larguraColuna = larguraColunasGrid[i];
strCabecalho += "<th style='width:"+larguraColuna+";'>"+labelColuna + "</th>";
}
strCabecalho = "<table cellpadding='0' class='tpTable' cellspacing='0' border='0' ><thead class='tpHead'>"+
"<tr>"+ strCabecalho + strColunaExcluirTodos +"</tr>"+
"</thead></table>";
strGridHtml += strCabecalho;
}
larguraTabela = larguraTabela - this.scsAjusteTabelaConteudo;
strGridHtml += "<div id='tabela' class='tpBodyFixed' style='height:"+this.scsAlturaGrid+";'>";
strGridHtml += "<table id='"+this.index+"_tblMultiplaSelecao' class='tpTable' cellpadding='0' cellspacing='0' border='0'>";
if (this.scsStrComponente != ""){
var strComp = this.scsStrComponente.split(this.delimitadorMV);
var qtdMV = strComp.length;
var listaDescricao = this.scsRetornaValorPropriedade(this.scsTabelaConsulta,strComp,mostraCampoTabelaConsulta);
var conteudo = "";
for(linha=0;linha<qtdMV;linha++){
var linhaTemporaria = "";
if (((linha+1)%2) == 0){
var zebra = "tpOdd";
}else{
var zebra = "tpEven";
}
var idLinha = this.index+"_linha"+(linha+1);
for(coluna=0;coluna<qtdColunas;coluna++){
larguraColuna = larguraColunasGrid[coluna];
valorColunaTemp = listaDescricao[((qtdColunas*linha)+coluna)];
linhaTemporaria += "<td style='width:"+ larguraColuna +"'><div class='tpCellBlock'>"+ valorColunaTemp +"</div></td>";
if((coluna+1) == qtdColunas){
var colunaExcluir = "<td style='width:30px;text-align:center;' onclick='zenPage.verificarAlteracaoCampo(); zenPage.getComponent("+this.index+").excluirMVMultiplaSelecaoCliente("+(linha+1)+")'>"+
"<div class='tpCellBlock'><img style='cursor:pointer;' alt='Excluir' src='img/icons/action_delete.png'/></div></td>";
linhaTemporaria = "<tr class='"+zebra+"' id='"+idLinha+"' onclick='javascript:zenPage.getComponent("+this.index+").alterarCorLinha("+(linha+1)+");'>"+linhaTemporaria+colunaExcluir+"</tr>";
}
}
strGridHtml += linhaTemporaria;
}
}
strGridHtml += "</table>";
strGridHtml += "</div>";
return strGridHtml
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_excluirMVMultiplaSelecaoCliente = function(pPosicao,pColuna) {
var dados = this.scsStrComponente;
var arrayDados = dados.split(this.delimitadorMV);
var totalPosicoes = arrayDados.length;
arrayDados.splice((pPosicao-1),1);
this.scsStrComponente = arrayDados.join(this.delimitadorMV);
this.scsTotalPosicoes = this.scsTotalPosicoes - 1;
this.atualizarGridHtmlCliente();
return true;
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_excluirTodosCliente = function() {
this.scsStrComponente = "";
this.atualizarGridHtmlCliente();
return true;
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_limpaComponenteCliente = function() {
if (this.scsStrComponente != "" ){
this.scsStrComponente = "";
this.atualizarGridHtmlCliente();
}
return true;
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_onDisplayHandler = function() {
this.resizeHeaders();
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_onPopupAction = function(popupName,action,value) {
var vm = String.fromCharCode(253);
var parametros = popupName.split(vm);
var tipoBusca = parametros[0];
var campoTipo = parametros[1];
var compositeNome = parametros[2];
var componente = zenPage.getComponent(this.index);
var campoNome = componente.scsCamposPersistencia;
if (value == "") return;
zenPage.getComponentById(campoNome).setProperty("value",value);
var idComposite = compositeNome;
zenPage.getComponentById(idComposite).setProperty("scsStrComponente",value);
zenPage.getComponentById(idComposite).atualizarGridHtmlCliente();
zenPage.verificarAlteracaoCampo();
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_onloadHandler = function() {
this.resizeHeaders();
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_pesquisaInformacao = function() {
var vm = String.fromCharCode(253);
var componente = zenPage.getComponent(this.index);
var nomeJanela= "buscaMVs"+vm+"page"+vm+componente.id;
var classePesq = componente.scsClassePesquisa;
if (!classePesq){
classePesq = "s00.componente.interface.scsCompositeMVMultiplaSelecaoPes.cls";
}
var link = zenLink(classePesq+'?'+
'ItemId='+escape(componente.scsItemId)
+'&SelecTodos='+((componente.scsSelecionarTodos)?'1':'0')
+'&Tabela='+escape(componente.scsTabelaConsulta)
+'&Titulo='+escape(componente.scsTituloJanelaConsulta)
+'&Propriedade='+escape(componente.scsCampoConsulta)
+'&StrMV='+escape(this.scsStrComponente)
+'&MaxItens='+escape(this.scsMaximoItensConsulta)
+'&ClausulaSql='+escape(this.scsWhereClause));
zenPage.launchPopupWindow(
link,
nomeJanela,
'status,scrollbars,resizable,width=802,height=600',
"",
componente);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_resizeHeaders = function() {
var enc = $(this.getEnclosingDiv()).find('.tablePaneAzulShift')[0];
enc.style.width = '';
if(enc.style.width != '') return 1
var tpHead = $(enc).find('.tpTable')[0];
var tpBody = $(enc).find('.tpBodyFixed')[0];
var tpAux = $(enc).find('.tpAuxColumn')[0]
var clientW = tpBody.clientWidth;
var larguraRolagem = tpBody.offsetWidth - clientW;
var alturaCabecalho = 0;
if($(enc).find('thead')[0]) {
alturaCabecalho = $(enc).find('thead')[0].offsetHeight;
}
if(larguraRolagem > 0) {
tpBody.style.marginRight = larguraRolagem*(-1) + 'px';
enc.style.marginRight = larguraRolagem + 'px';
tpAux.style.right = larguraRolagem*(-1) + 'px';
tpAux.style.width = larguraRolagem + 'px';
if(alturaCabecalho > 0) {
tpAux.style.height = alturaCabecalho + 'px';
} else {
tpAux.style.display = 'none';
}
}
if(clientW > 0) {
tpHead.style.width = enc.offsetWidth + 'px';
tpBody.children[0].style.width = enc.offsetWidth + 'px';
}
return 1;
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_AtualizarGridHtml = function() {
	return zenInstanceMethod(this,'AtualizarGridHtml','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_AtualizarTotalPosicoes = function() {
	return zenInstanceMethod(this,'AtualizarTotalPosicoes','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_ConsultarMVMultiplaSelecaoServ = function() {
	return zenInstanceMethod(this,'ConsultarMVMultiplaSelecaoServ','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_ExcluirMVMultiplaSelecao = function(posicao) {
	return zenInstanceMethod(this,'ExcluirMVMultiplaSelecao','L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_ExcluirTodos = function() {
	return zenInstanceMethod(this,'ExcluirTodos','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_LimpaComponente = function() {
	return zenInstanceMethod(this,'LimpaComponente','','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_criarHtml = function() {
	return zenInstanceMethod(this,'criarHtml','','VARCHAR',arguments);
}

self.s00_componente2_interface_scsCompositeMVMultiplaSelecao_scsRetornaValorPropriedade = function(pTabela,pListaCodigo,pListaPropriedade) {
	return zenClassMethod(this,'scsRetornaValorPropriedade','L,LI,LI','LISTDT',arguments);
}
self.s00_componente2_interface_scsCompositeMVMultiplaSelecao__Loader = function() {
	zenLoadClass('s00_componente2_interface_Padrao');
	s00_componente2_interface_scsCompositeMVMultiplaSelecao.prototype = zenCreate('s00_componente2_interface_Padrao',-1);
	var p = s00_componente2_interface_scsCompositeMVMultiplaSelecao.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente2_interface_scsCompositeMVMultiplaSelecao;
	p.superClass = ('undefined' == typeof s00_componente2_interface_Padrao) ? zenMaster.s00_componente2_interface_Padrao.prototype:s00_componente2_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente2.interface.scsCompositeMVMultiplaSelecao';
	p._type = 'scsCompositeMVMultiplaSelecao';
	p.serialize = s00_componente2_interface_scsCompositeMVMultiplaSelecao_serialize;
	p.getSettings = s00_componente2_interface_scsCompositeMVMultiplaSelecao_getSettings;
	p.AjustaTamanhoValor = s00_componente2_interface_scsCompositeMVMultiplaSelecao_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente2_interface_scsCompositeMVMultiplaSelecao_ApresentaExcecao;
	p.AtualizarGridHtml = s00_componente2_interface_scsCompositeMVMultiplaSelecao_AtualizarGridHtml;
	p.AtualizarTotalPosicoes = s00_componente2_interface_scsCompositeMVMultiplaSelecao_AtualizarTotalPosicoes;
	p.ConsultarMVMultiplaSelecaoServ = s00_componente2_interface_scsCompositeMVMultiplaSelecao_ConsultarMVMultiplaSelecaoServ;
	p.ExcluirMVMultiplaSelecao = s00_componente2_interface_scsCompositeMVMultiplaSelecao_ExcluirMVMultiplaSelecao;
	p.ExcluirTodos = s00_componente2_interface_scsCompositeMVMultiplaSelecao_ExcluirTodos;
	p.GeraCheckBoxHtml = s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraRadioHtml;
	p.GeraSV1Label = s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraSV1Label;
	p.GeraSV1Text = s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraSV1Text;
	p.GeraSelectHtml = s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente2_interface_scsCompositeMVMultiplaSelecao_GeraTextHtml;
	p.GetValorPropriedade = s00_componente2_interface_scsCompositeMVMultiplaSelecao_GetValorPropriedade;
	p.LimpaComponente = s00_componente2_interface_scsCompositeMVMultiplaSelecao_LimpaComponente;
	p.ReallyRefreshContents = s00_componente2_interface_scsCompositeMVMultiplaSelecao_ReallyRefreshContents;
	p.RecuperarMVMultiplaSelecao = s00_componente2_interface_scsCompositeMVMultiplaSelecao_RecuperarMVMultiplaSelecao;
	p.RetornaValorCampo = s00_componente2_interface_scsCompositeMVMultiplaSelecao_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente2_interface_scsCompositeMVMultiplaSelecao_SetValorPropriedade;
	p.VerificaErro = s00_componente2_interface_scsCompositeMVMultiplaSelecao_VerificaErro;
	p.alterarCorLinha = s00_componente2_interface_scsCompositeMVMultiplaSelecao_alterarCorLinha;
	p.atualizarGridHtmlCliente = s00_componente2_interface_scsCompositeMVMultiplaSelecao_atualizarGridHtmlCliente;
	p.consultarMVMultiplaSelecao = s00_componente2_interface_scsCompositeMVMultiplaSelecao_consultarMVMultiplaSelecao;
	p.criarHtml = s00_componente2_interface_scsCompositeMVMultiplaSelecao_criarHtml;
	p.criarHtmlCliente = s00_componente2_interface_scsCompositeMVMultiplaSelecao_criarHtmlCliente;
	p.excluirMVMultiplaSelecaoCliente = s00_componente2_interface_scsCompositeMVMultiplaSelecao_excluirMVMultiplaSelecaoCliente;
	p.excluirTodosCliente = s00_componente2_interface_scsCompositeMVMultiplaSelecao_excluirTodosCliente;
	p.limpaComponenteCliente = s00_componente2_interface_scsCompositeMVMultiplaSelecao_limpaComponenteCliente;
	p.onDisplayHandler = s00_componente2_interface_scsCompositeMVMultiplaSelecao_onDisplayHandler;
	p.onPopupAction = s00_componente2_interface_scsCompositeMVMultiplaSelecao_onPopupAction;
	p.onloadHandler = s00_componente2_interface_scsCompositeMVMultiplaSelecao_onloadHandler;
	p.pesquisaInformacao = s00_componente2_interface_scsCompositeMVMultiplaSelecao_pesquisaInformacao;
	p.resizeHeaders = s00_componente2_interface_scsCompositeMVMultiplaSelecao_resizeHeaders;
	p.scsRetornaValorPropriedade = s00_componente2_interface_scsCompositeMVMultiplaSelecao_scsRetornaValorPropriedade;
}

self._zenClassIdx['scsCompositeUpload'] = 's00_componente2_interface_scsCompositeUpload';
self.s00_componente2_interface_scsCompositeUpload = function(index,id) {
	if (index>=0) {s00_componente2_interface_scsCompositeUpload__init(this,index,id);}
}

self.s00_componente2_interface_scsCompositeUpload__init = function(o,index,id) {
	('undefined' == typeof s00_componente2_interface_Padrao__init) ?zenMaster.s00_componente2_interface_Padrao__init(o,index,id):s00_componente2_interface_Padrao__init(o,index,id);
	o.LinkPaginaUpload = '';
	o.scsBackgroundColor = '#FFFFFF';
	o.scsCodigoItem = '';
	o.scsDisabled = false;
	o.scsHeight = '100%';
	o.scsIniticialExecute = false;
	o.scsReadOnly = false;
	o.scsTipo = '';
}
function s00_componente2_interface_scsCompositeUpload_serialize(set,s)
{
	var o = this;s[0]='123943894';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.LinkPaginaUpload;s[7]=o.align;s[8]=o.aux;s[9]=o.cellAlign;s[10]=o.cellSize;s[11]=o.cellStyle;s[12]=o.cellVAlign;s[13]=set.serializeList(o,o.children,true,'children');s[14]=(o.childrenCreated?1:0);s[15]=o.containerStyle;s[16]=(o.disabled?1:0);s[17]=(o.dragEnabled?1:0);s[18]=(o.dropEnabled?1:0);s[19]=(o.dynamic?1:0);s[20]=o.enclosingClass;s[21]=o.enclosingStyle;s[22]=o.error;s[23]=o.groupClass;s[24]=o.groupStyle;s[25]=o.height;s[26]=(o.hidden?1:0);s[27]=o.hint;s[28]=o.hintClass;s[29]=o.hintStyle;s[30]=o.label;s[31]=o.labelClass;s[32]=o.labelDisabledClass;s[33]=o.labelPosition;s[34]=o.labelStyle;s[35]=o.layout;s[36]=o.onafterdrag;s[37]=o.onbeforedrag;s[38]=o.onclick;s[39]=o.ondrag;s[40]=o.ondrop;s[41]=o.onhide;s[42]=o.onrefresh;s[43]=o.onshow;s[44]=o.onupdate;s[45]=o.overlayMode;s[46]=o.renderFlag;s[47]=o.scsBackgroundColor;s[48]=o.scsCodigoItem;s[49]=(o.scsDisabled?1:0);s[50]=o.scsHeight;s[51]=(o.scsIniticialExecute?1:0);s[52]=(o.scsReadOnly?1:0);s[53]=o.scsTipo;s[54]=(o.showLabel?1:0);s[55]=o.slice;s[56]=o.title;s[57]=o.tuple;s[58]=o.valign;s[59]=(o.visible?1:0);s[60]=o.width;
}
function s00_componente2_interface_scsCompositeUpload_getSettings(s)
{
	s['name'] = 'string';
	s['LinkPaginaUpload'] = 'string';
	s['scsBackgroundColor'] = 'color';
	s['scsCodigoItem'] = 'string';
	s['scsDisabled'] = 'boolean';
	s['scsHeight'] = 'string';
	s['scsIniticialExecute'] = 'boolean';
	s['scsReadOnly'] = 'boolean';
	s['scsTipo'] = 'enum:1,2,3,4,5,101,102,103,104';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente2_interface_scsCompositeUpload_atualizar = function() {
var objIframe = this.getChildById("ifrmUploadPagina");
var parametros =
"&scsTipo="+this.scsTipo+
"&scsCodigoItem="+this.scsCodigoItem+
"&scsDisabled="+(+this.scsDisabled)+
"&scsReadOnly="+(+this.scsReadOnly)+
"&scsBackgroundColor="+escape(this.scsBackgroundColor);
objIframe.setProperty("src",this.LinkPaginaUpload+parametros);
}

self.s00_componente2_interface_scsCompositeUpload_onDisplayHandler = function() {
if (this.scsIniticialExecute){
var objIframe = this.getChildById("ifrmUploadPagina");
var src = objIframe.getProperty("src");
if (src == ""){
this.atualizar();
}
}
}

self.s00_componente2_interface_scsCompositeUpload_salvar = function(pFuncaoRetorno,pComponente) {
var retorno = true;
var zsm = zenSynchronousMode;
zenSynchronousMode = 1;
try{
var objIframe = this.getChildById("ifrmUploadPagina");
var paginaUpload = objIframe.getPage();
if((paginaUpload != null)){ //essa verificação é feita, porque existem casos em que a página não é carregada, devido a cuidados com performance
paginaUpload.setProperty("scsCodigoItem",this.getProperty("scsCodigoItem"));
retorno = paginaUpload.salvar();
this.verificaSalvou(pComponente);
}
}catch (ex){
retorno = false;
zenPage.alertaShift(ex.description);
if (typeof(pFuncaoRetorno) == "function") pFuncaoRetorno();
}
zenSynchronousMode = zsm;
return retorno;
}

self.s00_componente2_interface_scsCompositeUpload_verificaSalvou = function(pComponente) {
var objIframe = this.getChildById("ifrmUploadPagina");
var iframeDoc = objIframe.getDocument();
if (iframeDoc.readyState  == 'complete'){
try{	pComponente.retornoSalvouArquivo(); }catch(ex){}
return;
}
var pthis = this;
setTimeout(function(){pthis.verificaSalvou(pComponente)}, 100);
}

self.s00_componente2_interface_scsCompositeUpload_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente2_interface_scsCompositeUpload__Loader = function() {
	zenLoadClass('s00_componente2_interface_Padrao');
	s00_componente2_interface_scsCompositeUpload.prototype = zenCreate('s00_componente2_interface_Padrao',-1);
	var p = s00_componente2_interface_scsCompositeUpload.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente2_interface_scsCompositeUpload;
	p.superClass = ('undefined' == typeof s00_componente2_interface_Padrao) ? zenMaster.s00_componente2_interface_Padrao.prototype:s00_componente2_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente2.interface.scsCompositeUpload';
	p._type = 'scsCompositeUpload';
	p.serialize = s00_componente2_interface_scsCompositeUpload_serialize;
	p.getSettings = s00_componente2_interface_scsCompositeUpload_getSettings;
	p.ReallyRefreshContents = s00_componente2_interface_scsCompositeUpload_ReallyRefreshContents;
	p.atualizar = s00_componente2_interface_scsCompositeUpload_atualizar;
	p.onDisplayHandler = s00_componente2_interface_scsCompositeUpload_onDisplayHandler;
	p.salvar = s00_componente2_interface_scsCompositeUpload_salvar;
	p.verificaSalvou = s00_componente2_interface_scsCompositeUpload_verificaSalvou;
}

self._zenClassIdx['scsImportarArquivo'] = 's00_componente2_interface_scsImportarArquivo';
self.s00_componente2_interface_scsImportarArquivo = function(index,id) {
	if (index>=0) {s00_componente2_interface_scsImportarArquivo__init(this,index,id);}
}

self.s00_componente2_interface_scsImportarArquivo__init = function(o,index,id) {
	('undefined' == typeof s00_componente2_interface_Padrao__init) ?zenMaster.s00_componente2_interface_Padrao__init(o,index,id):s00_componente2_interface_Padrao__init(o,index,id);
	o.MensagemErro = 'Erro na importação do arquivo:';
	o.MensagemOk = 'Arquivo importado com sucesso.';
	o.Mensagens = new Object();
	o.scsCustomTrap = false;
	o.scsIndexComponente = '';
	o.scsLeft = '';
	o.scsManterExtensaoArquivo = false;
	o.scsManterNomeArquivo = false;
	o.scsMostrarMensagemOK = true;
	o.scsSemAlerta = false;
	o.scsTamanhoArquivo = '';
	o.scsTipoArquivo = '';
	o.scsTop = '';
}
function s00_componente2_interface_scsImportarArquivo_serialize(set,s)
{
	var o = this;s[0]='3916965170';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.MensagemErro;s[7]=o.MensagemOk;s[8]=set.serializeArray(o,o.Mensagens,false,'Mensagens');s[9]=o.align;s[10]=o.aux;s[11]=o.cellAlign;s[12]=o.cellSize;s[13]=o.cellStyle;s[14]=o.cellVAlign;s[15]=set.serializeList(o,o.children,true,'children');s[16]=(o.childrenCreated?1:0);s[17]=o.containerStyle;s[18]=(o.disabled?1:0);s[19]=(o.dragEnabled?1:0);s[20]=(o.dropEnabled?1:0);s[21]=(o.dynamic?1:0);s[22]=o.enclosingClass;s[23]=o.enclosingStyle;s[24]=o.error;s[25]=o.groupClass;s[26]=o.groupStyle;s[27]=o.height;s[28]=(o.hidden?1:0);s[29]=o.hint;s[30]=o.hintClass;s[31]=o.hintStyle;s[32]=o.label;s[33]=o.labelClass;s[34]=o.labelDisabledClass;s[35]=o.labelPosition;s[36]=o.labelStyle;s[37]=o.layout;s[38]=o.onafterdrag;s[39]=o.onbeforedrag;s[40]=o.onclick;s[41]=o.ondrag;s[42]=o.ondrop;s[43]=o.onhide;s[44]=o.onrefresh;s[45]=o.onshow;s[46]=o.onupdate;s[47]=o.overlayMode;s[48]=o.renderFlag;s[49]=(o.scsCustomTrap?1:0);s[50]=o.scsIndexComponente;s[51]=o.scsLeft;s[52]=(o.scsManterExtensaoArquivo?1:0);s[53]=(o.scsManterNomeArquivo?1:0);s[54]=(o.scsMostrarMensagemOK?1:0);s[55]=(o.scsSemAlerta?1:0);s[56]=o.scsTamanhoArquivo;s[57]=o.scsTipoArquivo;s[58]=o.scsTop;s[59]=(o.showLabel?1:0);s[60]=o.slice;s[61]=o.title;s[62]=o.tuple;s[63]=o.valign;s[64]=(o.visible?1:0);s[65]=o.width;
}
function s00_componente2_interface_scsImportarArquivo_getSettings(s)
{
	s['name'] = 'string';
	s['MensagemErro'] = 'string';
	s['MensagemOk'] = 'string';
	s['Mensagens'] = 'string';
	s['scsCustomTrap'] = 'boolean';
	s['scsIndexComponente'] = 'string';
	s['scsLeft'] = 'integer';
	s['scsManterExtensaoArquivo'] = 'boolean';
	s['scsManterNomeArquivo'] = 'boolean';
	s['scsMostrarMensagemOK'] = 'boolean';
	s['scsSemAlerta'] = 'boolean';
	s['scsTamanhoArquivo'] = 'integer';
	s['scsTipoArquivo'] = 'string';
	s['scsTop'] = 'integer';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente2_interface_scsImportarArquivo_fecharModalArquivo = function(pEnderecoArquivo) {
this.setProperty("hidden", true);
if (pEnderecoArquivo != ""){
if(this.scsIndexComponente == ""){
if (zenPage.ImportarArquivo){
var retorno = zenPage.ImportarArquivo(pEnderecoArquivo);
if (!this.scsSemAlerta){
if (retorno != ""){
var mensagem = this.MensagemErro + "\n\n" + retorno
zenPage.alertaShift(mensagem)
} else if (this.scsMostrarMensagemOK) {
zenPage.alertaShift(this.MensagemOk)
}
}
}else{
zenPage.alertaShift(this.Mensagens["ErroMetodoImportarArquivo"]);
}
}else{
var componente = zenPage.getComponent(this.scsIndexComponente);
if (componente.ImportarArquivo){
var retorno = componente.ImportarArquivo(pEnderecoArquivo);
if (!this.scsSemAlerta){
if (retorno != ""){
var mensagem = this.MensagemErro + "\n\n" + retorno
zenPage.alertaShift(mensagem)
} else if (this.scsMostrarMensagemOK) {
zenPage.alertaShift(this.MensagemOk)
}
}
}else{
zenPage.alertaShift(this.Mensagens["ErroMetodoImportarArquivo"]);
}
}
}
return 1;
}

self.s00_componente2_interface_scsImportarArquivo_setProperty = function(property,value,value2) {
switch(property){
case 'hidden':
if(value){
var src = "s00.iu.interface.cadastro.UploadArquivo.cls?componenteId="+this.id+"&manterNomeArquivo="+(+this.scsManterNomeArquivo)+"&manterExtensaoArquivo="+(+this.scsManterExtensaoArquivo)+"&semAlerta="+(+this.scsSemAlerta)+"&tipoArquivo="+this.scsTipoArquivo+"&tamanhoMaximo="+(+this.scsTamanhoArquivo);
this.getChildById("iframe").setProperty("src",src)
}
this.getChildById("caixaDialogo").setHidden(value);
break;
default:
return this.invokeSuper('setProperty',arguments);
}
return true;
}

self.s00_componente2_interface_scsImportarArquivo_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}
self.s00_componente2_interface_scsImportarArquivo__Loader = function() {
	zenLoadClass('s00_componente2_interface_Padrao');
	s00_componente2_interface_scsImportarArquivo.prototype = zenCreate('s00_componente2_interface_Padrao',-1);
	var p = s00_componente2_interface_scsImportarArquivo.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente2_interface_scsImportarArquivo;
	p.superClass = ('undefined' == typeof s00_componente2_interface_Padrao) ? zenMaster.s00_componente2_interface_Padrao.prototype:s00_componente2_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente2.interface.scsImportarArquivo';
	p._type = 'scsImportarArquivo';
	p.serialize = s00_componente2_interface_scsImportarArquivo_serialize;
	p.getSettings = s00_componente2_interface_scsImportarArquivo_getSettings;
	p.ReallyRefreshContents = s00_componente2_interface_scsImportarArquivo_ReallyRefreshContents;
	p.fecharModalArquivo = s00_componente2_interface_scsImportarArquivo_fecharModalArquivo;
	p.setProperty = s00_componente2_interface_scsImportarArquivo_setProperty;
}

self._zenClassIdx['scsMultiplaSelecao'] = 's00_componente2_interface_scsMultiplaSelecao';
self.s00_componente2_interface_scsMultiplaSelecao = function(index,id) {
	if (index>=0) {s00_componente2_interface_scsMultiplaSelecao__init(this,index,id);}
}

self.s00_componente2_interface_scsMultiplaSelecao__init = function(o,index,id) {
	('undefined' == typeof s00_componente2_interface_Padrao__init) ?zenMaster.s00_componente2_interface_Padrao__init(o,index,id):s00_componente2_interface_Padrao__init(o,index,id);
	o.scsBTStyle = '';
	o.scsCampoDisplay = '';
	o.scsCustomTrap = false;
	o.scsDCChoice = '';
	o.scsDCDisplay = '';
	o.scsDCDropDownHeight = '';
	o.scsDCDropDownLeft = '';
	o.scsDCDropDownWidth = '';
	o.scsDCEditable = '';
	o.scsDCExibir = false;
	o.scsDCHeader = '';
	o.scsDCsqlLookup = '';
	o.scsFilterEnum = '';
	o.scsFilterEnumDisplay = '';
	o.scsHzScroll = false;
	o.scsLabel = '';
	o.scsLabelStyle = '';
	o.scsOnIniciarSelecao = '';
	o.scsOnTerminarSelecao = '';
	o.scsPermiteNenhumSelecionados = false;
	o.scsPopupWidth = '480px';
	o.scsRSDataCombo = ''; // encrypted
	o.scsRSTablePane = ''; // encrypted
	o.scsSelecaoUnica = false;
	o.scsSize = '';
	o.scsTPBodyHeight = '';
	o.scsTPColunaHidden = '';
	o.scsTPColunaId = '';
	o.scsTPColunaTamanho = '';
	o.scsTPColunaTitulo = '';
	o.scsTPFilter = '';
	o.scsTPFilterOp = '';
	o.scsTPLeft = '';
	o.scsTPOrderByClause = '';
	o.scsTPPageSize = '';
	o.scsTPTableName = '';
	o.scsTPTop = '';
	o.scsTextNenhumSelecionados = 'Nenhum item selecionado';
	o.scsTextTodos = 'Todos os itens selecionados';
	o.scsTextVarios = 'Vários itens selecionados';
	o.scsTodosSelecionados = '';
	o.scsTpColumnIdWidth = '5%';
	o.scsWidth = '';
	o.selecionados = '';
	o.selecionadosAntes = '';
	o.todosAntes = '0';
	o.todosSelecionados = '0';
	o.total = '0';
}
function s00_componente2_interface_scsMultiplaSelecao_serialize(set,s)
{
	var o = this;s[0]='2720722671';s[1]=o.index;s[2]=o.id;s[3]=o.name;s[4]=set.addObject(o.parent,'parent');s[5]=set.addObject(o.composite,'composite');s[6]=o.align;s[7]=o.aux;s[8]=o.cellAlign;s[9]=o.cellSize;s[10]=o.cellStyle;s[11]=o.cellVAlign;s[12]=set.serializeList(o,o.children,true,'children');s[13]=(o.childrenCreated?1:0);s[14]=o.containerStyle;s[15]=(o.disabled?1:0);s[16]=(o.dragEnabled?1:0);s[17]=(o.dropEnabled?1:0);s[18]=(o.dynamic?1:0);s[19]=o.enclosingClass;s[20]=o.enclosingStyle;s[21]=o.error;s[22]=o.groupClass;s[23]=o.groupStyle;s[24]=o.height;s[25]=(o.hidden?1:0);s[26]=o.hint;s[27]=o.hintClass;s[28]=o.hintStyle;s[29]=o.label;s[30]=o.labelClass;s[31]=o.labelDisabledClass;s[32]=o.labelPosition;s[33]=o.labelStyle;s[34]=o.layout;s[35]=o.onafterdrag;s[36]=o.onbeforedrag;s[37]=o.onclick;s[38]=o.ondrag;s[39]=o.ondrop;s[40]=o.onhide;s[41]=o.onrefresh;s[42]=o.onshow;s[43]=o.onupdate;s[44]=o.overlayMode;s[45]=o.renderFlag;s[46]=o.scsBTStyle;s[47]=o.scsCampoDisplay;s[48]=(o.scsCustomTrap?1:0);s[49]=o.scsDCChoice;s[50]=o.scsDCDisplay;s[51]=o.scsDCDropDownHeight;s[52]=o.scsDCDropDownLeft;s[53]=o.scsDCDropDownWidth;s[54]=o.scsDCEditable;s[55]=(o.scsDCExibir?1:0);s[56]=o.scsDCHeader;s[57]=o.scsDCsqlLookup;s[58]=o.scsFilterEnum;s[59]=o.scsFilterEnumDisplay;s[60]=(o.scsHzScroll?1:0);s[61]=o.scsLabel;s[62]=o.scsLabelStyle;s[63]=o.scsOnIniciarSelecao;s[64]=o.scsOnTerminarSelecao;s[65]=(o.scsPermiteNenhumSelecionados?1:0);s[66]=o.scsPopupWidth;s[67]=o.scsRSDataCombo;s[68]=o.scsRSTablePane;s[69]=(o.scsSelecaoUnica?1:0);s[70]=o.scsSize;s[71]=o.scsTPBodyHeight;s[72]=o.scsTPColunaHidden;s[73]=o.scsTPColunaId;s[74]=o.scsTPColunaTamanho;s[75]=o.scsTPColunaTitulo;s[76]=o.scsTPFilter;s[77]=o.scsTPFilterOp;s[78]=o.scsTPLeft;s[79]=o.scsTPOrderByClause;s[80]=o.scsTPPageSize;s[81]=o.scsTPTableName;s[82]=o.scsTPTop;s[83]=o.scsTextNenhumSelecionados;s[84]=o.scsTextTodos;s[85]=o.scsTextVarios;s[86]=o.scsTodosSelecionados;s[87]=o.scsTpColumnIdWidth;s[88]=o.scsWidth;s[89]=o.selecionados;s[90]=o.selecionadosAntes;s[91]=(o.showLabel?1:0);s[92]=o.slice;s[93]=o.title;s[94]=o.todosAntes;s[95]=o.todosSelecionados;s[96]=o.total;s[97]=o.tuple;s[98]=o.valign;s[99]=(o.visible?1:0);s[100]=o.width;
}
function s00_componente2_interface_scsMultiplaSelecao_getSettings(s)
{
	s['name'] = 'string';
	s['scsBTStyle'] = 'string';
	s['scsCampoDisplay'] = 'string';
	s['scsCustomTrap'] = 'boolean';
	s['scsDCChoice'] = 'string';
	s['scsDCDisplay'] = 'string';
	s['scsDCDropDownHeight'] = 'string';
	s['scsDCDropDownLeft'] = 'string';
	s['scsDCDropDownWidth'] = 'string';
	s['scsDCEditable'] = 'string';
	s['scsDCExibir'] = 'boolean';
	s['scsDCHeader'] = 'string';
	s['scsDCsqlLookup'] = 'string';
	s['scsFilterEnum'] = 'string';
	s['scsFilterEnumDisplay'] = 'string';
	s['scsHzScroll'] = 'boolean';
	s['scsLabel'] = 'string';
	s['scsLabelStyle'] = 'string';
	s['scsOnIniciarSelecao'] = 'eventHandler';
	s['scsOnTerminarSelecao'] = 'eventHandler';
	s['scsPermiteNenhumSelecionados'] = 'boolean';
	s['scsPopupWidth'] = 'string';
	s['scsSelecaoUnica'] = 'boolean';
	s['scsSize'] = 'integer';
	s['scsTPBodyHeight'] = 'string';
	s['scsTPColunaHidden'] = 'string';
	s['scsTPColunaId'] = 'string';
	s['scsTPColunaTamanho'] = 'string';
	s['scsTPColunaTitulo'] = 'string';
	s['scsTPFilter'] = 'string';
	s['scsTPFilterOp'] = 'string';
	s['scsTPLeft'] = 'integer';
	s['scsTPOrderByClause'] = 'string';
	s['scsTPPageSize'] = 'integer';
	s['scsTPTableName'] = 'string';
	s['scsTPTop'] = 'integer';
	s['scsTextNenhumSelecionados'] = 'string';
	s['scsTextTodos'] = 'string';
	s['scsTextVarios'] = 'string';
	s['scsTodosSelecionados'] = 'string';
	s['scsTpColumnIdWidth'] = 'string';
	s['scsWidth'] = 'string';
	s['selecionados'] = 'string';
	s['selecionadosAntes'] = 'string';
	s['todosAntes'] = 'string';
	s['todosSelecionados'] = 'string';
	s['total'] = 'string';
	this.invokeSuper('getSettings',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_abrirPopup = function(pIdPopup,pTop,pLeft,pWidth,pHeight) {
componente = zenThis.composite;
var estilo = ""
if((pTop != undefined) && (pTop != "")){
var estilo = estilo + "top:"+pTop+";";
}
if((pLeft != undefined) && (pLeft != "")){
var estilo = estilo + "left:"+pLeft+";";
}
if((pWidth != undefined) && (pWidth != "")){
var estilo = estilo + "width:"+pWidth+";";
}
if((pHeight != undefined) && (pHeight != "")){
var estilo = estilo + "height:"+pHeight+";";
}
if(estilo != ""){
componente.getChildById(pIdPopup).setProperty("enclosingStyle",estilo);
}
componente.getChildById("fundoPopup").setProperty("hidden",0);
componente.getChildById(pIdPopup).setHidden(0);
}

self.s00_componente2_interface_scsMultiplaSelecao_cancelarSelecao = function() {
componente = zenPage.getComponent(this.index);
componente.selecionados = componente.selecionadosAntes;
componente.todosSelecionados = componente.todosAntes;
componente.getChildById("fundoPopup").setProperty("hidden",1);
componente.getChildById("popupSelecao").setHidden(1);
return true;
}

self.s00_componente2_interface_scsMultiplaSelecao_chamarOnIniciarSelecao = function() {
zenInvokeCallbackMethod(this.scsOnIniciarSelecao, this, "scsOnIniciarSelecao");
}

self.s00_componente2_interface_scsMultiplaSelecao_chamarOnTerminarSelecao = function() {
zenInvokeCallbackMethod(this.scsOnTerminarSelecao, this, "scsOnTerminarSelecao");
}

self.s00_componente2_interface_scsMultiplaSelecao_getSelecionados = function() {
var comp = zenPage.getComponent(this.index);
if(!comp.scsPermiteNenhumSelecionados && (comp.todosSelecionados == 1 || comp.selecionados == "")){
return comp.scsTodosSelecionados;
}else if(comp.scsPermiteNenhumSelecionados){
if(comp.todosSelecionados == 1){
return comp.scsTodosSelecionados;
}else if(comp.selecionados == ""){
return "";
}
}
return comp.selecionados;
}

self.s00_componente2_interface_scsMultiplaSelecao_iniciarSelecao = function() {
var retorno = 1;
var zsm = zenSynchronousMode;
zenSynchronousMode = 1;
try{
componente = zenPage.getComponent(this.index);
componente.getChildById("tpSelecao").resetColumnFilters();
componente.getChildById("tpSelecao").executeQuery();
componente.total = componente.getChildById("tpSelecao").getProperty("rowCount");
componente.selecionadosAntes = componente.selecionados;
componente.todosAntes = componente.todosSelecionados;
var top = 80;
var left = 120;
var width = 690;
if (componente.scsTPLeft != ""){ left = componente.scsTPLeft; }
if (componente.scsTPTop  != ""){ top  = componente.scsTPTop;  }
if (componente.scsWidth  != ""){ width = componente.scsWidth;  }
componente.abrirPopup("popupSelecao", top, left, width);
componente.chamarOnIniciarSelecao();
}catch(e){
retorno = 0;
zenPage.alertaShift(e.description);
}
zenSynchronousMode = zsm;
return retorno;
}

self.s00_componente2_interface_scsMultiplaSelecao_limparComponente = function() {
var zsm = zenSynchronousMode;
zenSynchronousMode = true;
try{
var comp = zenPage.getComponent(this.index);
var tp = comp.getChildById("tpSelecao");
tp.resetColumnFilters();
tp.sortOrder = "";
tp.currColumn = "";
var msg = "";
if(!comp.scsPermiteNenhumSelecionados){
msg = comp.scsTextTodos;
comp.todosSelecionados = 1;
}else{
msg = comp.scsTextNenhumSelecionados;
comp.todosSelecionados = 0;
}
comp.selecionados = "";
comp.getChildById("dtcSelecao").getEnclosingDiv().getElementsByTagName("input")[1].value = msg;
comp.getChildById("cbPaginacao").setValue("500");
comp.chamarOnTerminarSelecao();
}catch(ex){
if (ex && ex.description) zenPage.alertaShift(ex.description);
}
zenSynchronousMode = zsm;
}

self.s00_componente2_interface_scsMultiplaSelecao_listFind = function(pLista,pValor) {
var qtd = pLista.length
for(cvalor=0;cvalor < qtd;cvalor++) {
if (pLista[cvalor] == pValor) {
return cvalor
}
}
return -1
}

self.s00_componente2_interface_scsMultiplaSelecao_selecionar = function(pIdCampoChave,pIdCampoDesc) {
var retorno = 1;
try{
var comp = zenPage.getComponent(this.index);
var pTablePaneId	= "tpSelecao";
var pIdCampoChave	= "Codigo";
var pIdCampoDesc	= comp.scsCampoDisplay == "" ? "Descricao" : comp.scsCampoDisplay;
var todosSel	= comp.todosSelecionados == 1;
var selecao		= comp.selecionados;
var txtFiltro	= comp.getChildById("dtcSelecao").getEnclosingDiv().getElementsByTagName("input")[1];
if(todosSel){
txtFiltro.value = comp.scsTextTodos;
}else if(selecao){
var selecao = selecao.split(",");
if((selecao.length == 1)&&(selecao[0] != "")){
if(this.scsDCsqlLookup != "") {
comp.getChildById("dtcSelecao").setValue(selecao[0]);
} else {
var encontrou = false;
var pagina = 1;
var tpProc = comp.getChildById(pTablePaneId);
var totalPaginas = tpProc.getPageCount();
while((!encontrou)&&(pagina <= totalPaginas)){
var i = 0;
var linha;
while(linha = tpProc.getRenderedRowData(i)){
if(linha[pIdCampoChave] == selecao[0]){
txtFiltro.value = linha[pIdCampoDesc];
encontrou = true;
break;
}
i++;
}
if(!encontrou){
pagina++;
tpProc.nextPage();
}
}
}
}else if((selecao.length == 0)||((selecao.length == 1)&&(selecao[0] == ""))){
if(!comp.scsPermiteNenhumSelecionados){
txtFiltro.value = comp.scsTextTodos;
}else{
txtFiltro.value = comp.scsTextNenhumSelecionados;
}
}else{
txtFiltro.value = comp.scsTextVarios;
}
}else{
if(!comp.scsPermiteNenhumSelecionados){
txtFiltro.value = comp.scsTextTodos;
}else{
txtFiltro.value = comp.scsTextNenhumSelecionados;
}
}
comp.getChildById("fundoPopup").setProperty("hidden",1);
comp.getChildById("popupSelecao").setHidden(1);
comp.chamarOnTerminarSelecao();
}catch(e){
retorno = 0;
zenPage.alertaShift(e.description);
}
return retorno;
}

self.s00_componente2_interface_scsMultiplaSelecao_selecionarDataCombo = function(pIdDataCombo) {
var input = zenPage.getComponentById(pIdDataCombo).getEnclosingDiv().getElementsByTagName("input")[1];
input.select();
}

self.s00_componente2_interface_scsMultiplaSelecao_selecionarLinha = function(pTablePaneId,pId,pComp,pAlteraTodos,pSelecionado) {
try{
var comp = zenPage.getComponent(this.index);
var selecionados  = comp.selecionados ? comp.selecionados.split(",") : new Array();
if (pComp.checked){
selecionados.push(pId)
}else{
var posicao = comp.listFind(selecionados,pId);
if (posicao > -1){
selecionados.splice(posicao,1);
}
}
if(pAlteraTodos){
var todosSel = pSelecionado
}else{
var todosSel = comp.verificarTodosSelecionados(pTablePaneId, 1);
}
if(!todosSel) {
var posicao = comp.listFind(selecionados, comp.scsTodosSelecionados);
if (posicao > -1){
selecionados.splice(posicao,1);
}
}
comp.selecionados = selecionados.join(",");
if(todosSel){
comp.todosSelecionados = 1;
}else{
comp.todosSelecionados = 0;
}
}catch (ex){
zenPage.alertaShift(ex.description);
}
return 1
}

self.s00_componente2_interface_scsMultiplaSelecao_selecionarTodos = function(pTablePaneId,selecionado) {
var total = 0;
try{
var componente = zenPage.getComponent(this.index);
var elementos = document.getElementsByName("ckMult"+pTablePaneId);
total = elementos.length;
for (var i=0;i<total;i++){
var comp = elementos[i];
if (selecionado){
if (!comp.checked){
comp.checked = 1
componente.selecionarLinha(pTablePaneId,comp.value,comp,1,selecionado);
}
}else{
if (comp.checked){
comp.checked = 0
componente.selecionarLinha(pTablePaneId,comp.value,comp,1,selecionado);
}
}
}
}catch (ex){
zenPage.alertaShift(ex.description);
}finally{
if(total == 0) return;
var chkSelTodos = "ckTodos"+pTablePaneId;
document.getElementById(chkSelTodos).checked = selecionado ? "checked" : "";
if(selecionado && total == componente.total){
componente.todosSelecionados = 1;
}else{
componente.todosSelecionados = 0;
}
if(!selecionado) componente.selecionados = "";
}
return 1;
}

self.s00_componente2_interface_scsMultiplaSelecao_setFocus = function() {
var input = this.getChildById("dtcSelecao").getEnclosingDiv().getElementsByTagName("input")[1];
input.select();
}

self.s00_componente2_interface_scsMultiplaSelecao_setSelecaoDataCombo = function(pValor,pUsaLookup) {
var retorno = "";
try{
var comp = zenPage.getComponent(this.index);
comp.selecionados		= pValor;
comp.todosSelecionados	= 0;
if(pValor == ""){
var txtFiltro	= comp.getChildById("dtcSelecao").getEnclosingDiv().getElementsByTagName("input")[1];
if(!comp.scsPermiteNenhumSelecionados){
txtFiltro.value	= comp.scsTextTodos;
comp.todosSelecionados	= 1;
}else{
txtFiltro.value	= comp.scsTextNenhumSelecionados;
}
}else{
if(comp.scsDCsqlLookup != ""){
comp.getChildById("dtcSelecao").setValue(pValor);
}
if(pValor == comp.scsTodosSelecionados){
comp.todosSelecionados	= 1;
}
}
comp.chamarOnTerminarSelecao();
}catch(e){
retorno = "";
zenPage.alertaShift(e.description);
}
return retorno;
}

self.s00_componente2_interface_scsMultiplaSelecao_setSelecaoUnica = function(pSelecaoUnica) {
var btSelecao = this.getChildById("btAbrirSelecao");
btSelecao.setHidden(pSelecaoUnica);
}

self.s00_componente2_interface_scsMultiplaSelecao_setSelecionados = function(pValor,pRefresh) {
var zsm = zenSynchronousMode;
zenSynchronousMode = true;
var comp = zenPage.getComponent(this.index);
comp.setSelecaoDataCombo(pValor);
if(pRefresh != false) {
var ret = comp.getChildById("tpSelecao").executeQuery();
}
comp.selecionar();
zenSynchronousMode = zsm;
return 1;
}

self.s00_componente2_interface_scsMultiplaSelecao_setarLarguraTablePane = function(pTablePaneId) {
try{
var comp = zenPage.getComponent(this.index);
var checked 	  = comp.todosSelecionados == 1 ? "checked" : "";
var chkSelTodos   = "ckTodos"+pTablePaneId;
var componente = "<input id='"+chkSelTodos+"' "+
"		 type='checkbox' "+
"		 value='0' "+
"		 onclick='zenPage.getComponent("+this.index+").selecionarTodos(\""+pTablePaneId+"\", this.checked)' "+
checked+
"/>";
var tpanediv = document.getElementById(pTablePaneId);
var tpanethFirst = $(tpanediv).find("thead").find("tr").find("th")[0]; // tpanediv.childNodes[0].childNodes[0].childNodes[0].childNodes[0];
if(tpanethFirst != undefined){
tpanethFirst.onclick = "";
tpanethFirst.style.cursor= "default";
tpanethFirst.innerHTML = "";
var compCheckbox = $(componente)[0]; // document.createElement(componente);
tpanethFirst.appendChild(compCheckbox);
}
}catch (ex){
zenPage.alertaShift(ex.description);
}
return 1;
}

self.s00_componente2_interface_scsMultiplaSelecao_verificarTodosSelecionados = function(pTablePaneId,pSelecionar) {
try{
var componente = zenPage.getComponent(this.index);
var elementos = document.getElementsByName("ckMult"+pTablePaneId);
var total = elementos.length;
var chkSelTodos = document.getElementById("ckTodos"+pTablePaneId);
for (i=0;i<total;i++){
comp = elementos[i];
if (!comp.checked){
if(pSelecionar){
chkSelTodos.checked = false;
}
return false;
}
}
if(componente.total != total){
chkSelTodos.checked = false;
return false;
}
}catch (ex){
zenPage.alertaShift(ex.description);
}
if(pSelecionar){
chkSelTodos.checked = true;
}
return true;
}

self.s00_componente2_interface_scsMultiplaSelecao_AjustaTamanhoValor = function(pValor,pTamanhoCorreto) {
	return zenClassMethod(this,'AjustaTamanhoValor','L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_ApresentaExcecao = function(pErro,pAcao) {
	return zenClassMethod(this,'ApresentaExcecao','O,L','STATUS',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_GeraCheckBoxHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraCheckBoxHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_GeraLabelHtml = function(pId,pTextoLabel,pClass,pStyle,pSize,pOnClick,pOnBlur,pOnFocus,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraLabelHtml','L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_GeraRadioHtml = function(pId,pChecked,pTexto,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pWidth,pColuna,pLinha,pAlign,pValue) {
	return zenClassMethod(this,'GeraRadioHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_GeraSV1Label = function(pId,pTextoLabel,pClass,pStyle,pSize,pColuna,pLinha,pAlign) {
	return zenClassMethod(this,'GeraSV1Label','L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_GeraSV1Text = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pLabel,pAlign) {
	return zenClassMethod(this,'GeraSV1Text','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_GeraSelectHtml = function(pId,pTabela,pColunaTabela,pSql,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pColuna,pLinha,pValue,pAlign,pListaValue,pListaDisplay,pSeparador) {
	return zenClassMethod(this,'GeraSelectHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_GeraTextAreaHtml = function(pId,pValue,pRows,pCols,pOnClick,pOnChange,pOnBlur,pOnFocus,pReadOnly,pStyle,pClass,pColuna,pLinha,pSubValue,pAtrSubValue,pOnKeyPress,pOnKeyUp,pOnKeyDown) {
	return zenClassMethod(this,'GeraTextAreaHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_GeraTextHtml = function(pId,pValue,pSize,pOnClick,pOnChange,pOnBlur,pOnFocus,pDisabled,pStyle,pClass,pReadOnly,pMaxlength,pColuna,pLinha,pSubValue,pAtrSubValue,pAlign) {
	return zenClassMethod(this,'GeraTextHtml','L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_GetValorPropriedade = function(pPropriedade) {
	return zenClassMethod(this,'GetValorPropriedade','L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_ReallyRefreshContents = function() {
	zenInstanceMethod(this,'ReallyRefreshContents','','',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_RetornaValorCampo = function(pObj,pCampo) {
	return zenClassMethod(this,'RetornaValorCampo','O,L','VARCHAR',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_SetValorPropriedade = function(pPropriedade,pValor) {
	return zenClassMethod(this,'SetValorPropriedade','L,L','STATUS',arguments);
}

self.s00_componente2_interface_scsMultiplaSelecao_VerificaErro = function(pMsg,pAcao) {
	return zenClassMethod(this,'VerificaErro','L,L','BOOLEAN',arguments);
}
self.s00_componente2_interface_scsMultiplaSelecao__Loader = function() {
	zenLoadClass('s00_componente2_interface_Padrao');
	s00_componente2_interface_scsMultiplaSelecao.prototype = zenCreate('s00_componente2_interface_Padrao',-1);
	var p = s00_componente2_interface_scsMultiplaSelecao.prototype;
	if (null==p) {return;}
	p.constructor = s00_componente2_interface_scsMultiplaSelecao;
	p.superClass = ('undefined' == typeof s00_componente2_interface_Padrao) ? zenMaster.s00_componente2_interface_Padrao.prototype:s00_componente2_interface_Padrao.prototype;
	p.__ZENcomponent = true;
	p._serverClass = 's00.componente2.interface.scsMultiplaSelecao';
	p._type = 'scsMultiplaSelecao';
	p.serialize = s00_componente2_interface_scsMultiplaSelecao_serialize;
	p.getSettings = s00_componente2_interface_scsMultiplaSelecao_getSettings;
	p.AjustaTamanhoValor = s00_componente2_interface_scsMultiplaSelecao_AjustaTamanhoValor;
	p.ApresentaExcecao = s00_componente2_interface_scsMultiplaSelecao_ApresentaExcecao;
	p.GeraCheckBoxHtml = s00_componente2_interface_scsMultiplaSelecao_GeraCheckBoxHtml;
	p.GeraLabelHtml = s00_componente2_interface_scsMultiplaSelecao_GeraLabelHtml;
	p.GeraRadioHtml = s00_componente2_interface_scsMultiplaSelecao_GeraRadioHtml;
	p.GeraSV1Label = s00_componente2_interface_scsMultiplaSelecao_GeraSV1Label;
	p.GeraSV1Text = s00_componente2_interface_scsMultiplaSelecao_GeraSV1Text;
	p.GeraSelectHtml = s00_componente2_interface_scsMultiplaSelecao_GeraSelectHtml;
	p.GeraTextAreaHtml = s00_componente2_interface_scsMultiplaSelecao_GeraTextAreaHtml;
	p.GeraTextHtml = s00_componente2_interface_scsMultiplaSelecao_GeraTextHtml;
	p.GetValorPropriedade = s00_componente2_interface_scsMultiplaSelecao_GetValorPropriedade;
	p.ReallyRefreshContents = s00_componente2_interface_scsMultiplaSelecao_ReallyRefreshContents;
	p.RetornaValorCampo = s00_componente2_interface_scsMultiplaSelecao_RetornaValorCampo;
	p.SetValorPropriedade = s00_componente2_interface_scsMultiplaSelecao_SetValorPropriedade;
	p.VerificaErro = s00_componente2_interface_scsMultiplaSelecao_VerificaErro;
	p.abrirPopup = s00_componente2_interface_scsMultiplaSelecao_abrirPopup;
	p.cancelarSelecao = s00_componente2_interface_scsMultiplaSelecao_cancelarSelecao;
	p.chamarOnIniciarSelecao = s00_componente2_interface_scsMultiplaSelecao_chamarOnIniciarSelecao;
	p.chamarOnTerminarSelecao = s00_componente2_interface_scsMultiplaSelecao_chamarOnTerminarSelecao;
	p.getSelecionados = s00_componente2_interface_scsMultiplaSelecao_getSelecionados;
	p.iniciarSelecao = s00_componente2_interface_scsMultiplaSelecao_iniciarSelecao;
	p.limparComponente = s00_componente2_interface_scsMultiplaSelecao_limparComponente;
	p.listFind = s00_componente2_interface_scsMultiplaSelecao_listFind;
	p.selecionar = s00_componente2_interface_scsMultiplaSelecao_selecionar;
	p.selecionarDataCombo = s00_componente2_interface_scsMultiplaSelecao_selecionarDataCombo;
	p.selecionarLinha = s00_componente2_interface_scsMultiplaSelecao_selecionarLinha;
	p.selecionarTodos = s00_componente2_interface_scsMultiplaSelecao_selecionarTodos;
	p.setFocus = s00_componente2_interface_scsMultiplaSelecao_setFocus;
	p.setSelecaoDataCombo = s00_componente2_interface_scsMultiplaSelecao_setSelecaoDataCombo;
	p.setSelecaoUnica = s00_componente2_interface_scsMultiplaSelecao_setSelecaoUnica;
	p.setSelecionados = s00_componente2_interface_scsMultiplaSelecao_setSelecionados;
	p.setarLarguraTablePane = s00_componente2_interface_scsMultiplaSelecao_setarLarguraTablePane;
	p.verificarTodosSelecionados = s00_componente2_interface_scsMultiplaSelecao_verificarTodosSelecionados;
}
/* EOF */